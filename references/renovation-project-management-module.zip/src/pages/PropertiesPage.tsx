import { useState } from "react";
import {
  ArrowRight,
  Building2,
  CalendarClock,
  CheckCircle2,
  DoorOpen,
  Hammer,
  KeyRound,
  MapPin,
  Search,
  ShieldAlert,
  Users,
  X,
} from "lucide-react";
import { useStore } from "../lib/store";
import { PageHeader } from "../components/Layout";
import { Badge, Button, Card, EmptyState, Input, ProgressBar, StatusBadge, ToneIcon } from "../components/ui";
import { dateLong, money, projectFinancials, projectProgress, TODAY } from "../lib/finance";
import type { Route } from "../components/Layout";
import { cn } from "../utils/cn";

export function PropertiesPage({ onNavigate }: { onNavigate: (route: Route) => void }) {
  const { properties, projects } = useStore();
  const [search, setSearch] = useState("");
  const [occupancy, setOccupancy] = useState<"All" | "Occupied" | "Vacant" | "Ready for rent" | "Renovating">("All");

  const filtered = properties.filter((property) => {
    const query = search.toLowerCase().trim();
    if (query && ![property.name, property.address, property.city].join(" ").toLowerCase().includes(query)) return false;
    if (occupancy === "Renovating") return projects.some((p) => p.propertyId === property.id && !["Completed", "Cancelled"].includes(p.status) && p.status !== "Draft");
    if (occupancy !== "All") return property.units.some((unit) => unit.occupancy === occupancy);
    return true;
  });

  const totalUnits = properties.reduce((sum, property) => sum + property.units.length, 0);
  const activeProjects = projects.filter((p) => !["Completed", "Cancelled"].includes(p.status) && !p.archived);
  const readyUnits = properties.flatMap((p) => p.units).filter((u) => u.occupancy === "Ready for rent").length;
  const annualRent = properties.reduce((sum, property) => sum + property.units.filter((u) => u.occupancy === "Occupied").reduce((s, u) => s + u.marketRentCents * 12, 0), 0);

  return (
    <>
      <PageHeader
        eyebrow={<>Portfolio <span className="text-mist-600">/</span> Rental records</>}
        title="Properties & units"
        description="Renovation projects attach to existing property and unit records. Occupancy history is preserved — availability changes only after readiness approval."
        actions={<Button variant="secondary" size="md" icon={Hammer} onClick={() => onNavigate({ name: "projects" })}>Back to projects</Button>}
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="flex items-center gap-3 p-4"><ToneIcon icon={Building2} tone="acid" size="lg" /><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Properties</p><p className="font-mono text-[22px] text-mist-100">{properties.length}</p><p className="text-[9.5px] text-mist-500">{totalUnits} rental units</p></div></Card>
        <Card className="flex items-center gap-3 p-4"><ToneIcon icon={Hammer} tone="sky" size="lg" /><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Units in renovation</p><p className="font-mono text-[22px] text-mist-100">{new Set(activeProjects.map((p) => p.unitId)).size}</p><p className="text-[9.5px] text-mist-500">{activeProjects.length} active projects</p></div></Card>
        <Card className="flex items-center gap-3 p-4"><ToneIcon icon={DoorOpen} tone="aqua" size="lg" /><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Ready for rent</p><p className="font-mono text-[22px] text-mist-100">{readyUnits}</p><p className="text-[9.5px] text-mist-500">Readiness confirmed units</p></div></Card>
        <Card className="flex items-center gap-3 p-4"><ToneIcon icon={Users} tone="violet" size="lg" /><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Occupied annual rent</p><p className="font-mono text-[19px] text-mist-100">{money(annualRent, { compact: true })}</p><p className="text-[9.5px] text-mist-500">Preserved tenant associations</p></div></Card>
      </div>

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="relative min-w-[200px] flex-1 sm:max-w-[320px]">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-mist-500" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search properties or address…" className="h-8 pl-8 text-[11px]" />
          {search && <button onClick={() => setSearch("")} aria-label="Clear search" className="absolute right-2 top-1/2 -translate-y-1/2 text-mist-500"><X className="h-3 w-3" /></button>}
        </div>
        <div className="flex items-center gap-0.5 rounded-lg border border-white/[0.07] p-0.5">
          {(["All", "Occupied", "Vacant", "Ready for rent", "Renovating"] as const).map((item) => (
            <button key={item} onClick={() => setOccupancy(item)} className={cn("rounded px-2 py-1 text-[10px] transition", occupancy === item ? "bg-white/[0.09] text-mist-100" : "text-mist-500 hover:text-mist-300")}>{item === "Ready for rent" ? "Ready" : item}</button>
          ))}
        </div>
        <span className="ml-auto text-[10px] text-mist-500">As of {dateLong(TODAY)}</span>
      </div>

      {filtered.length === 0 ? (
        <Card className="p-6"><EmptyState icon={Building2} title="No properties match" description="Adjust your search or occupancy filter." action={<Button size="sm" variant="secondary" onClick={() => { setSearch(""); setOccupancy("All"); }}>Clear filters</Button>} /></Card>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {filtered.map((property) => {
            const propertyProjects = projects.filter((p) => p.propertyId === property.id);
            const active = propertyProjects.filter((p) => !["Completed", "Cancelled"].includes(p.status));
            const occupied = property.units.filter((u) => u.occupancy === "Occupied").length;
            return (
              <Card key={property.id} className="overflow-hidden">
                <div className="relative h-28 overflow-hidden border-b border-white/[0.06]">
                  <img src={property.image} alt={property.name} className="h-full w-full object-cover opacity-45" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-r from-ink-900 via-ink-900/70 to-transparent" />
                  <div className="absolute inset-0 flex items-end justify-between p-3">
                    <div>
                      <p className="flex items-center gap-1.5 text-[13.5px] font-semibold text-mist-100"><Building2 className="h-3.5 w-3.5 text-acid-300" /> {property.name}</p>
                      <p className="flex items-center gap-1 text-[9.5px] text-mist-400"><MapPin className="h-2.5 w-2.5" /> {property.address}, {property.city}</p>
                      <p className="mt-0.5 flex items-center gap-1.5 text-[9px] text-mist-500">{property.propertyType} · Built {property.yearBuilt} · {property.units.length} units · {occupied} occupied</p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      {active.length > 0 ? <Badge tone="acid" dot>{active.length} active</Badge> : <Badge tone="slate">No active works</Badge>}
                      <span className="rounded border border-white/10 bg-ink-950/50 px-1.5 py-0.5 font-mono text-[8.5px] text-mist-400">{property.id}</span>
                    </div>
                  </div>
                </div>
                <div className="divide-y divide-white/[0.045]">
                  {property.units.map((unit) => {
                    const unitProject = propertyProjects.find((p) => p.unitId === unit.id && p.status !== "Cancelled");
                    const fin = unitProject ? projectFinancials(unitProject) : null;
                    return (
                      <div key={unit.id} className="flex flex-wrap items-center gap-2 px-3 py-2">
                        <span className="flex h-7 w-7 items-center justify-center rounded-lg border border-white/[0.07] bg-white/[0.03] text-mist-300"><DoorOpen className="h-3.5 w-3.5" /></span>
                        <div className="min-w-[110px] flex-1">
                          <p className="flex items-center gap-1.5 text-[11px] font-medium text-mist-200">Unit {unit.number}<Badge tone={unit.occupancy === "Ready for rent" ? "aqua" : unit.occupancy === "Vacant" ? "amber" : "slate"} dot>{unit.occupancy}</Badge></p>
                          <p className="text-[9px] text-mist-500">{unit.beds} bd / {unit.baths} ba · {unit.sqft} sqft · {money(unit.marketRentCents)}/mo{unit.tenantName ? ` · ${unit.tenantName}` : ""}</p>
                        </div>
                        {unitProject ? (
                          <button onClick={() => onNavigate({ name: "project", id: unitProject.id })} className="min-w-[150px] flex-1 text-left">
                            <p className="flex items-center gap-1 truncate text-[9.5px] text-mist-300"><Hammer className="h-2.5 w-2.5 text-acid-300/80" /> {unitProject.name}</p>
                            <div className="mt-0.5 flex items-center gap-1.5"><ProgressBar value={projectProgress(unitProject)} tone={unitProject.status === "On Hold" ? "amber" : "acid"} height="h-1" className="flex-1" /><span className="font-mono text-[8px] text-mist-500">{projectProgress(unitProject)}%</span></div>
                            <p className="mt-0.5 flex items-center justify-between text-[8.5px] text-mist-500"><span>{unitProject.status} · {dateLong(unitProject.expectedReadyDate)}</span><span>{fin ? money(fin.currentBudget, { compact: true }) : ""}</span></p>
                          </button>
                        ) : (
                          <div className="flex-1 text-right"><p className="text-[9px] text-mist-500">No renovation project</p>{unit.occupancy === "Ready for rent" && <p className="flex items-center justify-end gap-1 text-[8.5px] text-aqua-300"><CheckCircle2 className="h-2.5 w-2.5" /> Readiness confirmed</p>}</div>
                        )}
                        {unitProject && <ArrowRight className="h-3 w-3 shrink-0 text-mist-600" />}
                      </div>
                    );
                  })}
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.06] bg-white/[0.012] px-3 py-2 text-[9px] text-mist-500">
                  <span className="flex items-center gap-1"><ShieldAlert className="h-2.5 w-2.5" /> Availability controlled by readiness approval</span>
                  <span className="flex items-center gap-1"><KeyRound className="h-2.5 w-2.5" /> {propertyProjects.length} renovation records</span>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <div className="mt-3 rounded-2xl border border-white/[0.06] bg-white/[0.015] p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="flex items-center gap-1.5 text-[10px] text-mist-400"><CalendarClock className="h-3 w-3 text-acid-300/80" /> Active renovation portfolio by ready date</p>
          <span className="text-[9px] text-mist-500">Expected ready-for-rent dates are planning targets, not availability.</span>
        </div>
        <div className="mt-2 grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
          {activeProjects.sort((a, b) => a.expectedReadyDate.localeCompare(b.expectedReadyDate)).map((project) => (
            <button key={project.id} onClick={() => onNavigate({ name: "project", id: project.id })} className="flex items-center gap-2 rounded-lg border border-white/[0.05] bg-white/[0.02] px-2 py-1.5 text-left transition hover:border-acid-400/20">
              <span className="flex h-6 w-6 items-center justify-center rounded-md border border-white/[0.07] bg-white/[0.03] text-mist-400"><Hammer className="h-3 w-3" /></span>
              <span className="min-w-0 flex-1"><span className="block truncate text-[10px] text-mist-200">{project.propertyName} · {project.unitNumber}</span><span className="block text-[8.5px] text-mist-500">{project.name}</span></span>
              <span className="text-right"><StatusBadge status={project.status} dot={false} /><span className="mt-0.5 block font-mono text-[8px] text-mist-500">{dateLong(project.expectedReadyDate)}</span></span>
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
