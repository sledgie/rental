import { useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowUpRight,
  BarChart3,
  Building2,
  CheckCircle2,
  CircleDollarSign,
  Clock,
  Download,
  FileBarChart,
  HardHat,
  PieChart,
  ReceiptText,
  ShieldAlert,
  Timer,
  TrendingDown,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { useStore } from "../lib/store";
import { PageHeader } from "../components/Layout";
import { Badge, Button, Card, EmptyState, ProgressBar, SectionHeader, StatusBadge, ToneIcon } from "../components/ui";
import { dateLong, dateShort, daysBetween, invoiceBalance, invoiceTotal, money, paymentStatusFor, projectFinancials, TODAY } from "../lib/finance";
import { exportContractorSpendCsv, exportInvoiceCsv, exportReportSummary } from "../lib/export";
import { cn } from "../utils/cn";
import type { Route } from "../components/Layout";

export function ReportsPage({ onNavigate }: { onNavigate: (route: Route) => void }) {
  const { projects, contractors } = useStore();
  const [range] = useState("Q1 2026");
  const scoped = projects.filter((p) => p.status !== "Cancelled" && p.id !== "PRJ-1022");

  const totals = useMemo(() => {
    return scoped.reduce(
      (acc, project) => {
        const fin = projectFinancials(project);
        return {
          budget: acc.budget + fin.currentBudget,
          original: acc.original + fin.originalBudget,
          incurred: acc.incurred + fin.incurred,
          committed: acc.committed + fin.committed,
          invoiced: acc.invoiced + fin.invoiced,
          paid: acc.paid + fin.paid,
          outstanding: acc.outstanding + fin.outstanding,
          forecast: acc.forecast + fin.forecastFinal,
          variance: acc.variance + fin.variance,
        };
      },
      { budget: 0, original: 0, incurred: 0, committed: 0, invoiced: 0, paid: 0, outstanding: 0, forecast: 0, variance: 0 },
    );
  }, [scoped]);

  const contractorSpend = useMemo(
    () =>
      contractors
        .map((contractor) => {
          const relevant = scoped.filter((project) => project.team.some((m) => m.contractorId === contractor.id));
          const committed = relevant.reduce((sum, project) => sum + project.team.filter((m) => m.contractorId === contractor.id).reduce((s, m) => s + m.contractAmountCents, 0), 0);
          const invoiced = scoped.reduce((sum, project) => sum + project.invoices.filter((i) => i.vendorId === contractor.id).reduce((s, i) => s + invoiceTotal(i), 0), 0);
          const paid = scoped.reduce((sum, project) => sum + project.payments.filter((p) => p.payeeId === contractor.id).reduce((s, p) => s + p.amountCents, 0), 0);
          return { contractor, projects: relevant.length, committed, invoiced, paid };
        })
        .filter((entry) => entry.projects > 0 || entry.invoiced > 0)
        .sort((a, b) => b.invoiced + b.committed - (a.invoiced + a.committed)),
    [contractors, scoped],
  );

  const costMix = useMemo(() => {
    const map = new Map<string, number>();
    scoped.forEach((project) => {
      project.expenses.filter((e) => e.approval === "Approved").forEach((expense) => map.set(expense.category, (map.get(expense.category) ?? 0) + expense.totalCents));
      project.invoices.filter((i) => i.approval === "Approved").forEach((invoice) => map.set("Contractor invoices", (map.get("Contractor invoices") ?? 0) + invoiceTotal(invoice)));
    });
    const sorted = Array.from(map.entries()).map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
    return sorted.length ? sorted : [{ label: "No costs recorded", value: 1 }];
  }, [scoped]);
  const mixTotal = costMix.reduce((sum, item) => sum + item.value, 0);
  const mixColors = ["#c6f45b", "#5ee6d0", "#ffc861", "#a78bfa", "#7dd3fc", "#ff7d8a", "#7b8b9e", "#f59e0b"];

  const unpaid = scoped.flatMap((project) =>
    project.invoices
      .filter((invoice) => invoice.approval === "Approved" && invoiceBalance(invoice, project.payments) > 0)
      .map((invoice) => ({ project, invoice, balance: invoiceBalance(invoice, project.payments), status: paymentStatusFor(invoice, project.payments) })),
  ).sort((a, b) => a.invoice.dueDate.localeCompare(b.invoice.dueDate));

  const delayed = scoped.filter((project) => project.estimatedCompletion < TODAY && project.status !== "Completed");
  const openDeficiencies = projects.reduce((sum, project) => sum + project.deficiencies.filter((d) => d.status === "Open" || d.status === "In Progress").length, 0);
  const avgUtilisation = scoped.length ? Math.round(scoped.reduce((sum, p) => sum + projectFinancials(p).utilisation, 0) / scoped.length) : 0;

  return (
    <>
      <PageHeader
        eyebrow={<>Insights <span className="text-mist-600">/</span> {range}</>}
        title="Renovation reporting"
        description="Cost, commitment and delivery reporting across the portfolio. Every metric is derived from approved financial records and recorded payments."
        actions={
          <>
            <Button variant="secondary" size="md" icon={Download} onClick={() => exportReportSummary(scoped)}>Portfolio CSV</Button>
            <Button variant="secondary" size="md" icon={ReceiptText} onClick={() => exportInvoiceCsv(scoped)}>Invoices</Button>
            <Button variant="primary" size="md" icon={HardHat} onClick={() => exportContractorSpendCsv(scoped, contractors)}>Contractor spend</Button>
          </>
        }
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="relative overflow-hidden p-4">
          <div className="blueprint pointer-events-none absolute -right-4 -top-4 h-24 w-24 opacity-40" />
          <div className="flex items-start justify-between"><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Approved capital</p><p className="mt-1 font-mono text-[22px] text-mist-100">{money(totals.budget)}</p><p className="text-[9.5px] text-mist-500">Across {scoped.length} live projects · original {money(totals.original, { compact: true })}</p></div><ToneIcon icon={Wallet} tone="acid" /></div>
          <ProgressBar value={totals.budget ? (totals.incurred / totals.budget) * 100 : 0} className="mt-2" height="h-1" /><p className="mt-1 text-[9px] text-mist-500">{money(totals.incurred)} incurred · {avgUtilisation}% average utilisation</p>
        </Card>
        <Card className="p-4"><div className="flex items-start justify-between"><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Forecast final cost</p><p className="mt-1 font-mono text-[22px] text-mist-100">{money(totals.forecast)}</p><p className={cn("text-[9.5px]", totals.variance < 0 ? "text-rose-300" : "text-acid-300")}>{totals.variance >= 0 ? `${money(totals.variance)} under budget` : `${money(Math.abs(totals.variance))} over budget`}</p></div><ToneIcon icon={TrendingUp} tone={totals.variance < 0 ? "rose" : "aqua"} /></div><ProgressBar value={totals.budget ? (totals.forecast / totals.budget) * 100 : 0} tone={totals.variance < 0 ? "rose" : "aqua"} className="mt-2" height="h-1" /><p className="mt-1 text-[9px] text-mist-500">{money(totals.committed)} committed · forecast includes open commitments</p></Card>
        <Card className="p-4"><div className="flex items-start justify-between"><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Outstanding payables</p><p className="mt-1 font-mono text-[22px] text-mist-100">{money(totals.outstanding)}</p><p className="text-[9.5px] text-mist-500">{unpaid.length} unpaid invoices · {money(totals.paid)} paid</p></div><ToneIcon icon={ReceiptText} tone="amber" /></div><div className="mt-2 flex h-1.5 overflow-hidden rounded-full bg-white/[0.07]"><div className="bg-aqua-400/80" style={{ width: `${totals.invoiced ? (totals.paid / totals.invoiced) * 100 : 0}%` }} /><div className="bg-amber-400/80" style={{ width: `${totals.invoiced ? (totals.outstanding / totals.invoiced) * 100 : 0}%` }} /></div><p className="mt-1 text-[9px] text-mist-500">{money(totals.invoiced)} invoiced · payment status calculated separately</p></Card>
        <Card className="p-4"><div className="flex items-start justify-between"><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Delivery risk</p><p className="mt-1 font-mono text-[22px] text-mist-100">{delayed.length}<span className="text-[12px] text-mist-500"> delayed</span></p><p className="text-[9.5px] text-mist-500">{openDeficiencies} open deficiencies</p></div><ToneIcon icon={ShieldAlert} tone={delayed.length ? "amber" : "aqua"} /></div><div className="mt-2 flex flex-wrap gap-1.5"><Badge tone="rose" icon={AlertTriangle}>{openDeficiencies} deficiencies</Badge><Badge tone="amber" icon={Timer}>{delayed.length} past due</Badge></div></Card>
      </div>

      <div className="grid gap-3 xl:grid-cols-[1.5fr_1fr]">
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] px-4 py-3"><SectionHeader icon={BarChart3} title="Contractor spending" subtitle="Committed, invoiced and paid by contractor" /><Button size="xs" variant="ghost" icon={Download} onClick={() => exportContractorSpendCsv(scoped, contractors)}>Export</Button></div>
          <div className="space-y-2.5 p-4">
            {contractorSpend.slice(0, 6).map((entry) => {
              const max = Math.max(...contractorSpend.map((c) => c.committed + c.invoiced), 1);
              return (
                <div key={entry.contractor.id}>
                  <div className="mb-1 flex items-center justify-between gap-2">
                    <span className="flex min-w-0 items-center gap-1.5"><HardHat className="h-3 w-3 shrink-0 text-mist-500" /><span className="truncate text-[11px] text-mist-200">{entry.contractor.name}</span><span className="hidden text-[9px] text-mist-500 sm:inline">· {entry.contractor.trade.split("·")[0]}</span></span>
                    <span className="shrink-0 font-mono text-[10px] text-mist-300">{money(entry.invoiced)}<span className="text-mist-600"> invoiced</span></span>
                  </div>
                  <div className="flex h-2 overflow-hidden rounded-full bg-white/[0.055]">
                    <div className="bg-acid-400/85" style={{ width: `${Math.min(100, (entry.committed / max) * 100)}%` }} />
                    <div className="bg-aqua-400/60" style={{ width: `${Math.min(100, (entry.invoiced / max) * 100)}%` }} />
                  </div>
                  <div className="mt-0.5 flex justify-between text-[8.5px] text-mist-500"><span>{entry.projects} project{entry.projects === 1 ? "" : "s"}</span><span>{money(entry.committed, { compact: true })} committed · {money(entry.paid, { compact: true })} paid</span></div>
                </div>
              );
            })}
            {contractorSpend.length === 0 && <EmptyState compact icon={HardHat} title="No contractor spend yet" description="Assign contractors and record invoices to build this report." />}
          </div>
          <div className="flex items-center gap-3 border-t border-white/[0.06] bg-white/[0.012] px-4 py-2 text-[9px] text-mist-500"><span className="flex items-center gap-1"><span className="h-1.5 w-3 rounded-full bg-acid-400/85" /> Committed</span><span className="flex items-center gap-1"><span className="h-1.5 w-3 rounded-full bg-aqua-400/60" /> Invoiced</span></div>
        </Card>

        <Card className="overflow-hidden">
          <div className="border-b border-white/[0.06] px-4 py-3"><SectionHeader icon={PieChart} title="Incurred cost mix" subtitle="Approved expenses and invoices" /></div>
          <div className="flex flex-col items-center gap-3 p-4 sm:flex-row">
            <div className="relative h-32 w-32 shrink-0 rounded-full" style={{ background: `conic-gradient(${costMix.reduce<{ stops: string[]; acc: number }>((state, item, index) => { const start = (state.acc / mixTotal) * 100; state.acc += item.value; const end = (state.acc / mixTotal) * 100; state.stops.push(`${mixColors[index % mixColors.length]} ${start}% ${end}%`); return state; }, { stops: [], acc: 0 }).stops.join(", ")})` }}>
              <div className="absolute inset-[18px] flex flex-col items-center justify-center rounded-full border border-white/[0.06] bg-ink-850">
                <span className="font-mono text-[15px] text-mist-100">{money(mixTotal, { compact: true })}</span>
                <span className="text-[8px] uppercase tracking-wide text-mist-500">incurred</span>
              </div>
            </div>
            <div className="min-w-0 flex-1 space-y-1">
              {costMix.slice(0, 6).map((item, index) => (
                <div key={item.label} className="flex items-center gap-1.5 text-[9.5px]">
                  <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: mixColors[index % mixColors.length] }} />
                  <span className="min-w-0 flex-1 truncate text-mist-400">{item.label}</span>
                  <span className="font-mono text-mist-300">{Math.round((item.value / mixTotal) * 100)}%</span>
                </div>
              ))}
            </div>
          </div>
          <div className="border-t border-white/[0.06] px-4 py-2 text-[9px] text-mist-500">Invoices are counted once as incurred costs — expense records linked to an invoice are excluded.</div>
        </Card>
      </div>

      <div className="mt-3 grid gap-3 xl:grid-cols-[1.35fr_1fr]">
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] px-4 py-3"><SectionHeader icon={TrendingUp} title="Budget vs forecast" subtitle="Approved budget and forecast final cost by project" /><Button size="xs" variant="ghost" icon={Download} onClick={() => exportReportSummary(scoped)}>Export</Button></div>
          <div className="space-y-2.5 p-4">
            {scoped.filter((p) => p.status !== "Completed").map((project) => {
              const fin = projectFinancials(project);
              const max = Math.max(...scoped.map((p) => Math.max(projectFinancials(p).currentBudget, projectFinancials(p).forecastFinal)), 1);
              return (
                <button key={project.id} onClick={() => onNavigate({ name: "project", id: project.id })} className="block w-full text-left">
                  <div className="mb-1 flex items-center justify-between gap-2">
                    <span className="flex min-w-0 items-center gap-1.5"><span className="truncate text-[10.5px] text-mist-300">{project.propertyName} · {project.unitNumber}</span>{fin.overBudget && <Badge tone="rose">Over</Badge>}</span>
                    <span className="shrink-0 font-mono text-[9.5px] text-mist-400">{money(fin.currentBudget, { compact: true })} <span className="text-mist-600">→</span> <span className={fin.overBudget ? "text-rose-300" : "text-acid-300"}>{money(fin.forecastFinal, { compact: true })}</span></span>
                  </div>
                  <div className="relative h-4 overflow-hidden rounded bg-white/[0.045]">
                    <div className="absolute inset-y-0 left-0 rounded bg-white/[0.13]" style={{ width: `${(fin.currentBudget / max) * 100}%` }} />
                    <div className={cn("absolute inset-y-0 left-0 rounded border-r-2 bg-gradient-to-r", fin.overBudget ? "border-rose-300 from-rose-500/70 to-rose-400/70" : "border-acid-300 from-acid-500/60 to-acid-400/50")} style={{ width: `${(fin.forecastFinal / max) * 100}%` }} />
                  </div>
                </button>
              );
            })}
            {scoped.length === 0 && <EmptyState compact icon={FileBarChart} title="No projects to report" description="Create a renovation project to populate portfolio reporting." />}
          </div>
        </Card>

        <Card className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-white/[0.06] px-4 py-3"><SectionHeader icon={Clock} title="Project delays" subtitle="Planned completion vs today" /><Badge tone={delayed.length ? "amber" : "acid"}>{delayed.length} delayed</Badge></div>
          <div className="divide-y divide-white/[0.05]">
            {delayed.map((project) => (
              <button key={project.id} onClick={() => onNavigate({ name: "project", id: project.id })} className="flex w-full items-center gap-2 px-4 py-2.5 text-left transition hover:bg-white/[0.02]">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-amber-400/20 bg-amber-400/[0.07] text-amber-300"><Timer className="h-3.5 w-3.5" /></span>
                <span className="min-w-0 flex-1"><span className="block truncate text-[10.5px] text-mist-200">{project.propertyName} · {project.unitNumber}</span><span className="block truncate text-[9px] text-mist-500">{project.name} · due {dateLong(project.estimatedCompletion)}</span></span>
                <span className="text-right"><span className="block font-mono text-[10px] text-amber-300">+{daysBetween(project.estimatedCompletion, TODAY)}d</span><StatusBadge status={project.status} dot={false} /></span>
              </button>
            ))}
            {delayed.length === 0 && <div className="p-4"><EmptyState compact icon={CheckCircle2} title="No delayed projects" description="All live projects are within their planned completion date." /></div>}
          </div>
          <div className="border-t border-white/[0.06] px-4 py-2"><button onClick={() => onNavigate({ name: "projects" })} className="flex items-center gap-1 text-[9.5px] text-acid-300 hover:text-acid-200">Open projects list <ArrowUpRight className="h-3 w-3" /></button></div>
        </Card>
      </div>

      <div className="mt-3 grid gap-3 xl:grid-cols-2">
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] px-4 py-3"><SectionHeader icon={ReceiptText} title="Unpaid invoices" subtitle="Approved invoices with outstanding balances" /><Button size="xs" variant="ghost" icon={Download} onClick={() => exportInvoiceCsv(scoped)}>Export</Button></div>
          <div className="divide-y divide-white/[0.05]">
            {unpaid.slice(0, 6).map(({ project, invoice, balance, status }) => (
              <button key={invoice.id} onClick={() => onNavigate({ name: "project", id: project.id })} className="flex w-full items-center gap-2 px-4 py-2.5 text-left transition hover:bg-white/[0.02]">
                <span className="min-w-0 flex-1"><span className="flex items-center gap-1.5"><span className="font-mono text-[10.5px] text-mist-200">{invoice.number}</span><StatusBadge status={status} /><span className="text-[9px] text-mist-500">{invoice.vendorName}</span></span><span className="block truncate text-[9px] text-mist-500">{project.propertyName} · {project.unitNumber} · due {dateLong(invoice.dueDate)}</span></span>
                <span className="text-right"><span className="block font-mono text-[10.5px] text-mist-100">{money(balance, { cents: true })}</span><span className={cn("text-[8.5px]", invoice.dueDate < TODAY ? "text-rose-300" : "text-mist-500")}>{invoice.dueDate < TODAY ? `${daysBetween(invoice.dueDate, TODAY)}d overdue` : "Current"}</span></span>
              </button>
            ))}
            {unpaid.length === 0 && <div className="p-4"><EmptyState compact icon={CheckCircle2} title="All invoices settled" description="No approved invoice has an outstanding balance." /></div>}
          </div>
        </Card>

        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] px-4 py-3"><SectionHeader icon={Building2} title="Renovation history by property" subtitle="Project count and incurred value" /><Badge tone="slate">{new Set(scoped.map((p) => p.propertyId)).size} properties</Badge></div>
          <div className="divide-y divide-white/[0.05]">
            {Array.from(new Set(scoped.map((p) => p.propertyId))).map((propertyId) => {
              const propertyProjects = scoped.filter((p) => p.propertyId === propertyId);
              const value = propertyProjects.reduce((sum, p) => sum + projectFinancials(p).incurred, 0);
              return (
                <div key={propertyId} className="flex items-center gap-2 px-4 py-2.5">
                  <span className="flex h-7 w-7 items-center justify-center rounded-lg border border-white/[0.07] bg-white/[0.03] text-mist-400"><Building2 className="h-3.5 w-3.5" /></span>
                  <div className="min-w-0 flex-1"><p className="truncate text-[10.5px] text-mist-200">{propertyProjects[0]?.propertyName ?? propertyId}</p><p className="text-[9px] text-mist-500">{propertyProjects.length} project{propertyProjects.length === 1 ? "" : "s"} · {money(value)} incurred</p></div>
                  <div className="text-right"><p className="font-mono text-[9.5px] text-mist-300">{money(propertyProjects.reduce((s, p) => s + projectFinancials(p).currentBudget, 0), { compact: true })}</p><p className="text-[8.5px] text-mist-500">approved</p></div>
                  <button onClick={() => onNavigate({ name: "properties" })} aria-label="Open property records" className="flex h-6 w-6 items-center justify-center rounded text-mist-500 hover:text-mist-200"><ArrowUpRight className="h-3 w-3" /></button>
                </div>
              );
            })}
          </div>
          <div className="flex items-center justify-between border-t border-white/[0.06] bg-white/[0.012] px-4 py-2 text-[9px] text-mist-500"><span className="flex items-center gap-1"><TrendingDown className="h-3 w-3" /> Variance {money(totals.variance)}</span><span className="flex items-center gap-1"><CircleDollarSign className="h-3 w-3" /> All amounts CAD · generated {dateShort(TODAY)}</span></div>
        </Card>
      </div>
    </>
  );
}
