import { useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowUpRight,
  BadgeCheck,
  Building2,
  CalendarClock,
  CheckCircle2,
  ChevronRight,
  Download,
  HardHat,
  Mail,
  MapPin,
  Phone,
  Plus,
  Search,
  ShieldAlert,
  ShieldCheck,
  Star,
  UserRound,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { useStore } from "../lib/store";
import { PageHeader } from "../components/Layout";
import { Avatar, Badge, Button, Card, EmptyState, InfoNote, Input, Modal, ProgressBar, Select, StatusBadge, ToneIcon } from "../components/ui";
import { dateLong, daysBetween, invoiceTotal, money, projectFinancials, TODAY } from "../lib/finance";
import { downloadCsv } from "../lib/export";
import type { Contractor } from "../lib/types";
import { cn } from "../utils/cn";
import type { Route } from "../components/Layout";

export function ContractorsPage({ onNavigate }: { onNavigate: (route: Route) => void }) {
  const { contractors, projects, notify } = useStore();
  const [search, setSearch] = useState("");
  const [trade, setTrade] = useState("");
  const [status, setStatus] = useState("");
  const [compliance, setCompliance] = useState("");
  const [selected, setSelected] = useState<Contractor | null>(null);

  const enriched = useMemo(
    () =>
      contractors.map((contractor) => {
        const assigned = projects.filter((project) => project.team.some((member) => member.contractorId === contractor.id));
        const committed = assigned.reduce((sum, project) => sum + project.team.filter((m) => m.contractorId === contractor.id).reduce((s, m) => s + m.contractAmountCents, 0), 0);
        const invoiced = projects.reduce((sum, project) => sum + project.invoices.filter((invoice) => invoice.vendorId === contractor.id).reduce((s, invoice) => s + invoiceTotal(invoice), 0), 0);
        const paid = projects.reduce((sum, project) => sum + project.payments.filter((payment) => payment.payeeId === contractor.id).reduce((s, payment) => s + payment.amountCents, 0), 0);
        const insuranceDays = daysBetween(TODAY, contractor.insuranceExpiry);
        const wsibDays = daysBetween(TODAY, contractor.wsibExpiry);
        const complianceState = !contractor.active ? "Inactive" : insuranceDays < 0 || wsibDays < 0 ? "Expired" : insuranceDays <= 45 || wsibDays <= 45 ? "Expiring" : "Compliant";
        return { contractor, assigned, committed, invoiced, paid, insuranceDays, wsibDays, complianceState };
      }),
    [contractors, projects],
  );

  const filtered = enriched.filter((entry) => {
    if (trade && !entry.contractor.trade.toLowerCase().includes(trade.toLowerCase())) return false;
    if (status === "Active" && !entry.contractor.active) return false;
    if (status === "Inactive" && entry.contractor.active) return false;
    if (compliance && entry.complianceState !== compliance) return false;
    const query = search.toLowerCase().trim();
    if (!query) return true;
    return [entry.contractor.name, entry.contractor.trade, entry.contractor.contactPerson, entry.contractor.email, entry.contractor.license].join(" ").toLowerCase().includes(query);
  });

  const expiring = enriched.filter((entry) => entry.complianceState === "Expiring" || entry.complianceState === "Expired");
  const totalCommitted = enriched.reduce((sum, entry) => sum + entry.committed, 0);
  const totalPaid = enriched.reduce((sum, entry) => sum + entry.paid, 0);
  const trades = Array.from(new Set(contractors.map((c) => c.trade.split("·")[0].trim())));

  const exportDirectory = () => {
    downloadCsv(
      `habitat-contractor-directory-${TODAY}.csv`,
      ["Contractor ID", "Name", "Trade", "Contact", "Phone", "Email", "Pricing model", "Agreed rate", "Payment terms", "Status", "Insurance expiry", "WSIB expiry", "Projects", "Committed", "Paid"],
      enriched.map(({ contractor, assigned, committed, paid }) => [contractor.id, contractor.name, contractor.trade, contractor.contactPerson, contractor.phone, contractor.email, contractor.pricingModel, contractor.agreedRate, contractor.paymentTerms, contractor.active ? "Active" : "Inactive", contractor.insuranceExpiry, contractor.wsibExpiry, assigned.length, money(committed), money(paid)]),
    );
    notify("Directory exported", "success", "Contractor records downloaded as CSV.");
  };

  return (
    <>
      <PageHeader
        eyebrow={<>Operations <span className="text-mist-600">/</span> Reusable directory</>}
        title="Contractor directory"
        description="One contractor record powers every project assignment. Compliance, rates, workers and financial history stay connected."
        actions={<><Button variant="secondary" size="md" icon={Download} onClick={exportDirectory}>Export directory</Button><Button variant="primary" size="md" icon={Plus} onClick={() => notify("New contractor", "info", "Contractor creation is managed in the shared vendor system. This demo exposes the reuse and assignment flow.")}>Add contractor</Button></>}
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="flex items-center gap-3 p-4"><ToneIcon icon={HardHat} tone="acid" size="lg" /><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Active contractors</p><p className="font-mono text-[22px] text-mist-100">{contractors.filter((c) => c.active).length}<span className="text-[12px] text-mist-500">/{contractors.length}</span></p><p className="text-[9.5px] text-mist-500">In the reusable directory</p></div></Card>
        <Card className="flex items-center gap-3 p-4"><ToneIcon icon={ShieldAlert} tone={expiring.length ? "amber" : "aqua"} size="lg" /><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Compliance alerts</p><p className={cn("font-mono text-[22px]", expiring.length ? "text-amber-300" : "text-mist-100")}>{expiring.length}</p><p className="text-[9.5px] text-mist-500">Insurance / WSIB &lt; 45 days</p></div></Card>
        <Card className="flex items-center gap-3 p-4"><ToneIcon icon={Wallet} tone="aqua" size="lg" /><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Committed across projects</p><p className="font-mono text-[22px] text-mist-100">{money(totalCommitted)}</p><p className="text-[9.5px] text-mist-500">{money(totalPaid)} paid to date</p></div></Card>
        <Card className="flex items-center gap-3 p-4"><ToneIcon icon={Users} tone="violet" size="lg" /><div><p className="text-[9.5px] uppercase tracking-[0.1em] text-mist-500">Workers under contract</p><p className="font-mono text-[22px] text-mist-100">{contractors.reduce((sum, c) => sum + c.workers.length, 0)}</p><p className="text-[9.5px] text-mist-500">{trades.length} trades represented</p></div></Card>
      </div>

      {expiring.length > 0 && (
        <div className="mb-3"><InfoNote tone="warning"><span className="font-medium">Compliance review required:</span> {expiring.map((entry) => `${entry.contractor.name} (${entry.contractor.insuranceExpiry < TODAY ? "insurance expired" : entry.complianceState === "Inactive" ? "inactive" : `insurance ${entry.insuranceDays}d`})`).join("; ")}. Update certificates before awarding new work.</InfoNote></div>
      )}

      <Card className="overflow-hidden">
        <div className="flex flex-wrap items-center gap-2 border-b border-white/[0.06] px-3 py-2.5 sm:px-4">
          <div className="relative min-w-[180px] flex-1 sm:max-w-[280px]">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-mist-500" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, trade, license…" className="h-8 pl-8 text-[11px]" />
            {search && <button onClick={() => setSearch("")} aria-label="Clear search" className="absolute right-2 top-1/2 -translate-y-1/2 text-mist-500"><X className="h-3 w-3" /></button>}
          </div>
          <Select value={trade} onChange={(e) => setTrade(e.target.value)} className="h-8 w-[150px] text-[11px]" aria-label="Filter by trade"><option value="">All trades</option>{trades.map((t) => <option key={t}>{t}</option>)}</Select>
          <Select value={status} onChange={(e) => setStatus(e.target.value)} className="h-8 w-[120px] text-[11px]" aria-label="Filter by status"><option value="">Any status</option><option>Active</option><option>Inactive</option></Select>
          <Select value={compliance} onChange={(e) => setCompliance(e.target.value)} className="h-8 w-[140px] text-[11px]" aria-label="Filter by compliance"><option value="">Any compliance</option><option>Compliant</option><option>Expiring</option><option>Expired</option></Select>
          <span className="ml-auto text-[10px] text-mist-500">{filtered.length} contractors</span>
        </div>

        {filtered.length === 0 ? (
          <div className="p-6"><EmptyState icon={HardHat} title="No contractors match" description="Clear filters or search for a different trade." action={<Button size="sm" variant="secondary" onClick={() => { setSearch(""); setTrade(""); setStatus(""); setCompliance(""); }}>Clear filters</Button>} /></div>
        ) : (
          <div className="grid gap-3 p-3 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map(({ contractor, assigned, committed, paid, complianceState }) => (
              <button key={contractor.id} onClick={() => setSelected(contractor)} className="group flex flex-col rounded-xl border border-white/[0.065] bg-white/[0.018] p-3 text-left transition hover:border-white/15 hover:bg-white/[0.03]">
                <div className="flex items-start gap-2.5">
                  <Avatar name={contractor.name} size="md" />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <p className="truncate text-[12.5px] font-semibold text-mist-100 group-hover:text-acid-200">{contractor.name}</p>
                      <StatusBadge status={contractor.active ? "Active" : "Inactive"} />
                    </div>
                    <p className="truncate text-[10px] text-mist-500">{contractor.trade}</p>
                    <p className="mt-0.5 flex items-center gap-1 text-[9px] text-mist-500"><span className="font-mono">{contractor.id}</span> · {contractor.pricingModel} · <Star className="h-2.5 w-2.5 fill-amber-300/70 text-amber-300" /> {contractor.rating.toFixed(1)}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-mist-600 transition group-hover:text-acid-300" />
                </div>
                <div className="mt-2.5 grid grid-cols-3 gap-1.5">
                  <div className="rounded-md bg-white/[0.03] px-2 py-1"><p className="text-[8px] uppercase tracking-wide text-mist-500">Projects</p><p className="font-mono text-[10.5px] text-mist-200">{assigned.length}</p></div>
                  <div className="rounded-md bg-white/[0.03] px-2 py-1"><p className="text-[8px] uppercase tracking-wide text-mist-500">Committed</p><p className="font-mono text-[10.5px] text-mist-200">{money(committed, { compact: true })}</p></div>
                  <div className="rounded-md bg-white/[0.03] px-2 py-1"><p className="text-[8px] uppercase tracking-wide text-mist-500">Paid</p><p className="font-mono text-[10.5px] text-aqua-300">{money(paid, { compact: true })}</p></div>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <Badge tone={complianceState === "Compliant" ? "aqua" : complianceState === "Inactive" ? "slate" : complianceState === "Expired" ? "rose" : "amber"} icon={complianceState === "Compliant" ? ShieldCheck : AlertTriangle}>Insurance {dateLong(contractor.insuranceExpiry)}</Badge>
                  <Badge tone="slate">WSIB {contractor.wsibExpiry}</Badge>
                </div>
                <div className="mt-2 flex items-center justify-between border-t border-white/[0.05] pt-2 text-[9.5px] text-mist-500">
                  <span className="flex items-center gap-1 truncate"><UserRound className="h-2.5 w-2.5" /> {contractor.contactPerson}</span>
                  <span className="flex items-center gap-1"><Users className="h-2.5 w-2.5" /> {contractor.workers.length} workers</span>
                </div>
              </button>
            ))}
          </div>
        )}
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.06] bg-white/[0.012] px-4 py-2 text-[9.5px] text-mist-500"><span className="flex items-center gap-1"><BadgeCheck className="h-3 w-3 text-acid-400/80" /> Directory records are reused across projects. Assignment-level role, rate and dates are stored on the project.</span><span>{filtered.length} of {contractors.length} shown</span></div>
      </Card>

      <ContractorModal contractor={selected} onClose={() => setSelected(null)} onNavigate={onNavigate} />
    </>
  );
}

function ContractorModal({ contractor, onClose, onNavigate }: { contractor: Contractor | null; onClose: () => void; onNavigate: (route: Route) => void }) {
  const { projects } = useStore();
  if (!contractor) return null;
  const assigned = projects.filter((project) => project.team.some((member) => member.contractorId === contractor.id));
  const insuranceDays = daysBetween(TODAY, contractor.insuranceExpiry);
  return (
    <Modal open={!!contractor} onClose={onClose} title={contractor.name} description={contractor.trade} icon={HardHat} size="lg"
      footer={<><Button variant="ghost" size="md" onClick={onClose}>Close</Button>{assigned[0] && <Button variant="primary" size="md" icon={ArrowUpRight} onClick={() => { onClose(); onNavigate({ name: "project", id: assigned[0].id }); }}>Open related project</Button>}</>}>
      <div className="grid gap-3 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-1.5"><StatusBadge status={contractor.active ? "Active" : "Inactive"} /><Badge tone="slate">{contractor.pricingModel}</Badge><Badge tone="slate">{contractor.id}</Badge><span className="flex items-center gap-1 text-[10px] text-amber-300"><Star className="h-2.5 w-2.5 fill-amber-300" /> {contractor.rating.toFixed(1)} rating</span></div>
          <div className="grid gap-2 sm:grid-cols-2">
            <InfoRow icon={UserRound} label="Contact person" value={contractor.contactPerson} />
            <InfoRow icon={Phone} label="Phone" value={contractor.phone} />
            <InfoRow icon={Mail} label="Email" value={contractor.email} />
            <InfoRow icon={MapPin} label="Business address" value={contractor.address} />
            <InfoRow icon={BadgeCheck} label="License" value={contractor.license} />
            <InfoRow icon={CalendarClock} label="Payment terms" value={contractor.paymentTerms} />
            <InfoRow icon={Wallet} label="Agreed rates" value={contractor.agreedRate} />
            <InfoRow icon={Building2} label="Insurance provider" value={contractor.insuranceProvider} />
          </div>
          <div>
            <p className="text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Internal notes</p>
            <p className="mt-1 rounded-lg border border-white/[0.06] bg-white/[0.02] p-2 text-[10.5px] leading-relaxed text-mist-300">{contractor.notes}</p>
          </div>
          {contractor.workers.length > 0 && (
            <div><p className="mb-1 text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Workers / contacts</p><div className="grid gap-1.5 sm:grid-cols-2">{contractor.workers.map((worker) => <div key={worker.name} className="flex items-center gap-2 rounded-lg border border-white/[0.06] bg-white/[0.02] px-2 py-1.5"><Avatar name={worker.name} size="xs" /><div className="min-w-0"><p className="truncate text-[10px] text-mist-200">{worker.name}</p><p className="truncate text-[8.5px] text-mist-500">{worker.role}{worker.phone ? ` · ${worker.phone}` : ""}</p></div></div>)}</div></div>
          )}
          {contractor.documents.length > 0 && <div className="flex flex-wrap gap-1.5">{contractor.documents.map((doc) => <Badge key={doc.name} tone="slate" icon={BadgeCheck}>{doc.name}</Badge>)}</div>}
        </div>
        <div className="space-y-2">
          <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-2.5">
            <p className="text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Compliance</p>
            <div className="mt-1.5 space-y-1.5">
              <div className={cn("flex items-center justify-between rounded border px-2 py-1.5 text-[10px]", insuranceDays < 0 ? "border-rose-400/25 bg-rose-400/[0.06]" : insuranceDays <= 45 ? "border-amber-400/25 bg-amber-400/[0.06]" : "border-aqua-400/20 bg-aqua-400/[0.04]")}>
                <span className="flex items-center gap-1 text-mist-300"><ShieldCheck className="h-3 w-3" /> Insurance</span>
                <span className={cn("font-mono", insuranceDays < 0 ? "text-rose-300" : insuranceDays <= 45 ? "text-amber-300" : "text-aqua-300")}>{contractor.insuranceExpiry}</span>
              </div>
              <div className="flex items-center justify-between rounded border border-white/[0.07] px-2 py-1.5 text-[10px]"><span className="flex items-center gap-1 text-mist-400"><ShieldCheck className="h-3 w-3" /> WSIB</span><span className="font-mono text-mist-300">{contractor.wsibExpiry}</span></div>
              <div className="flex items-center justify-between rounded border border-white/[0.07] px-2 py-1.5 text-[10px]"><span className="flex items-center gap-1 text-mist-400"><ShieldCheck className="h-3 w-3" /> License</span><span className="truncate font-mono text-mist-300">{contractor.license}</span></div>
            </div>
          </div>
          <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-2.5">
            <p className="text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Assigned projects ({assigned.length})</p>
            <div className="mt-1 space-y-1">
              {assigned.map((project) => (
                <button key={project.id} onClick={() => { onClose(); onNavigate({ name: "project", id: project.id }); }} className="w-full rounded-lg border border-white/[0.05] bg-white/[0.02] px-2 py-1.5 text-left transition hover:border-acid-400/25">
                  <p className="flex items-center justify-between gap-1 text-[10px] text-mist-200"><span className="truncate">{project.propertyName} · {project.unitNumber}</span><StatusBadge status={project.status} dot={false} /></p>
                  <p className="truncate text-[8.5px] text-mist-500">{project.name} · {money(projectFinancials(project).currentBudget, { compact: true })} budget</p>
                </button>
              ))}
              {assigned.length === 0 && <p className="text-[10px] text-mist-500">No current project assignments.</p>}
            </div>
          </div>
          <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-2.5 text-[9.5px] text-mist-500">
            <p className="flex items-center gap-1 text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-400"><CheckCircle2 className="h-3 w-3 text-acid-400/80" /> Assignment rules</p>
            <p className="mt-1 leading-relaxed">Inactive contractors and expired compliance documents cannot be assigned to new work. Each project stores its own role, responsibilities, dates and agreed amount.</p>
            <ProgressBar value={contractor.active && insuranceDays > 0 ? 100 : 35} tone={contractor.active && insuranceDays > 0 ? "aqua" : "amber"} className="mt-1.5" height="h-1" />
          </div>
        </div>
      </div>
    </Modal>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: typeof UserRound; label: string; value: string }) {
  return (
    <div className="flex items-start gap-1.5 rounded-lg border border-white/[0.055] bg-white/[0.018] px-2 py-1.5">
      <Icon className="mt-0.5 h-3 w-3 shrink-0 text-mist-500" />
      <div className="min-w-0"><p className="text-[8px] uppercase tracking-[0.08em] text-mist-500">{label}</p><p className="truncate text-[10px] text-mist-300">{value}</p></div>
    </div>
  );
}
