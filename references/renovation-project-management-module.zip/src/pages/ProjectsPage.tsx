import { useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  ArrowUpRight,
  Ban,
  Building2,
  CalendarClock,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  Download,
  FileBarChart,
  Filter,
  Gauge,
  Hammer,
  HardHat,
  LayoutGrid,
  List,
  MoreHorizontal,
  Plus,
  Search,
  ShieldAlert,
  SlidersHorizontal,
  Timer,
  TrendingUp,
  Wallet,
  X,
} from "lucide-react";
import { useStore } from "../lib/store";
import { PageHeader } from "../components/Layout";
import { NewProjectModal } from "../components/NewProjectModal";
import { Avatar, Badge, Button, Card, ConfirmDialog, EmptyState, IconButton, ProgressBar, ProgressRing, SectionHeader, Select, Input, StatusBadge, ToneIcon, InfoNote } from "../components/ui";
import { dateLong, dateShort, daysBetween, money, projectFinancials, projectHealthFlags, projectProgress, TODAY, invoiceTotal } from "../lib/finance";
import { exportProjectsCsv } from "../lib/export";
import type { Project, ProjectStatus } from "../lib/types";
import { cn } from "../utils/cn";
import type { Route } from "../components/Layout";

type StatusTab = "All" | "In Progress" | "Approved" | "Planned" | "Draft" | "On Hold" | "Completed" | "Cancelled";

const statusTabs: StatusTab[] = ["All", "In Progress", "Approved", "Planned", "Draft", "On Hold", "Completed", "Cancelled"];

const projectTypeIcon = (type: string) => {
  if (type === "Repair") return ShieldAlert;
  if (type === "Maintenance") return Gauge;
  if (type === "Upgrade") return TrendingUp;
  if (type === "Restoration") return Building2;
  return Hammer;
};

export function ProjectsPage({ onNavigate }: { onNavigate: (route: Route) => void }) {
  const { projects, contractors, properties, toggleArchive, transitionProject, notify, user } = useStore();
  const [modalOpen, setModalOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [statusTab, setStatusTab] = useState<StatusTab>("All");
  const [showFilters, setShowFilters] = useState(false);
  const [showArchived, setShowArchived] = useState(false);
  const [propsFilter, setPropsFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [managerFilter, setManagerFilter] = useState("");
  const [healthFilter, setHealthFilter] = useState("");
  const [contractorFilter, setContractorFilter] = useState("");
  const [dueBefore, setDueBefore] = useState("");
  const [sort, setSort] = useState("priority");
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  const [archiveTarget, setArchiveTarget] = useState<Project | null>(null);
  const [cancelTarget, setCancelTarget] = useState<Project | null>(null);
  const [cancelReason, setCancelReason] = useState("");
  const [view, setView] = useState<"list" | "grid">("list");

  const visibleProjects = projects.filter((p) => showArchived || !p.archived);
  const active = projects.filter((p) => !p.archived && ["Approved", "In Progress", "On Hold"].includes(p.status));
  const pipeline = projects.filter((p) => !p.archived && ["Draft", "Planned"].includes(p.status));

  const totals = useMemo(() => {
    const inScope = projects.filter((p) => p.status !== "Cancelled");
    return inScope.reduce(
      (acc, project) => {
        const fin = projectFinancials(project);
        return {
          original: acc.original + fin.originalBudget,
          current: acc.current + fin.currentBudget,
          committed: acc.committed + fin.committed,
          incurred: acc.incurred + fin.incurred,
          invoiced: acc.invoiced + fin.invoiced,
          paid: acc.paid + fin.paid,
          outstanding: acc.outstanding + fin.outstanding,
          changes: acc.changes + fin.budgetChanges,
          openDeficiencies: acc.openDeficiencies + project.deficiencies.filter((d) => d.status === "Open" || d.status === "In Progress").length,
          overdueMilestones: acc.overdueMilestones + project.milestones.filter((m) => m.status !== "Completed" && m.plannedDate < TODAY).length,
          pendingInvoices: acc.pendingInvoices + project.invoices.filter((i) => i.approval === "Pending Approval").length,
          pendingChangeOrders: acc.pendingChangeOrders + project.changeOrders.filter((c) => c.approval === "Pending Approval").length,
          delayed: acc.delayed + (project.estimatedCompletion < TODAY && !["Completed", "Cancelled"].includes(project.status) ? 1 : 0),
        };
      },
      { original: 0, current: 0, committed: 0, incurred: 0, invoiced: 0, paid: 0, outstanding: 0, changes: 0, openDeficiencies: 0, overdueMilestones: 0, pendingInvoices: 0, pendingChangeOrders: 0, delayed: 0 },
    );
  }, [projects]);

  const overduePayables = projects.reduce(
    (sum, project) =>
      sum +
      project.invoices.filter((invoice) => invoice.approval === "Approved" && invoice.dueDate < TODAY).reduce((s, invoice) => {
        const paid = project.payments.reduce((ps, p) => ps + p.allocations.filter((a) => a.invoiceId === invoice.id).reduce((x, a) => x + a.amountCents, 0), 0);
        return s + Math.max(0, invoiceTotal(invoice) - paid);
      }, 0),
    0,
  );

  const alerts = useMemo(() => {
    const list: { project: Project; title: string; detail: string; icon: typeof AlertTriangle; tone: "rose" | "amber" | "sky"; routeTab?: string }[] = [];
    projects.forEach((project) => {
      if (project.status === "Cancelled" || project.archived) return;
      const flags = projectHealthFlags(project);
      if (flags.fin.overBudget)
        list.push({ project, title: "Forecast exceeds approved budget", detail: `${money(Math.abs(flags.fin.variance))} over forecast`, icon: TrendingUp, tone: "rose" });
      if (flags.delayed)
        list.push({ project, title: "Project is past planned completion", detail: `Was due ${dateLong(project.estimatedCompletion)}`, icon: CalendarClock, tone: "amber" });
      if (flags.openDeficiencies)
        list.push({ project, title: `${flags.openDeficiencies} open inspection deficienc${flags.openDeficiencies > 1 ? "ies" : "y"}`, detail: "Completion is blocked until verified", icon: ShieldAlert, tone: "sky" });
      if (flags.pendingChangeOrders)
        list.push({ project, title: `${flags.pendingChangeOrders} change order awaiting approval`, detail: "Budget impact not yet reflected", icon: FileBarChart, tone: "amber" });
      if (flags.pendingInvoices)
        list.push({ project, title: `${flags.pendingInvoices} invoice pending approval`, detail: "Separate from payment status", icon: Wallet, tone: "amber" });
    });
    return list.slice(0, 5);
  }, [projects]);

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    const result = visibleProjects.filter((project) => {
      if (statusTab !== "All" && project.status !== statusTab) return false;
      if (propsFilter && project.propertyId !== propsFilter) return false;
      if (typeFilter && project.type !== typeFilter) return false;
      if (managerFilter && project.manager !== managerFilter) return false;
      if (healthFilter && projectFinancials(project).budgetHealth !== healthFilter) return false;
      if (contractorFilter && !project.team.some((member) => member.contractorId === contractorFilter)) return false;
      if (dueBefore && project.estimatedCompletion > dueBefore) return false;
      if (!query) return true;
      return [project.name, project.id, project.propertyName, project.unitNumber, project.manager, project.description, project.type]
        .join(" ")
        .toLowerCase()
        .includes(query);
    });
    const priorityRank: Record<string, number> = { Emergency: 0, High: 1, Normal: 2, Low: 3 };
    return result.sort((a, b) => {
      if (sort === "budget") return projectFinancials(b).currentBudget - projectFinancials(a).currentBudget;
      if (sort === "completion") return projectProgress(b) - projectProgress(a);
      if (sort === "due") return a.estimatedCompletion.localeCompare(b.estimatedCompletion);
      if (sort === "name") return a.name.localeCompare(b.name);
      return (priorityRank[a.priority] ?? 9) - (priorityRank[b.priority] ?? 9) || a.estimatedCompletion.localeCompare(b.estimatedCompletion);
    });
  }, [visibleProjects, statusTab, propsFilter, typeFilter, managerFilter, healthFilter, contractorFilter, dueBefore, search, sort]);

  const activeFilterCount = [propsFilter, typeFilter, managerFilter, healthFilter, contractorFilter, dueBefore].filter(Boolean).length;

  const resetFilters = () => {
    setPropsFilter("");
    setTypeFilter("");
    setManagerFilter("");
    setHealthFilter("");
    setContractorFilter("");
    setDueBefore("");
    setStatusTab("All");
    setSearch("");
  };

  const managers = Array.from(new Set(projects.map((p) => p.manager)));
  const utilisation = totals.current ? Math.round((totals.incurred / totals.current) * 100) : 0;

  const handleArchive = () => {
    if (!archiveTarget) return;
    toggleArchive(archiveTarget.id, !archiveTarget.archived);
    setArchiveTarget(null);
  };

  const handleCancel = () => {
    if (!cancelTarget) return;
    if (!cancelReason.trim()) {
      notify("Cancellation reason required", "warning", "Financial and audit records are retained when a project is cancelled.");
      return;
    }
    if (cancelTarget.status === "Completed" || cancelTarget.status === "Cancelled") {
      notify("Unable to cancel", "error", "This project can no longer be cancelled.");
      return;
    }
    const result = transitionProject(cancelTarget.id, "Cancelled" as ProjectStatus, cancelReason);
    if (!result.ok) notify("Unable to cancel", "error", result.error);
    else {
      setCancelTarget(null);
      setCancelReason("");
    }
  };

  return (
    <>
      <PageHeader
        eyebrow={<>Renovation operations <span className="text-mist-600">/</span> Q1 2026</>}
        title="Renovation projects"
        subtitle="Plan, fund and deliver unit improvements across the Northwind portfolio — with budgets, inspections and unit readiness in one auditable record."
        actions={
          <>
            <Button variant="secondary" size="md" icon={Download} onClick={() => exportProjectsCsv(filtered, contractors)}>Export</Button>
            <Button variant="secondary" size="md" icon={FileBarChart} onClick={() => onNavigate({ name: "reports" })} className="hidden sm:inline-flex">Reports</Button>
            <Button variant="primary" size="md" icon={Plus} onClick={() => setModalOpen(true)} className="shine">New project</Button>
          </>
        }
      />

      <div className="mb-4 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
        <Card className="relative overflow-hidden p-4">
          <div className="blueprint pointer-events-none absolute -right-6 -top-8 h-28 w-28 rounded-full opacity-40" />
          <div className="flex items-start justify-between">
            <div>
              <p className="flex items-center gap-1.5 text-[9.5px] font-semibold uppercase tracking-[0.13em] text-mist-500"><Hammer className="h-3 w-3" /> Active projects</p>
              <div className="mt-1.5 flex items-end gap-2">
                <span className="font-mono text-[27px] font-medium leading-none tracking-tight text-mist-100">{active.length}</span>
                <Badge tone="acid" icon={ArrowUpRight}>{pipeline.length} in pipeline</Badge>
              </div>
            </div>
            <ToneIcon icon={Hammer} tone="acid" />
          </div>
          <div className="mt-3 flex items-center justify-between gap-2">
            <div className="flex -space-x-1.5">
              {managers.map((manager) => <Avatar key={manager} name={manager} size="xs" className="ring-2 ring-ink-850" />)}
            </div>
            <span className="text-[10px] text-mist-500">{totals.delayed} delayed · {active.filter((p) => p.priority === "Emergency" || p.priority === "High").length} high priority</span>
          </div>
          <div className="mt-2.5 grid grid-cols-2 gap-1.5">
            <div className="rounded-md bg-white/[0.03] px-2 py-1"><p className="text-[8.5px] uppercase tracking-wide text-mist-500">In progress</p><p className="font-mono text-[11px] text-mist-200">{projects.filter((p) => p.status === "In Progress").length}</p></div>
            <div className="rounded-md bg-white/[0.03] px-2 py-1"><p className="text-[8.5px] uppercase tracking-wide text-mist-500">On hold</p><p className="font-mono text-[11px] text-amber-300">{projects.filter((p) => p.status === "On Hold").length}</p></div>
          </div>
        </Card>

        <Card className="relative overflow-hidden p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="flex items-center gap-1.5 text-[9.5px] font-semibold uppercase tracking-[0.13em] text-mist-500"><CircleDollarSign className="h-3 w-3" /> Approved capital</p>
              <p className="mt-1.5 font-mono text-[24px] font-medium leading-none tracking-tight text-mist-100">{money(totals.current)}</p>
              <p className="mt-1 text-[10px] text-mist-500">Original {money(totals.original)} <span className="text-acid-300">+{money(totals.changes)}</span> approved changes</p>
            </div>
            <ProgressRing value={utilisation} size={54} stroke={5} tone={utilisation > 85 ? "rose" : "acid"}>
              <span className="font-mono text-[10px] text-mist-200">{utilisation}%</span>
            </ProgressRing>
          </div>
          <div className="mt-3">
            <ProgressBar value={utilisation} height="h-1.5" />
            <div className="mt-2 flex items-center justify-between">
              <span className="text-[10px] text-mist-400"><span className="font-mono text-mist-200">{money(totals.incurred)}</span> incurred</span>
              <span className="text-[10px] text-mist-500">{money(totals.committed)} committed</span>
            </div>
          </div>
          <div className="mt-2.5 flex gap-2 text-[9px] text-mist-500">
            <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-acid-400" /> Incurred</span>
            <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-aqua-400/70" /> Committed</span>
            <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-white/20" /> Remaining</span>
          </div>
        </Card>

        <Card className="relative overflow-hidden p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="flex items-center gap-1.5 text-[9.5px] font-semibold uppercase tracking-[0.13em] text-mist-500"><Wallet className="h-3 w-3" /> Outstanding payables</p>
              <p className="mt-1.5 font-mono text-[24px] font-medium leading-none tracking-tight text-mist-100">{money(totals.outstanding)}</p>
              <p className="mt-1 text-[10px] text-mist-500">{money(totals.invoiced)} invoiced · {money(totals.paid)} paid</p>
            </div>
            <ToneIcon icon={Wallet} tone="sky" />
          </div>
          <div className="mt-3 flex h-1.5 overflow-hidden rounded-full bg-white/[0.07]">
            <div className="bg-aqua-400/80" style={{ width: `${totals.invoiced ? (totals.paid / totals.invoiced) * 100 : 0}%` }} />
            <div className="bg-amber-400/80" style={{ width: `${totals.invoiced ? (totals.outstanding / totals.invoiced) * 100 : 0}%` }} />
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            <div className="rounded-md bg-white/[0.03] px-2 py-1"><p className="text-[8.5px] uppercase tracking-wide text-mist-500">Overdue</p><p className="font-mono text-[11px] text-rose-300">{money(overduePayables)}</p></div>
            <div className="rounded-md bg-white/[0.03] px-2 py-1"><p className="text-[8.5px] uppercase tracking-wide text-mist-500">Pending approval</p><p className="font-mono text-[11px] text-amber-300">{totals.pendingInvoices} invoice{totals.pendingInvoices === 1 ? "" : "s"}</p></div>
          </div>
        </Card>

        <Card className="relative overflow-hidden border-amber-400/[0.14] p-4">
          <div className="absolute right-0 top-0 h-24 w-24 rounded-full bg-amber-400/[0.07] blur-2xl" />
          <div className="flex items-start justify-between">
            <div>
              <p className="flex items-center gap-1.5 text-[9.5px] font-semibold uppercase tracking-[0.13em] text-amber-300/80"><AlertTriangle className="h-3 w-3" /> Needs attention</p>
              <p className="mt-1.5 font-mono text-[24px] font-medium leading-none tracking-tight text-mist-100">{totals.openDeficiencies + totals.overdueMilestones + totals.pendingChangeOrders + totals.delayed}</p>
              <p className="mt-1 text-[10px] text-mist-500">Across {alerts.length} project signal{alerts.length === 1 ? "" : "s"}</p>
            </div>
            <ToneIcon icon={ShieldAlert} tone="amber" />
          </div>
          <div className="mt-3 space-y-1">
            {[
              { label: "Open deficiencies", value: totals.openDeficiencies, tone: "text-rose-300" },
              { label: "Overdue milestones", value: totals.overdueMilestones, tone: "text-amber-300" },
              { label: "Pending change orders", value: totals.pendingChangeOrders, tone: "text-sky-300" },
            ].map((row) => (
              <div key={row.label} className="flex items-center justify-between text-[10px]">
                <span className="text-mist-400">{row.label}</span>
                <span className={cn("font-mono", row.tone)}>{row.value}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mb-4 grid gap-3 xl:grid-cols-[1.55fr_1fr]">
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] px-4 py-3">
            <SectionHeader icon={TrendingUp} title="Capital deployment" subtitle="Current approved budget vs incurred by project" />
            <div className="flex items-center gap-3 text-[9px] text-mist-500">
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-acid-400" /> Incurred</span>
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-aqua-400/80" /> Committed</span>
              <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-white/15" /> Budget</span>
            </div>
          </div>
          <div className="space-y-3 px-4 py-3.5">
            {projects
              .filter((p) => p.status !== "Cancelled")
              .sort((a, b) => projectFinancials(b).currentBudget - projectFinancials(a).currentBudget)
              .slice(0, 6)
              .map((project) => {
                const fin = projectFinancials(project);
                const committedPct = fin.currentBudget ? Math.min(100, (fin.committed / fin.currentBudget) * 100) : 0;
                return (
                  <button key={project.id} onClick={() => onNavigate({ name: "project", id: project.id })} className="group block w-full text-left">
                    <div className="mb-1 flex items-center justify-between gap-2">
                      <span className="flex min-w-0 items-center gap-1.5">
                        <span className="truncate text-[11px] font-medium text-mist-200 transition group-hover:text-acid-200">{project.propertyName} <span className="text-mist-500">· {project.unitNumber}</span></span>
                        {fin.overBudget && <Badge tone="rose" dot>Over</Badge>}
                        {!fin.overBudget && fin.budgetHealth === "At risk" && <Badge tone="amber" dot>At risk</Badge>}
                      </span>
                      <span className="shrink-0 font-mono text-[10px] text-mist-400">{money(fin.incurred, { compact: true })} <span className="text-mist-600">/</span> {money(fin.currentBudget, { compact: true })}</span>
                    </div>
                    <div className="relative h-2 overflow-hidden rounded-full bg-white/[0.055]">
                      <div className="absolute inset-y-0 left-0 rounded-full bg-aqua-400/35" style={{ width: `${committedPct}%` }} />
                      <div className={cn("absolute inset-y-0 left-0 rounded-full bg-gradient-to-r", fin.overBudget ? "from-rose-500 to-rose-300" : fin.utilisation > 80 ? "from-amber-500 to-amber-300" : "from-acid-500 to-acid-300")} style={{ width: `${Math.min(100, fin.utilisation)}%` }} />
                    </div>
                  </button>
                );
              })}
          </div>
          <div className="flex items-center justify-between border-t border-white/[0.06] bg-white/[0.015] px-4 py-2">
            <p className="flex items-center gap-1.5 text-[9.5px] text-mist-500"><ShieldAlert className="h-3 w-3" /> Committed, incurred, invoiced and paid are tracked separately to prevent double counting.</p>
            <button onClick={() => onNavigate({ name: "reports" })} className="flex items-center gap-1 text-[10px] font-medium text-acid-300 hover:text-acid-200">Full reports <ArrowRight className="h-3 w-3" /></button>
          </div>
        </Card>

        <Card className="flex flex-col">
          <div className="flex items-center justify-between border-b border-white/[0.06] px-4 py-3">
            <SectionHeader icon={AlertTriangle} title="Action queue" subtitle="Highest-signal exceptions in the portfolio" />
            <Badge tone="rose">{alerts.length}</Badge>
          </div>
          <div className="min-h-0 flex-1 divide-y divide-white/[0.05]">
            {alerts.length === 0 && <div className="p-4"><EmptyState compact icon={CheckCircle2} title="Nothing needs attention" description="All projects are within budget and schedule." /></div>}
            {alerts.map((alert, index) => {
              const AlertIcon = alert.icon;
              return (
                <button
                  key={`${alert.project.id}-${index}`}
                  onClick={() => onNavigate({ name: "project", id: alert.project.id })}
                  className="flex w-full items-center gap-2.5 px-4 py-2.5 text-left transition hover:bg-white/[0.035]"
                >
                  <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border", alert.tone === "rose" ? "border-rose-400/25 bg-rose-400/10 text-rose-300" : alert.tone === "amber" ? "border-amber-400/25 bg-amber-400/10 text-amber-300" : "border-sky-400/25 bg-sky-400/10 text-sky-300")}>
                    <AlertIcon className="h-3.5 w-3.5" strokeWidth={1.9} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[11.5px] font-medium text-mist-200">{alert.title}</span>
                    <span className="block truncate text-[10px] text-mist-500">{alert.project.propertyName} · Unit {alert.project.unitNumber} — {alert.detail}</span>
                  </span>
                  <ChevronRight className="h-3.5 w-3.5 shrink-0 text-mist-600" />
                </button>
              );
            })}
          </div>
          <div className="border-t border-white/[0.06] px-4 py-2">
            <div className="flex items-center justify-between text-[9.5px] text-mist-500">
              <span className="flex items-center gap-1"><Timer className="h-3 w-3" /> Live as of {dateLong(TODAY)}</span>
              <span>CAD · {user.role}</span>
            </div>
          </div>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="border-b border-white/[0.06] px-3 pt-3 sm:px-4">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <SectionHeader icon={LayoutGrid} title="All projects" subtitle={`${filtered.length} of ${visibleProjects.length} projects shown`} />
            <div className="flex items-center gap-1.5">
              <div className="relative">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-mist-500" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search projects…" className="h-8 w-[170px] pl-8 text-[11px] sm:w-[210px]" />
                {search && <button onClick={() => setSearch("")} aria-label="Clear search" className="absolute right-2 top-1/2 -translate-y-1/2 text-mist-500 hover:text-mist-200"><X className="h-3 w-3" /></button>}
              </div>
              <Button
                variant={showFilters || activeFilterCount ? "primary" : "secondary"}
                size="sm"
                icon={SlidersHorizontal}
                onClick={() => setShowFilters((open) => !open)}
              >
                Filters {activeFilterCount > 0 && <span className="rounded bg-ink-950/20 px-1 font-mono text-[9px]">{activeFilterCount}</span>}
              </Button>
              <div className="hidden items-center rounded-lg border border-white/[0.08] p-0.5 sm:flex">
                <button onClick={() => setView("list")} aria-label="List view" className={cn("flex h-6 w-6 items-center justify-center rounded", view === "list" ? "bg-white/[0.09] text-mist-100" : "text-mist-500 hover:text-mist-300")}><List className="h-3.5 w-3.5" /></button>
                <button onClick={() => setView("grid")} aria-label="Grid view" className={cn("flex h-6 w-6 items-center justify-center rounded", view === "grid" ? "bg-white/[0.09] text-mist-100" : "text-mist-500 hover:text-mist-300")}><LayoutGrid className="h-3.5 w-3.5" /></button>
              </div>
              <div className="hidden items-center gap-1 md:flex">
                <Select value={sort} onChange={(e) => setSort(e.target.value)} className="h-8 w-[128px] text-[11px]" aria-label="Sort projects">
                  <option value="priority">Priority first</option>
                  <option value="due">Due soonest</option>
                  <option value="budget">Largest budget</option>
                  <option value="completion">Most complete</option>
                  <option value="name">Name A–Z</option>
                </Select>
                <IconButton icon={Download} label="Export filtered list" onClick={() => exportProjectsCsv(filtered, contractors)} />
              </div>
            </div>
          </div>

          <div className="no-scrollbar mt-2 flex items-center gap-1 overflow-x-auto">
            {statusTabs.map((tab) => {
              const count = tab === "All" ? visibleProjects.length : visibleProjects.filter((p) => p.status === tab).length;
              return (
                <button
                  key={tab}
                  onClick={() => setStatusTab(tab)}
                  className={cn(
                    "relative flex shrink-0 items-center gap-1.5 rounded-t-md px-2.5 py-2 text-[11px] font-medium transition",
                    statusTab === tab ? "text-acid-300" : "text-mist-500 hover:text-mist-300",
                  )}
                >
                  {tab}
                  <span className={cn("rounded px-1 font-mono text-[9px]", statusTab === tab ? "bg-acid-400/15 text-acid-300" : "bg-white/[0.05] text-mist-500")}>{count}</span>
                  {statusTab === tab && <span className="absolute inset-x-1 -bottom-px h-[2px] rounded-full bg-acid-400" />}
                </button>
              );
            })}
            <label className="ml-auto flex shrink-0 cursor-pointer items-center gap-1.5 pb-1 text-[10px] text-mist-500">
              <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} className="h-3 w-3 accent-acid-400" /> Archived
            </label>
          </div>
        </div>

        {showFilters && (
          <div className="animate-in border-b border-white/[0.06] bg-white/[0.018] px-3 py-3 sm:px-4">
            <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-4">
              <div><p className="mb-1 text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Property</p><Select value={propsFilter} onChange={(e) => setPropsFilter(e.target.value)} className="h-8 text-[11px]"><option value="">All properties</option>{properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</Select></div>
              <div><p className="mb-1 text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Project type</p><Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="h-8 text-[11px]"><option value="">All types</option>{["Renovation", "Repair", "Maintenance", "Upgrade", "Restoration", "Other"].map((t) => <option key={t}>{t}</option>)}</Select></div>
              <div><p className="mb-1 text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Project manager</p><Select value={managerFilter} onChange={(e) => setManagerFilter(e.target.value)} className="h-8 text-[11px]"><option value="">All managers</option>{managers.map((m) => <option key={m}>{m}</option>)}</Select></div>
              <div><p className="mb-1 text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Budget status</p><Select value={healthFilter} onChange={(e) => setHealthFilter(e.target.value)} className="h-8 text-[11px]"><option value="">Any budget status</option>{["On track", "At risk", "Over budget"].map((h) => <option key={h}>{h}</option>)}</Select></div>
              <div><p className="mb-1 text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Assigned contractor</p><Select value={contractorFilter} onChange={(e) => setContractorFilter(e.target.value)} className="h-8 text-[11px]"><option value="">All contractors</option>{contractors.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select></div>
              <div><p className="mb-1 text-[9px] font-semibold uppercase tracking-[0.1em] text-mist-500">Due on or before</p><Input type="date" value={dueBefore} onChange={(e) => setDueBefore(e.target.value)} className="h-8 text-[11px]" aria-label="Completion due before" /></div>
              <div className="flex items-end gap-2"><Button variant="ghost" size="sm" icon={X} onClick={resetFilters} className="h-8">Clear all filters</Button></div>
            </div>
            {activeFilterCount > 0 && (
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                {propsFilter && <FilterChip label={properties.find((p) => p.id === propsFilter)?.name ?? propsFilter} onClear={() => setPropsFilter("")} />}
                {typeFilter && <FilterChip label={typeFilter} onClear={() => setTypeFilter("")} />}
                {managerFilter && <FilterChip label={managerFilter} onClear={() => setManagerFilter("")} />}
                {healthFilter && <FilterChip label={healthFilter} onClear={() => setHealthFilter("")} />}
                {contractorFilter && <FilterChip label={contractors.find((c) => c.id === contractorFilter)?.name ?? contractorFilter} onClear={() => setContractorFilter("")} />}
                {dueBefore && <FilterChip label={`Due ≤ ${dueBefore}`} onClear={() => setDueBefore("")} />}
              </div>
            )}
          </div>
        )}

        {filtered.length === 0 ? (
          <div className="p-6">
            <EmptyState icon={Filter} title="No projects match these filters" description="Try adjusting the status, property or budget filters, or create a new renovation project." action={<div className="flex gap-2"><Button size="sm" variant="secondary" icon={X} onClick={resetFilters}>Clear filters</Button><Button size="sm" variant="primary" icon={Plus} onClick={() => setModalOpen(true)}>New project</Button></div>} />
          </div>
        ) : view === "grid" ? (
          <div className="grid gap-3 p-3 sm:grid-cols-2 xl:grid-cols-3">
            {filtered.map((project) => <ProjectCard key={project.id} project={project} onNavigate={onNavigate} />)}
          </div>
        ) : (
          <>
            <div className="hidden grid-cols-[minmax(0,2.35fr)_0.95fr_1.25fr_0.9fr_0.8fr_auto] gap-3 border-b border-white/[0.05] bg-white/[0.015] px-4 py-2 text-[9px] font-semibold uppercase tracking-[0.11em] text-mist-500 lg:grid">
              <span>Project / unit</span><span>Status</span><span>Progress & budget</span><span>Planned completion</span><span>Manager</span><span className="sr-only">Actions</span>
            </div>
            <div className="divide-y divide-white/[0.05]">
              {filtered.map((project) => {
                const fin = projectFinancials(project);
                const progress = projectProgress(project);
                const property = properties.find((p) => p.id === project.propertyId);
                const flags = projectHealthFlags(project);
                const TypeIcon = projectTypeIcon(project.type);
                const isArchived = project.archived;
                return (
                  <div key={project.id} className={cn("group relative px-3 py-3 transition hover:bg-white/[0.022] sm:px-4 lg:grid lg:grid-cols-[minmax(0,2.35fr)_0.95fr_1.25fr_0.9fr_0.8fr_auto] lg:items-center lg:gap-3", isArchived && "opacity-70")}>
                    <div className="flex min-w-0 items-start gap-2.5">
                      <div className="relative hidden h-10 w-12 shrink-0 overflow-hidden rounded-lg border border-white/10 bg-ink-700 sm:block">
                        {property?.image ? <img src={property.image} alt="" className="h-full w-full object-cover opacity-80" loading="lazy" /> : null}
                        <span className="absolute inset-0 bg-gradient-to-t from-ink-950/80 to-transparent" />
                        <span className="absolute bottom-0.5 left-0.5 flex items-center gap-0.5 rounded bg-ink-950/70 px-1 text-[7px] font-medium text-mist-300"><TypeIcon className="h-2 w-2" /> {project.type.slice(0, 4)}</span>
                      </div>
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <button onClick={() => onNavigate({ name: "project", id: project.id })} className="truncate text-left text-[12.5px] font-semibold text-mist-100 transition hover:text-acid-200">{project.name}</button>
                          {project.priority === "Emergency" && <Badge tone="rose" dot>Emergency</Badge>}
                          {project.priority === "High" && <Badge tone="amber" dot>High</Badge>}
                          {isArchived && <Badge tone="slate">Archived</Badge>}
                        </div>
                        <div className="mt-0.5 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[10px] text-mist-500">
                          <span className="font-mono text-[9.5px] text-mist-400">{project.id}</span>
                          <span className="text-mist-600">·</span>
                          <span className="flex items-center gap-1"><Building2 className="h-2.5 w-2.5" /> {project.propertyName}</span>
                          <span className="text-mist-600">·</span>
                          <span className="rounded border border-white/[0.07] px-1 font-mono text-[9px]">Unit {project.unitNumber}</span>
                          {flags.openDeficiencies > 0 && <span className="flex items-center gap-0.5 text-rose-300/90"><ShieldAlert className="h-2.5 w-2.5" /> {flags.openDeficiencies}</span>}
                          {flags.delayed && <span className="flex items-center gap-0.5 text-amber-300/90"><Timer className="h-2.5 w-2.5" /> delayed</span>}
                          {project.status === "Completed" && !project.readinessApproved && <span className="flex items-center gap-0.5 text-amber-300/90"><CheckCircle2 className="h-2.5 w-2.5" /> readiness pending</span>}
                        </div>
                        <div className="mt-1 flex items-center gap-1.5 text-[9.5px] text-mist-500 lg:hidden">
                          <StatusBadge status={project.status} />
                          <span className="font-mono text-mist-300">{money(fin.currentBudget, { compact: true })}</span>
                          <span>· {progress}% complete</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-2 flex items-center gap-1.5 lg:mt-0 lg:block">
                      <StatusBadge status={project.status} />
                      <div className="mt-1 hidden text-[9px] text-mist-500 lg:block">{project.type}</div>
                    </div>

                    <div className="mt-2 lg:mt-0">
                      <div className="flex items-center justify-between gap-2 text-[9.5px]">
                        <span className="text-mist-400">{progress}% complete</span>
                        <span className={cn("font-mono", fin.overBudget ? "text-rose-300" : fin.budgetHealth === "At risk" ? "text-amber-300" : "text-mist-300")}>{money(fin.currentBudget, { compact: true })}</span>
                      </div>
                      <div className="mt-1 flex items-center gap-2">
                        <ProgressBar value={progress} tone={project.status === "On Hold" ? "amber" : "acid"} className="flex-1" height="h-1" />
                        <ProgressBar value={fin.utilisation} tone={fin.overBudget ? "rose" : fin.utilisation > 80 ? "amber" : "aqua"} className="w-10" height="h-1" />
                      </div>
                      <div className="mt-1 flex items-center justify-between text-[8.5px] text-mist-500">
                        <span>{project.tasks.filter((t) => t.status === "Completed").length}/{project.tasks.length} tasks · {project.tasks.filter((t) => t.status === "Blocked").length} blocked</span>
                        <span>{fin.utilisation}% spent</span>
                      </div>
                    </div>

                    <div className="mt-2 flex items-center justify-between lg:mt-0 lg:block">
                      <span className="flex items-center gap-1 text-[10.5px] text-mist-300 lg:text-[11px]"><CalendarClock className="h-3 w-3 text-mist-500 lg:hidden" /> {dateShort(project.estimatedCompletion)}</span>
                      <p className={cn("text-[9px]", flags.delayed ? "text-amber-300" : "text-mist-500")}>{flags.delayed ? `${daysBetween(project.estimatedCompletion, TODAY)}d overdue` : project.status === "Completed" ? "Completed" : `${Math.max(0, daysBetween(TODAY, project.estimatedCompletion))}d remaining`}</p>
                    </div>

                    <div className="mt-2 flex items-center gap-1.5 lg:mt-0">
                      <Avatar name={project.manager} size="xs" />
                      <div className="min-w-0">
                        <p className="truncate text-[10.5px] text-mist-300">{project.manager.split(" ")[0]}</p>
                        <p className="text-[8.5px] text-mist-500">Manager</p>
                      </div>
                    </div>

                    <div className="mt-2 flex items-center justify-end gap-1 lg:mt-0">
                      <Button size="xs" variant="secondary" iconRight={ChevronRight} onClick={() => onNavigate({ name: "project", id: project.id })} className="hidden sm:inline-flex">View</Button>
                      <div className="relative">
                        <IconButton icon={MoreHorizontal} label="Project actions" onClick={() => setMenuOpen(menuOpen === project.id ? null : project.id)} className="h-7 w-7" />
                        {menuOpen === project.id && (
                          <>
                            <div className="fixed inset-0 z-30" onClick={() => setMenuOpen(null)} />
                            <div className="animate-pop absolute right-0 top-8 z-40 w-[205px] overflow-hidden rounded-xl border border-white/10 bg-ink-800 p-1 shadow-2xl">
                              <MenuItem icon={ArrowUpRight} label="Open project" onClick={() => { setMenuOpen(null); onNavigate({ name: "project", id: project.id }); }} />
                              <MenuItem icon={Building2} label="Property & unit" onClick={() => { setMenuOpen(null); onNavigate({ name: "properties" }); }} />
                              <MenuItem icon={FileBarChart} label="View financials" onClick={() => { setMenuOpen(null); onNavigate({ name: "project", id: project.id }); }} />
                              <div className="my-1 h-px bg-white/[0.07]" />
                              <MenuItem icon={Download} label="Export project row" onClick={() => { exportProjectsCsv([project], contractors); setMenuOpen(null); notify("Project exported", "success", `${project.id} downloaded as CSV.`); }} />
                              <MenuItem icon={Filter} label={isArchived ? "Restore from archive" : "Archive project"} onClick={() => { setMenuOpen(null); setArchiveTarget(project); }} />
                              <MenuItem
                                icon={Ban}
                                label="Cancel project"
                                danger
                                disabled={["Cancelled", "Completed"].includes(project.status)}
                                onClick={() => { setMenuOpen(null); setCancelTarget(project); setCancelReason(""); }}
                              />
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.06] bg-white/[0.012] px-4 py-2.5">
          <p className="flex items-center gap-1.5 text-[9.5px] text-mist-500"><CircleDollarSign className="h-3 w-3" /> All amounts CAD. Financial metrics are derived from approved change orders, invoices and recorded payments.</p>
          <div className="flex items-center gap-1 text-[9.5px] text-mist-500">
            <HardHat className="h-3 w-3" /> {contractors.filter((c) => c.active).length} active contractors <span className="mx-1 text-mist-600">·</span> {properties.length} properties
          </div>
        </div>
      </Card>

      <div className="mt-3">
        <InfoNote>
          <span className="font-medium text-sky-100/90">Financial integrity:</span> invoice approval is recorded separately from payment status. Project completion never changes unit availability — readiness confirmation is a distinct, permissioned step.
        </InfoNote>
      </div>

      <NewProjectModal open={modalOpen} onClose={() => setModalOpen(false)} onCreated={(id) => onNavigate({ name: "project", id })} />

      <ConfirmDialog
        open={!!archiveTarget}
        onClose={() => setArchiveTarget(null)}
        onConfirm={handleArchive}
        title={archiveTarget?.archived ? "Restore this project?" : "Archive this project?"}
        description={archiveTarget ? `${archiveTarget.id} — ${archiveTarget.name}` : ""}
        confirmLabel={archiveTarget?.archived ? "Restore project" : "Archive project"}
        tone={archiveTarget?.archived ? "primary" : "danger"}
      >
        <div className="rounded-xl border border-white/[0.07] bg-white/[0.025] p-3 text-[11.5px] leading-relaxed text-mist-400">
          {archiveTarget?.archived
            ? "The project will return to the active portfolio view. All records remain unchanged."
            : "Archiving hides the project from default lists while preserving tasks, invoices, payments, documents and the full audit trail. It can be restored at any time."}
        </div>
      </ConfirmDialog>

      {cancelTarget && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
          <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-sm" onClick={() => setCancelTarget(null)} />
          <div className="animate-pop relative z-10 w-full max-w-md overflow-hidden rounded-t-2xl border border-rose-400/20 bg-ink-850 shadow-2xl sm:rounded-2xl">
            <div className="flex items-start gap-3 border-b border-white/[0.07] bg-rose-400/[0.05] px-5 py-4">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-rose-400/25 bg-rose-400/10 text-rose-300"><Ban className="h-4 w-4" /></span>
              <div className="flex-1">
                <h2 className="text-[15px] font-semibold text-mist-100">Cancel project</h2>
                <p className="mt-0.5 text-[11px] text-mist-400">{cancelTarget.id} · {cancelTarget.propertyName} · Unit {cancelTarget.unitNumber}</p>
              </div>
              <IconButton icon={X} label="Close" onClick={() => setCancelTarget(null)} />
            </div>
            <div className="space-y-3 p-5">
              <InfoNote tone="warning">Cancellation preserves every task, invoice, payment and audit entry. It cannot be reversed — create a new project if works resume.</InfoNote>
              <div>
                <label className="mb-1 block text-[10px] font-semibold uppercase tracking-[0.09em] text-mist-400">Cancellation reason <span className="text-rose-300">*</span></label>
                <textarea
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  rows={3}
                  placeholder="Why is this project being cancelled? Recorded with your name and timestamp."
                  className="w-full rounded-lg border border-white/10 bg-ink-900/80 px-3 py-2 text-[12px] text-mist-100 outline-none placeholder:text-mist-500 focus:border-rose-400/50 focus:ring-2 focus:ring-rose-400/15"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 border-t border-white/[0.07] bg-ink-900/60 px-5 py-3">
              <Button variant="ghost" size="sm" onClick={() => setCancelTarget(null)}>Keep project</Button>
              <Button variant="danger" size="sm" icon={Ban} onClick={handleCancel}>Cancel project</Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function FilterChip({ label, onClear }: { label: string; onClear: () => void }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-md border border-acid-400/25 bg-acid-400/10 px-1.5 py-0.5 text-[9.5px] text-acid-200">
      {label}
      <button onClick={onClear} aria-label={`Remove ${label} filter`}><X className="h-2.5 w-2.5" /></button>
    </span>
  );
}

function MenuItem({ icon: Icon, label, onClick, danger, disabled }: { icon: typeof ArrowUpRight; label: string; onClick: () => void; danger?: boolean; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn("flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[11px] transition disabled:cursor-not-allowed disabled:opacity-40", danger ? "text-rose-300 hover:bg-rose-400/10" : "text-mist-300 hover:bg-white/[0.06] hover:text-mist-100")}
    >
      <Icon className="h-3.5 w-3.5" /> {label}
    </button>
  );
}

function ProjectCard({ project, onNavigate }: { project: Project; onNavigate: (route: Route) => void }) {
  const fin = projectFinancials(project);
  const progress = projectProgress(project);
  const flags = projectHealthFlags(project);
  return (
    <button onClick={() => onNavigate({ name: "project", id: project.id })} className="group panel-flat overflow-hidden rounded-xl text-left transition hover:border-white/15 hover:bg-white/[0.03]">
      <div className="flex items-start justify-between gap-2 border-b border-white/[0.06] px-3 py-2.5">
        <div className="flex min-w-0 items-center gap-2">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-acid-400/20 bg-acid-400/10 text-acid-300"><Hammer className="h-3.5 w-3.5" /></span>
          <div className="min-w-0">
            <p className="truncate text-[12px] font-semibold text-mist-100 group-hover:text-acid-200">{project.name}</p>
            <p className="truncate font-mono text-[9px] text-mist-500">{project.id} · {project.propertyName} · {project.unitNumber}</p>
          </div>
        </div>
        <StatusBadge status={project.status} />
      </div>
      <div className="grid grid-cols-3 gap-2 px-3 py-2.5">
        <div><p className="text-[8px] uppercase tracking-wide text-mist-500">Budget</p><p className="font-mono text-[11px] text-mist-200">{money(fin.currentBudget, { compact: true })}</p></div>
        <div><p className="text-[8px] uppercase tracking-wide text-mist-500">Spent</p><p className={cn("font-mono text-[11px]", fin.overBudget ? "text-rose-300" : "text-mist-200")}>{fin.utilisation}%</p></div>
        <div><p className="text-[8px] uppercase tracking-wide text-mist-500">Due</p><p className="font-mono text-[11px] text-mist-200">{dateShort(project.estimatedCompletion)}</p></div>
      </div>
      <div className="px-3 pb-2"><ProgressBar value={progress} tone={flags.delayed ? "amber" : "acid"} height="h-1" /></div>
      <div className="flex items-center justify-between border-t border-white/[0.06] px-3 py-2">
        <span className="flex items-center gap-1.5 text-[9.5px] text-mist-500"><Avatar name={project.manager} size="xs" /> {project.manager}</span>
        <span className="flex items-center gap-1 text-[9.5px] font-medium text-acid-300">{project.tasks.filter((t) => t.status === "Completed").length}/{project.tasks.length} tasks <ArrowRight className="h-3 w-3" /></span>
      </div>
    </button>
  );
}
