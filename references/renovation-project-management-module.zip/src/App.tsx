import { useEffect, useState } from "react";
import { Layout, type Route } from "./components/Layout";
import { StoreProvider } from "./lib/store";
import { ProjectsPage } from "./pages/ProjectsPage";
import { ProjectDetailPage } from "./pages/ProjectDetail";
import { ContractorsPage } from "./pages/ContractorsPage";
import { ReportsPage } from "./pages/ReportsPage";
import { PropertiesPage } from "./pages/PropertiesPage";

function routeHash(route: Route) {
  if (route.name === "project") return `#/projects/${route.id}`;
  if (route.name === "projects") return "#/projects";
  return `#/${route.name}`;
}

function parseHash(): Route {
  const hash = window.location.hash.replace(/^#\/?/, "");
  const [section, id] = hash.split("/");
  if (section === "projects" && id) return { name: "project", id };
  if (section === "contractors") return { name: "contractors" };
  if (section === "reports") return { name: "reports" };
  if (section === "properties") return { name: "properties" };
  return { name: "projects" };
}

export default function App() {
  const [route, setRoute] = useState<Route>(() => parseHash());

  useEffect(() => {
    const onHashChange = () => setRoute(parseHash());
    window.addEventListener("hashchange", onHashChange);
    window.addEventListener("popstate", onHashChange);
    return () => {
      window.removeEventListener("hashchange", onHashChange);
      window.removeEventListener("popstate", onHashChange);
    };
  }, []);

  const navigate = (next: Route) => {
    setRoute(next);
    window.history.pushState(null, "", routeHash(next));
  };

  return (
    <StoreProvider>
      <Layout route={route} onNavigate={navigate}>
        {route.name === "projects" && <ProjectsPage onNavigate={navigate} />}
        {route.name === "project" && <ProjectDetailPage projectId={route.id} onBack={() => navigate({ name: "projects" })} />}
        {route.name === "contractors" && <ContractorsPage onNavigate={navigate} />}
        {route.name === "reports" && <ReportsPage onNavigate={navigate} />}
        {route.name === "properties" && <PropertiesPage onNavigate={navigate} />}
      </Layout>
    </StoreProvider>
  );
}
