import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  ArrowUpRight,
  BarChart3,
  Bell,
  Building2,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  DoorOpen,
  FileText,
  FolderClosed,
  Hammer,
  HardHat,
  LayoutGrid,
  LifeBuoy,
  Menu,
  Plus,
  Search,
  Settings,
  Sparkles,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { cn } from "../utils/cn";
import { useStore } from "../lib/store";
import { daysBetween, invoiceTotal, money, projectFinancials, TODAY } from "../lib/finance";
import { Avatar, Badge, Button, IconButton, ProgressBar, ProgressRing, StatusBadge } from "./ui";

export type Route =
  | { name: "projects" }
  | { name: "project"; id: string }
  | { name: "contractors" }
  | { name: "reports" }
  | { name: "properties" };

interface LayoutProps {
  route: Route;
  onNavigate: (route: Route) => void;
  children: ReactNode;
}

const navSections = [
  {
    label: "Portfolio",
    items: [
      { label: "Overview", icon: LayoutGrid, route: "projects" as const, live: true },
      { label: "Properties", icon: Building2, route: "properties" as const, live: true },
      { label: "Units", icon: DoorOpen, live: false },
      { label: "Tenants", icon: Users, live: false },
    ],
  },
  {
    label: "Operations",
    items: [
      { label: "Renovations", icon: Hammer, route: "projects" as const, live: true, badge: true },
      { label: "Contractors", icon: HardHat, route: "contractors" as const, live: true },
      { label: "Documents", icon: FolderClosed, live: false },
      { label: "Financials", icon: Wallet, live: false },
    ],
  },
  {
    label: "Insights",
    items: [
      { label: "Reports", icon: BarChart3, route: "reports" as const, live: true },
      { label: "Settings", icon: Settings, live: false },
    ],
  },
];

export function Layout({ route, onNavigate, children }: LayoutProps) {
  const { projects, contractors, user, notify } = useStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);

  const activeProjects = projects.filter((p) => !p.archived && p.status !== "Completed" && p.status !== "Cancelled");
  const portfolioBudget = projects
    .filter((p) => p.status !== "Cancelled")
    .reduce((sum, p) => sum + projectFinancials(p).currentBudget, 0);
  const portfolioSpent = projects
    .filter((p) => p.status !== "Cancelled")
    .reduce((sum, p) => sum + projectFinancials(p).incurred, 0);
  const utilisation = portfolioBudget ? Math.round((portfolioSpent / portfolioBudget) * 100) : 0;

  const searchResults = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return { projects: [], contractors: [] };
    return {
      projects: projects
        .filter(
          (p) =>
            p.name.toLowerCase().includes(query) ||
            p.id.toLowerCase().includes(query) ||
            p.propertyName.toLowerCase().includes(query) ||
            p.unitNumber.toLowerCase().includes(query) ||
            p.manager.toLowerCase().includes(query),
        )
        .slice(0, 5),
      contractors: contractors
        .filter(
          (c) =>
            c.name.toLowerCase().includes(query) ||
            c.trade.toLowerCase().includes(query) ||
            c.contactPerson.toLowerCase().includes(query),
        )
        .slice(0, 3),
    };
  }, [projects, contractors, search]);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        searchRef.current?.focus();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  const notifications = useMemo(() => {
    const items: { projectId: string; title: string; detail: string; tone: "rose" | "amber" | "sky" | "acid" }[] = [];
    projects.forEach((project) => {
      if (project.status === "Cancelled") return;
      const overdueInvoices = project.invoices.filter((invoice) => {
        const paid = project.payments.reduce(
          (sum, p) => sum + p.allocations.filter((a) => a.invoiceId === invoice.id).reduce((s, a) => s + a.amountCents, 0),
          0,
        );
        return invoice.approval === "Approved" && invoice.dueDate < TODAY && paid < invoiceTotal(invoice);
      });
      if (overdueInvoices.length)
        items.push({ projectId: project.id, title: `${overdueInvoices.length} overdue invoice${overdueInvoices.length > 1 ? "s" : ""}`, detail: `${project.propertyName} · ${project.unitNumber}`, tone: "rose" });
      const co = project.changeOrders.filter((c) => c.approval === "Pending Approval");
      if (co.length)
        items.push({ projectId: project.id, title: `Change order ${co[0].number} awaiting approval`, detail: `${project.name} · ${project.id}`, tone: "amber" });
      const deficiencies = project.deficiencies.filter((d) => d.status === "Open" || d.status === "In Progress");
      if (deficiencies.length)
        items.push({ projectId: project.id, title: `${deficiencies.length} open deficienc${deficiencies.length > 1 ? "ies" : "y"}`, detail: `${project.propertyName} · ${project.unitNumber}`, tone: "sky" });
      const compliance = contractors.find((c) => project.team.some((t) => t.contractorId === c.id) && daysBetween(TODAY, c.insuranceExpiry) <= 30 && daysBetween(TODAY, c.insuranceExpiry) >= 0);
      if (compliance)
        items.push({ projectId: project.id, title: `${compliance.name} insurance expires soon`, detail: `Expires ${compliance.insuranceExpiry} · ${compliance.trade.split("·")[0]}`, tone: "amber" });
    });
    return items.slice(0, 6);
  }, [projects, contractors]);

  const go = (target: Route) => {
    onNavigate(target);
    setMobileOpen(false);
    setSearchOpen(false);
    setSearch("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between px-4 pb-4 pt-4">
        <button onClick={() => go({ name: "projects" })} className="group flex items-center gap-2.5 text-left">
          <span className="relative flex h-9 w-9 items-center justify-center overflow-hidden rounded-xl border border-acid-400/30 bg-gradient-to-br from-acid-400 to-acid-500 text-ink-950 shadow-[0_8px_24px_-10px_rgba(198,244,91,0.8)]">
            <span className="absolute inset-0 opacity-20" style={{ backgroundImage: "linear-gradient(135deg, #000 1px, transparent 1px)", backgroundSize: "6px 6px" }} />
            <Hammer className="relative h-4 w-4" strokeWidth={2.2} />
          </span>
          <span>
            <span className="block text-[15px] font-bold leading-4 tracking-tight text-mist-100">Habitat</span>
            <span className="block text-[9px] font-medium uppercase tracking-[0.2em] text-mist-500">Property OS</span>
          </span>
        </button>
        <IconButton icon={X} label="Close navigation" onClick={() => setMobileOpen(false)} className="lg:hidden" />
      </div>

      <div className="mx-3 mb-4 flex items-center gap-2.5 rounded-xl border border-white/[0.07] bg-white/[0.03] p-2.5 transition hover:border-white/15">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg border border-aqua-400/25 bg-aqua-400/10 text-aqua-400">
          <Building2 className="h-3.5 w-3.5" />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[11.5px] font-semibold text-mist-200">Northwind Property Group</span>
          <span className="block text-[9.5px] text-mist-500">7 properties · 62 units</span>
        </span>
        <ChevronDown className="h-3.5 w-3.5 text-mist-500" />
      </div>

      <nav className="min-h-0 flex-1 overflow-y-auto px-3 pb-2">
        {navSections.map((section) => (
          <div key={section.label} className="mb-4">
            <p className="mb-1.5 px-2 text-[9px] font-semibold uppercase tracking-[0.16em] text-mist-600">{section.label}</p>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const isActive =
                  item.label === "Renovations"
                    ? route.name === "projects" || route.name === "project"
                    : item.route === "properties"
                      ? route.name === "properties"
                      : item.route === "contractors"
                        ? route.name === "contractors"
                        : item.route === "reports"
                          ? route.name === "reports"
                          : false;
                const ItemIcon = item.icon;
                return (
                  <button
                    key={item.label}
                    onClick={() => {
                      if (!item.live) {
                        notify(`${item.label} lives in the core rental system`, "info", "Renovations is the active module in this workspace.");
                        return;
                      }
                      if (item.route) go({ name: item.route });
                    }}
                    className={cn(
                      "group relative flex w-full items-center gap-2.5 rounded-lg px-2.5 py-[7px] text-left text-[12px] transition",
                      isActive ? "bg-acid-400/[0.09] font-semibold text-acid-200" : item.live ? "text-mist-300 hover:bg-white/[0.045] hover:text-mist-100" : "text-mist-500 hover:bg-white/[0.03]",
                    )}
                  >
                    {isActive && <span className="absolute left-0 top-1/2 h-4 w-[2.5px] -translate-y-1/2 rounded-r-full bg-acid-400 shadow-[0_0_8px_rgba(198,244,91,0.8)]" />}
                    <ItemIcon className={cn("h-[15px] w-[15px]", isActive ? "text-acid-300" : "text-mist-500 group-hover:text-mist-300")} strokeWidth={1.9} />
                    <span className="flex-1">{item.label}</span>
                    {"badge" in item && item.badge && <span className="flex h-[17px] min-w-[17px] items-center justify-center rounded-md bg-acid-400/15 px-1 font-mono text-[9px] font-semibold text-acid-300">{activeProjects.length}</span>}
                    {!item.live && <span className="rounded border border-white/[0.07] px-1 py-px text-[8px] uppercase tracking-wide text-mist-600">soon</span>}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="mx-3 mb-3 overflow-hidden rounded-xl border border-white/[0.07] bg-gradient-to-br from-white/[0.04] to-transparent">
        <div className="blueprint relative p-3">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-mist-400">
              <Sparkles className="h-3 w-3 text-acid-300" /> Q1 capital
            </span>
            <span className="font-mono text-[10px] text-acid-300">{utilisation}%</span>
          </div>
          <ProgressBar value={utilisation} className="mt-2" height="h-1" />
          <p className="mt-2 font-mono text-[13px] font-medium text-mist-100">{money(portfolioSpent, { compact: true })}<span className="text-mist-500"> / {money(portfolioBudget, { compact: true })}</span></p>
          <p className="text-[9.5px] text-mist-500">Incurred vs current approved budget</p>
          <button onClick={() => go({ name: "reports" })} className="mt-2 flex w-full items-center justify-between text-[10px] font-medium text-acid-300 transition hover:text-acid-200">
            Portfolio reports <ArrowUpRight className="h-3 w-3" />
          </button>
        </div>
      </div>

      <div className="border-t border-white/[0.06] p-3">
        <button onClick={() => notify("Preferences", "info", "Workspace settings are managed in the core system.")} className="flex w-full items-center gap-2.5 rounded-lg p-1.5 text-left transition hover:bg-white/[0.04]">
          <Avatar name={user.name} size="sm" />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[11.5px] font-semibold text-mist-200">{user.name}</span>
            <span className="block truncate text-[9.5px] text-mist-500">{user.role}</span>
          </span>
          <Settings className="h-3.5 w-3.5 text-mist-500" />
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen text-mist-200">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[236px] border-r border-white/[0.06] bg-ink-900/80 backdrop-blur-xl lg:block">{sidebar}</aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="animate-pop absolute inset-y-0 left-0 w-[270px] border-r border-white/10 bg-ink-900 shadow-2xl">{sidebar}</div>
        </div>
      )}

      <div className="lg:pl-[236px]">
        <header className="glass sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-white/[0.06] px-3 sm:px-5">
          <IconButton icon={Menu} label="Open navigation" onClick={() => setMobileOpen(true)} className="lg:hidden" />
          <div className="hidden items-center gap-1.5 text-[11px] sm:flex">
            <button onClick={() => go({ name: "projects" })} className="text-mist-500 transition hover:text-mist-300">Northwind</button>
            <ChevronRight className="h-3 w-3 text-mist-600" />
            <span className="text-mist-300">Renovations</span>
            {route.name === "project" && (
              <>
                <ChevronRight className="h-3 w-3 text-mist-600" />
                <span className="font-mono text-[10.5px] text-acid-300">{route.id}</span>
              </>
            )}
            {route.name === "contractors" && (
              <>
                <ChevronRight className="h-3 w-3 text-mist-600" />
                <span className="text-mist-300">Contractors</span>
              </>
            )}
            {route.name === "reports" && (
              <>
                <ChevronRight className="h-3 w-3 text-mist-600" />
                <span className="text-mist-300">Reports</span>
              </>
            )}
            {route.name === "properties" && (
              <>
                <ChevronRight className="h-3 w-3 text-mist-600" />
                <span className="text-mist-300">Properties</span>
              </>
            )}
          </div>

          <div className="relative ml-auto w-full max-w-[300px] sm:ml-auto sm:w-auto">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-mist-500" />
            <input
              ref={searchRef}
              value={search}
              onChange={(event) => {
                setSearch(event.target.value);
                setSearchOpen(true);
              }}
              onFocus={() => setSearchOpen(true)}
              placeholder="Search projects, contractors…"
              className="h-8 w-full rounded-lg border border-white/[0.08] bg-ink-900/70 pl-8 pr-12 text-[11.5px] text-mist-200 outline-none transition placeholder:text-mist-500 focus:border-acid-400/40 focus:bg-ink-900 sm:w-[260px]"
            />
            <kbd className="pointer-events-none absolute right-2 top-1/2 hidden -translate-y-1/2 rounded border border-white/10 bg-white/[0.04] px-1 py-0.5 font-mono text-[9px] text-mist-500 sm:block">⌘K</kbd>
            {searchOpen && search.trim() && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setSearchOpen(false)} />
                <div className="animate-pop absolute right-0 top-10 z-40 w-[360px] overflow-hidden rounded-xl border border-white/10 bg-ink-850 shadow-2xl">
                  <div className="max-h-[380px] overflow-y-auto p-1.5">
                    <p className="px-2 py-1 text-[9px] font-semibold uppercase tracking-[0.14em] text-mist-500">Projects</p>
                    {searchResults.projects.length === 0 && <p className="px-2 py-2 text-[11px] text-mist-500">No matching projects</p>}
                    {searchResults.projects.map((project) => (
                      <button key={project.id} onClick={() => go({ name: "project", id: project.id })} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left transition hover:bg-white/[0.05]">
                        <span className="flex h-6 w-6 items-center justify-center rounded-md border border-white/[0.07] bg-white/[0.03] text-acid-300"><Hammer className="h-3 w-3" /></span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[11.5px] font-medium text-mist-200">{project.name}</span>
                          <span className="block truncate text-[10px] text-mist-500">{project.propertyName} · Unit {project.unitNumber} · {project.id}</span>
                        </span>
                        <StatusBadge status={project.status} dot={false} />
                      </button>
                    ))}
                    {searchResults.contractors.length > 0 && <p className="px-2 pb-1 pt-2 text-[9px] font-semibold uppercase tracking-[0.14em] text-mist-500">Contractors</p>}
                    {searchResults.contractors.map((contractor) => (
                      <button key={contractor.id} onClick={() => go({ name: "contractors" })} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left transition hover:bg-white/[0.05]">
                        <Avatar name={contractor.name} size="xs" />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-[11.5px] font-medium text-mist-200">{contractor.name}</span>
                          <span className="block truncate text-[10px] text-mist-500">{contractor.trade}</span>
                        </span>
                        <ChevronRight className="h-3 w-3 text-mist-500" />
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="relative flex items-center gap-1">
            <span className="hidden items-center gap-1.5 rounded-md border border-white/[0.07] bg-white/[0.03] px-2 py-1 text-[10px] text-mist-400 xl:flex">
              <span className="h-1.5 w-1.5 rounded-full bg-acid-400 shadow-[0_0_6px_rgba(198,244,91,.9)]" /> Feb 16, 2026
            </span>
            <div className="relative">
              <button
                onClick={() => setNotificationsOpen((open) => !open)}
                aria-label="Notifications"
                className="relative flex h-8 w-8 items-center justify-center rounded-lg text-mist-400 transition hover:bg-white/[0.06] hover:text-mist-100"
              >
                <Bell className="h-[17px] w-[17px]" strokeWidth={1.8} />
                {notifications.length > 0 && <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-rose-400 ring-2 ring-ink-900" />}
              </button>
              {notificationsOpen && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setNotificationsOpen(false)} />
                  <div className="animate-pop absolute right-0 top-10 z-40 w-[330px] overflow-hidden rounded-xl border border-white/10 bg-ink-850 shadow-2xl">
                    <div className="flex items-center justify-between border-b border-white/[0.07] px-3 py-2.5">
                      <p className="text-[12px] font-semibold text-mist-100">Operational alerts</p>
                      <Badge tone="rose">{notifications.length} open</Badge>
                    </div>
                    <div className="max-h-[320px] overflow-y-auto p-1.5">
                      {notifications.length === 0 && <p className="px-2 py-4 text-center text-[11px] text-mist-500">Nothing needs attention. Nice work.</p>}
                      {notifications.map((notification, index) => (
                        <button
                          key={`${notification.projectId}-${index}`}
                          onClick={() => {
                            go({ name: "project", id: notification.projectId });
                            setNotificationsOpen(false);
                          }}
                          className="flex w-full items-start gap-2 rounded-lg px-2 py-2 text-left transition hover:bg-white/[0.05]"
                        >
                          <span className={cn("mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full", notification.tone === "rose" ? "bg-rose-400" : notification.tone === "amber" ? "bg-amber-400" : notification.tone === "sky" ? "bg-sky-400" : "bg-acid-400")} />
                          <span className="min-w-0 flex-1">
                            <span className="block text-[11.5px] font-medium leading-snug text-mist-200">{notification.title}</span>
                            <span className="block truncate text-[10px] text-mist-500">{notification.detail}</span>
                          </span>
                          <ChevronRight className="mt-1 h-3 w-3 shrink-0 text-mist-600" />
                        </button>
                      ))}
                    </div>
                    <div className="border-t border-white/[0.07] p-2">
                      <Button size="xs" variant="ghost" className="w-full justify-between" icon={CircleHelp} onClick={() => notify("Notification rules", "info", "Alerts are generated from invoice due dates, compliance expiry, deficiencies and pending approvals.")}>
                        How alerts work <ArrowUpRight className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </div>
            <IconButton icon={LifeBuoy} label="Help & support" onClick={() => notify("Help centre", "info", "Search the knowledge base or contact workspace support.")} className="hidden sm:inline-flex" />
            <div className="ml-1 hidden h-6 w-px bg-white/10 sm:block" />
            <button onClick={() => notify("Account", "info", `${user.name} · ${user.role} · Full renovation module permissions.`)} className="ml-1 flex items-center gap-1.5 rounded-full">
              <Avatar name={user.name} size="sm" />
              <ChevronDown className="hidden h-3 w-3 text-mist-500 sm:block" />
            </button>
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1500px] px-3 pb-16 pt-4 sm:px-5 lg:pt-5">{children}</main>
      </div>

      <ToastHost />
    </div>
  );
}

function ToastHost() {
  const { toasts, dismissToast } = useStore();
  return (
    <div className="pointer-events-none fixed bottom-4 right-3 z-[60] flex w-[calc(100%-24px)] max-w-sm flex-col gap-2 sm:right-5">
      {toasts.map((toast) => {
        const palette = {
          success: { border: "border-acid-400/30", icon: "bg-acid-400/15 text-acid-300", Icon: Hammer },
          error: { border: "border-rose-400/30", icon: "bg-rose-400/15 text-rose-300", Icon: X },
          warning: { border: "border-amber-400/30", icon: "bg-amber-400/15 text-amber-300", Icon: CircleHelp },
          info: { border: "border-sky-400/30", icon: "bg-sky-400/15 text-sky-300", Icon: CircleHelp },
        }[toast.tone];
        const ToastIcon = palette.Icon;
        return (
          <div key={toast.id} className={cn("animate-toast pointer-events-auto flex items-start gap-2.5 rounded-xl border bg-ink-800/95 p-3 shadow-2xl backdrop-blur", palette.border)}>
            <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-lg", palette.icon)}><ToastIcon className="h-3.5 w-3.5" /></span>
            <div className="min-w-0 flex-1">
              <p className="text-[12px] font-semibold text-mist-100">{toast.title}</p>
              {toast.description && <p className="mt-0.5 text-[10.5px] leading-relaxed text-mist-400">{toast.description}</p>}
            </div>
            <button onClick={() => dismissToast(toast.id)} aria-label="Dismiss" className="text-mist-500 transition hover:text-mist-200"><X className="h-3.5 w-3.5" /></button>
          </div>
        );
      })}
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  subtitle,
  description,
  actions,
  children,
}: {
  eyebrow?: ReactNode;
  title: ReactNode;
  subtitle?: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <div className="animate-in mb-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          {eyebrow && <div className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-acid-300/80">{eyebrow}</div>}
          <h1 className="text-balance text-[23px] font-semibold leading-tight tracking-[-0.02em] text-mist-100 sm:text-[27px]">{title}</h1>
          {(subtitle || description) && <p className="mt-1 max-w-2xl text-[12px] leading-relaxed text-mist-400">{subtitle ?? description}</p>}
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </div>
      {children}
    </div>
  );
}

export function NewButton({ onClick, label = "New project" }: { onClick: () => void; label?: string }) {
  return (
    <Button variant="primary" size="md" icon={Plus} onClick={onClick} className="shine">
      {label}
    </Button>
  );
}

export function CapacityRing() {
  const { projects } = useStore();
  const totals = projects.reduce(
    (acc, project) => {
      const fin = projectFinancials(project);
      return { budget: acc.budget + fin.currentBudget, incurred: acc.incurred + fin.incurred };
    },
    { budget: 0, incurred: 0 },
  );
  const pct = totals.budget ? Math.round((totals.incurred / totals.budget) * 100) : 0;
  return (
    <ProgressRing value={pct} size={62} stroke={5} tone={pct > 85 ? "rose" : "acid"}>
      <span className="font-mono text-[12px] font-semibold text-mist-100">{pct}%</span>
      <span className="text-[7.5px] uppercase tracking-wide text-mist-500">spent</span>
    </ProgressRing>
  );
}

export { FileText };
