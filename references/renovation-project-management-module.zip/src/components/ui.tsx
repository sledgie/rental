import { useEffect, useId, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Info,
  Loader2,
  X,
  type LucideIcon,
} from "lucide-react";
import { cn } from "../utils/cn";

/* ------------------------------- Buttons ------------------------------- */

type ButtonVariant = "primary" | "secondary" | "ghost" | "danger" | "outline" | "subtle";
type ButtonSize = "xs" | "sm" | "md" | "lg" | "icon";

const buttonVariants: Record<ButtonVariant, string> = {
  primary:
    "bg-acid-400 text-ink-950 font-semibold hover:bg-acid-300 active:bg-acid-500 shadow-[0_10px_30px_-14px_rgba(198,244,91,0.85)] border border-acid-300/40",
  secondary:
    "bg-white/[0.045] text-mist-100 border border-white/10 hover:bg-white/[0.085] hover:border-white/20",
  ghost: "text-mist-300 hover:text-mist-100 hover:bg-white/[0.055] border border-transparent",
  danger: "bg-rose-500/12 text-rose-200 border border-rose-400/25 hover:bg-rose-500/20",
  outline: "border border-white/15 text-mist-200 hover:bg-white/[0.05] hover:text-white",
  subtle: "bg-ink-700/70 text-mist-200 border border-white/[0.06] hover:bg-ink-600/70",
};

const buttonSizes: Record<ButtonSize, string> = {
  xs: "h-7 px-2.5 text-[11px] gap-1.5 rounded-lg",
  sm: "h-8 px-3 text-xs gap-1.5 rounded-lg",
  md: "h-10 px-4 text-[13px] gap-2 rounded-xl",
  lg: "h-11 px-5 text-sm gap-2 rounded-xl",
  icon: "h-9 w-9 rounded-lg",
};

export function Button({
  variant = "secondary",
  size = "md",
  icon: Icon,
  iconRight: IconRight,
  loading,
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: LucideIcon;
  iconRight?: LucideIcon;
  loading?: boolean;
}) {
  return (
    <button
      {...props}
      disabled={props.disabled || loading}
      className={cn(
        "inline-flex items-center justify-center whitespace-nowrap font-medium transition-all duration-150 outline-none focus-visible:ring-2 focus-visible:ring-acid-400/50 disabled:cursor-not-allowed disabled:opacity-45",
        buttonVariants[variant],
        buttonSizes[size],
        className,
      )}
    >
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : Icon ? <Icon className={size === "xs" ? "h-3.5 w-3.5" : "h-4 w-4"} strokeWidth={1.9} /> : null}
      {children}
      {IconRight ? <IconRight className="h-3.5 w-3.5" strokeWidth={2} /> : null}
    </button>
  );
}

export function IconButton({
  icon: Icon,
  label,
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { icon: LucideIcon; label: string }) {
  return (
    <button
      {...props}
      aria-label={label}
      title={label}
      className={cn(
        "inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/[0.07] bg-white/[0.03] text-mist-400 transition hover:border-white/15 hover:bg-white/[0.08] hover:text-mist-100",
        className,
      )}
    >
      <Icon className="h-4 w-4" strokeWidth={1.9} />
    </button>
  );
}

/* -------------------------------- Badges -------------------------------- */

export type Tone = "slate" | "sky" | "violet" | "acid" | "amber" | "aqua" | "rose" | "orange";

const tones: Record<Tone, string> = {
  slate: "bg-white/[0.06] text-mist-300 border-white/10",
  sky: "bg-sky-400/10 text-sky-300 border-sky-400/25",
  violet: "bg-violet-400/10 text-violet-300 border-violet-400/25",
  acid: "bg-acid-400/12 text-acid-300 border-acid-400/30",
  amber: "bg-amber-400/10 text-amber-300 border-amber-400/25",
  aqua: "bg-teal-400/10 text-teal-300 border-teal-400/25",
  rose: "bg-rose-400/10 text-rose-300 border-rose-400/25",
  orange: "bg-orange-400/10 text-orange-300 border-orange-400/25",
};

const toneDots: Record<Tone, string> = {
  slate: "bg-mist-400",
  sky: "bg-sky-400",
  violet: "bg-violet-400",
  acid: "bg-acid-400",
  amber: "bg-amber-400",
  aqua: "bg-teal-400",
  rose: "bg-rose-400",
  orange: "bg-orange-400",
};

export function Badge({
  tone = "slate",
  dot,
  icon: Icon,
  children,
  className,
}: {
  tone?: Tone;
  dot?: boolean;
  icon?: LucideIcon;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[10.5px] font-semibold leading-4 tracking-wide", tones[tone], className)}>
      {dot && <span className={cn("h-1.5 w-1.5 rounded-full", toneDots[tone], tone === "acid" && "shadow-[0_0_6px_rgba(198,244,91,.9)]")} />}
      {Icon && <Icon className="h-3 w-3" strokeWidth={2.1} />}
      {children}
    </span>
  );
}

const statusTone: Record<string, Tone> = {
  Draft: "slate",
  Planned: "sky",
  Approved: "violet",
  "In Progress": "acid",
  "On Hold": "amber",
  Completed: "aqua",
  Cancelled: "rose",
  "Not Started": "slate",
  Blocked: "rose",
  "Pending Approval": "amber",
  Rejected: "rose",
  "Partially Paid": "sky",
  Unpaid: "slate",
  Paid: "aqua",
  Overdue: "rose",
  Pass: "aqua",
  Fail: "rose",
  Conditional: "amber",
  Scheduled: "sky",
  Pending: "amber",
  Resolved: "sky",
  Verified: "aqua",
  Open: "rose",
  Inactive: "slate",
  Active: "acid",
  Assigned: "sky",
  Complete: "aqua",
  Released: "slate",
  Low: "slate",
  Normal: "sky",
  High: "amber",
  Emergency: "rose",
  Medium: "amber",
  Critical: "rose",
  Accepted: "aqua",
  Declined: "rose",
  Expired: "slate",
  Ordered: "violet",
  Received: "aqua",
};

export function StatusBadge({ status, dot = true, className }: { status: string; dot?: boolean; className?: string }) {
  return (
    <Badge tone={statusTone[status] ?? "slate"} dot={dot} className={className}>
      {status}
    </Badge>
  );
}

export function PermissionNote({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 text-[10px] text-mist-500">
      <Info className="h-3 w-3" /> {children}
    </span>
  );
}

/* -------------------------------- Surfaces ------------------------------- */

export function Card({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div {...props} className={cn("panel rounded-2xl", className)}>
      {children}
    </div>
  );
}

export function SectionHeader({
  title,
  subtitle,
  icon: Icon,
  action,
  className,
}: {
  title: ReactNode;
  subtitle?: ReactNode;
  icon?: LucideIcon;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-wrap items-start justify-between gap-3", className)}>
      <div className="flex min-w-0 items-start gap-2.5">
        {Icon && (
          <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-white/[0.07] bg-white/[0.035] text-acid-300">
            <Icon className="h-3.5 w-3.5" strokeWidth={1.9} />
          </span>
        )}
        <div className="min-w-0">
          <h3 className="text-[13.5px] font-semibold tracking-tight text-mist-100">{title}</h3>
          {subtitle && <p className="mt-0.5 text-[11.5px] leading-relaxed text-mist-400">{subtitle}</p>}
        </div>
      </div>
      {action && <div className="flex shrink-0 items-center gap-2">{action}</div>}
    </div>
  );
}

/* ------------------------------ Progress ------------------------------- */

export function ProgressBar({
  value,
  tone = "acid",
  className,
  height = "h-1.5",
  label,
}: {
  value: number;
  tone?: "acid" | "aqua" | "amber" | "rose" | "sky" | "violet";
  className?: string;
  height?: string;
  label?: string;
}) {
  const safe = Math.max(0, Math.min(100, value));
  const gradients = {
    acid: "from-acid-500 to-acid-300",
    aqua: "from-teal-500 to-aqua-400",
    amber: "from-amber-500 to-amber-300",
    rose: "from-rose-500 to-rose-300",
    sky: "from-sky-500 to-sky-300",
    violet: "from-violet-500 to-violet-300",
  };
  return (
    <div className={cn("relative overflow-hidden rounded-full bg-white/[0.07]", height, className)}>
      <div
        className={cn("h-full rounded-full bg-gradient-to-r transition-all duration-700", gradients[tone])}
        style={{ width: `${safe}%` }}
        role="progressbar"
        aria-valuenow={safe}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label ?? "Progress"}
      />
    </div>
  );
}

export function ProgressRing({
  value,
  size = 72,
  stroke = 6,
  tone = "acid",
  children,
  className,
}: {
  value: number;
  size?: number;
  stroke?: number;
  tone?: "acid" | "aqua" | "amber" | "rose" | "sky";
  children?: ReactNode;
  className?: string;
}) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const safe = Math.max(0, Math.min(100, value));
  const colors = { acid: "#c6f45b", aqua: "#5ee6d0", amber: "#ffc861", rose: "#ff7d8a", sky: "#7dd3fc" };
  return (
    <div className={cn("relative inline-flex shrink-0 items-center justify-center", className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={colors[tone]}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference - (safe / 100) * circumference}
          style={{ transition: "stroke-dashoffset .8s cubic-bezier(.16,1,.3,1)", filter: `drop-shadow(0 0 6px ${colors[tone]}55)` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}

export function Sparkline({
  values,
  tone = "acid",
  height = 32,
  width = 92,
}: {
  values: number[];
  tone?: "acid" | "aqua" | "amber" | "rose";
  height?: number;
  width?: number;
}) {
  const colors = { acid: "#c6f45b", aqua: "#5ee6d0", amber: "#ffc861", rose: "#ff7d8a" };
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const points = values.map((v, i) => {
    const x = (i / Math.max(values.length - 1, 1)) * width;
    const y = height - ((v - min) / Math.max(max - min, 1)) * (height - 4) - 2;
    return `${x},${y}`;
  });
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
      <polyline points={`0,${height} ${points.join(" ")} ${width},${height}`} fill={`${colors[tone]}14`} stroke="none" />
      <polyline points={points.join(" ")} fill="none" stroke={colors[tone]} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={width} cy={points[points.length - 1]?.split(",")[1]} r={2.4} fill={colors[tone]} />
    </svg>
  );
}

/* -------------------------------- Avatars -------------------------------- */

const avatarHues = [76, 168, 202, 262, 22, 320, 44, 148];

export function Avatar({ name, size = "md", className }: { name: string; size?: "xs" | "sm" | "md" | "lg"; className?: string }) {
  const initials = name
    .split(/[\s.]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
  const hue = avatarHues[name.split("").reduce((sum, char) => sum + char.charCodeAt(0), 0) % avatarHues.length];
  const sizes = { xs: "h-5 w-5 text-[8px]", sm: "h-7 w-7 text-[10px]", md: "h-9 w-9 text-[11px]", lg: "h-12 w-12 text-sm" };
  return (
    <span
      className={cn("inline-flex shrink-0 items-center justify-center rounded-full border font-semibold tracking-wide", sizes[size], className)}
      style={{ background: `hsl(${hue} 45% 16%)`, borderColor: `hsl(${hue} 55% 32%)`, color: `hsl(${hue} 80% 76%)` }}
      title={name}
    >
      {initials || "?"}
    </span>
  );
}

/* -------------------------------- Modal -------------------------------- */

export function Modal({
  open,
  onClose,
  title,
  description,
  icon: Icon,
  children,
  footer,
  size = "md",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  icon?: LucideIcon;
  children: ReactNode;
  footer?: ReactNode;
  size?: "sm" | "md" | "lg" | "xl";
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [open, onClose]);

  if (!open) return null;
  const widths = { sm: "max-w-md", md: "max-w-2xl", lg: "max-w-4xl", xl: "max-w-5xl" };
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-sm" onClick={onClose} aria-hidden />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cn(
          "animate-pop relative z-10 flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-2xl border border-white/10 bg-ink-850 shadow-[0_40px_120px_-20px_rgba(0,0,0,0.9)] sm:rounded-2xl",
          widths[size],
        )}
      >
        <div className="blueprint flex items-start justify-between gap-4 border-b border-white/[0.07] bg-gradient-to-b from-white/[0.045] to-transparent px-5 py-4">
          <div className="flex items-start gap-3">
            {Icon && (
              <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-acid-400/25 bg-acid-400/10 text-acid-300">
                <Icon className="h-4 w-4" strokeWidth={1.9} />
              </span>
            )}
            <div>
              <h2 className="text-[15px] font-semibold tracking-tight text-mist-100">{title}</h2>
              {description && <p className="mt-0.5 max-w-lg text-xs leading-relaxed text-mist-400">{description}</p>}
            </div>
          </div>
          <IconButton icon={X} label="Close dialog" onClick={onClose} />
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex flex-wrap items-center justify-end gap-2 border-t border-white/[0.07] bg-ink-900/60 px-5 py-3.5">{footer}</div>}
      </div>
    </div>
  );
}

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  description,
  confirmLabel = "Confirm",
  tone = "primary",
  children,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmLabel?: string;
  tone?: "primary" | "danger";
  children?: ReactNode;
}) {
  return (
    <Modal open={open} onClose={onClose} title={title} description={description} icon={AlertTriangle} size="sm"
      footer={
        <>
          <Button variant="ghost" size="md" onClick={onClose}>Cancel</Button>
          <Button variant={tone === "danger" ? "danger" : "primary"} size="md" icon={CheckCircle2} onClick={onConfirm}>{confirmLabel}</Button>
        </>
      }
    >
      {children ?? (
        <p className="rounded-xl border border-white/[0.07] bg-white/[0.025] p-3 text-xs leading-relaxed text-mist-400">
          This action is recorded in the project audit trail with your name, the timestamp and the reason provided. Financial history is preserved.
        </p>
      )}
    </Modal>
  );
}

/* -------------------------------- Forms -------------------------------- */

export const inputClass =
  "h-9 w-full rounded-lg border border-white/[0.09] bg-ink-900/80 px-3 text-[12.5px] text-mist-100 shadow-inner shadow-black/20 outline-none transition placeholder:text-mist-500 hover:border-white/20 focus:border-acid-400/60 focus:ring-2 focus:ring-acid-400/15 disabled:opacity-50";

export function Field({
  label,
  hint,
  error,
  required,
  children,
  className,
  htmlFor,
}: {
  label: string;
  hint?: string;
  error?: string;
  required?: boolean;
  children: ReactNode;
  className?: string;
  htmlFor?: string;
}) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <label htmlFor={htmlFor} className="flex items-center gap-1 text-[10.5px] font-semibold uppercase tracking-[0.09em] text-mist-400">
        {label} {required && <span className="text-acid-400">*</span>}
      </label>
      {children}
      {error ? (
        <p className="flex items-center gap-1 text-[10.5px] text-rose-300"><AlertTriangle className="h-3 w-3" /> {error}</p>
      ) : hint ? (
        <p className="text-[10.5px] leading-relaxed text-mist-500">{hint}</p>
      ) : null}
    </div>
  );
}

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cn(inputClass, className)} />;
}

export function Select({ className, children, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select {...props} className={cn(inputClass, "select-chevron appearance-none pr-8", className)}>
      {children}
    </select>
  );
}

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cn(inputClass, "h-auto min-h-[76px] resize-y py-2 leading-relaxed", className)} />;
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (checked: boolean) => void; label: string }) {
  const id = useId();
  return (
    <div className="flex items-center gap-2.5">
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn("relative h-5 w-9 shrink-0 rounded-full border transition", checked ? "border-acid-400/50 bg-acid-400/80" : "border-white/10 bg-white/[0.07]")}
      >
        <span className={cn("absolute top-0.5 h-3.5 w-3.5 rounded-full bg-ink-950 transition-all", checked ? "left-[18px] bg-ink-950" : "left-0.5 bg-mist-400")} />
      </button>
      <label htmlFor={id} className="cursor-pointer text-xs text-mist-300">{label}</label>
    </div>
  );
}

/* ------------------------------ Empty / misc ----------------------------- */

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  compact,
}: {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: ReactNode;
  compact?: boolean;
}) {
  return (
    <div className={cn("flex flex-col items-center justify-center rounded-xl border border-dashed border-white/10 bg-white/[0.015] text-center", compact ? "px-4 py-6" : "px-6 py-12")}>
      <span className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl border border-white/[0.07] bg-white/[0.03] text-mist-400">
        <Icon className="h-5 w-5" strokeWidth={1.6} />
      </span>
      <p className="text-[13px] font-medium text-mist-200">{title}</p>
      {description && <p className="mt-1 max-w-sm text-[11.5px] leading-relaxed text-mist-500">{description}</p>}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

export function InfoNote({ children, tone = "info" }: { children: ReactNode; tone?: "info" | "warning" | "success" }) {
  const styles = {
    info: "border-sky-400/20 bg-sky-400/[0.06] text-sky-200/80",
    warning: "border-amber-400/20 bg-amber-400/[0.06] text-amber-200/80",
    success: "border-acid-400/20 bg-acid-400/[0.055] text-acid-200/80",
  };
  const NoteIcon = tone === "warning" ? AlertTriangle : tone === "success" ? CheckCircle2 : Info;
  return (
    <div className={cn("flex items-start gap-2 rounded-lg border px-3 py-2 text-[11px] leading-relaxed", styles[tone])}>
      <NoteIcon className="mt-0.5 h-3.5 w-3.5 shrink-0" strokeWidth={1.9} />
      <span>{children}</span>
    </div>
  );
}

export function Metric({
  label,
  value,
  hint,
  tone,
  icon,
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  tone?: "default" | "positive" | "warning" | "negative";
  icon?: LucideIcon;
}) {
  const tones = {
    default: "text-mist-100",
    positive: "text-acid-300",
    warning: "text-amber-300",
    negative: "text-rose-300",
  };
  return (
    <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
      <p className="flex items-center gap-1 text-[9.5px] font-semibold uppercase tracking-[0.1em] text-mist-500">
        {icon && (() => { const MetricIcon = icon; return <MetricIcon className="h-3 w-3" strokeWidth={2} />; })()} {label}
      </p>
      <p className={cn("mt-1 font-mono text-[15px] font-medium tracking-tight", tones[tone ?? "default"])}>{value}</p>
      {hint && <p className="mt-0.5 text-[10px] leading-tight text-mist-500">{hint}</p>}
    </div>
  );
}

export function LinkRow({ label, value, icon: Icon }: { label: string; value: ReactNode; icon?: LucideIcon }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1.5">
      <span className="flex min-w-0 items-center gap-1.5 text-[11px] text-mist-400">
        {Icon && <Icon className="h-3 w-3 shrink-0" strokeWidth={1.8} />}
        <span className="truncate">{label}</span>
      </span>
      <span className="shrink-0 text-right text-[11px] font-medium text-mist-200">{value}</span>
    </div>
  );
}

export function Breadcrumb({ items }: { items: { label: string; onClick?: () => void }[] }) {
  return (
    <nav className="flex items-center gap-1.5 text-[11px] text-mist-500">
      {items.map((item, index) => (
        <span key={`${item.label}-${index}`} className="flex items-center gap-1.5">
          {index > 0 && <ChevronRight className="h-3 w-3 text-mist-600" />}
          {item.onClick ? (
            <button onClick={item.onClick} className="transition hover:text-acid-300">{item.label}</button>
          ) : (
            <span className={index === items.length - 1 ? "text-mist-300" : ""}>{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

export function ToneIcon({ icon: Icon, tone = "acid", size = "md" }: { icon: LucideIcon; tone?: Tone; size?: "sm" | "md" | "lg" }) {
  const sizes = { sm: "h-7 w-7", md: "h-9 w-9", lg: "h-11 w-11" };
  const iconSizes = { sm: "h-3.5 w-3.5", md: "h-4 w-4", lg: "h-5 w-5" };
  return (
    <span className={cn("inline-flex shrink-0 items-center justify-center rounded-xl border", sizes[size], tones[tone])}>
      <Icon className={iconSizes[size]} strokeWidth={1.9} />
    </span>
  );
}

export { CheckCircle2, AlertTriangle };
