import { MOCK_NOTIFICATIONS } from "@/notifications/mockNotifications";
import {
  applyNotificationFilters,
  getVisibleNotifications,
  groupNotifications,
  isRedacted,
  summarize,
  sortNotifications,
  type NotificationScope,
} from "@/notifications/logic";
import { permissionsFor } from "@/lib/rbac";
import { PROPERTIES } from "@/lib/mockData";
import { NOTIFICATION_FILTER_DEFAULTS } from "@/notifications/types";

const ownerScope: NotificationScope = {
  organizationId: "org-evergreen",
  userId: "user-maya",
  role: "owner",
  granted: permissionsFor("user-maya", "org-evergreen"),
};
const investorScope: NotificationScope = {
  organizationId: "org-evergreen",
  userId: "user-hana",
  role: "read_only_investor",
  granted: permissionsFor("user-hana", "org-evergreen"),
};

const total = MOCK_NOTIFICATIONS.length;
const evergreen = MOCK_NOTIFICATIONS.filter((n) => n.organizationId === "org-evergreen");
const northline = MOCK_NOTIFICATIONS.filter((n) => n.organizationId === "org-northline");
const visible = getVisibleNotifications(MOCK_NOTIFICATIONS, ownerScope);
const dismissed = visible.filter((n) => n.dismissedAt).length;
const unread = visible.filter((n) => !n.readAt);
const urgent = unread.filter((n) => n.severity === "critical" || n.severity === "high");

console.log("total mock notifications:", total);
console.log("evergreen / northline:", evergreen.length, "/", northline.length);
console.log("owner visible (active, scoped, permitted):", visible.length);
console.log("dismissed leaking into inbox:", dismissed);
console.log("summary:", summarize(visible));
console.log("unread:", unread.length, "urgent:", urgent.length);
console.log("snoozed hidden:", visible.every((n) => n.id !== "ntf-1078"));
console.log("group buckets:", groupNotifications(sortNotifications(visible)).map((g) => `${g.label}=${g.items.length}`).join(", "));

// Scoping: northline records must never appear for the evergreen owner
console.log("cross-org leak:", visible.some((n) => n.organizationId !== "org-evergreen"));

// Investor sees fewer notifications and gets redaction
const investorVisible = getVisibleNotifications(MOCK_NOTIFICATIONS, investorScope);
console.log("investor visible:", investorVisible.length, "vs owner:", visible.length);
console.log("investor redacted rows:", investorVisible.filter((n) => isRedacted(n, investorScope)).map((n) => n.id));

// Search across title, message, property, unit, entity reference
for (const q of ["overdue", "harborview", "loft 9", "INV-2041", "sofia", "nonexistentterm"]) {
  const count = applyNotificationFilters(visible, { ...NOTIFICATION_FILTER_DEFAULTS, query: q }, ownerScope).length;
  console.log(`search "${q}":`, count);
}

// Filters
console.log(
  "unread+financial+severity high:",
  applyNotificationFilters(visible, { ...NOTIFICATION_FILTER_DEFAULTS, tab: "unread", category: "financial", severity: "high" }, ownerScope).length
);
const prop = PROPERTIES.find((p) => p.name === "Harborview Lofts")!;
console.log(
  "property filter (Harborview):",
  applyNotificationFilters(visible, { ...NOTIFICATION_FILTER_DEFAULTS, propertyId: prop.id }, ownerScope).length
);
console.log(
  "record type=invoice:",
  applyNotificationFilters(visible, { ...NOTIFICATION_FILTER_DEFAULTS, entityType: "invoice" }, ownerScope).length
);
const dates = [...new Set(visible.map((n) => n.createdAt.slice(0, 10)))].sort();
console.log(
  "date range (latest day only):",
  applyNotificationFilters(visible, { ...NOTIFICATION_FILTER_DEFAULTS, fromDate: dates[dates.length - 1] }, ownerScope).length
);
console.log(
  "assigned to me:",
  applyNotificationFilters(visible, { ...NOTIFICATION_FILTER_DEFAULTS, tab: "assigned" }, ownerScope).length
);
console.log(
  "read-status=read:",
  applyNotificationFilters(visible, { ...NOTIFICATION_FILTER_DEFAULTS, readStatus: "read" }, ownerScope).length
);
console.log("distinct categories:", [...new Set(visible.map((n) => n.category))].length);
console.log("notifications without property:", visible.filter((n) => !n.propertyName).length);
console.log("mock severity mix:", visible.reduce((acc, n) => ({ ...acc, [n.severity]: (acc[n.severity] ?? 0) + 1 }), {} as Record<string, number>));
