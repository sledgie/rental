import { JSDOM } from "jsdom";
import * as React from "react";
import { createRoot } from "react-dom/client";

const dom = new JSDOM("<!doctype html><html><body><div id='root'></div></body></html>", { url: "https://loft.example/#/notifications", pretendToBeVisual: true });
(globalThis as any).window = dom.window;
(globalThis as any).document = dom.window.document;
(globalThis as any).navigator = dom.window.navigator;
(globalThis as any).HTMLElement = dom.window.HTMLElement;
(globalThis as any).Element = dom.window.Element;
(globalThis as any).Node = dom.window.Node;
(globalThis as any).Event = dom.window.Event;
(globalThis as any).HTMLInputElement = dom.window.HTMLInputElement;
(globalThis as any).requestAnimationFrame = (cb: any) => setTimeout(() => cb(Date.now()), 0);
(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;

const { HashRouter } = require("react-router-dom");
const { AppProvider } = require("@/state/AppStore");
const { ToastProvider } = require("@/components/ui/Toast");
const App = require("@/App").default;
const act = (React as any).act;

const container = document.getElementById("root")!;
const root = createRoot(container);
const render = async (userId: string) => {
  window.location.hash = "#/notifications";
  await act(async () => {
    root.render(
      <AppProvider key={userId} initialUserId={userId}>
        <ToastProvider>
          <HashRouter><App /></HashRouter>
        </ToastProvider>
      </AppProvider>
    );
  });
  await act(async () => { await new Promise((r) => setTimeout(r, 15)); });
};
const $$ = (s: string) => Array.from(document.querySelectorAll(s));

const watchdog = setTimeout(() => { console.error("TIMEOUT"); process.exit(9); }, 25000);
(async () => {
  await render("user-maya");
  console.log("rows:", $$("ul.divide-y > li").length);
  console.log("unread spans:", $$('span[aria-label="Unread"]').length);
  console.log("group headings:", $$("section[aria-label*='notifications'] h2").map((h) => h.textContent));
  console.log("titles:", $$("ul.divide-y > li h3").map((h) => h.textContent!.slice(0, 42)));

  const input = document.querySelector("input[type='search']") as HTMLInputElement;
  console.log("input value before:", JSON.stringify(input.value));
  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")!.set!;
  await act(async () => {
    setter.call(input, "harborview");
    input.dispatchEvent(new window.Event("input", { bubbles: true }));
    await new Promise((r) => setTimeout(r, 5));
  });
  console.log("input value after:", JSON.stringify(input.value), "rows:", $$("ul.divide-y > li").length);

  // investor
  await render("user-hana");
  console.log("investor rows:", $$("ul.divide-y > li").length);
  console.log("investor titles:", $$("ul.divide-y > li h3").map((h) => h.textContent!.slice(0, 42)));
  console.log("restricted badge:", document.body.textContent!.includes("Restricted"));
  clearTimeout(watchdog);
  process.exit(0);
})();
