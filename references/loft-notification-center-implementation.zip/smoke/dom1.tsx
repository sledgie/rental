import { JSDOM } from "jsdom";
import * as React from "react";
import { createRoot } from "react-dom/client";

const dom = new JSDOM("<!doctype html><html><body><div id='root'></div></body></html>", {
  url: "https://loft.example/#/notifications",
  pretendToBeVisual: true,
});
(globalThis as any).window = dom.window;
(globalThis as any).document = dom.window.document;
(globalThis as any).navigator = dom.window.navigator;
(globalThis as any).HTMLElement = dom.window.HTMLElement;
(globalThis as any).Element = dom.window.Element;
(globalThis as any).Node = dom.window.Node;
(globalThis as any).requestAnimationFrame = (cb: any) => setTimeout(() => cb(Date.now()), 0);
(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;

const { HashRouter } = require("react-router-dom");
const { AppProvider } = require("@/state/AppStore");
const { ToastProvider } = require("@/components/ui/Toast");
const App = require("@/App").default;
const act = (React as any).act;

const container = document.getElementById("root")!;
const root = createRoot(container);

const watchdog = setTimeout(() => {
  console.error("TIMEOUT — dumping body length:", document.body.textContent?.length);
  process.exit(9);
}, 20000);

(async () => {
  console.log("render start");
  window.location.hash = "#/notifications";
  await act(async () => {
    root.render(
      <AppProvider>
        <ToastProvider>
          <HashRouter>
            <App />
          </HashRouter>
        </ToastProvider>
      </AppProvider>
    );
  });
  console.log("first render done, body length:", document.body.textContent?.length);
  await act(async () => { await new Promise((r) => setTimeout(r, 20)); });
  console.log("settled, body length:", document.body.textContent?.length);
  console.log("has Today:", document.body.textContent?.includes("Today"));
  console.log("rows:", document.querySelectorAll("ul.divide-y > li").length);
  clearTimeout(watchdog);
  process.exit(0);
})();
