import { renderToString } from "react-dom/server";
import { MemoryRouter } from "react-router-dom";
import { AppProvider } from "@/state/AppStore";
import { ToastProvider } from "@/components/ui/Toast";
import App from "@/App";

const routes = [
  "/dashboard",
  "/notifications",
  "/notifications?q=rent",
  "/properties",
  "/properties/prop-maplewood",
  "/tenants/tenant-elena",
  "/leases/lease-4368",
  "/applications/app-3301",
  "/accounting",
  "/accounting/invoices/inv-2041",
  "/accounting/payments/pay-8841",
  "/accounting/expenses/exp-552",
  "/maintenance/mr-1188",
  "/projects/proj-302",
  "/documents/doc-7741",
  "/communications/msg-4410",
  "/team/user-priya",
  "/activity-logs",
  "/scheduled-tasks",
  "/workflow-automation",
  "/settings",
  "/settings/notifications",
  "/settings/team",
  "/settings/integrations",
  "/settings/billing",
  "/record/integration/integration-umpqua-feed",
  "/record/bank_account/bank-umpqua-operating",
];

let failures = 0;
for (const route of routes) {
  for (const userId of ["user-maya", "user-priya", "user-hana"]) {
    try {
      const html = renderToString(
        <AppProvider initialUserId={userId}>
          <ToastProvider>
            <MemoryRouter initialEntries={[route]}>
              <App />
            </MemoryRouter>
          </ToastProvider>
        </AppProvider>
      );
      if (html.length < 200) throw new Error("suspiciously short output");
      if (route === "/notifications" && userId === "user-maya") {
        const counts = [
          ["Today", (html.match(/Today/g) || []).length],
          ["unread-dot", (html.match(/Unread/g) || []).length],
          ["severity", (html.match(/Critical/g) || []).length],
        ];
        console.log("   /notifications html length:", html.length, counts);
      }
    } catch (error) {
      failures += 1;
      console.error(`FAIL ${route} (user ${userId}):`, (error as Error).message);
    }
  }
}
console.log(failures === 0 ? `ALL ${routes.length} ROUTES OK` : `${failures} FAILURES`);
