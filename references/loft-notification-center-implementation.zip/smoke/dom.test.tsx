import { JSDOM } from "jsdom";
import * as React from "react";
import { createRoot } from "react-dom/client";

const dom = new JSDOM("<!doctype html><html><body><div id='root'></div></body></html>", {
  url: "https://loft.example/#/notifications",
  pretendToBeVisual: true,
});
(globalThis as any).window = dom.window;
(globalThis as any).document = dom.window.document;
(globalThis as any).navigator = dom.window.navigator;
(globalThis as any).HTMLElement = dom.window.HTMLElement;
(globalThis as any).Element = dom.window.Element;
(globalThis as any).Node = dom.window.Node;
(globalThis as any).Event = dom.window.Event;
(globalThis as any).KeyboardEvent = dom.window.KeyboardEvent;
(globalThis as any).HTMLInputElement = dom.window.HTMLInputElement;
(globalThis as any).HTMLSelectElement = dom.window.HTMLSelectElement;
(globalThis as any).requestAnimationFrame = (cb: any) => setTimeout(() => cb(Date.now()), 0);
(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;

const { HashRouter } = require("react-router-dom");
const { AppProvider } = require("@/state/AppStore");
const { ToastProvider } = require("@/components/ui/Toast");
const App = require("@/App").default;
const act = (React as any).act;

const container = document.getElementById("root")!;
const root = createRoot(container);
const tick = () => act(async () => { await new Promise((r) => setTimeout(r, 15)); });

const render = async (route: string, userId = "user-maya") => {
  window.location.hash = route;
  await act(async () => {
    root.render(
      <AppProvider initialUserId={userId} key={`${route}-${userId}`}>
        <ToastProvider>
          <HashRouter>
            <App />
          </HashRouter>
        </ToastProvider>
      </AppProvider>
    );
  });
  await tick();
};

const $ = (sel: string) => document.querySelector(sel);
const $$ = (sel: string) => Array.from(document.querySelectorAll(sel));
const text = () => document.body.textContent || "";
const byText = (sel: string, needle: string | RegExp) =>
  $$(sel).find((el) => (el.textContent || "").match(needle));
const click = async (el?: Element) => {
  if (!el) return;
  await act(async () => {
    (el as HTMLElement).click();
    await new Promise((r) => setTimeout(r, 4));
  });
};
const setValue = async (el: any, value: string) => {
  await act(async () => {
    const proto = el instanceof window.HTMLSelectElement ? window.HTMLSelectElement.prototype : window.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value")!.set!.call(el, value);
    el.dispatchEvent(new window.Event(el instanceof window.HTMLSelectElement ? "change" : "input", { bubbles: true }));
    await new Promise((r) => setTimeout(r, 4));
  });
};

let failures = 0;
const check = (label: string, condition: boolean) => {
  console.log(`${condition ? "PASS" : "FAIL"}  ${label}`);
  if (!condition) failures += 1;
};

const watchdog = setTimeout(() => { console.error("TIMEOUT"); process.exit(9); }, 90000);

(async () => {
  await render("#/notifications");

  check("page heading renders", text().includes("Stay on top of important updates across your rental business"));
  check("summary cards render", text().includes("All Notifications") && text().includes("Urgent"));
  check("date groups render", text().includes("Today") && text().includes("Yesterday"));
  check("rows loaded incrementally (8)", $$("ul.divide-y > li").length === 8);
  check("unread markers present", $$('span[aria-label="Unread"]').length > 5);
  check("severity badges present", text().includes("Critical") && text().includes("Informational"));
  check("primary actions present", $$("a").filter((a) => /Open /.test(a.textContent || "")).length > 0);
  check("search placeholder correct", ($("input[type='search']") as HTMLInputElement)?.placeholder === "Search notifications...");
  const summaryNumbers = $$(".text-2xl").map((el) => el.textContent);
  check("summary counts derived from data", summaryNumbers.length === 3 && summaryNumbers.join(",") !== "0,0,0");

  // Mark all as read
  await click(byText("button", /Mark All as Read/));
  check("unread cleared by mark-all-read", $$('span[aria-label="Unread"]').length === 0);
  check("toast confirmation", /Marked \d+ notifications? as read/.test(text()));
  check("bell badge hidden at zero", !byText("button", /^\d+ unread/));

  // Mark unread via More menu
  await click($$('button[aria-label="More notification actions"]')[0]);
  check("more menu lists snooze options", text().includes("Snooze 1 hour") && text().includes("Snooze 1 week"));
  await click(byText("button", /^Mark as unread$/));
  check("unread restored for one row", $$('span[aria-label="Unread"]').length === 1);

  // Snooze
  await click($$('button[aria-label="More notification actions"]')[0]);
  await click(byText("button", /Snooze 1 hour/));
  check("snoozed notification hidden", $$("ul.divide-y > li").length === 7);

  // Search
  await setValue($("input[type='search']"), "harborview");
  check("search narrows results", $$("ul.divide-y > li").length > 0 && $$("ul.divide-y > li").length < 7);
  await setValue($("input[type='search']"), "qqqqnothing");
  check("no-search-results empty state", text().includes("No notifications match your search"));
  await click(byText("button", /Clear search/));
  check("clear search restores list", $$("ul.divide-y > li").length === 7);

  // Tabs
  await click(byText('button[role="tab"]', /Unread/));
  check("unread tab filters", $$("ul.divide-y > li").length === 1);
  check("caught-up state after marking read", byText("button[role='tab']", /^All$/) !== undefined);
  await click(byText('button[role="tab"]', /Assigned to Me/));
  check("assigned tab works", $$("ul.divide-y > li").length >= 1);
  await click(byText('button[role="tab"]', /System/));
  check("system category empty state", text().includes("Nothing in this category right now"));

  // Advanced filters with apply workflow
  await click(byText("button", /Filters/));
  check("advanced panel opens", !!$("form#notification-advanced-filters"));
  await setValue($("select#filter-severity"), "critical");
  await setValue($("select#filter-read"), "all");
  await click(byText("button", /Apply filters/));
  check("advanced filters applied", text().includes("Severity: Critical"));
  check("advanced filter narrows rows", $$("ul.divide-y > li").length < 7);

  // Clear all filters
  await click(byText("button", /^Clear all$/));
  check("filters cleared", !text().includes("Severity: Critical") && $$("ul.divide-y > li").length === 7);

  // Bulk actions
  await click($('input[aria-label="Select all visible notifications"]'));
  check("bulk toolbar shows", /\d+ selected/.test(text()));
  await click(byText("button", /^Dismiss$/));
  check("bulk dismiss confirmation", text().includes("are not modified"));
  await click($$('button').filter((b) => b.textContent === "Dismiss").pop());
  check("bulk dismiss removes rows", $$("ul.divide-y > li").length === 0);
  check("empty state after dismissing everything", text().includes("No notifications"));

  // Deep-link navigation
  await render("#/notifications");
  const link = $$("a").find((a) => /Open /.test(a.textContent || ""));
  check("primary action link present", !!link);
  await click(link);
  check("deep link navigates to record", window.location.hash.startsWith("#/accounting/invoices/") || /#\/(properties|leases|maintenance|projects|documents|team|communications|record)\//.test(window.location.hash));

  // Placeholder route
  await render("#/record/integration/integration-umpqua-feed");
  check("placeholder route is controlled", text().includes("controlled placeholder"));

  // Bell dropdown
  await render("#/notifications");
  await click(byText("button", /Open notifications panel/));
  const panel = $('div[role="dialog"][aria-label="Notifications panel"]');
  check("bell dropdown opens", !!panel);
  check("dropdown lists 5 recent", panel ? panel.querySelectorAll("li, .divide-y > div").length >= 4 : false);
  check("dropdown links to all notifications", !!byText("a", /View all notifications/));
  document.dispatchEvent(new window.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
  await tick();
  check("dropdown closes on Escape", !$('div[role="dialog"][aria-label="Notifications panel"]'));

  // Preferences page
  await render("#/settings/notifications");
  check("preferences renders", text().includes("In-app events") && text().includes("Delivery channels"));
  check("upcoming channels distinguished", (text().match(/Upcoming/g) || []).length >= 2);
  check("in-app marked operational", text().includes("Operational"));
  check("restore defaults available", !!byText("button", /Restore Defaults/));

  // Investor permission scoping
  await render("#/notifications", "user-hana");
  check("investor inbox reduced", $$("ul.divide-y > li").length > 0 && $$("ul.divide-y > li").length <= 4);
  check("sensitive preview redacted", text().includes("Restricted"));

  clearTimeout(watchdog);
  console.log(failures === 0 ? "\nALL DOM CHECKS PASSED" : `\n${failures} DOM CHECK(S) FAILED`);
  process.exitCode = failures === 0 ? 0 : 1;
})();
