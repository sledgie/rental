import { JSDOM } from "jsdom";
import * as React from "react";
import { createRoot } from "react-dom/client";
const dom = new JSDOM("<!doctype html><html><body><div id='root'></div></body></html>", { url: "https://loft.example/#/notifications", pretendToBeVisual: true });
(globalThis as any).window = dom.window;
(globalThis as any).document = dom.window.document;
(globalThis as any).navigator = dom.window.navigator;
(globalThis as any).HTMLElement = dom.window.HTMLElement;
(globalThis as any).Event = dom.window.Event;
(globalThis as any).HTMLInputElement = dom.window.HTMLInputElement;
(globalThis as any).requestAnimationFrame = (cb: any) => setTimeout(() => cb(Date.now()), 0);
(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;
const { HashRouter } = require("react-router-dom");
const { AppProvider } = require("@/state/AppStore");
const { ToastProvider } = require("@/components/ui/Toast");
const App = require("@/App").default;
const act = (React as any).act;
const root = createRoot(document.getElementById("root")!);

const Mini = () => {
  const [value, setValue] = React.useState("");
  return (
    <div>
      <input aria-label="mini" value={value} onChange={(e) => setValue(e.target.value)} />
      <p id="mini-out">{value || "empty"}</p>
    </div>
  );
};

const watchdog = setTimeout(() => { console.error("TIMEOUT"); process.exit(9); }, 25000);
(async () => {
  // 1) Does React onChange fire in this jsdom setup at all?
  await act(async () => { root.render(<Mini />); });
  const mini = document.querySelector("input[aria-label='mini']") as HTMLInputElement;
  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")!.set!;
  await act(async () => {
    setter.call(mini, "typed");
    mini.dispatchEvent(new window.Event("input", { bubbles: true }));
    await new Promise((r) => setTimeout(r, 5));
  });
  console.log("mini output:", document.getElementById("mini-out")!.textContent);

  // 2) Which user is the app scoped to?
  await act(async () => {
    root.render(
      <AppProvider initialUserId="user-hana">
        <ToastProvider><HashRouter><App /></HashRouter></ToastProvider>
      </AppProvider>
    );
  });
  await act(async () => { await new Promise((r) => setTimeout(r, 20)); });
  const header = document.querySelector("header");
  console.log("header text:", header?.textContent?.replace(/\s+/g, " ").slice(0, 200));
  const scopeLine = Array.from(document.querySelectorAll("p")).map((p) => p.textContent || "").find((t) => t.includes("·") && t.includes("Ito") || t.includes("Alvarez"));
  console.log("scope line:", scopeLine);
  console.log("rows:", document.querySelectorAll("ul.divide-y > li").length);
  clearTimeout(watchdog); process.exit(0);
})();
