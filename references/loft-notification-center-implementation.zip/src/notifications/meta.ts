import {
  AlertTriangle,
  Building2,
  CircleDollarSign,
  FileSignature,
  FileText,
  Landmark,
  MessageSquareWarning,
  Receipt,
  ShieldCheck,
  Users,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import type { NotificationCategory, NotificationSeverity } from "./types";

export const CATEGORY_META: Record<
  NotificationCategory,
  { label: string; short: string; icon: LucideIcon; tone: string }
> = {
  financial: {
    label: "Financial",
    short: "Financial",
    icon: CircleDollarSign,
    tone: "bg-forest-100 text-forest",
  },
  properties_leases: {
    label: "Properties & Leases",
    short: "Properties",
    icon: Building2,
    tone: "bg-sage text-forest",
  },
  maintenance_projects: {
    label: "Maintenance & Projects",
    short: "Maintenance",
    icon: Wrench,
    tone: "bg-high-bg text-high-fg",
  },
  team_organization: {
    label: "Team & Organization",
    short: "Team",
    icon: Users,
    tone: "bg-inform-bg text-inform-fg",
  },
  communications_documents: {
    label: "Communications & Documents",
    short: "Comms & Docs",
    icon: FileText,
    tone: "bg-inform-bg text-inform-fg",
  },
  system: {
    label: "System",
    short: "System",
    icon: ShieldCheck,
    tone: "bg-critical-bg text-critical-fg",
  },
};

export const SEVERITY_META: Record<
  NotificationSeverity,
  {
    label: string;
    description: string;
    badge: string;
    dot: string;
    bar: string;
    weight: number;
  }
> = {
  critical: {
    label: "Critical",
    description: "Serious incident requiring immediate attention",
    badge:
      "bg-critical-bg text-critical-fg border-critical-line ring-critical-line/40",
    dot: "bg-critical-fg",
    bar: "bg-critical-fg",
    weight: 3,
  },
  high: {
    label: "High",
    description: "Time-sensitive operational or financial issue",
    badge: "bg-high-bg text-high-fg border-high-line ring-high-line/40",
    dot: "bg-high-fg",
    bar: "bg-high-fg",
    weight: 2,
  },
  normal: {
    label: "Normal",
    description: "Routine task, reminder, or meaningful business update",
    badge: "bg-normal-bg text-normal-fg border-normal-line ring-normal-line/40",
    dot: "bg-normal-fg",
    bar: "bg-normal-fg",
    weight: 1,
  },
  informational: {
    label: "Informational",
    description: "Non-urgent status update",
    badge: "bg-inform-bg text-inform-fg border-inform-line ring-inform-line/40",
    dot: "bg-inform-fg",
    bar: "bg-inform-fg",
    weight: 0,
  },
};

/** Fine-grained event iconography used on notification rows. */
const EVENT_ICONS: Record<string, LucideIcon> = {
  rent_payment_overdue: Receipt,
  rent_payment_recorded: CircleDollarSign,
  invoice_due_soon: Receipt,
  invoice_overdue: Receipt,
  payment_posting_completed: Landmark,
  payment_operation_failed: AlertTriangle,
  refund_processed: CircleDollarSign,
  expense_submitted: Receipt,
  bank_reconciliation_attention: Landmark,
  accounting_period_closing: Landmark,
  lease_expiring: FileSignature,
  lease_created: FileSignature,
  application_received: FileSignature,
  application_status_changed: FileSignature,
  unit_occupancy_changed: Building2,
  tenant_document_missing: FileText,
  maintenance_request_new: Wrench,
  maintenance_request_urgent: AlertTriangle,
  maintenance_request_assigned: Wrench,
  work_order_deadline: Wrench,
  work_order_overdue: AlertTriangle,
  preventive_maintenance_due: Wrench,
  project_budget_threshold: Landmark,
  project_milestone_delayed: AlertTriangle,
  team_member_invited: Users,
  invitation_accepted: Users,
  invitation_expired: Users,
  user_access_suspended: ShieldCheck,
  role_changed: Users,
  sms_delivery_failed: MessageSquareWarning,
  tenant_opted_out: MessageSquareWarning,
  document_uploaded: FileText,
  document_needs_review: FileText,
  document_processing_issue: AlertTriangle,
  integration_failed: AlertTriangle,
  service_unavailable: AlertTriangle,
  configuration_attention: ShieldCheck,
  access_attempt_denied: ShieldCheck,
};

export function getNotificationIcon(
  category: NotificationCategory,
  eventType?: string
): LucideIcon {
  if (eventType && EVENT_ICONS[eventType]) return EVENT_ICONS[eventType];
  return CATEGORY_META[category].icon;
}
