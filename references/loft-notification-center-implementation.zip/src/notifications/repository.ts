import { MOCK_NOTIFICATIONS } from "./mockNotifications";
import type { AppNotification } from "./types";

/**
 * Notification data access seam.
 *
 * The UI talks to this repository only. Swapping the mock implementation for a
 * Supabase-backed service (same interface, `select`/`update` against the
 * `notifications` table with RLS) requires no component changes.
 */
export interface NotificationRepository {
  /** Every notification the signed-in account can address (all organizations). */
  list(): Promise<AppNotification[]>;
  markRead(ids: string[], readAt: string): Promise<void>;
  markUnread(ids: string[]): Promise<void>;
  dismiss(ids: string[], dismissedAt: string): Promise<void>;
  snooze(ids: string[], snoozedUntil: string): Promise<void>;
}

const clone = (rows: AppNotification[]): AppNotification[] => rows.map((r) => ({ ...r }));

class MockNotificationRepository implements NotificationRepository {
  private rows: AppNotification[] = clone(MOCK_NOTIFICATIONS);

  async list(): Promise<AppNotification[]> {
    return clone(this.rows);
  }

  async markRead(ids: string[], readAt: string): Promise<void> {
    this.patch(ids, (row) => ({ ...row, readAt }));
  }

  async markUnread(ids: string[]): Promise<void> {
    this.patch(ids, (row) => ({ ...row, readAt: null }));
  }

  async dismiss(ids: string[], dismissedAt: string): Promise<void> {
    this.patch(ids, (row) => ({ ...row, dismissedAt }));
  }

  async snooze(ids: string[], snoozedUntil: string): Promise<void> {
    this.patch(ids, (row) => ({ ...row, snoozedUntil }));
  }

  private patch(ids: string[], updater: (row: AppNotification) => AppNotification) {
    const idSet = new Set(ids);
    this.rows = this.rows.map((row) => (idSet.has(row.id) ? updater(row) : row));
  }
}

export const notificationRepository: NotificationRepository = new MockNotificationRepository();
