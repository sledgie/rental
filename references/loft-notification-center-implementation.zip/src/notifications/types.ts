import type { Permission, Role } from "@/lib/types";

/* ------------------------------------------------------------------ */
/* Notification domain types                                           */
/* ------------------------------------------------------------------ */

export type NotificationCategory =
  | "financial"
  | "properties_leases"
  | "maintenance_projects"
  | "team_organization"
  | "communications_documents"
  | "system";

export type NotificationSeverity =
  | "critical"
  | "high"
  | "normal"
  | "informational";

/**
 * Who a notification is addressed to. Personal notifications are only visible
 * to `recipientUserId`. Role notifications are visible to members holding one
 * of `targetRoles`. Organization notifications are visible to every member.
 */
export type NotificationAudience = "recipient" | "role" | "organization";

export interface AppNotification {
  /** Stable unique identifier (list key + future primary key). */
  id: string;
  organizationId: string;
  /** Intended recipient. Always set, even for role/organization notifications. */
  recipientUserId: string;
  audience: NotificationAudience;
  /** Roles allowed to see a role-scoped notification. */
  targetRoles?: Role[];
  /** Optional explicit owner of the follow-up work. */
  assignedToUserId?: string;
  assignedToName?: string;

  category: NotificationCategory;
  /** Granular event identifier, e.g. `rent_payment_overdue`. */
  eventType: string;
  severity: NotificationSeverity;

  title: string;
  message: string;

  /** Related record reference, if any. */
  entityType?: string;
  entityId?: string;
  entityLabel?: string;

  propertyId?: string;
  propertyName?: string;
  unitLabel?: string;

  /** ISO 8601 timestamps. */
  createdAt: string;
  readAt: string | null;
  dismissedAt: string | null;
  snoozedUntil?: string | null;
  expiresAt?: string | null;

  actionLabel?: string;
  actionRoute?: string;

  deduplicationKey?: string;

  /** Permission required to see the notification content. */
  requiredPermission?: Permission;
  /** Preview text must be withheld from users without `pii:read`. */
  sensitive?: boolean;
  /** True when the recipient must do something, not just be informed. */
  actionRequired?: boolean;
}

/* ------------------------------------------------------------------ */
/* Filters                                                             */
/* ------------------------------------------------------------------ */

export type NotificationTabId =
  | "all"
  | "unread"
  | "assigned"
  | "high_priority"
  | "financial"
  | "properties_leases"
  | "maintenance_projects"
  | "team_organization"
  | "communications_documents"
  | "system";

export type ReadStatusFilter = "all" | "unread" | "read";

export interface NotificationFilterState {
  query: string;
  tab: NotificationTabId;
  category: NotificationCategory | "all";
  severity: NotificationSeverity | "all";
  readStatus: ReadStatusFilter;
  propertyId: string | "all";
  /** Local date inputs, `yyyy-mm-dd`. */
  fromDate: string;
  toDate: string;
  entityType: string | "all";
}

export const NOTIFICATION_FILTER_DEFAULTS: NotificationFilterState = {
  query: "",
  tab: "all",
  category: "all",
  severity: "all",
  readStatus: "all",
  propertyId: "all",
  fromDate: "",
  toDate: "",
  entityType: "all",
};

/* ------------------------------------------------------------------ */
/* Preferences                                                         */
/* ------------------------------------------------------------------ */

export type ChannelId = "in_app" | "sms" | "email" | "digest";

export interface CategoryPreference {
  enabled: boolean;
  /** Minimum severity that should generate a notification. */
  minimumSeverity: NotificationSeverity;
}

export type NotificationPreferences = {
  categories: Record<NotificationCategory, CategoryPreference>;
  /** SMS is only wired to implemented tenant messaging workflows. */
  smsEnabled: boolean;
};

export const SEVERITY_ORDER: NotificationSeverity[] = [
  "informational",
  "normal",
  "high",
  "critical",
];

export const DEFAULT_NOTIFICATION_PREFERENCES: NotificationPreferences = {
  categories: {
    financial: { enabled: true, minimumSeverity: "informational" },
    properties_leases: { enabled: true, minimumSeverity: "informational" },
    maintenance_projects: { enabled: true, minimumSeverity: "normal" },
    team_organization: { enabled: true, minimumSeverity: "informational" },
    communications_documents: { enabled: true, minimumSeverity: "normal" },
    system: { enabled: true, minimumSeverity: "high" },
  },
  smsEnabled: false,
};
