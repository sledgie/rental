import type { Permission, Role } from "@/lib/types";
import { CATEGORY_META, SEVERITY_META } from "./meta";
import type {
  AppNotification,
  NotificationCategory,
  NotificationFilterState,
  NotificationSeverity,
  NotificationTabId,
} from "./types";

/* ------------------------------------------------------------------ */
/* Scope                                                               */
/* ------------------------------------------------------------------ */

export interface NotificationScope {
  organizationId: string;
  userId: string;
  role?: Role;
  granted: Permission[];
}

/** A notification is "active" when it is neither dismissed, snoozed, nor expired. */
export function isActiveInInbox(n: AppNotification, now: Date = new Date()): boolean {
  if (n.dismissedAt) return false;
  if (n.snoozedUntil && new Date(n.snoozedUntil).getTime() > now.getTime()) return false;
  if (n.expiresAt && new Date(n.expiresAt).getTime() < now.getTime()) return false;
  return true;
}

/** Organization + audience scoping. Other organizations are never visible. */
export function isWithinScope(n: AppNotification, scope: NotificationScope): boolean {
  if (n.organizationId !== scope.organizationId) return false;
  switch (n.audience) {
    case "recipient":
      return n.recipientUserId === scope.userId;
    case "role":
      return (
        n.recipientUserId === scope.userId ||
        (scope.role !== undefined && (n.targetRoles ?? []).includes(scope.role))
      );
    case "organization":
      return true;
  }
}

/** The recipient must hold the permission the notification content depends on. */
export function isContentPermitted(n: AppNotification, scope: NotificationScope): boolean {
  return !n.requiredPermission || scope.granted.includes(n.requiredPermission);
}

/** Sensitive previews are withheld from roles without identity/PII access. */
export function isRedacted(n: AppNotification, scope: NotificationScope): boolean {
  return Boolean(n.sensitive) && !scope.granted.includes("pii:read");
}

export function isAssignedToMe(n: AppNotification, scope: NotificationScope): boolean {
  return n.recipientUserId === scope.userId || n.assignedToUserId === scope.userId;
}

export function isUnread(n: AppNotification): boolean {
  return n.readAt === null;
}

export function isUrgent(n: AppNotification): boolean {
  return SEVERITY_META[n.severity].weight >= SEVERITY_META.high.weight;
}

/** Scope + permission filter used by every surface (page, bell, dropdown). */
export function getVisibleNotifications(
  notifications: AppNotification[],
  scope: NotificationScope,
  now: Date = new Date()
): AppNotification[] {
  return notifications.filter(
    (n) => isActiveInInbox(n, now) && isWithinScope(n, scope) && isContentPermitted(n, scope)
  );
}

/* ------------------------------------------------------------------ */
/* Summary                                                             */
/* ------------------------------------------------------------------ */

export interface NotificationSummary {
  total: number;
  unread: number;
  urgent: number;
}

export function summarize(list: AppNotification[]): NotificationSummary {
  const unread = list.filter(isUnread);
  return {
    total: list.length,
    unread: unread.length,
    urgent: unread.filter(isUrgent).length,
  };
}

/* ------------------------------------------------------------------ */
/* Search + filters                                                    */
/* ------------------------------------------------------------------ */

const TAB_PREDICATES: Record<
  NotificationTabId,
  (n: AppNotification, scope: NotificationScope) => boolean
> = {
  all: () => true,
  unread: (n) => isUnread(n),
  assigned: (n, scope) => isAssignedToMe(n, scope),
  high_priority: (n) => isUrgent(n),
  financial: (n) => n.category === "financial",
  properties_leases: (n) => n.category === "properties_leases",
  maintenance_projects: (n) => n.category === "maintenance_projects",
  team_organization: (n) => n.category === "team_organization",
  communications_documents: (n) => n.category === "communications_documents",
  system: (n) => n.category === "system",
};

export const TAB_ORDER: NotificationTabId[] = [
  "all",
  "unread",
  "assigned",
  "high_priority",
  "financial",
  "properties_leases",
  "maintenance_projects",
  "team_organization",
  "communications_documents",
  "system",
];

export function getTabLabel(tab: NotificationTabId): string {
  switch (tab) {
    case "all":
      return "All";
    case "unread":
      return "Unread";
    case "assigned":
      return "Assigned to Me";
    case "high_priority":
      return "High Priority";
    default:
      return CATEGORY_META[tab as NotificationCategory].label;
  }
}

export function getTabCount(
  tab: NotificationTabId,
  visible: AppNotification[],
  scope: NotificationScope
): number {
  return visible.filter((n) => TAB_PREDICATES[tab](n, scope)).length;
}

function matchesQuery(n: AppNotification, rawQuery: string): boolean {
  const query = rawQuery.trim().toLowerCase();
  if (!query) return true;
  const haystack = [
    n.title,
    n.message,
    n.entityLabel,
    n.propertyName,
    n.unitLabel,
    n.assignedToName,
    n.eventType,
    CATEGORY_META[n.category].label,
    SEVERITY_META[n.severity].label,
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  return query.split(/\s+/).every((token) => haystack.includes(token));
}

export interface NotificationFilterOptions {
  categories: NotificationCategory[];
  severities: NotificationSeverity[];
  properties: Array<{ id: string; name: string }>;
  entityTypes: Array<{ value: string; label: string }>;
}

export function applyNotificationFilters(
  list: AppNotification[],
  filters: NotificationFilterState,
  scope: NotificationScope
): AppNotification[] {
  return list.filter((n) => {
    if (!TAB_PREDICATES[filters.tab](n, scope)) return false;
    if (filters.category !== "all" && n.category !== filters.category) return false;
    if (filters.severity !== "all" && n.severity !== filters.severity) return false;
    if (filters.readStatus === "unread" && !isUnread(n)) return false;
    if (filters.readStatus === "read" && isUnread(n)) return false;
    if (filters.propertyId !== "all" && n.propertyId !== filters.propertyId) return false;
    if (filters.entityType !== "all" && n.entityType !== filters.entityType) return false;
    if (filters.fromDate && n.createdAt.slice(0, 10) < filters.fromDate) return false;
    if (filters.toDate && n.createdAt.slice(0, 10) > filters.toDate) return false;
    if (!matchesQuery(n, filters.query)) return false;
    return true;
  });
}

/** How many non-default filters are applied (drives the "active filters" chip row). */
export function countActiveFilters(filters: NotificationFilterState): number {
  let count = 0;
  if (filters.query.trim()) count += 1;
  if (filters.tab !== "all") count += 1;
  if (filters.category !== "all") count += 1;
  if (filters.severity !== "all") count += 1;
  if (filters.readStatus !== "all") count += 1;
  if (filters.propertyId !== "all") count += 1;
  if (filters.entityType !== "all") count += 1;
  if (filters.fromDate) count += 1;
  if (filters.toDate) count += 1;
  return count;
}

/* ------------------------------------------------------------------ */
/* Date grouping                                                       */
/* ------------------------------------------------------------------ */

export type NotificationBucket =
  | "today"
  | "yesterday"
  | "earlier_this_week"
  | "earlier";

export const BUCKET_LABEL: Record<NotificationBucket, string> = {
  today: "Today",
  yesterday: "Yesterday",
  earlier_this_week: "Earlier This Week",
  earlier: "Earlier",
};

export interface NotificationGroup {
  bucket: NotificationBucket;
  label: string;
  items: AppNotification[];
}

function startOfDay(d: Date): Date {
  const copy = new Date(d);
  copy.setHours(0, 0, 0, 0);
  return copy;
}

function startOfWeek(d: Date): Date {
  const copy = startOfDay(d);
  const day = (copy.getDay() + 6) % 7; // Monday = 0
  copy.setDate(copy.getDate() - day);
  return copy;
}

export function getBucket(iso: string, now: Date = new Date()): NotificationBucket {
  const created = new Date(iso);
  const today = startOfDay(now);
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const weekStart = startOfWeek(now);

  if (created.getTime() >= today.getTime()) return "today";
  if (created.getTime() >= yesterday.getTime()) return "yesterday";
  if (created.getTime() >= weekStart.getTime()) return "earlier_this_week";
  return "earlier";
}

const BUCKET_ORDER: NotificationBucket[] = [
  "today",
  "yesterday",
  "earlier_this_week",
  "earlier",
];

export function groupNotifications(
  list: AppNotification[],
  now: Date = new Date()
): NotificationGroup[] {
  const byBucket = new Map<NotificationBucket, AppNotification[]>();
  for (const n of list) {
    const bucket = getBucket(n.createdAt, now);
    const bucketItems = byBucket.get(bucket);
    if (bucketItems) bucketItems.push(n);
    else byBucket.set(bucket, [n]);
  }
  return BUCKET_ORDER.filter((bucket) => byBucket.has(bucket)).map((bucket) => ({
    bucket,
    label: BUCKET_LABEL[bucket],
    items: byBucket.get(bucket)!,
  }));
}

/* ------------------------------------------------------------------ */
/* Formatting                                                          */
/* ------------------------------------------------------------------ */

const timeFormatter = new Intl.DateTimeFormat("en-US", {
  hour: "numeric",
  minute: "2-digit",
});

const dayTimeFormatter = new Intl.DateTimeFormat("en-US", {
  weekday: "short",
  hour: "numeric",
  minute: "2-digit",
});

const dateFormatter = new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  hour: "numeric",
  minute: "2-digit",
});

const fullFormatter = new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  year: "numeric",
  hour: "numeric",
  minute: "2-digit",
  timeZoneName: "short",
});

export function formatFullTimestamp(iso: string): string {
  return fullFormatter.format(new Date(iso));
}

/** Compact relative timestamp used on notification rows. */
export function formatRelativeTimestamp(iso: string, now: Date = new Date()): string {
  const date = new Date(iso);
  const diffMinutes = Math.round((now.getTime() - date.getTime()) / 60_000);
  if (diffMinutes < 1) return "Just now";
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  if (diffMinutes < 60 * 24) {
    const hours = Math.floor(diffMinutes / 60);
    const minutes = diffMinutes % 60;
    return minutes > 0 ? `${hours}h ${minutes}m ago` : `${hours}h ago`;
  }
  const bucket = getBucket(iso, now);
  if (bucket === "yesterday") return `Yesterday, ${timeFormatter.format(date)}`;
  if (diffMinutes < 60 * 24 * 7) return dayTimeFormatter.format(date);
  return dateFormatter.format(date);
}

export function sortNotifications(list: AppNotification[]): AppNotification[] {
  return [...list].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}
