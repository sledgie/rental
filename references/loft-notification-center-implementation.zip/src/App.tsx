import { Navigate, Route, Routes } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { ToastProvider } from "@/components/ui/Toast";
import { ApplicationsListPage, ModuleListPage } from "@/pages/ModuleListPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { EntityDetailPage, RecordPlaceholderPage } from "@/pages/RecordPages";
import { NotificationCenterPage } from "@/pages/NotificationCenterPage";
import SettingsLayout from "@/pages/settings/SettingsLayout";
import NotificationPreferencesPage from "@/pages/settings/NotificationPreferencesPage";
import {
  BillingSettingsPage,
  IntegrationsSettingsPage,
  OrganizationSettingsPage,
  TeamSettingsPage,
} from "@/pages/settings/SettingsPages";
import { AppProvider } from "@/state/AppStore";

/**
 * Route map.
 *
 * Every notification deep link resolves through `ENTITY_ROUTES` in
 * `src/lib/routing.ts`. Entity types without a built surface route to the
 * controlled placeholder at `/record/:entityType/:entityId`.
 */
export default function App() {
  return (
    <AppProvider>
      <ToastProvider>
        <Routes>
          <Route element={<AppLayout />}>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/notifications" element={<NotificationCenterPage />} />

            {/* Portfolio */}
            <Route path="/properties" element={<ModuleListPage />} />
            <Route path="/properties/:id" element={<EntityDetailPage entityType="property" />} />
            <Route path="/tenants" element={<ModuleListPage />} />
            <Route path="/tenants/:id" element={<EntityDetailPage entityType="tenant" />} />
            <Route path="/leases" element={<ModuleListPage />} />
            <Route path="/leases/:id" element={<EntityDetailPage entityType="lease" />} />
            <Route path="/applications" element={<ApplicationsListPage />} />
            <Route
              path="/applications/:id"
              element={<EntityDetailPage entityType="application" />}
            />

            {/* Accounting */}
            <Route path="/accounting" element={<ModuleListPage />} />
            <Route
              path="/accounting/invoices/:id"
              element={<EntityDetailPage entityType="invoice" />}
            />
            <Route
              path="/accounting/payments/:id"
              element={<EntityDetailPage entityType="payment" />}
            />
            <Route
              path="/accounting/expenses/:id"
              element={<EntityDetailPage entityType="expense" />}
            />

            {/* Operations */}
            <Route path="/maintenance" element={<ModuleListPage />} />
            <Route
              path="/maintenance/:id"
              element={<EntityDetailPage entityType="maintenance_request" />}
            />
            <Route path="/projects" element={<ModuleListPage />} />
            <Route path="/projects/:id" element={<EntityDetailPage entityType="project" />} />
            <Route path="/documents" element={<ModuleListPage />} />
            <Route path="/documents/:id" element={<EntityDetailPage entityType="document" />} />
            <Route path="/communications" element={<ModuleListPage />} />
            <Route
              path="/communications/:id"
              element={<EntityDetailPage entityType="communication" />}
            />
            <Route path="/team" element={<ModuleListPage />} />
            <Route path="/team/:id" element={<EntityDetailPage entityType="team_member" />} />

            {/* Workspace */}
            <Route path="/activity-logs" element={<ModuleListPage />} />
            <Route path="/scheduled-tasks" element={<ModuleListPage />} />
            <Route path="/workflow-automation" element={<ModuleListPage />} />

            {/* Settings */}
            <Route path="/settings" element={<SettingsLayout />}>
              <Route index element={<OrganizationSettingsPage />} />
              <Route path="notifications" element={<NotificationPreferencesPage />} />
              <Route path="team" element={<TeamSettingsPage />} />
              <Route path="integrations" element={<IntegrationsSettingsPage />} />
              <Route path="billing" element={<BillingSettingsPage />} />
            </Route>

            {/* Controlled placeholder for records without a built surface */}
            <Route path="/record/:entityType/:id" element={<RecordPlaceholderPage />} />

            <Route
              path="*"
              element={<Navigate to="/dashboard" replace />}
            />
          </Route>
        </Routes>
      </ToastProvider>
    </AppProvider>
  );
}
