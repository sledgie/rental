import { Link } from "react-router-dom";
import {
  ArrowRight,
  Bell,
  CalendarClock,
  CircleDollarSign,
  History,
  TriangleAlert,
  Workflow,
  Wrench,
} from "lucide-react";
import { NotificationSeverityBadge } from "@/components/notifications/NotificationSeverityBadge";
import { Button, Card, LinkButton } from "@/components/ui/primitives";
import { formatCurrency, INVOICES, MAINTENANCE_REQUESTS } from "@/lib/mockData";
import { formatRelativeTimestamp, isUnread, sortNotifications } from "@/notifications/logic";
import { getNotificationIcon } from "@/notifications/meta";
import { useApp } from "@/state/AppStore";
import { cn } from "@/utils/cn";

const MODULE_COMPARISON = [
  {
    icon: Bell,
    title: "Notifications",
    question: "What needs my attention?",
    example: "A lease expires in 30 days.",
    to: "/notifications",
  },
  {
    icon: History,
    title: "Activity Logs",
    question: "What happened, and who did it?",
    example: "A property manager updated a lease record.",
    to: "/activity-logs",
  },
  {
    icon: CalendarClock,
    title: "Scheduled Tasks",
    question: "What runs at a specific time?",
    example: "A reminder task runs on the 1st of the month.",
    to: "/scheduled-tasks",
  },
  {
    icon: Workflow,
    title: "Workflow Automation",
    question: "What should happen when an event occurs?",
    example: "When an invoice becomes overdue, create a follow-up action.",
    to: "/workflow-automation",
  },
];

export function DashboardPage() {
  const { user, organization, scopedNotifications, summary, properties, role } = useApp();
  const avgOccupancy = Math.round(
    properties.reduce((total, property) => total + property.occupancy, 0) / (properties.length || 1)
  );
  const openRequests = MAINTENANCE_REQUESTS.filter((m) => m.status !== "completed").length;
  const overdueBalance = INVOICES.filter((i) => i.status === "overdue").reduce(
    (total, invoice) => total + invoice.amount,
    0
  );

  const attention = sortNotifications(
    scopedNotifications.filter((n) => isUnread(n) && (n.severity === "critical" || n.severity === "high"))
  ).slice(0, 4);

  const kpis = [
    { label: "Portfolio occupancy", value: `${avgOccupancy}%`, hint: `${properties.length} properties` },
    { label: "Open maintenance", value: String(openRequests), hint: "Requests and work orders" },
    { label: "Overdue balances", value: formatCurrency(overdueBalance), hint: "Across active invoices" },
    { label: "Unread notifications", value: String(summary.unread), hint: `${summary.urgent} urgent` },
  ];

  return (
    <div className="space-y-4 sm:space-y-5">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-ink sm:text-2xl">
          Welcome back, {user.name.split(" ")[0]}
        </h1>
        <p className="mt-1 text-sm text-muted">
          {organization.name} · {role} · {properties.length} properties in view
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="p-3.5 sm:p-4">
            <p className="text-xs font-medium tracking-wide text-muted uppercase">{kpi.label}</p>
            <p className="mt-1 text-2xl leading-7 font-semibold text-ink tabular-nums">{kpi.value}</p>
            <p className="mt-0.5 text-xs text-muted">{kpi.hint}</p>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between gap-2 border-b border-line px-4 py-3 sm:px-5">
            <div className="flex items-center gap-2">
              <TriangleAlert className="h-4 w-4 text-high-fg" aria-hidden="true" />
              <h2 className="text-sm font-semibold text-ink">Needs your attention</h2>
            </div>
            <Link
              to="/notifications"
              className="inline-flex items-center gap-1 text-xs font-semibold text-forest transition-colors hover:text-evergreen"
            >
              View all
              <ArrowRight className="h-3 w-3" aria-hidden="true" />
            </Link>
          </div>
          {attention.length === 0 ? (
            <p className="px-4 py-8 text-center text-sm text-muted sm:px-5">
              Nothing urgent right now — you are caught up.
            </p>
          ) : (
            <ul className="divide-y divide-line">
              {attention.map((n) => {
                const Icon = getNotificationIcon(n.category, n.eventType);
                return (
                  <li key={n.id} className="flex items-start gap-3 px-4 py-3 sm:px-5">
                    <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-critical-bg text-critical-fg">
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <p className="text-sm font-semibold text-ink">{n.title}</p>
                        <NotificationSeverityBadge severity={n.severity} compact />
                      </div>
                      <p className="mt-0.5 line-clamp-1 text-sm text-muted">{n.message}</p>
                      <p className="mt-1 text-[11px] text-muted">
                        {formatRelativeTimestamp(n.createdAt)}
                        {n.propertyName ? ` · ${n.propertyName}` : ""}
                      </p>
                    </div>
                    {n.actionRoute ? (
                      <LinkButton to={n.actionRoute} size="xs" variant="ghost" className="shrink-0">
                        Open
                        <ArrowRight className="h-3 w-3" aria-hidden="true" />
                      </LinkButton>
                    ) : null}
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        <Card>
          <div className="border-b border-line px-4 py-3 sm:px-5">
            <h2 className="text-sm font-semibold text-ink">Quick actions</h2>
          </div>
          <div className="space-y-2 p-3 sm:p-4">
            {[
              { to: "/maintenance", label: "Triage maintenance", icon: Wrench },
              { to: "/accounting", label: "Review accounting", icon: CircleDollarSign },
              { to: "/settings/notifications", label: "Notification preferences", icon: Bell },
            ].map((action) => {
              const Icon = action.icon;
              return (
                <Link
                  key={action.to}
                  to={action.to}
                  className="flex items-center gap-2.5 rounded-lg border border-line bg-white px-3 py-2.5 text-sm text-ink transition-colors hover:border-forest-200 hover:bg-forest-50"
                >
                  <Icon className="h-4 w-4 text-forest" aria-hidden="true" />
                  <span className="flex-1">{action.label}</span>
                  <ArrowRight className="h-3.5 w-3.5 text-muted" aria-hidden="true" />
                </Link>
              );
            })}
          </div>
        </Card>
      </div>

      <Card>
        <div className="border-b border-line px-4 py-3 sm:px-5">
          <h2 className="text-sm font-semibold text-ink">How the modules differ</h2>
          <p className="mt-0.5 text-xs text-muted">
            Notifications, Activity Logs, Scheduled Tasks, and Workflow Automation answer different
            questions.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-3 p-3 sm:grid-cols-2 sm:p-4">
          {MODULE_COMPARISON.map((module) => {
            const Icon = module.icon;
            return (
              <Link
                key={module.title}
                to={module.to}
                className={cn(
                  "rounded-xl border border-line bg-white p-3.5 transition-colors",
                  "hover:border-forest-200 hover:bg-forest-50"
                )}
              >
                <div className="flex items-center gap-2">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-forest-100 text-forest">
                    <Icon className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <p className="text-sm font-semibold text-ink">{module.title}</p>
                </div>
                <p className="mt-2 text-xs font-medium text-forest">{module.question}</p>
                <p className="mt-1 text-xs leading-5 text-muted">{module.example}</p>
              </Link>
            );
          })}
        </div>
      </Card>

      <div className="flex justify-end">
        <Link to="/notifications">
          <Button variant="primary" size="sm">
            Open Notification Center
            <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </Button>
        </Link>
      </div>
    </div>
  );
}
