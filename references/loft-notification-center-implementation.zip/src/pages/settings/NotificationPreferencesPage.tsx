import { Link } from "react-router-dom";
import {
  Bell,
  Building2,
  CalendarClock,
  Check,
  CircleDollarSign,
  FileText,
  Info,
  Mail,
  MessageSquare,
  RotateCcw,
  ShieldCheck,
  Users,
  Wrench,
} from "lucide-react";
import { Button, Card, SelectInput, Switch } from "@/components/ui/primitives";
import { useToast } from "@/components/ui/Toast";
import { CATEGORY_META, SEVERITY_META } from "@/notifications/meta";
import {
  DEFAULT_NOTIFICATION_PREFERENCES,
  SEVERITY_ORDER,
  type NotificationCategory,
} from "@/notifications/types";
import { useApp } from "@/state/AppStore";
import { cn } from "@/utils/cn";

const CATEGORY_DESCRIPTION: Record<NotificationCategory, string> = {
  financial:
    "Overdue rent, failed payments, expenses awaiting review, reconciliation and period closing.",
  properties_leases:
    "Applications, lease expirations and renewals, occupancy changes, and missing tenant documents.",
  maintenance_projects:
    "New and urgent requests, assignments, work order deadlines, preventive maintenance, and project alerts.",
  team_organization:
    "Invitations, role and permission changes, and access suspensions in this organization.",
  communications_documents:
    "Message delivery failures, SMS opt-outs, document uploads, and documents that need review.",
  system:
    "Integration failures, background service disruptions, and configuration that needs attention.",
};

const CATEGORY_ICON: Record<NotificationCategory, typeof Bell> = {
  financial: CircleDollarSign,
  properties_leases: Building2,
  maintenance_projects: Wrench,
  team_organization: Users,
  communications_documents: FileText,
  system: ShieldCheck,
};

export default function NotificationPreferencesPage() {
  const {
    preferences,
    setCategoryEnabled,
    setCategoryMinimumSeverity,
    setSmsEnabled,
    restoreDefaultPreferences,
    user,
    organization,
  } = useApp();
  const toast = useToast();

  const changedFromDefault =
    JSON.stringify(preferences) !== JSON.stringify(DEFAULT_NOTIFICATION_PREFERENCES);

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h2 className="text-lg font-semibold text-ink">Notification preferences</h2>
          <p className="mt-1 text-sm text-muted">
            Choose which events create in-app notifications for you. Preferences apply to{" "}
            {organization.name} and are saved for this session only.
          </p>
        </div>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => {
            restoreDefaultPreferences();
            toast.push({
              variant: "success",
              title: "Preferences restored to defaults",
              description: "Your notification settings match the L.O.F.T. defaults.",
            });
          }}
          disabled={!changedFromDefault}
        >
          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
          Restore Defaults
        </Button>
      </div>

      {/* In-app events */}
      <Card>
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3 sm:px-5">
          <div>
            <h3 className="text-sm font-semibold text-ink">In-app events</h3>
            <p className="text-xs text-muted">
              Controls which events create notifications for {user.name}.
            </p>
          </div>
          <span className="inline-flex items-center gap-1 rounded-full border border-forest-200 bg-forest-50 px-2 py-0.5 text-[11px] font-medium text-forest">
            <Check className="h-3 w-3" aria-hidden="true" />
            Operational
          </span>
        </div>

        <ul className="divide-y divide-line">
          {(Object.keys(CATEGORY_META) as NotificationCategory[]).map((category) => {
            const meta = CATEGORY_META[category];
            const Icon = CATEGORY_ICON[category];
            const preference = preferences.categories[category];
            return (
              <li
                key={category}
                className={cn(
                  "flex flex-col gap-3 px-4 py-3.5 sm:flex-row sm:items-center sm:gap-4 sm:px-5",
                  !preference.enabled && "bg-ivory/60"
                )}
              >
                <span
                  className={cn(
                    "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",
                    meta.tone
                  )}
                >
                  <Icon className="h-[18px] w-[18px]" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-ink">{meta.label}</p>
                  <p className="mt-0.5 text-xs leading-5 text-muted">
                    {CATEGORY_DESCRIPTION[category]}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-40">
                    <label
                      htmlFor={`severity-${category}`}
                      className="mb-1 block text-[11px] font-medium text-muted"
                    >
                      Minimum severity
                    </label>
                    <SelectInput
                      id={`severity-${category}`}
                      value={preference.minimumSeverity}
                      disabled={!preference.enabled}
                      onChange={(event) =>
                        setCategoryMinimumSeverity(
                          category,
                          event.target.value as typeof preference.minimumSeverity
                        )
                      }
                      className="disabled:cursor-not-allowed disabled:bg-ivory disabled:text-muted"
                    >
                      {SEVERITY_ORDER.map((severity) => (
                        <option key={severity} value={severity}>
                          {SEVERITY_META[severity].label} and above
                        </option>
                      ))}
                    </SelectInput>
                  </div>
                  <Switch
                    checked={preference.enabled}
                    onChange={(next) => setCategoryEnabled(category, next)}
                    label={`${meta.label} in-app notifications`}
                  />
                </div>
              </li>
            );
          })}
        </ul>

        <div className="border-t border-line bg-ivory/70 px-4 py-3 sm:px-5">
          <p className="text-xs leading-5 text-muted">
            These settings govern which events generate notifications going forward. Notifications
            already in your{" "}
            <Link to="/notifications" className="font-medium text-forest underline decoration-dotted">
              inbox
            </Link>{" "}
            stay there so you do not lose track of open work.
          </p>
        </div>
      </Card>

      {/* Delivery channels */}
      <Card>
        <div className="border-b border-line px-4 py-3 sm:px-5">
          <h3 className="text-sm font-semibold text-ink">Delivery channels</h3>
          <p className="text-xs text-muted">
            In-app is the only channel in production today. Other channels are shown so the plan is
            clear — they are not sending anything yet.
          </p>
        </div>
        <ul className="divide-y divide-line">
          <li className="flex items-start gap-3 px-4 py-3.5 sm:px-5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-forest-100 text-forest">
              <Bell className="h-[18px] w-[18px]" aria-hidden="true" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-ink">In-app notifications</p>
              <p className="mt-0.5 text-xs leading-5 text-muted">
                Delivered to your notification center and the header bell.
              </p>
            </div>
            <span className="inline-flex items-center gap-1 rounded-full border border-forest-200 bg-forest-50 px-2 py-0.5 text-[11px] font-medium text-forest">
              <Check className="h-3 w-3" aria-hidden="true" />
              Active
            </span>
          </li>

          <li className="flex items-start gap-3 px-4 py-3.5 sm:px-5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-inform-bg text-inform-fg">
              <MessageSquare className="h-[18px] w-[18px]" aria-hidden="true" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-ink">SMS alerts to you</p>
              <p className="mt-0.5 text-xs leading-5 text-muted">
                Optional text alerts for critical maintenance and financial events. Uses the same
                Twilio messaging workflow that is already implemented for tenant messages.
              </p>
              <p className="mt-1.5 text-[11px] leading-4 text-muted">
                Your alert preference is separate from tenant messaging consent — a tenant's SMS
                opt-out is never overridden by these settings.
              </p>
            </div>
            <div className="pt-1.5">
              <Switch
                checked={preferences.smsEnabled}
                onChange={(next) => {
                  setSmsEnabled(next);
                  toast.push({
                    variant: "info",
                    title: next ? "SMS alerts enabled" : "SMS alerts disabled",
                    description: "Mock preference — no messages are sent in this build.",
                  });
                }}
                label="SMS alerts"
              />
            </div>
          </li>

          <li className="flex items-start gap-3 px-4 py-3.5 sm:px-5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-inform-bg text-inform-fg">
              <Mail className="h-[18px] w-[18px]" aria-hidden="true" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-ink">Email notifications</p>
              <p className="mt-0.5 text-xs leading-5 text-muted">
                Email delivery is not implemented yet. This toggle will become active once the
                delivery service ships.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-1.5">
              <span className="rounded-full border border-line bg-ivory px-2 py-0.5 text-[11px] font-medium text-muted">
                Upcoming
              </span>
              <Switch checked={false} onChange={() => undefined} label="Email notifications" disabled />
            </div>
          </li>

          <li className="flex items-start gap-3 px-4 py-3.5 sm:px-5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-inform-bg text-inform-fg">
              <CalendarClock className="h-[18px] w-[18px]" aria-hidden="true" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-ink">Scheduled digests</p>
              <p className="mt-0.5 text-xs leading-5 text-muted">
                Daily or weekly summary emails require a background scheduler. Not available in this
                build.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-1.5">
              <span className="rounded-full border border-line bg-ivory px-2 py-0.5 text-[11px] font-medium text-muted">
                Upcoming
              </span>
              <Switch checked={false} onChange={() => undefined} label="Scheduled digests" disabled />
            </div>
          </li>
        </ul>

        <div className="flex items-start gap-2 border-t border-line bg-ivory/70 px-4 py-3 sm:px-5">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
          <p className="text-xs leading-5 text-muted">
            Mock state only: preferences persist for the current session and are not written to the
            database. Server-side persistence, per-user channels, and delivery are planned follow-up
            work.
          </p>
        </div>
      </Card>
    </div>
  );
}
