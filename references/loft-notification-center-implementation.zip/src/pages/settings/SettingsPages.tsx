import { Link } from "react-router-dom";
import { Bell, Check } from "lucide-react";
import { Badge, Button, Card } from "@/components/ui/primitives";
import { MEMBERSHIPS, PROPERTIES, ROLE_LABEL, USERS } from "@/lib/mockData";
import { useApp } from "@/state/AppStore";

function Panel({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <Card>
      <div className="border-b border-line px-4 py-3 sm:px-5">
        <h2 className="text-sm font-semibold text-ink">{title}</h2>
        {description ? <p className="mt-0.5 text-xs text-muted">{description}</p> : null}
      </div>
      {children}
    </Card>
  );
}

export function OrganizationSettingsPage() {
  const { organization, properties, user } = useApp();
  return (
    <div className="space-y-4">
      <Panel title="Organization profile" description="Details shown on tenant-facing documents.">
        <dl className="grid grid-cols-1 gap-x-6 gap-y-3 px-4 py-4 sm:grid-cols-2 sm:px-5">
          {[
            ["Legal name", organization.name],
            ["Workspace slug", organization.slug],
            ["Plan", `${organization.plan} plan`],
            ["Properties", `${properties.length} · ${properties.reduce((t, p) => t + p.unitCount, 0)} units`],
            ["Primary contact", user.name],
            ["Fiscal year", "January – December"],
          ].map(([label, value]) => (
            <div key={label}>
              <dt className="text-[11px] font-semibold tracking-wide text-muted uppercase">{label}</dt>
              <dd className="mt-0.5 text-sm text-ink">{value}</dd>
            </div>
          ))}
        </dl>
      </Panel>

      <Panel title="Notification settings" description="Which events create notifications.">
        <div className="flex flex-col items-start gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-5">
          <p className="text-sm text-muted">
            Manage in-app events, severity thresholds, and delivery channels for your account.
          </p>
          <Link to="/settings/notifications">
            <Button variant="secondary" size="sm">
              <Bell className="h-3.5 w-3.5" aria-hidden="true" />
              Notification preferences
            </Button>
          </Link>
        </div>
      </Panel>

      <Panel title="Properties in this organization">
        <ul className="divide-y divide-line">
          {PROPERTIES.filter((p) => p.organizationId === organization.id).map((property) => (
            <li key={property.id} className="flex items-center justify-between gap-3 px-4 py-2.5 sm:px-5">
              <div className="min-w-0">
                <p className="truncate text-sm text-ink">{property.name}</p>
                <p className="text-xs text-muted">
                  {property.city}, {property.state} · {property.unitCount} units
                </p>
              </div>
              <Badge tone="forest">{property.occupancy}% occupied</Badge>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}

export function TeamSettingsPage() {
  const { organization, can } = useApp();
  const members = MEMBERSHIPS.filter((m) => m.organizationId === organization.id);
  return (
    <Panel
      title="Team & roles"
      description="Roles control which notifications and records each member can see."
    >
      <ul className="divide-y divide-line">
        {members.map((membership) => {
          const member = USERS.find((u) => u.id === membership.userId)!;
          return (
            <li key={membership.userId} className="flex items-center gap-3 px-4 py-3 sm:px-5">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-forest-100 text-[11px] font-bold text-forest">
                {member.initials}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm text-ink">{member.name}</p>
                <p className="truncate text-xs text-muted">{member.email}</p>
              </div>
              <Badge tone="outline">{ROLE_LABEL[membership.role]}</Badge>
            </li>
          );
        })}
      </ul>
      {!can("team:manage") ? (
        <div className="border-t border-line bg-ivory/70 px-4 py-3 text-xs text-muted sm:px-5">
          You can view team members, but only owners can change roles or send invitations.
        </div>
      ) : null}
    </Panel>
  );
}

export function IntegrationsSettingsPage() {
  const integrations = [
    {
      name: "Umpqua Bank feed",
      detail: "Operating account ·· 4471 — nightly transaction import",
      status: "Needs attention",
      tone: "critical" as const,
    },
    {
      name: "Twilio messaging",
      detail: "Tenant SMS workflows — delivery and opt-out handling",
      status: "Connected",
      tone: "forest" as const,
    },
    {
      name: "Stripe payments",
      detail: "Card and ACH payments for tenant portals",
      status: "Connected",
      tone: "forest" as const,
    },
    {
      name: "QuickBooks Online",
      detail: "Chart of accounts and journal sync",
      status: "Not connected",
      tone: "inform" as const,
    },
  ];
  return (
    <Panel title="Integrations" description="Connected services for this organization.">
      <ul className="divide-y divide-line">
        {integrations.map((integration) => (
          <li key={integration.name} className="flex items-center justify-between gap-3 px-4 py-3 sm:px-5">
            <div className="min-w-0">
              <p className="truncate text-sm text-ink">{integration.name}</p>
              <p className="truncate text-xs text-muted">{integration.detail}</p>
            </div>
            <Badge tone={integration.tone}>{integration.status}</Badge>
          </li>
        ))}
      </ul>
      <div className="border-t border-line bg-ivory/70 px-4 py-3 text-xs text-muted sm:px-5">
        Integration failures raise notifications in the System category.
      </div>
    </Panel>
  );
}

export function BillingSettingsPage() {
  const { organization } = useApp();
  return (
    <Panel title="Plan & billing" description="Subscription and invoice history.">
      <div className="flex flex-col items-start gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-5">
        <div>
          <p className="text-sm font-semibold text-ink">{organization.plan} plan</p>
          <p className="text-xs text-muted">
            {organization.propertyCount} properties · billed annually · renews Mar 1, 2027
          </p>
        </div>
        <Badge tone="forest" icon={<Check className="h-3 w-3" aria-hidden="true" />}>
          Active
        </Badge>
      </div>
      <div className="border-t border-line bg-ivory/70 px-4 py-3 text-xs text-muted sm:px-5">
        Demo workspace — no billing data is real.
      </div>
    </Panel>
  );
}
