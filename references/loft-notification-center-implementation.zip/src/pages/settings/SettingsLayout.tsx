import { NavLink, Outlet } from "react-router-dom";
import { Bell, Building2, CreditCard, Plug, Users } from "lucide-react";
import { cn } from "@/utils/cn";

const SETTINGS_NAV = [
  { to: "/settings", label: "Organization", icon: Building2, end: true },
  { to: "/settings/notifications", label: "Notifications", icon: Bell, end: false },
  { to: "/settings/team", label: "Team & Roles", icon: Users, end: false },
  { to: "/settings/integrations", label: "Integrations", icon: Plug, end: false },
  { to: "/settings/billing", label: "Plan & Billing", icon: CreditCard, end: false },
];

export default function SettingsLayout() {
  return (
    <div className="space-y-4 sm:space-y-5">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-ink sm:text-2xl">Settings</h1>
        <p className="mt-1 text-sm text-muted">
          Manage your organization, notification behavior, and connected services.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[13rem_1fr]">
        <nav aria-label="Settings sections" className="-mx-3 flex gap-1.5 overflow-x-auto px-3 scrollbar-none lg:mx-0 lg:flex-col lg:overflow-visible lg:px-0">
          {SETTINGS_NAV.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  cn(
                    "inline-flex shrink-0 items-center gap-2 rounded-lg border px-3 py-2 text-sm transition-colors",
                    isActive
                      ? "border-forest-200 bg-forest-50 font-semibold text-forest"
                      : "border-line bg-white text-muted hover:border-forest-200 hover:text-ink"
                  )
                }
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
                {item.label}
              </NavLink>
            );
          })}
        </nav>

        <div className="min-w-0">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
