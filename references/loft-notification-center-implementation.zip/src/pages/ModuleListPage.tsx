import { Link, useLocation } from "react-router-dom";
import { ArrowUpRight, Inbox, Lock } from "lucide-react";
import { Button, Card, EmptyState } from "@/components/ui/primitives";
import { MODULE_CONFIG } from "@/lib/modulePages";
import { useApp } from "@/state/AppStore";
import { cn } from "@/utils/cn";

export function ModuleListPage() {
  const { pathname } = useLocation();
  const { can, organization } = useApp();
  const config = MODULE_CONFIG[pathname];

  if (!config) {
    return (
      <Card>
        <EmptyState
          icon={<Inbox className="h-5 w-5" aria-hidden="true" />}
          title="This module is not part of the demo build"
          description="The page you requested exists in the navigation but is not implemented here."
          action={
            <Link to="/dashboard" className="text-sm font-semibold text-forest underline decoration-dotted">
              Back to dashboard
            </Link>
          }
        />
      </Card>
    );
  }

  if (config.permission && !can(config.permission)) {
    return (
      <Card>
        <EmptyState
          icon={<Lock className="h-5 w-5" aria-hidden="true" />}
          title="You do not have access to this module"
          description={`Your role in ${organization.name} does not include the "${config.permission}" permission. Ask an owner for access.`}
          action={
            <Link
              to="/dashboard"
              className="text-sm font-semibold text-forest underline decoration-dotted"
            >
              Back to dashboard
            </Link>
          }
        />
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-ink sm:text-2xl">{config.title}</h1>
        <p className="mt-1 text-sm text-muted">{config.description}</p>
      </div>

      {config.note ? (
        <div className="rounded-xl border border-forest-200 bg-forest-50 px-4 py-3 text-sm text-forest">
          {config.note}
        </div>
      ) : null}

      <Card className="overflow-hidden">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full min-w-[40rem] text-left text-sm">
            <thead>
              <tr className="border-b border-line bg-ivory/70">
                {config.columns.map((column) => (
                  <th
                    key={column.key}
                    scope="col"
                    className={cn(
                      "px-4 py-2.5 text-xs font-semibold tracking-wide text-muted uppercase",
                      column.align === "right" && "text-right"
                    )}
                  >
                    {column.label}
                  </th>
                ))}
                <th scope="col" className="w-10 px-3" aria-label="Open record" />
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {config.rows.map((row) => (
                <tr key={row.id} className="transition-colors hover:bg-forest-50/50">
                  {config.columns.map((column) => (
                    <td
                      key={column.key}
                      className={cn(
                        "px-4 py-3 text-ink",
                        column.align === "right" && "text-right tabular-nums"
                      )}
                    >
                      {row.cells[column.key]}
                    </td>
                  ))}
                  <td className="px-3 py-3 text-right">
                    {row.href ? (
                      <Link
                        to={row.href}
                        aria-label={`Open ${row.cells[config.columns[0].key]}`}
                        className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-muted transition-colors hover:bg-forest-100 hover:text-forest"
                      >
                        <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                      </Link>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <p className="text-xs text-muted">
        Showing {config.rows.length} sample records from the mock dataset for {organization.name}.
      </p>
    </div>
  );
}

export function ApplicationsListPage() {
  const { organization } = useApp();
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-ink sm:text-2xl">
          Rental applications
        </h1>
        <p className="mt-1 text-sm text-muted">
          New applications received through the leasing portal.
        </p>
      </div>
      <Card className="overflow-hidden">
        <table className="w-full min-w-[32rem] text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-ivory/70">
              {["Reference", "Applicant", "Property / Unit", "Status"].map((label) => (
                <th
                  key={label}
                  scope="col"
                  className="px-4 py-2.5 text-xs font-semibold tracking-wide text-muted uppercase"
                >
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            <tr className="hover:bg-forest-50/50">
              <td className="px-4 py-3">APP-3301</td>
              <td className="px-4 py-3">Naomi Castellanos</td>
              <td className="px-4 py-3">Harborview Lofts · Loft 4</td>
              <td className="px-4 py-3">Received</td>
            </tr>
            <tr className="hover:bg-forest-50/50">
              <td className="px-4 py-3">APP-3297</td>
              <td className="px-4 py-3">Ethan Brooks</td>
              <td className="px-4 py-3">Maplewood Court Apartments · Unit 18A</td>
              <td className="px-4 py-3">Screening</td>
            </tr>
          </tbody>
        </table>
      </Card>
      <p className="text-xs text-muted">Sample records · {organization.name}</p>
      <div>
        <Link to="/notifications">
          <Button variant="secondary" size="sm">
            Back to notifications
          </Button>
        </Link>
      </div>
    </div>
  );
}
