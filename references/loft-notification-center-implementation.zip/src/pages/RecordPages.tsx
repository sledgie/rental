import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Building2, CalendarClock, Clock, FileWarning, Lock } from "lucide-react";
import { Badge, Button, Card, EmptyState } from "@/components/ui/primitives";
import { getEntityRecord } from "@/lib/mockData";
import { ENTITY_ROUTES } from "@/lib/routing";
import { useApp } from "@/state/AppStore";

const ENTITY_TYPE_LABEL: Record<string, string> = Object.fromEntries(
  Object.entries(ENTITY_ROUTES).map(([key, value]) => [key, value.label])
);

function RecordShell({
  label,
  subtitle,
  badge,
  children,
  backTo,
}: {
  label: string;
  subtitle?: string;
  badge?: { tone: "critical" | "high" | "normal" | "informational"; text: string };
  children: React.ReactNode;
  backTo?: string;
}) {
  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          {backTo ? (
            <Link
              to={backTo}
              className="mb-2 inline-flex items-center gap-1.5 text-xs font-semibold text-forest transition-colors hover:text-evergreen"
            >
              <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
              Back to notifications
            </Link>
          ) : null}
          <h1 className="text-xl font-semibold tracking-tight text-ink sm:text-2xl">{label}</h1>
          {subtitle ? <p className="mt-1 text-sm text-muted">{subtitle}</p> : null}
        </div>
        {badge ? (
          <Badge
            tone={
              badge.tone === "critical"
                ? "critical"
                : badge.tone === "high"
                  ? "high"
                  : badge.tone === "normal"
                    ? "forest"
                    : "inform"
            }
          >
            {badge.text}
          </Badge>
        ) : null}
      </div>
      {children}
    </div>
  );
}

/** Detail surface for records that exist in the demo dataset. */
export function EntityDetailPage({ entityType }: { entityType: string }) {
  const { id = "" } = useParams();
  const { can, organization } = useApp();
  const record = getEntityRecord(entityType, id);
  const route = ENTITY_ROUTES[entityType];
  const permitted = !route?.permission || can(route.permission);

  if (!permitted) {
    return (
      <Card>
        <EmptyState
          icon={<Lock className="h-5 w-5" aria-hidden="true" />}
          title="You do not have access to this record"
          description={`Your role in ${organization.name} cannot open ${route?.label.toLowerCase() ?? "this record"} records.`}
          action={
            <Link to="/notifications">
              <Button variant="secondary" size="sm">
                Back to notifications
              </Button>
            </Link>
          }
        />
      </Card>
    );
  }

  if (!record) {
    return <RecordPlaceholderPage />;
  }

  return (
    <RecordShell
      label={record.label}
      subtitle={record.subtitle}
      backTo="/notifications"
      badge={
        record.statusLabel
          ? { tone: record.statusTone ?? "normal", text: record.statusLabel }
          : undefined
      }
    >
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="border-b border-line px-4 py-3 sm:px-5">
            <h2 className="text-sm font-semibold text-ink">Details</h2>
          </div>
          <dl className="grid grid-cols-1 gap-x-6 gap-y-3 px-4 py-4 sm:grid-cols-2 sm:px-5">
            {record.fields.map((field) => (
              <div key={field.label} className="min-w-0">
                <dt className="text-[11px] font-semibold tracking-wide text-muted uppercase">
                  {field.label}
                </dt>
                <dd className="mt-0.5 text-sm text-ink">{field.value}</dd>
              </div>
            ))}
            {record.propertyName ? (
              <div className="min-w-0">
                <dt className="text-[11px] font-semibold tracking-wide text-muted uppercase">
                  Property
                </dt>
                <dd className="mt-0.5 flex items-center gap-1.5 text-sm text-ink">
                  <Building2 className="h-3.5 w-3.5 text-muted" aria-hidden="true" />
                  {record.propertyName}
                  {record.unitLabel ? ` · ${record.unitLabel}` : ""}
                </dd>
              </div>
            ) : null}
          </dl>
        </Card>

        <Card>
          <div className="border-b border-line px-4 py-3 sm:px-5">
            <h2 className="text-sm font-semibold text-ink">Activity</h2>
          </div>
          <ol className="space-y-3 px-4 py-4 sm:px-5">
            {record.timeline.map((entry) => (
              <li key={entry.label} className="flex gap-2.5">
                <Clock className="mt-0.5 h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
                <div>
                  <p className="text-sm text-ink">{entry.label}</p>
                  <p className="text-xs text-muted">{entry.value}</p>
                </div>
              </li>
            ))}
          </ol>
          <div className="border-t border-line bg-ivory/70 px-4 py-3 text-xs text-muted sm:px-5">
            Demo record — data is illustrative and scoped to {organization.name}.
          </div>
        </Card>
      </div>
    </RecordShell>
  );
}

/**
 * Controlled placeholder for related records whose module surface is not built
 * yet. Notifications link here instead of dropping the user on an unrelated
 * screen.
 */
export function RecordPlaceholderPage() {
  const { entityType, id = "" } = useParams();
  const { organization } = useApp();
  const label = ENTITY_TYPE_LABEL[entityType ?? ""] ?? "record";
  const record = getEntityRecord(entityType, id);

  return (
    <div className="space-y-4">
      <RecordShell
        label={record?.label ?? `${label} · ${id}`}
        subtitle={record?.subtitle ?? `${label} record reference`}
        backTo="/notifications"
      >
        <Card>
          <EmptyState
            icon={<FileWarning className="h-5 w-5" aria-hidden="true" />}
            title={`This ${label.toLowerCase()} surface is not part of the demo build`}
            description={`The notification you came from is real, and the ${label.toLowerCase()} record exists in ${organization.name}. This screen is a controlled placeholder so you never land on an unrelated page.`}
            action={
              <div className="flex flex-wrap justify-center gap-2">
                <Link to="/notifications">
                  <Button variant="secondary" size="sm">
                    <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
                    Back to notifications
                  </Button>
                </Link>
                <Link to="/dashboard">
                  <Button variant="ghost" size="sm">
                    Go to dashboard
                  </Button>
                </Link>
              </div>
            }
          />
        </Card>

        <Card>
          <div className="border-b border-line px-4 py-3 sm:px-5">
            <h2 className="text-sm font-semibold text-ink">What is available today</h2>
          </div>
          <ul className="divide-y divide-line text-sm">
            {[
              "Notification center with filtering, bulk actions, and preferences",
              "Portfolio, lease, maintenance, project, and document record views",
              "Accounting records for invoices, payments, and expenses",
              "Activity Logs, Scheduled Tasks, and Workflow Automation modules",
            ].map((item) => (
              <li key={item} className="flex items-start gap-2 px-4 py-2.5 sm:px-5">
                <CalendarClock className="mt-0.5 h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
                <span className="text-ink">{item}</span>
              </li>
            ))}
          </ul>
        </Card>
      </RecordShell>
    </div>
  );
}
