import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { CheckCheck, ChevronDown, Settings2 } from "lucide-react";
import { NotificationBulkActions } from "@/components/notifications/NotificationBulkActions";
import { NotificationEmptyState } from "@/components/notifications/NotificationEmptyState";
import { NotificationFilters } from "@/components/notifications/NotificationFilters";
import { NotificationGroup } from "@/components/notifications/NotificationGroup";
import { NotificationSearch } from "@/components/notifications/NotificationSearch";
import { NotificationSummaryCards } from "@/components/notifications/NotificationSummaryCards";
import { Modal } from "@/components/ui/Modal";
import { Button, Card, LinkButton, SkeletonRow } from "@/components/ui/primitives";
import { useToast } from "@/components/ui/Toast";
import {
  applyNotificationFilters,
  countActiveFilters,
  getTabCount,
  groupNotifications,
  isAssignedToMe,
  isRedacted,
  sortNotifications,
} from "@/notifications/logic";
import {
  NOTIFICATION_FILTER_DEFAULTS,
  type AppNotification,
  type NotificationFilterState,
  type NotificationTabId,
} from "@/notifications/types";
import { useApp } from "@/state/AppStore";
import type { EmptyStateKind } from "@/components/notifications/NotificationEmptyState";

const PAGE_SIZE = 8;
const CATEGORY_TABS = new Set<string>([
  "financial",
  "properties_leases",
  "maintenance_projects",
  "team_organization",
  "communications_documents",
  "system",
]);

function resolveEmptyState(
  scopedCount: number,
  filteredCount: number,
  filters: NotificationFilterState
): EmptyStateKind {
  if (filteredCount > 0) return "no_notifications";
  if (scopedCount === 0) return "no_notifications";
  if (filters.query.trim()) return "no_search_results";
  // A category tab and its matching category filter count as a single filter.
  const effectiveFilters: NotificationFilterState = {
    ...filters,
    category: filters.category === filters.tab ? "all" : filters.category,
  };
  const hasAdvancedFilters =
    countActiveFilters(effectiveFilters) > (filters.tab !== "all" ? 1 : 0);
  if (hasAdvancedFilters) return "no_advanced_filter_results";
  switch (filters.tab) {
    case "unread":
      return "no_unread";
    case "assigned":
      return "no_assigned";
    case "high_priority":
      return "no_advanced_filter_results";
    default:
      return "no_category_results";
  }
}

export function NotificationCenterPage() {
  const {
    scopedNotifications,
    summary,
    isLoading,
    scope,
    properties,
    organization,
    user,
    role,
    markRead,
    markUnread,
    dismiss,
    snooze,
    markAllRead,
  } = useApp();
  const toast = useToast();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState<NotificationFilterState>(NOTIFICATION_FILTER_DEFAULTS);
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [pendingDismiss, setPendingDismiss] = useState<string[] | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const urlQueryApplied = useRef(false);

  /* Deep-link support: /notifications?q=rent */
  useEffect(() => {
    if (urlQueryApplied.current) return;
    urlQueryApplied.current = true;
    const query = searchParams.get("q");
    if (query) setFilters((prev) => ({ ...prev, query }));
  }, [searchParams]);

  useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [filters]);

  /* Keep selection limited to what is currently on screen. */
  useEffect(() => {
    setSelectedIds((prev) => {
      if (prev.size === 0) return prev;
      const allowed = new Set(
        applyNotificationFilters(scopedNotifications, filters, scope).map((n) => n.id)
      );
      const next = new Set([...prev].filter((id) => allowed.has(id)));
      return next.size === prev.size ? prev : next;
    });
  }, [scopedNotifications, filters, scope]);

  const filtered = useMemo(
    () => applyNotificationFilters(scopedNotifications, filters, scope),
    [scopedNotifications, filters, scope]
  );

  const sorted = useMemo(() => sortNotifications(filtered), [filtered]);
  const pageItems = useMemo(() => sorted.slice(0, visibleCount), [sorted, visibleCount]);
  const groups = useMemo(() => groupNotifications(pageItems), [pageItems]);
  const remaining = Math.max(sorted.length - pageItems.length, 0);

  const tabCounts = useMemo(() => {
    const counts = {} as Record<NotificationTabId, number>;
    const tabs: NotificationTabId[] = [
      "all",
      "unread",
      "assigned",
      "high_priority",
      "financial",
      "properties_leases",
      "maintenance_projects",
      "team_organization",
      "communications_documents",
      "system",
    ];
    for (const tab of tabs) counts[tab] = getTabCount(tab, scopedNotifications, scope);
    return counts;
  }, [scopedNotifications, scope]);

  const restrictedIds = useMemo(
    () =>
      new Set(scopedNotifications.filter((n) => isRedacted(n, scope)).map((n) => n.id)),
    [scopedNotifications, scope]
  );

  const assignedIds = useMemo(
    () =>
      new Set(scopedNotifications.filter((n) => isAssignedToMe(n, scope)).map((n) => n.id)),
    [scopedNotifications, scope]
  );

  /* ------------------------------ actions ------------------------------ */

  const handleTabChange = useCallback((tab: NotificationTabId) => {
    setFilters((prev) => ({
      ...prev,
      tab,
      category: CATEGORY_TABS.has(tab) ? (tab as NotificationFilterState["category"]) : "all",
    }));
  }, []);

  const handleApplyAdvanced = useCallback(
    (draft: Partial<NotificationFilterState>) => {
      setFilters((prev) => {
        const next = { ...prev, ...draft };
        if (draft.category && draft.category !== "all") {
          next.tab = draft.category as NotificationTabId;
        } else if (CATEGORY_TABS.has(prev.tab)) {
          next.tab = "all";
        }
        return next;
      });
      toast.push({
        variant: "info",
        title: "Filters applied",
        description: `${countActiveFilters({ ...filters, ...draft })} filter(s) active.`,
      });
    },
    [filters, toast]
  );

  const handleRemoveFilter = useCallback((key: keyof NotificationFilterState) => {
    setFilters((prev) => ({ ...prev, [key]: NOTIFICATION_FILTER_DEFAULTS[key] }));
  }, []);

  const handleClearAll = useCallback(() => {
    setFilters(NOTIFICATION_FILTER_DEFAULTS);
    setSearchParams({}, { replace: true });
  }, [setSearchParams]);

  const handleMarkAllRead = useCallback(() => {
    const count = markAllRead();
    toast.push(
      count > 0
        ? {
            variant: "success",
            title: `Marked ${count} notification${count === 1 ? "" : "s"} as read`,
            description: `Scoped to ${organization.name} and ${user.name}. Dismissed notifications were not changed.`,
          }
        : {
            variant: "info",
            title: "Nothing to mark as read",
            description: "All active notifications in this organization are already read.",
          }
    );
  }, [markAllRead, organization.name, user.name, toast]);

  const handleDismiss = useCallback(
    (ids: string[]) => {
      dismiss(ids);
      setSelectedIds((prev) => {
        if (prev.size === 0) return prev;
        const next = new Set([...prev].filter((id) => !ids.includes(id)));
        return next;
      });
      toast.push({
        variant: "info",
        title:
          ids.length === 1
            ? "Notification dismissed"
            : `Dismissed ${ids.length} notifications`,
        description: "Removed from your inbox. The related business record is unchanged.",
      });
    },
    [dismiss, toast]
  );

  const handleSnoozeMessage = useCallback(
    (notification: AppNotification, label: string) => {
      toast.push({
        variant: "info",
        title: `Snoozed: ${notification.title}`,
        description: `${label.replace("Snooze ", "")} from now it will return to your inbox. Frontend demo only — no background scheduler runs.`,
      });
    },
    [toast]
  );

  const toggleSelect = useCallback((id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const allVisibleSelected = pageItems.length > 0 && pageItems.every((n) => selectedIds.has(n.id));
  const someVisibleSelected = pageItems.some((n) => selectedIds.has(n.id));

  const emptyKind = resolveEmptyState(scopedNotifications.length, filtered.length, filters);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Page header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h1 className="text-xl font-semibold tracking-tight text-ink sm:text-2xl">
            Notifications
          </h1>
          <p className="mt-1 text-sm text-muted">
            Stay on top of important updates across your rental business.
          </p>
          <p className="mt-1.5 text-xs text-muted">
            {organization.name} · {user.name} · {role}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="secondary" size="sm" onClick={handleMarkAllRead} disabled={summary.unread === 0}>
            <CheckCheck className="h-3.5 w-3.5" aria-hidden="true" />
            Mark All as Read
          </Button>
          <LinkButton to="/settings/notifications" variant="primary" size="sm">
            <Settings2 className="h-3.5 w-3.5" aria-hidden="true" />
            Notification Preferences
          </LinkButton>
        </div>
      </div>

      {/* Summary cards */}
      <NotificationSummaryCards
        summary={summary}
        activeTab={filters.tab}
        onSelect={handleTabChange}
        isLoading={isLoading}
      />

      {/* Search + filters */}
      <div className="space-y-3">
        <NotificationSearch
          ref={searchInputRef}
          value={filters.query}
          onChange={(query) => setFilters((prev) => ({ ...prev, query }))}
          resultCount={filtered.length}
          totalInScope={scopedNotifications.length}
          isLoading={isLoading}
        />
        <NotificationFilters
          filters={filters}
          tabCounts={tabCounts}
          properties={properties.map((p) => ({ id: p.id, name: p.name }))}
          onTabChange={handleTabChange}
          onApplyAdvanced={handleApplyAdvanced}
          onClearAll={handleClearAll}
          onRemoveFilter={handleRemoveFilter}
          isLoading={isLoading}
        />
      </div>

      {/* Bulk actions */}
      <NotificationBulkActions
        selectedCount={selectedIds.size}
        onMarkRead={() => {
          const ids = [...selectedIds];
          markRead(ids);
          toast.push({ variant: "success", title: `Marked ${ids.length} as read` });
        }}
        onMarkUnread={() => {
          const ids = [...selectedIds];
          markUnread(ids);
          toast.push({ variant: "success", title: `Marked ${ids.length} as unread` });
        }}
        onDismiss={() => setPendingDismiss([...selectedIds])}
        onClearSelection={() => setSelectedIds(new Set())}
      />

      {/* List */}
      {isLoading ? (
        <Card>
          <div className="border-b border-line px-4 py-3 sm:px-5">
            <p className="text-xs font-semibold tracking-wide text-muted uppercase">
              Loading notifications…
            </p>
          </div>
          {[0, 1, 2, 3, 4].map((index) => (
            <SkeletonRow key={index} />
          ))}
        </Card>
      ) : groups.length === 0 ? (
        <Card>
          <NotificationEmptyState
            kind={emptyKind}
            onClearFilters={handleClearAll}
            onClearSearch={() => setFilters((prev) => ({ ...prev, query: "" }))}
            onShowAll={() => handleTabChange("all")}
            onOpenPreferences={() => navigate("/settings/notifications")}
          />
        </Card>
      ) : (
        <Card>
          {/* List toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line bg-ivory/70 px-3 py-2.5 sm:px-5">
            <div className="flex items-center gap-2.5">
              <input
                type="checkbox"
                checked={allVisibleSelected}
                ref={(node) => {
                  if (node) node.indeterminate = someVisibleSelected && !allVisibleSelected;
                }}
                onChange={() =>
                  setSelectedIds(
                    allVisibleSelected
                      ? new Set()
                      : new Set(pageItems.map((n) => n.id))
                  )
                }
                aria-label="Select all visible notifications"
                className="h-4 w-4 cursor-pointer rounded border-line accent-[var(--color-forest)]"
              />
              <p className="text-xs text-muted">
                Showing <span className="font-semibold text-ink tabular-nums">{pageItems.length}</span>{" "}
                of <span className="font-semibold text-ink tabular-nums">{sorted.length}</span> matching
                notifications
              </p>
            </div>
            {selectedIds.size > 0 ? (
              <p className="text-xs font-medium text-forest" role="status">
                {selectedIds.size} selected
              </p>
            ) : (
              <p className="text-xs text-muted">
                {remaining > 0 ? "Incremental loading · 8 rows at a time" : "All matching rows shown"}
              </p>
            )}
          </div>

          {groups.map((group) => (
            <NotificationGroup
              key={group.bucket}
              group={group}
              selectedIds={selectedIds}
              selectionMode
              restrictedIds={restrictedIds}
              assignedIds={assignedIds}
              onToggleSelect={toggleSelect}
              onMarkRead={markRead}
              onMarkUnread={markUnread}
              onDismiss={handleDismiss}
              onSnooze={snooze}
              onSnoozeMessage={handleSnoozeMessage}
            />
          ))}

          <div className="flex flex-col items-center justify-between gap-2 border-t border-line bg-ivory/70 px-4 py-3 sm:flex-row sm:px-5">
            <p className="text-xs text-muted">
              {remaining > 0
                ? `${remaining} older notification${remaining === 1 ? "" : "s"} available`
                : "End of matching notifications"}
            </p>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => setVisibleCount((prev) => prev + PAGE_SIZE)}
              disabled={remaining === 0}
            >
              Load more
              <ChevronDown className="h-3.5 w-3.5" aria-hidden="true" />
            </Button>
          </div>
        </Card>
      )}

      {/* Bulk dismiss confirmation */}
      <DismissConfirmDialog
        open={pendingDismiss !== null}
        count={pendingDismiss?.length ?? 0}
        onCancel={() => setPendingDismiss(null)}
        onConfirm={() => {
          if (pendingDismiss) handleDismiss(pendingDismiss);
          setPendingDismiss(null);
        }}
      />
    </div>
  );
}

function DismissConfirmDialog({
  open,
  count,
  onCancel,
  onConfirm,
}: {
  open: boolean;
  count: number;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <Modal
      open={open}
      onClose={onCancel}
      title={`Dismiss ${count} notification${count === 1 ? "" : "s"}?`}
      description="This only changes your inbox."
      size="sm"
      footer={
        <>
          <Button variant="secondary" size="sm" onClick={onCancel}>
            Cancel
          </Button>
          <Button variant="danger" size="sm" onClick={onConfirm}>
            Dismiss
          </Button>
        </>
      }
    >
      <p className="text-sm text-muted">
        Dismissed notifications are removed from your inbox and your unread count. The related
        invoices, work orders, leases, and documents are not modified.
      </p>
    </Modal>
  );
}
