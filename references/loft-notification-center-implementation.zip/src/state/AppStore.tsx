import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { MEMBERSHIPS, ORGANIZATIONS, PROPERTIES, USERS } from "@/lib/mockData";
import { can, permissionsFor, roleFor } from "@/lib/rbac";
import type { Organization, Permission, Property, User } from "@/lib/types";
import { notificationRepository } from "@/notifications/repository";
import {
  DEFAULT_NOTIFICATION_PREFERENCES,
  type AppNotification,
  type NotificationCategory,
  type NotificationPreferences,
  type NotificationSeverity,
} from "@/notifications/types";
import {
  getVisibleNotifications,
  summarize,
  type NotificationScope,
  type NotificationSummary,
} from "@/notifications/logic";

interface AppContextValue {
  /* Session + scope */
  organization: Organization;
  organizations: Organization[];
  user: User;
  usersInOrganization: User[];
  properties: Property[];
  role: string;
  permissions: Permission[];
  can: (permission: Permission) => boolean;
  switchOrganization: (organizationId: string) => void;
  switchUser: (userId: string) => void;

  /* Notification state */
  notifications: AppNotification[];
  scopedNotifications: AppNotification[];
  summary: NotificationSummary;
  unreadCount: number;
  isLoading: boolean;
  scope: NotificationScope;
  markRead: (ids: string[]) => void;
  markUnread: (ids: string[]) => void;
  dismiss: (ids: string[]) => void;
  snooze: (ids: string[], until: string) => void;
  markAllRead: () => number;

  /* Preferences (session-only mock state) */
  preferences: NotificationPreferences;
  setCategoryEnabled: (category: NotificationCategory, enabled: boolean) => void;
  setCategoryMinimumSeverity: (
    category: NotificationCategory,
    severity: NotificationSeverity
  ) => void;
  setSmsEnabled: (enabled: boolean) => void;
  restoreDefaultPreferences: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const ROLE_LABELS: Record<string, string> = {
  owner: "Owner",
  property_manager: "Property Manager",
  accountant: "Accountant",
  maintenance_lead: "Maintenance Lead",
  read_only_investor: "Read-only Investor",
};

export function AppProvider({
  children,
  initialOrganizationId = ORGANIZATIONS[0].id,
  initialUserId = USERS[0].id,
}: {
  children: ReactNode;
  /** Overridable for smoke tests / storybook-style harnesses. */
  initialOrganizationId?: string;
  initialUserId?: string;
}) {
  const [activeOrgId, setActiveOrgId] = useState<string>(initialOrganizationId);
  const [activeUserId, setActiveUserId] = useState<string>(initialUserId);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [preferences, setPreferences] = useState<NotificationPreferences>(
    DEFAULT_NOTIFICATION_PREFERENCES
  );

  useEffect(() => {
    let cancelled = false;
    notificationRepository.list().then((rows) => {
      if (cancelled) return;
      setNotifications(rows);
      setIsLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const organization = useMemo(
    () => ORGANIZATIONS.find((o) => o.id === activeOrgId) ?? ORGANIZATIONS[0],
    [activeOrgId]
  );

  const user = useMemo(
    () => USERS.find((u) => u.id === activeUserId) ?? USERS[0],
    [activeUserId]
  );

  const role = useMemo(
    () => roleFor(activeUserId, activeOrgId),
    [activeUserId, activeOrgId]
  );

  const permissions = useMemo(
    () => permissionsFor(activeUserId, activeOrgId),
    [activeUserId, activeOrgId]
  );

  const usersInOrganization = useMemo(
    () =>
      MEMBERSHIPS.filter((m) => m.organizationId === activeOrgId).map(
        (m) => USERS.find((u) => u.id === m.userId)!
      ),
    [activeOrgId]
  );

  const properties = useMemo(
    () => PROPERTIES.filter((p) => p.organizationId === activeOrgId),
    [activeOrgId]
  );

  const scope: NotificationScope = useMemo(
    () => ({
      organizationId: activeOrgId,
      userId: activeUserId,
      role,
      granted: permissions,
    }),
    [activeOrgId, activeUserId, role, permissions]
  );

  const scopedNotifications = useMemo(
    () => getVisibleNotifications(notifications, scope),
    [notifications, scope]
  );

  const summary = useMemo(() => summarize(scopedNotifications), [scopedNotifications]);

  const patch = useCallback(
    (
      ids: string[],
      updater: (row: AppNotification) => AppNotification,
      persist?: (ids: string[], repo: typeof notificationRepository) => void
    ) => {
      if (ids.length === 0) return;
      const idSet = new Set(ids);
      setNotifications((prev) => prev.map((n) => (idSet.has(n.id) ? updater(n) : n)));
      persist?.(ids, notificationRepository);
    },
    []
  );

  const markRead = useCallback(
    (ids: string[]) =>
      patch(
        ids,
        (n) => ({ ...n, readAt: new Date().toISOString() }),
        (ids2, repo) => void repo.markRead(ids2, new Date().toISOString())
      ),
    [patch]
  );

  const markUnread = useCallback(
    (ids: string[]) =>
      patch(
        ids,
        (n) => ({ ...n, readAt: null }),
        (ids2, repo) => void repo.markUnread(ids2)
      ),
    [patch]
  );

  const dismiss = useCallback(
    (ids: string[]) =>
      patch(
        ids,
        (n) => ({ ...n, dismissedAt: new Date().toISOString() }),
        (ids2, repo) => void repo.dismiss(ids2, new Date().toISOString())
      ),
    [patch]
  );

  const snooze = useCallback(
    (ids: string[], until: string) =>
      patch(
        ids,
        (n) => ({ ...n, snoozedUntil: until }),
        (ids2, repo) => void repo.snooze(ids2, until)
      ),
    [patch]
  );

  /**
   * Marks every active, unread notification in the current organization and
   * recipient scope as read. Dismissed notifications are untouched and other
   * organizations are never modified.
   */
  const markAllRead = useCallback(() => {
    const ids = scopedNotifications
      .filter((n) => n.readAt === null)
      .map((n) => n.id);
    if (ids.length > 0) markRead(ids);
    return ids.length;
  }, [scopedNotifications, markRead]);

  const switchOrganization = useCallback((organizationId: string) => {
    setActiveOrgId(organizationId);
  }, []);

  const switchUser = useCallback((userId: string) => {
    setActiveUserId(userId);
  }, []);

  const value: AppContextValue = useMemo(
    () => ({
      organization,
      organizations: ORGANIZATIONS,
      user,
      usersInOrganization,
      properties,
      role: role ?? "Read-only",
      permissions,
      can: (permission: Permission) => can(permission, permissions),
      switchOrganization,
      switchUser,
      notifications,
      scopedNotifications,
      summary,
      unreadCount: summary.unread,
      isLoading,
      scope,
      markRead,
      markUnread,
      dismiss,
      snooze,
      markAllRead,
      preferences,
      setCategoryEnabled: (category, enabled) =>
        setPreferences((prev) => ({
          ...prev,
          categories: { ...prev.categories, [category]: { ...prev.categories[category], enabled } },
        })),
      setCategoryMinimumSeverity: (category, minimumSeverity) =>
        setPreferences((prev) => ({
          ...prev,
          categories: { ...prev.categories, [category]: { ...prev.categories[category], minimumSeverity } },
        })),
      setSmsEnabled: (smsEnabled) => setPreferences((prev) => ({ ...prev, smsEnabled })),
      restoreDefaultPreferences: () => setPreferences(DEFAULT_NOTIFICATION_PREFERENCES),
    }),
    [
      organization,
      user,
      usersInOrganization,
      properties,
      role,
      permissions,
      switchOrganization,
      switchUser,
      notifications,
      scopedNotifications,
      summary,
      isLoading,
      scope,
      markRead,
      markUnread,
      dismiss,
      snooze,
      markAllRead,
      preferences,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used inside <AppProvider>");
  return context;
}

export { ROLE_LABELS };
