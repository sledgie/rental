import { NavLink } from "react-router-dom";
import {
  Bell,
  Building2,
  CalendarClock,
  ClipboardList,
  FileSignature,
  FileText,
  History,
  Landmark,
  LayoutDashboard,
  MessageSquare,
  UserCog,
  Users,
  Workflow,
  Wrench,
  X,
  type LucideIcon,
} from "lucide-react";
import { NAV_SECTIONS } from "@/lib/routing";
import { useApp } from "@/state/AppStore";
import { cn } from "@/utils/cn";

const ICONS: Record<string, LucideIcon> = {
  LayoutDashboard,
  Bell,
  Building2,
  Users,
  FileSignature,
  Landmark,
  Wrench,
  ClipboardList,
  FileText,
  MessageSquare,
  UserCog,
  History,
  CalendarClock,
  Workflow,
};

export function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { can, unreadCount } = useApp();

  return (
    <div className="flex h-full flex-col bg-evergreen">
      <div className="flex items-center gap-2.5 px-5 py-4">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-forest text-sm font-bold text-white">
          L
        </span>
        <div className="leading-tight">
          <p className="text-sm font-semibold text-white">L.O.F.T.</p>
          <p className="text-[11px] text-white/60">Property Operations</p>
        </div>
        {onNavigate ? (
          <button
            type="button"
            onClick={onNavigate}
            aria-label="Close navigation menu"
            className="ml-auto rounded-md p-1.5 text-white/70 transition-colors hover:bg-white/10 hover:text-white lg:hidden"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        ) : null}
      </div>

      <nav
        aria-label="Main navigation"
        className="flex-1 space-y-5 overflow-y-auto px-3 py-3 scrollbar-thin"
      >
        {NAV_SECTIONS.map((section) => {
          const items = section.items.filter(
            (item) => !item.permission || can(item.permission)
          );
          if (items.length === 0) return null;
          return (
            <div key={section.label}>
              <p className="px-3 pb-1.5 text-[11px] font-semibold tracking-wider text-white/45 uppercase">
                {section.label}
              </p>
              <ul className="space-y-0.5">
                {items.map((item) => {
                  const Icon = ICONS[item.icon] ?? LayoutDashboard;
                  return (
                    <li key={item.to}>
                      <NavLink
                        to={item.to}
                        onClick={onNavigate}
                        className={({ isActive }) =>
                          cn(
                            "group flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition-colors",
                            isActive
                              ? "bg-white/12 font-semibold text-white"
                              : "text-white/75 hover:bg-white/8 hover:text-white"
                          )
                        }
                      >
                        <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                        <span className="truncate">{item.label}</span>
                        {item.badge === "notifications" && unreadCount > 0 ? (
                          <span className="ml-auto rounded-full bg-white/90 px-1.5 py-0.5 text-[10px] font-bold text-evergreen">
                            {unreadCount > 99 ? "99+" : unreadCount}
                          </span>
                        ) : null}
                      </NavLink>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </nav>

      <div className="border-t border-white/10 px-5 py-3.5 text-[11px] leading-relaxed text-white/50">
        Demo workspace · mock data only. Amounts and records are illustrative.
      </div>
    </div>
  );
}
