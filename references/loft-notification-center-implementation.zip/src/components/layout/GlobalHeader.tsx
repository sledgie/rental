import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Check, ChevronsUpDown, Menu, Search, Settings, UserCircle2 } from "lucide-react";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { Popover } from "@/components/ui/Popover";
import { ROLE_LABELS, useApp } from "@/state/AppStore";
import { cn } from "@/utils/cn";

export function GlobalHeader({ onOpenNavigation }: { onOpenNavigation: () => void }) {
  const {
    organization,
    organizations,
    user,
    usersInOrganization,
    role,
    switchOrganization,
    switchUser,
  } = useApp();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  const submitSearch = (event: React.FormEvent) => {
    event.preventDefault();
    const trimmed = query.trim();
    navigate(trimmed ? `/notifications?q=${encodeURIComponent(trimmed)}` : "/notifications");
  };

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white/95 backdrop-blur">
      <div className="flex h-16 items-center gap-2 px-3 sm:gap-3 sm:px-5">
        <button
          type="button"
          onClick={onOpenNavigation}
          aria-label="Open navigation menu"
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-line bg-white text-ink transition-colors hover:bg-forest-50 lg:hidden"
        >
          <Menu className="h-[18px] w-[18px]" aria-hidden="true" />
        </button>

        {/* Organization switcher */}
        <Popover
          ariaLabel="Switch organization"
          widthClass="w-72"
          align="start"
          panelClassName="left-0"
          trigger={({ open, toggle, ref }) => (
            <button
              type="button"
              ref={ref}
              onClick={toggle}
              aria-haspopup="dialog"
              aria-expanded={open}
              className={cn(
                "flex min-w-0 items-center gap-2 rounded-lg border px-2.5 py-2 text-left transition-colors",
                open
                  ? "border-forest-200 bg-forest-50"
                  : "border-line bg-white hover:border-forest-200 hover:bg-forest-50"
              )}
            >
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-evergreen text-[11px] font-bold text-white">
                {organization.name.slice(0, 2).toUpperCase()}
              </span>
              <span className="min-w-0">
                <span className="block max-w-[9rem] truncate text-sm font-semibold text-ink sm:max-w-[14rem]">
                  {organization.name}
                </span>
                <span className="hidden text-[11px] text-muted sm:block">
                  {organization.plan} plan · {organization.propertyCount} properties
                </span>
              </span>
              <ChevronsUpDown className="h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
            </button>
          )}
        >
          {(close) => (
            <div className="p-1.5">
              <p className="px-2.5 pt-1 pb-2 text-[11px] font-semibold tracking-wide text-muted uppercase">
                Organizations
              </p>
              <ul className="space-y-0.5">
                {organizations.map((org) => (
                  <li key={org.id}>
                    <button
                      type="button"
                      onClick={() => {
                        switchOrganization(org.id);
                        close();
                      }}
                      className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-forest-50"
                    >
                      <span className="flex h-8 w-8 items-center justify-center rounded-md bg-evergreen text-[11px] font-bold text-white">
                        {org.name.slice(0, 2).toUpperCase()}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium text-ink">
                          {org.name}
                        </span>
                        <span className="block text-xs text-muted">
                          {org.propertyCount} properties · {org.plan}
                        </span>
                      </span>
                      {org.id === organization.id ? (
                        <Check className="h-4 w-4 text-forest" aria-hidden="true" />
                      ) : null}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Popover>

        <form
          role="search"
          onSubmit={submitSearch}
          className="ml-auto hidden max-w-sm flex-1 md:block"
        >
          <label htmlFor="global-search" className="sr-only">
            Search notifications
          </label>
          <div className="relative">
            <Search
              className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted"
              aria-hidden="true"
            />
            <input
              id="global-search"
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search notifications..."
              className="h-10 w-full rounded-lg border border-line bg-ivory pr-3 pl-9 text-sm text-ink placeholder:text-muted/70 focus:border-forest focus:bg-white focus:outline-none focus:ring-2 focus:ring-forest/15"
            />
          </div>
        </form>

        <div className="ml-auto flex items-center gap-2 md:ml-0">
          <Link
            to="/settings/notifications"
            aria-label="Notification preferences"
            className="hidden h-10 w-10 items-center justify-center rounded-lg border border-line bg-white text-ink transition-colors hover:border-forest-200 hover:bg-forest-50 sm:flex"
          >
            <Settings className="h-[18px] w-[18px]" aria-hidden="true" />
          </Link>

          <NotificationBell />

          {/* User menu */}
          <Popover
            ariaLabel="Account menu"
            widthClass="w-72"
            trigger={({ open, toggle, ref }) => (
              <button
                type="button"
                ref={ref}
                onClick={toggle}
                aria-haspopup="dialog"
                aria-expanded={open}
                className={cn(
                  "flex h-10 items-center gap-2 rounded-lg border px-1.5 transition-colors sm:px-2",
                  open
                    ? "border-forest-200 bg-forest-50"
                    : "border-line bg-white hover:border-forest-200 hover:bg-forest-50"
                )}
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-forest-100 text-[11px] font-bold text-forest">
                  {user.initials}
                </span>
                <span className="hidden text-left leading-tight sm:block">
                  <span className="block max-w-[8rem] truncate text-sm font-medium text-ink">
                    {user.name}
                  </span>
                  <span className="block text-[11px] text-muted">{role}</span>
                </span>
                <ChevronsUpDown className="hidden h-4 w-4 text-muted sm:block" aria-hidden="true" />
              </button>
            )}
          >
            {() => (
              <div className="p-1.5">
                <div className="px-2.5 pt-1 pb-2">
                  <p className="text-sm font-semibold text-ink">{user.name}</p>
                  <p className="truncate text-xs text-muted">{user.email}</p>
                  <p className="mt-1 text-xs text-forest">
                    {role} · {organization.name}
                  </p>
                </div>

                <p className="px-2.5 pt-2 pb-1.5 text-[11px] font-semibold tracking-wide text-muted uppercase">
                  Demo: signed in as
                </p>
                <ul className="space-y-0.5">
                  {usersInOrganization.map((member) => (
                    <li key={member.id}>
                      <button
                        type="button"
                        onClick={() => switchUser(member.id)}
                        className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-forest-50"
                      >
                        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-forest-100 text-[10px] font-bold text-forest">
                          {member.initials}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium text-ink">
                            {member.name}
                          </span>
                          <span className="block truncate text-xs text-muted">
                            {member.jobTitle}
                          </span>
                        </span>
                        {member.id === user.id ? (
                          <Check className="h-4 w-4 text-forest" aria-hidden="true" />
                        ) : null}
                      </button>
                    </li>
                  ))}
                </ul>

                <div className="mt-2 border-t border-line pt-2">
                  <p className="px-2.5 pb-1 text-[11px] text-muted">
                    Roles gate notification visibility. Try switching to{" "}
                    {usersInOrganization.find((m) => m.id !== user.id)?.name ?? "another member"}{" "}
                    to see permission-aware behavior.
                  </p>
                  <Link
                    to="/settings/notifications"
                    className="flex items-center gap-2 rounded-lg px-2.5 py-2 text-sm text-ink transition-colors hover:bg-forest-50"
                  >
                    <UserCircle2 className="h-4 w-4 text-muted" aria-hidden="true" />
                    Notification preferences
                  </Link>
                  <p className="px-2.5 py-1.5 text-[11px] text-muted">
                    {ROLE_LABELS[role] ? `${ROLE_LABELS[role]} access` : "Member access"}
                  </p>
                </div>
              </div>
            )}
          </Popover>
        </div>
      </div>
    </header>
  );
}
