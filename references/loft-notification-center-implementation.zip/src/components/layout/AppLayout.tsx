import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { GlobalHeader } from "./GlobalHeader";
import { SidebarContent } from "./Sidebar";
import { cn } from "@/utils/cn";

export function AppLayout() {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setMobileNavOpen(false);
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [location.pathname, location.search]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMobileNavOpen(false);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-ivory">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-evergreen-deep/40 lg:block">
        <SidebarContent />
      </aside>

      {/* Mobile navigation drawer */}
      <div
        className={cn(
          "fixed inset-0 z-50 lg:hidden",
          mobileNavOpen ? "pointer-events-auto visible" : "pointer-events-none invisible"
        )}
        aria-hidden={!mobileNavOpen}
      >
        <div
          onClick={() => setMobileNavOpen(false)}
          className={cn(
            "absolute inset-0 bg-evergreen-deep/50 transition-opacity duration-150",
            mobileNavOpen ? "opacity-100" : "opacity-0"
          )}
        />
        <div
          role="dialog"
          aria-label="Navigation menu"
          className={cn(
            "absolute inset-y-0 left-0 w-[17.5rem] max-w-[86%] shadow-pop transition-transform duration-200",
            mobileNavOpen ? "translate-x-0" : "-translate-x-full"
          )}
        >
          <SidebarContent onNavigate={() => setMobileNavOpen(false)} />
        </div>
      </div>

      <div className="lg:pl-64">
        <GlobalHeader onOpenNavigation={() => setMobileNavOpen(true)} />
        <main id="main-content" className="mx-auto w-full max-w-[100rem] px-3 py-5 sm:px-5 sm:py-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
