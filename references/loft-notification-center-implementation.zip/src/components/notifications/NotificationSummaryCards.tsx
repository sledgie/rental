import { Bell, BellRing, TriangleAlert } from "lucide-react";
import type { NotificationSummary } from "@/notifications/logic";
import type { NotificationTabId } from "@/notifications/types";
import { cn } from "@/utils/cn";

const CARD_TONES = {
  all: {
    icon: Bell,
    ring: "focus-visible:ring-forest/30",
    active: "border-forest-200 bg-forest-50",
    iconTone: "bg-forest-100 text-forest",
  },
  unread: {
    icon: BellRing,
    ring: "focus-visible:ring-forest/30",
    active: "border-forest-200 bg-forest-50",
    iconTone: "bg-forest-100 text-forest",
  },
  urgent: {
    icon: TriangleAlert,
    ring: "focus-visible:ring-critical-fg/30",
    active: "border-critical-line bg-critical-bg",
    iconTone: "bg-critical-bg text-critical-fg",
  },
} as const;

export function NotificationSummaryCards({
  summary,
  activeTab,
  onSelect,
  isLoading,
}: {
  summary: NotificationSummary;
  activeTab: NotificationTabId;
  onSelect: (tab: NotificationTabId) => void;
  isLoading?: boolean;
}) {
  const cards: Array<{
    id: NotificationTabId;
    key: keyof typeof CARD_TONES;
    label: string;
    value: number;
    hint: string;
  }> = [
    {
      id: "all",
      key: "all",
      label: "All Notifications",
      value: summary.total,
      hint: "Active in this organization",
    },
    {
      id: "unread",
      key: "unread",
      label: "Unread",
      value: summary.unread,
      hint: "Awaiting your review",
    },
    {
      id: "high_priority",
      key: "urgent",
      label: "Urgent",
      value: summary.urgent,
      hint: "Unread critical or high severity",
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
      {cards.map((card) => {
        const tone = CARD_TONES[card.key];
        const Icon = tone.icon;
        const isActive =
          activeTab === card.id ||
          (card.id === "unread" && activeTab === "unread") ||
          (card.id === "high_priority" && activeTab === "high_priority");
        return (
          <button
            key={card.id}
            type="button"
            onClick={() => onSelect(card.id)}
            aria-pressed={isActive}
            aria-label={`${card.label}: ${isLoading ? "loading" : card.value}`}
            className={cn(
              "group flex items-center gap-3 rounded-xl border bg-white p-3.5 text-left shadow-card transition-colors sm:p-4",
              "hover:border-forest-200 focus-visible:ring-2",
              tone.ring,
              isActive ? tone.active : "border-line"
            )}
          >
            <span
              className={cn(
                "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                tone.iconTone
              )}
            >
              <Icon className="h-5 w-5" aria-hidden="true" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-xs font-medium tracking-wide text-muted uppercase">
                {card.label}
              </span>
              <span
                className="mt-0.5 block text-2xl leading-7 font-semibold text-ink tabular-nums"
                aria-hidden={isLoading}
              >
                {isLoading ? "—" : card.value}
              </span>
              <span className="mt-0.5 block truncate text-xs text-muted">{card.hint}</span>
            </span>
          </button>
        );
      })}
    </div>
  );
}
