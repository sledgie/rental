import { forwardRef } from "react";
import { Search, X } from "lucide-react";
import { Button } from "@/components/ui/primitives";

export interface NotificationSearchProps {
  value: string;
  onChange: (value: string) => void;
  resultCount: number;
  totalInScope: number;
  isLoading?: boolean;
}

export const NotificationSearch = forwardRef<
  HTMLInputElement,
  NotificationSearchProps
>(function NotificationSearch(
  { value, onChange, resultCount, totalInScope, isLoading },
  ref
) {
  return (
    <div className="w-full">
      <div className="relative">
        <Search
          className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted"
          aria-hidden="true"
        />
        <input
          ref={ref}
          type="search"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          placeholder="Search notifications..."
          aria-label="Search notifications"
          aria-describedby="notification-search-status"
          className="h-10 w-full rounded-lg border border-line bg-white pr-24 pl-9 text-sm text-ink placeholder:text-muted/70 focus:border-forest focus:outline-none focus:ring-2 focus:ring-forest/15 [&::-webkit-search-cancel-button]:hidden"
        />
        {value ? (
          <Button
            size="xs"
            variant="ghost"
            onClick={() => onChange("")}
            className="absolute top-1/2 right-2 -translate-y-1/2"
            aria-label="Clear search"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
            Clear
          </Button>
        ) : null}
      </div>
      <p id="notification-search-status" className="sr-only" role="status">
        {isLoading
          ? "Loading notifications"
          : value.trim()
            ? `${resultCount} of ${totalInScope} notifications match "${value.trim()}"`
            : `${totalInScope} active notifications in this organization`}
      </p>
    </div>
  );
});
