import { Link } from "react-router-dom";
import {
  CheckCheck,
  ChevronRight,
  Clock,
  Eye,
  EyeOff,
  MoreHorizontal,
  X,
} from "lucide-react";
import { Popover } from "@/components/ui/Popover";
import { Button, LinkButton } from "@/components/ui/primitives";
import {
  formatFullTimestamp,
  formatRelativeTimestamp,
} from "@/notifications/logic";
import { CATEGORY_META, getNotificationIcon } from "@/notifications/meta";
import type { AppNotification } from "@/notifications/types";
import {
  NotificationCategoryBadge,
  NotificationSeverityBadge,
  RestrictedBadge,
} from "./NotificationSeverityBadge";
import { cn } from "@/utils/cn";

export const SNOOZE_OPTIONS = [
  { label: "Snooze 1 hour", minutes: 60 },
  { label: "Snooze 1 day", minutes: 60 * 24 },
  { label: "Snooze 1 week", minutes: 60 * 24 * 7 },
];

export interface NotificationItemProps {
  notification: AppNotification;
  restricted: boolean;
  assignedToMe: boolean;
  unread: boolean;
  selectable?: boolean;
  selected?: boolean;
  onToggleSelect?: (id: string) => void;
  onMarkRead: (ids: string[]) => void;
  onMarkUnread: (ids: string[]) => void;
  onDismiss: (ids: string[]) => void;
  onSnooze: (ids: string[], until: string) => void;
  onSnoozeMessage: (notification: AppNotification, label: string) => void;
}

export function NotificationItem({
  notification: n,
  restricted,
  assignedToMe,
  unread,
  selectable = true,
  selected = false,
  onToggleSelect,
  onMarkRead,
  onMarkUnread,
  onDismiss,
  onSnooze,
  onSnoozeMessage,
}: NotificationItemProps) {
  const Icon = getNotificationIcon(n.category, n.eventType);
  const urgent = n.severity === "critical" || n.severity === "high";
  const canOpen = Boolean(n.actionRoute) && !restricted;
  const selectLabel = `Select notification: ${n.title}`;

  return (
    <li
      className={cn(
        "relative flex gap-3 border-b border-line px-3 py-3.5 transition-colors last:border-b-0 sm:px-5",
        unread ? "bg-forest-50/55" : "bg-white hover:bg-ivory/70",
        selected && "bg-forest-100/60"
      )}
    >
      {urgent ? (
        <span
          aria-hidden="true"
          className={cn(
            "absolute inset-y-0 left-0 w-[3px]",
            n.severity === "critical" ? "bg-critical-fg" : "bg-high-fg"
          )}
        />
      ) : null}

      {selectable ? (
        <div className="flex items-start pt-1.5">
          <input
            type="checkbox"
            checked={selected}
            onChange={() => onToggleSelect?.(n.id)}
            aria-label={selectLabel}
            className="h-4 w-4 shrink-0 cursor-pointer rounded border-line accent-[var(--color-forest)]"
          />
        </div>
      ) : null}

      <span
        aria-hidden="true"
        className={cn(
          "mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",
          CATEGORY_META[n.category].tone
        )}
      >
        <Icon className="h-[18px] w-[18px]" />
      </span>

      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-x-3 gap-y-1">
          <div className="flex min-w-0 flex-1 items-start gap-2">
            {unread ? (
              <span
                aria-label="Unread"
                title="Unread notification"
                className="mt-[7px] h-2 w-2 shrink-0 rounded-full bg-forest ring-2 ring-forest/15"
              />
            ) : (
              <span aria-hidden="true" className="mt-[7px] h-2 w-2 shrink-0" />
            )}
            <div className="min-w-0">
              <h3 className="text-sm leading-5 font-semibold text-ink">
                {canOpen ? (
                  <Link
                    to={n.actionRoute!}
                    onClick={() => unread && onMarkRead([n.id])}
                    className="transition-colors hover:text-forest"
                  >
                    {n.title}
                  </Link>
                ) : (
                  <span>{n.title}</span>
                )}
              </h3>
              <p className="mt-1 text-sm leading-5 text-muted">
                {restricted
                  ? "Details are hidden because your role does not have access to this record."
                  : n.message}
              </p>
            </div>
          </div>
          <time
            dateTime={n.createdAt}
            title={formatFullTimestamp(n.createdAt)}
            className="shrink-0 pt-0.5 text-[11px] whitespace-nowrap text-muted"
          >
            {formatRelativeTimestamp(n.createdAt)}
          </time>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          <NotificationSeverityBadge severity={n.severity} />
          <NotificationCategoryBadge category={n.category} />
          {restricted ? <RestrictedBadge /> : null}
          {assignedToMe ? (
            <span className="inline-flex items-center gap-1 rounded-full border border-forest-200 bg-white px-2 py-0.5 text-[11px] font-medium leading-4 text-forest">
              You
            </span>
          ) : null}
          {!restricted && (n.propertyName || n.unitLabel || n.entityLabel) ? (
            <span className="inline-flex min-w-0 items-center gap-1 truncate rounded-full border border-line bg-white px-2 py-0.5 text-[11px] leading-4 text-muted">
              {[n.propertyName, n.unitLabel, n.entityLabel].filter(Boolean).join(" · ")}
            </span>
          ) : null}
          {assignedToMe === false && n.assignedToName ? (
            <span className="inline-flex items-center gap-1 rounded-full border border-line bg-white px-2 py-0.5 text-[11px] leading-4 text-muted">
              <Clock className="h-3 w-3" aria-hidden="true" />
              {n.assignedToName}
            </span>
          ) : null}
        </div>

        <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
          {canOpen ? (
            <LinkButton
              to={n.actionRoute!}
              size="xs"
              variant="secondary"
              onClick={() => unread && onMarkRead([n.id])}
              ariaLabel={`${n.actionLabel ?? "Open record"}: ${n.title}`}
              className="[&_svg]:transition-transform hover:[&_svg]:translate-x-0.5"
            >
              {n.actionLabel ?? "Open record"}
              <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
            </LinkButton>
          ) : (
            <span className="inline-flex h-7 items-center rounded-lg border border-dashed border-line px-2.5 text-xs text-muted">
              No linked record
            </span>
          )}

          {unread ? (
            <Button
              size="xs"
              variant="ghost"
              onClick={() => onMarkRead([n.id])}
              title="Mark as read"
            >
              <CheckCheck className="h-3.5 w-3.5" aria-hidden="true" />
              Mark read
            </Button>
          ) : (
            <Button
              size="xs"
              variant="ghost"
              onClick={() => onMarkUnread([n.id])}
              title="Mark as unread"
            >
              <EyeOff className="h-3.5 w-3.5" aria-hidden="true" />
              Mark unread
            </Button>
          )}

          <Popover
            ariaLabel={`More actions for ${n.title}`}
            widthClass="w-52"
            trigger={({ open, toggle, ref }) => (
              <button
                type="button"
                ref={ref}
                onClick={toggle}
                aria-haspopup="dialog"
                aria-expanded={open}
                aria-label="More notification actions"
                title="More actions"
                className={cn(
                  "inline-flex h-7 items-center gap-1.5 rounded-lg border border-transparent px-2.5 text-xs font-medium transition-colors",
                  open
                    ? "bg-forest-100 text-forest"
                    : "text-muted hover:bg-forest-50 hover:text-ink"
                )}
              >
                <MoreHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
                More
              </button>
            )}
          >
            {(close) => (
              <div className="p-1.5" role="menu">
                {SNOOZE_OPTIONS.map((option) => (
                  <button
                    key={option.label}
                    type="button"
                    role="menuitem"
                    className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm text-ink transition-colors hover:bg-forest-50"
                    onClick={() => {
                      onSnooze(
                        [n.id],
                        new Date(Date.now() + option.minutes * 60_000).toISOString()
                      );
                      onSnoozeMessage(n, option.label);
                      close();
                    }}
                  >
                    <Clock className="h-4 w-4 text-muted" aria-hidden="true" />
                    {option.label}
                  </button>
                ))}
                <div className="my-1 border-t border-line" />
                {unread ? (
                  <button
                    type="button"
                    role="menuitem"
                    className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm text-ink transition-colors hover:bg-forest-50"
                    onClick={() => {
                      onMarkRead([n.id]);
                      close();
                    }}
                  >
                    <Eye className="h-4 w-4 text-muted" aria-hidden="true" />
                    Mark as read
                  </button>
                ) : (
                  <button
                    type="button"
                    role="menuitem"
                    className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm text-ink transition-colors hover:bg-forest-50"
                    onClick={() => {
                      onMarkUnread([n.id]);
                      close();
                    }}
                  >
                    <EyeOff className="h-4 w-4 text-muted" aria-hidden="true" />
                    Mark as unread
                  </button>
                )}
                <button
                  type="button"
                  role="menuitem"
                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm text-critical-fg transition-colors hover:bg-critical-bg"
                  onClick={() => {
                    onDismiss([n.id]);
                    close();
                  }}
                >
                  <X className="h-4 w-4" aria-hidden="true" />
                  Dismiss notification
                </button>
              </div>
            )}
          </Popover>
        </div>
      </div>
    </li>
  );
}
