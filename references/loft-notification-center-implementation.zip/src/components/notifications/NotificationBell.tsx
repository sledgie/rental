import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Bell, CheckCheck, ChevronRight } from "lucide-react";
import { Popover } from "@/components/ui/Popover";
import { Button } from "@/components/ui/primitives";
import { useToast } from "@/components/ui/Toast";
import { formatRelativeTimestamp, isUnread, sortNotifications } from "@/notifications/logic";
import { CATEGORY_META, getNotificationIcon } from "@/notifications/meta";
import { useApp } from "@/state/AppStore";
import { cn } from "@/utils/cn";

const RECENT_LIMIT = 5;

export function NotificationBell() {
  const {
    scopedNotifications,
    unreadCount,
    markRead,
    markAllRead,
    user,
    organization,
  } = useApp();
  const toast = useToast();

  const recent = useMemo(
    () => sortNotifications(scopedNotifications).slice(0, RECENT_LIMIT),
    [scopedNotifications]
  );

  const handleMarkAllRead = () => {
    const count = markAllRead();
    toast.push(
      count > 0
        ? {
            variant: "success",
            title: `Marked ${count} notification${count === 1 ? "" : "s"} as read`,
            description: `${organization.name} · ${user.name}`,
          }
        : {
            variant: "info",
            title: "Nothing to mark as read",
            description: "Your active notifications are already read.",
          }
    );
  };

  return (
    <Popover
      ariaLabel="Notifications panel"
      widthClass="w-[22rem] sm:w-[24rem]"
      panelClassName="left-2 right-2 top-[calc(100%+0.5rem)] mt-0 sm:left-auto sm:right-0 sm:w-[24rem] sm:mt-2"
      trigger={({ open, toggle, ref }) => (
        <button
          type="button"
          ref={ref}
          onClick={toggle}
          aria-haspopup="dialog"
          aria-expanded={open}
          aria-label={
            unreadCount > 0
              ? `Notifications, ${unreadCount} unread. Open notifications panel`
              : "Notifications. Open notifications panel"
          }
          className={cn(
            "relative flex h-10 w-10 items-center justify-center rounded-lg border transition-colors",
            open
              ? "border-forest-200 bg-forest-50 text-forest"
              : "border-line bg-white text-ink hover:border-forest-200 hover:bg-forest-50"
          )}
        >
          <Bell className="h-[18px] w-[18px]" aria-hidden="true" />
          {unreadCount > 0 ? (
            <span
              aria-hidden="true"
              className="absolute -top-1.5 -right-1.5 flex h-5 min-w-5 items-center justify-center rounded-full border-2 border-white bg-critical-fg px-1 text-[10px] font-bold text-white"
            >
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          ) : null}
        </button>
      )}
    >
      {(close) => (
        <div className="flex max-h-[min(28rem,75vh)] flex-col">
          <div className="flex items-center justify-between gap-2 border-b border-line px-4 py-3">
            <div className="min-w-0">
              <p className="text-sm font-semibold text-ink">Notifications</p>
              <p className="truncate text-xs text-muted">
                {unreadCount > 0
                  ? `${unreadCount} unread · ${organization.name}`
                  : `All caught up · ${organization.name}`}
              </p>
            </div>
            <Button size="xs" variant="ghost" onClick={handleMarkAllRead}>
              <CheckCheck className="h-3.5 w-3.5" aria-hidden="true" />
              Mark all read
            </Button>
          </div>

          <div
            className="flex-1 divide-y divide-line overflow-y-auto scrollbar-thin"
            role="feed"
            aria-label="Recent notifications"
          >
            {recent.length === 0 ? (
              <p className="px-4 py-8 text-center text-sm text-muted">
                No active notifications in this organization.
              </p>
            ) : (
              recent.map((n) => {
                const Icon = getNotificationIcon(n.category, n.eventType);
                const unread = isUnread(n);
                return (
                  <div
                    key={n.id}
                    className={cn(
                      "flex items-start gap-3 px-4 py-3 transition-colors",
                      unread ? "bg-forest-50/60" : "bg-white"
                    )}
                  >
                    <span
                      className={cn(
                        "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
                        CATEGORY_META[n.category].tone
                      )}
                    >
                      <Icon className="h-4 w-4" aria-hidden="true" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start gap-2">
                        {unread ? (
                          <span
                            aria-label="Unread"
                            className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-forest"
                          />
                        ) : null}
                        <p
                          className={cn(
                            "line-clamp-2 text-sm leading-5",
                            unread ? "font-semibold text-ink" : "text-ink"
                          )}
                        >
                          {n.title}
                        </p>
                      </div>
                      <p className="mt-1 line-clamp-2 text-xs leading-4 text-muted">
                        {n.message}
                      </p>
                      <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-muted">
                        <span>{formatRelativeTimestamp(n.createdAt)}</span>
                        {n.propertyName ? (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="truncate">
                              {n.propertyName}
                              {n.unitLabel ? ` · ${n.unitLabel}` : ""}
                            </span>
                          </>
                        ) : null}
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                        {n.actionRoute ? (
                          <Link
                            to={n.actionRoute}
                            onClick={close}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-forest transition-colors hover:text-evergreen"
                          >
                            {n.actionLabel ?? "Open record"}
                            <ChevronRight className="h-3 w-3" aria-hidden="true" />
                          </Link>
                        ) : null}
                        {unread ? (
                          <button
                            type="button"
                            onClick={() => markRead([n.id])}
                            className="text-xs font-medium text-muted transition-colors hover:text-ink"
                          >
                            Mark read
                          </button>
                        ) : null}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="flex items-center justify-between gap-2 border-t border-line bg-ivory px-4 py-2.5">
            <Link
              to="/notifications"
              onClick={close}
              className="text-xs font-semibold text-forest transition-colors hover:text-evergreen"
            >
              View all notifications
            </Link>
            <Link
              to="/settings/notifications"
              onClick={close}
              className="text-xs text-muted transition-colors hover:text-ink"
            >
              Preferences
            </Link>
          </div>
        </div>
      )}
    </Popover>
  );
}


