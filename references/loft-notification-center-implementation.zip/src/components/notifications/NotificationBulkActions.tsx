import { CheckCheck, EyeOff, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/primitives";
import { cn } from "@/utils/cn";

export function NotificationBulkActions({
  selectedCount,
  onMarkRead,
  onMarkUnread,
  onDismiss,
  onClearSelection,
  className,
}: {
  selectedCount: number;
  onMarkRead: () => void;
  onMarkUnread: () => void;
  onDismiss: () => void;
  onClearSelection: () => void;
  className?: string;
}) {
  if (selectedCount === 0) return null;

  return (
    <div
      role="toolbar"
      aria-label="Bulk notification actions"
      className={cn(
        "flex animate-slide-up flex-wrap items-center gap-2 rounded-xl border border-forest-200 bg-forest-50 p-2.5 shadow-card",
        className
      )}
    >
      <p className="mr-1 pl-1 text-sm font-semibold text-forest" role="status">
        {selectedCount} selected
      </p>
      <Button size="sm" variant="secondary" onClick={onMarkRead}>
        <CheckCheck className="h-3.5 w-3.5" aria-hidden="true" />
        Mark as read
      </Button>
      <Button size="sm" variant="secondary" onClick={onMarkUnread}>
        <EyeOff className="h-3.5 w-3.5" aria-hidden="true" />
        Mark as unread
      </Button>
      <Button size="sm" variant="dangerSubtle" onClick={onDismiss}>
        <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
        Dismiss
      </Button>
      <Button size="sm" variant="ghost" onClick={onClearSelection} className="ml-auto">
        <X className="h-3.5 w-3.5" aria-hidden="true" />
        Clear selection
      </Button>
    </div>
  );
}
