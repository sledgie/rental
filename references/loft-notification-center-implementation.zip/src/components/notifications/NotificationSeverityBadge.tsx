import { AlertTriangle, Lock } from "lucide-react";
import { CATEGORY_META, SEVERITY_META } from "@/notifications/meta";
import type {
  NotificationCategory,
  NotificationSeverity,
} from "@/notifications/types";
import { cn } from "@/utils/cn";

/** Reusable severity badge — consistent labels plus icon so status is never color-only. */
export function NotificationSeverityBadge({
  severity,
  compact,
}: {
  severity: NotificationSeverity;
  compact?: boolean;
}) {
  const meta = SEVERITY_META[severity];
  const Icon =
    severity === "critical"
      ? AlertTriangle
      : severity === "high"
        ? AlertTriangle
        : undefined;
  return (
    <span
      title={meta.description}
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold leading-4 whitespace-nowrap",
        meta.badge
      )}
    >
      {Icon && !compact ? <Icon className="h-3 w-3" aria-hidden="true" /> : null}
      {meta.label}
    </span>
  );
}

export function NotificationCategoryBadge({ category }: { category: NotificationCategory }) {
  const meta = CATEGORY_META[category];
  const Icon = meta.icon;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border border-transparent px-2 py-0.5 text-[11px] font-medium leading-4 whitespace-nowrap",
        meta.tone
      )}
    >
      <Icon className="h-3 w-3" aria-hidden="true" />
      {meta.short}
    </span>
  );
}

export function RestrictedBadge() {
  return (
    <span
      title="Your role does not have access to the details behind this notification."
      className="inline-flex items-center gap-1 rounded-full border border-line bg-inform-bg px-2 py-0.5 text-[11px] font-medium leading-4 text-inform-fg whitespace-nowrap"
    >
      <Lock className="h-3 w-3" aria-hidden="true" />
      Restricted
    </span>
  );
}
