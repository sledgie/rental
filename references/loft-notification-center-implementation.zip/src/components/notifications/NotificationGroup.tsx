import type { NotificationGroup as Group } from "@/notifications/logic";
import type { AppNotification } from "@/notifications/types";
import { NotificationItem } from "./NotificationItem";
import { cn } from "@/utils/cn";

export interface NotificationGroupProps {
  group: Group;
  selectedIds: Set<string>;
  selectionMode: boolean;
  restrictedIds: Set<string>;
  assignedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  onMarkRead: (ids: string[]) => void;
  onMarkUnread: (ids: string[]) => void;
  onDismiss: (ids: string[]) => void;
  onSnooze: (ids: string[], until: string) => void;
  onSnoozeMessage: (notification: AppNotification, label: string) => void;
}

export function NotificationGroup(props: NotificationGroupProps) {
  const { group } = props;
  const unreadCount = group.items.filter((n) => n.readAt === null).length;

  return (
    <section aria-label={`${group.label} notifications`}>
      <div className="sticky top-16 z-10 flex items-center justify-between gap-2 border-y border-line bg-ivory/95 px-4 py-2 backdrop-blur sm:px-5">
        <h2 className="text-xs font-semibold tracking-wide text-ink uppercase">
          {group.label}
        </h2>
        <p className="text-[11px] text-muted">
          {group.items.length} notification{group.items.length === 1 ? "" : "s"}
          {unreadCount > 0 ? ` · ${unreadCount} unread` : ""}
        </p>
      </div>
      <ul className="divide-y divide-line">
        {group.items.map((n) => (
          <NotificationItem
            key={n.id}
            notification={n}
            unread={n.readAt === null}
            restricted={props.restrictedIds.has(n.id)}
            assignedToMe={props.assignedIds.has(n.id)}
            selectable={props.selectionMode}
            selected={props.selectedIds.has(n.id)}
            onToggleSelect={props.onToggleSelect}
            onMarkRead={props.onMarkRead}
            onMarkUnread={props.onMarkUnread}
            onDismiss={props.onDismiss}
            onSnooze={props.onSnooze}
            onSnoozeMessage={props.onSnoozeMessage}
          />
        ))}
      </ul>
    </section>
  );
}

export function NotificationGroupHeader({ label, count }: { label: string; count: number }) {
  return (
    <div className={cn("flex items-center justify-between px-4 py-2 sm:px-5")}>
      <h2 className="text-xs font-semibold tracking-wide text-ink uppercase">{label}</h2>
      <span className="text-[11px] text-muted">{count}</span>
    </div>
  );
}
