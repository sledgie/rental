import { Inbox } from "lucide-react";
import { Button, EmptyState } from "@/components/ui/primitives";

export type EmptyStateKind =
  | "no_notifications"
  | "no_unread"
  | "no_search_results"
  | "no_category_results"
  | "no_advanced_filter_results"
  | "no_assigned";

interface NotificationEmptyStateProps {
  kind: EmptyStateKind;
  onClearFilters?: () => void;
  onClearSearch?: () => void;
  onShowAll?: () => void;
  onOpenPreferences?: () => void;
}

export function NotificationEmptyState({
  kind,
  onClearFilters,
  onClearSearch,
  onShowAll,
  onOpenPreferences,
}: NotificationEmptyStateProps) {
  switch (kind) {
    case "no_unread":
      return (
        <EmptyState
          icon={<Inbox className="h-5 w-5" aria-hidden="true" />}
          title="You're all caught up"
          description="Every active notification in this organization has been read. New events will appear here as they happen."
          action={
            onShowAll ? (
              <Button variant="secondary" size="sm" onClick={onShowAll}>
                Show all notifications
              </Button>
            ) : null
          }
        />
      );
    case "no_search_results":
      return (
        <EmptyState
          icon={<Inbox className="h-5 w-5" aria-hidden="true" />}
          title="No notifications match your search"
          description="Try a different property, unit, invoice number, or tenant name. Search looks across titles, messages, categories, and related records."
          action={
            onClearSearch ? (
              <Button variant="secondary" size="sm" onClick={onClearSearch}>
                Clear search
              </Button>
            ) : null
          }
        />
      );
    case "no_category_results":
      return (
        <EmptyState
          icon={<Inbox className="h-5 w-5" aria-hidden="true" />}
          title="Nothing in this category right now"
          description="There are no active notifications in this category for your organization and role."
          action={
            <div className="flex flex-wrap justify-center gap-2">
              {onShowAll ? (
                <Button variant="secondary" size="sm" onClick={onShowAll}>
                  Show all notifications
                </Button>
              ) : null}
              {onOpenPreferences ? (
                <Button variant="ghost" size="sm" onClick={onOpenPreferences}>
                  Review preferences
                </Button>
              ) : null}
            </div>
          }
        />
      );
    case "no_advanced_filter_results":
      return (
        <EmptyState
          icon={<Inbox className="h-5 w-5" aria-hidden="true" />}
          title="No notifications match these filters"
          description="No active notification matches the combination of filters you applied. Try widening the date range or clearing a filter."
          action={
            onClearFilters ? (
              <Button variant="secondary" size="sm" onClick={onClearFilters}>
                Clear all filters
              </Button>
            ) : null
          }
        />
      );
    case "no_assigned":
      return (
        <EmptyState
          icon={<Inbox className="h-5 w-5" aria-hidden="true" />}
          title="Nothing is assigned to you"
          description="Notifications land here when you own the follow-up work. Team-wide updates stay in the All list."
          action={
            onShowAll ? (
              <Button variant="secondary" size="sm" onClick={onShowAll}>
                Show all notifications
              </Button>
            ) : null
          }
        />
      );
    case "no_notifications":
    default:
      return (
        <EmptyState
          icon={<Inbox className="h-5 w-5" aria-hidden="true" />}
          title="No notifications yet"
          description="When something needs your attention — an overdue invoice, an urgent repair, a lease renewal — it will show up here."
          action={
            onOpenPreferences ? (
              <Button variant="secondary" size="sm" onClick={onOpenPreferences}>
                Notification preferences
              </Button>
            ) : null
          }
        />
      );
  }
}
