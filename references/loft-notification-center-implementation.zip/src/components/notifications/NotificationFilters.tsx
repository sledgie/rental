import { useEffect, useRef, useState } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import { Button, Field, SelectInput, TextInput } from "@/components/ui/primitives";
import { ENTITY_TYPE_OPTIONS } from "@/lib/routing";
import { countActiveFilters, getTabLabel } from "@/notifications/logic";
import { CATEGORY_META, SEVERITY_META } from "@/notifications/meta";
import {
  NOTIFICATION_FILTER_DEFAULTS,
  SEVERITY_ORDER,
  type NotificationCategory,
  type NotificationFilterState,
  type NotificationSeverity,
  type NotificationTabId,
} from "@/notifications/types";
import { TAB_ORDER } from "@/notifications/logic";
import { cn } from "@/utils/cn";

const CATEGORY_OPTIONS = Object.entries(CATEGORY_META).map(([value, meta]) => ({
  value,
  label: meta.label,
}));

const SEVERITY_OPTIONS = SEVERITY_ORDER.map((severity) => ({
  value: severity,
  label: SEVERITY_META[severity].label,
}));

const ENTITY_LABEL: Record<string, string> = Object.fromEntries(
  ENTITY_TYPE_OPTIONS.map((o) => [o.value, o.label])
);

const READ_OPTIONS = [
  { value: "all", label: "All" },
  { value: "unread", label: "Unread only" },
  { value: "read", label: "Read only" },
];

const COUNTED_TABS: NotificationTabId[] = ["unread", "high_priority"];

export interface NotificationFiltersProps {
  filters: NotificationFilterState;
  tabCounts: Record<NotificationTabId, number>;
  properties: Array<{ id: string; name: string }>;
  onTabChange: (tab: NotificationTabId) => void;
  onApplyAdvanced: (draft: Partial<NotificationFilterState>) => void;
  onClearAll: () => void;
  onRemoveFilter: (key: keyof NotificationFilterState) => void;
  isLoading?: boolean;
}

export function NotificationFilters({
  filters,
  tabCounts,
  properties,
  onTabChange,
  onApplyAdvanced,
  onClearAll,
  onRemoveFilter,
  isLoading,
}: NotificationFiltersProps) {
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [draft, setDraft] = useState<NotificationFilterState>(filters);
  const firstFieldRef = useRef<HTMLSelectElement>(null);

  useEffect(() => {
    if (advancedOpen) {
      setDraft(filters);
      window.setTimeout(() => firstFieldRef.current?.focus(), 30);
    }
  }, [advancedOpen, filters]);

  const activeFilterCount = countActiveFilters(filters);
  const advancedDraftCount = countActiveFilters(draft);

  const activeChips: Array<{ key: keyof NotificationFilterState; label: string }> = [];
  if (filters.query.trim()) activeChips.push({ key: "query", label: `Search: "${filters.query.trim()}"` });
  if (filters.tab !== "all" && filters.tab !== filters.category) {
    activeChips.push({ key: "tab", label: `View: ${getTabLabel(filters.tab)}` });
  }
  if (filters.category !== "all")
    activeChips.push({
      key: "category",
      label: `Category: ${CATEGORY_META[filters.category].label}`,
    });
  if (filters.severity !== "all")
    activeChips.push({ key: "severity", label: `Severity: ${SEVERITY_META[filters.severity].label}` });
  if (filters.readStatus !== "all")
    activeChips.push({
      key: "readStatus",
      label: `Read status: ${READ_OPTIONS.find((o) => o.value === filters.readStatus)?.label ?? ""}`,
    });
  if (filters.propertyId !== "all")
    activeChips.push({
      key: "propertyId",
      label: `Property: ${properties.find((p) => p.id === filters.propertyId)?.name ?? "Property"}`,
    });
  if (filters.entityType !== "all")
    activeChips.push({
      key: "entityType",
      label: `Record: ${ENTITY_LABEL[filters.entityType] ?? filters.entityType}`,
    });
  if (filters.fromDate) activeChips.push({ key: "fromDate", label: `From: ${filters.fromDate}` });
  if (filters.toDate) activeChips.push({ key: "toDate", label: `To: ${filters.toDate}` });

  return (
    <div className="space-y-3">
      {/* Primary filter tabs */}
      <div className="flex items-center gap-2">
        <div
          role="tablist"
          aria-label="Notification filters"
          className="-mx-3 flex flex-1 items-center gap-1.5 overflow-x-auto px-3 pb-1 scrollbar-none sm:mx-0 sm:px-0"
        >
          {TAB_ORDER.map((tab) => {
            const isActive = filters.tab === tab;
            const showCount = COUNTED_TABS.includes(tab) && tabCounts[tab] > 0;
            return (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => onTabChange(tab)}
                className={cn(
                  "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors",
                  isActive
                    ? "border-evergreen bg-evergreen text-white shadow-card"
                    : "border-line bg-white text-muted hover:border-forest-200 hover:bg-forest-50 hover:text-ink"
                )}
              >
                {getTabLabel(tab)}
                {showCount ? (
                  <span
                    className={cn(
                      "rounded-full px-1.5 py-0.5 text-[10px] font-semibold tabular-nums",
                      isActive ? "bg-white/20 text-white" : "bg-forest-50 text-forest"
                    )}
                  >
                    {tabCounts[tab]}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>

        <Button
          variant={advancedOpen || activeFilterCount > 0 ? "subtle" : "secondary"}
          size="sm"
          onClick={() => setAdvancedOpen((prev) => !prev)}
          aria-expanded={advancedOpen}
          aria-controls="notification-advanced-filters"
          className="shrink-0"
        >
          <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" />
          Filters
          {activeFilterCount > 0 ? (
            <span className="rounded-full bg-forest px-1.5 text-[10px] font-bold text-white tabular-nums">
              {activeFilterCount}
            </span>
          ) : null}
        </Button>
      </div>

      {/* Advanced filters */}
      {advancedOpen ? (
        <form
          id="notification-advanced-filters"
          onSubmit={(event) => {
            event.preventDefault();
            onApplyAdvanced(draft);
            setAdvancedOpen(false);
          }}
          className="animate-slide-up rounded-xl border border-line bg-white p-4 shadow-card"
        >
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Category" htmlFor="filter-category">
              <SelectInput
                id="filter-category"
                ref={firstFieldRef}
                value={draft.category}
                onChange={(event) =>
                  setDraft((prev) => ({
                    ...prev,
                    category: event.target.value as NotificationCategory | "all",
                  }))
                }
              >
                <option value="all">All categories</option>
                {CATEGORY_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </SelectInput>
            </Field>

            <Field label="Severity" htmlFor="filter-severity">
              <SelectInput
                id="filter-severity"
                value={draft.severity}
                onChange={(event) =>
                  setDraft((prev) => ({
                    ...prev,
                    severity: event.target.value as NotificationSeverity | "all",
                  }))
                }
              >
                <option value="all">All severities</option>
                {SEVERITY_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </SelectInput>
            </Field>

            <Field label="Read status" htmlFor="filter-read">
              <SelectInput
                id="filter-read"
                value={draft.readStatus}
                onChange={(event) =>
                  setDraft((prev) => ({
                    ...prev,
                    readStatus: event.target.value as NotificationFilterState["readStatus"],
                  }))
                }
              >
                {READ_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </SelectInput>
            </Field>

            <Field label="Property" htmlFor="filter-property">
              <SelectInput
                id="filter-property"
                value={draft.propertyId}
                onChange={(event) =>
                  setDraft((prev) => ({ ...prev, propertyId: event.target.value }))
                }
              >
                <option value="all">All properties</option>
                {properties.map((property) => (
                  <option key={property.id} value={property.id}>
                    {property.name}
                  </option>
                ))}
              </SelectInput>
            </Field>

            <Field label="Related record type" htmlFor="filter-entity">
              <SelectInput
                id="filter-entity"
                value={draft.entityType}
                onChange={(event) =>
                  setDraft((prev) => ({ ...prev, entityType: event.target.value }))
                }
              >
                <option value="all">Any record type</option>
                {ENTITY_TYPE_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </SelectInput>
            </Field>

            <Field label="Date range" hint="Notifications created within the selected dates.">
              <div className="flex items-center gap-2">
                <TextInput
                  type="date"
                  aria-label="From date"
                  value={draft.fromDate}
                  max={draft.toDate || undefined}
                  onChange={(event) =>
                    setDraft((prev) => ({ ...prev, fromDate: event.target.value }))
                  }
                />
                <span className="text-muted" aria-hidden="true">
                  —
                </span>
                <TextInput
                  type="date"
                  aria-label="To date"
                  value={draft.toDate}
                  min={draft.fromDate || undefined}
                  onChange={(event) =>
                    setDraft((prev) => ({ ...prev, toDate: event.target.value }))
                  }
                />
              </div>
            </Field>
          </div>

          <div className="mt-4 flex flex-col-reverse gap-2 border-t border-line pt-3 sm:flex-row sm:items-center sm:justify-between">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => {
                setDraft({ ...NOTIFICATION_FILTER_DEFAULTS, query: filters.query, tab: filters.tab });
              }}
            >
              Reset panel
            </Button>
            <div className="flex flex-col-reverse gap-2 sm:flex-row">
              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={() => {
                  onClearAll();
                  setAdvancedOpen(false);
                }}
              >
                Clear filters
              </Button>
              <Button type="submit" variant="primary" size="sm">
                Apply filters
                {advancedDraftCount > 0 ? ` (${advancedDraftCount})` : ""}
              </Button>
            </div>
          </div>
        </form>
      ) : null}

      {/* Active filter chips */}
      {activeChips.length > 0 ? (
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-semibold tracking-wide text-muted uppercase">
            Active
          </span>
          {activeChips.map((chip) => (
            <span
              key={chip.key}
              className="inline-flex max-w-full items-center gap-1 rounded-full border border-forest-200 bg-forest-50 py-0.5 pr-1 pl-2 text-[11px] font-medium text-forest"
            >
              <span className="truncate">{chip.label}</span>
              <button
                type="button"
                onClick={() => onRemoveFilter(chip.key)}
                aria-label={`Remove filter: ${chip.label}`}
                className="rounded-full p-0.5 transition-colors hover:bg-forest-200/70"
              >
                <X className="h-3 w-3" aria-hidden="true" />
              </button>
            </span>
          ))}
          <button
            type="button"
            onClick={onClearAll}
            className="ml-1 text-[11px] font-semibold text-muted underline decoration-dotted transition-colors hover:text-ink"
          >
            Clear all
          </button>
        </div>
      ) : null}

      <p className="sr-only" role="status">
        {isLoading
          ? "Loading notifications"
          : `${tabCounts[filters.tab]} notifications in the current view`}
      </p>
    </div>
  );
}
