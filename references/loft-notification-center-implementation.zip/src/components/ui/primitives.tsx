import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
  Ref,
  SelectHTMLAttributes,
} from "react";
import { Link } from "react-router-dom";
import { cn } from "@/utils/cn";

/* -------------------------------- Button -------------------------------- */

type ButtonVariant =
  | "primary"
  | "secondary"
  | "ghost"
  | "subtle"
  | "danger"
  | "dangerSubtle";
type ButtonSize = "xs" | "sm" | "md" | "iconSm" | "iconMd";

const BUTTON_VARIANTS: Record<ButtonVariant, string> = {
  primary:
    "bg-evergreen text-white border border-evergreen hover:bg-forest hover:border-forest shadow-card",
  secondary:
    "bg-white text-ink border border-line hover:bg-forest-50 hover:border-forest-200 shadow-card",
  ghost: "bg-transparent text-muted border border-transparent hover:bg-forest-50 hover:text-ink",
  subtle: "bg-forest-50 text-forest border border-forest-100 hover:bg-forest-100",
  danger: "bg-critical-fg text-white border border-critical-fg hover:bg-[#8f130d]",
  dangerSubtle:
    "bg-critical-bg text-critical-fg border border-critical-line hover:bg-critical-line/60",
};

const BUTTON_SIZES: Record<ButtonSize, string> = {
  xs: "h-7 gap-1.5 px-2.5 text-xs",
  sm: "h-9 gap-2 px-3 text-sm",
  md: "h-10 gap-2 px-4 text-sm",
  iconSm: "h-9 w-9 justify-center",
  iconMd: "h-10 w-10 justify-center",
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
}

export function Button({
  variant = "secondary",
  size = "sm",
  className,
  type = "button",
  ...props
}: ButtonProps) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex items-center rounded-lg font-medium transition-colors duration-150",
        "disabled:pointer-events-none disabled:opacity-50",
        BUTTON_SIZES[size],
        BUTTON_VARIANTS[variant],
        className
      )}
      {...props}
    />
  );
}

/** Anchor styled as a button — used for primary actions that navigate. */
export function LinkButton({
  to,
  variant = "secondary",
  size = "sm",
  className,
  children,
  onClick,
  ariaLabel,
}: {
  to: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  children: ReactNode;
  onClick?: () => void;
  ariaLabel?: string;
}) {
  return (
    <Link
      to={to}
      aria-label={ariaLabel}
      onClick={onClick}
      className={cn(
        "inline-flex items-center rounded-lg font-medium transition-colors duration-150",
        BUTTON_SIZES[size],
        BUTTON_VARIANTS[variant],
        className
      )}
    >
      {children}
    </Link>
  );
}

/* --------------------------------- Badge -------------------------------- */

export type BadgeTone = "neutral" | "forest" | "critical" | "high" | "inform" | "outline";

const BADGE_TONES: Record<BadgeTone, string> = {
  neutral: "bg-forest-50 text-muted border-line",
  forest: "bg-forest-100 text-forest border-forest-200",
  critical: "bg-critical-bg text-critical-fg border-critical-line",
  high: "bg-high-bg text-high-fg border-high-line",
  inform: "bg-inform-bg text-inform-fg border-inform-line",
  outline: "bg-white text-muted border-line",
};

export function Badge({
  tone = "neutral",
  icon,
  children,
  className,
}: {
  tone?: BadgeTone;
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium leading-4",
        BADGE_TONES[tone],
        className
      )}
    >
      {icon}
      {children}
    </span>
  );
}

/* --------------------------------- Card --------------------------------- */

export function Card({
  children,
  className,
  as: As = "section",
}: {
  children: ReactNode;
  className?: string;
  as?: "section" | "div" | "article" | "aside";
}) {
  return (
    <As
      className={cn(
        "rounded-xl border border-line bg-white shadow-card",
        className
      )}
    >
      {children}
    </As>
  );
}

/* -------------------------------- Inputs -------------------------------- */

export function TextInput({
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-9 w-full rounded-lg border border-line bg-white px-3 text-sm text-ink",
        "placeholder:text-muted/70 focus:border-forest focus:outline-none focus:ring-2 focus:ring-forest/15",
        className
      )}
      {...props}
    />
  );
}

export function SelectInput({
  className,
  children,
  ...props
}: SelectHTMLAttributes<HTMLSelectElement> & { ref?: Ref<HTMLSelectElement> }) {
  return (
    <div className="relative">
      <select
        className={cn(
          "h-9 w-full appearance-none rounded-lg border border-line bg-white pl-3 pr-8 text-sm text-ink",
          "focus:border-forest focus:outline-none focus:ring-2 focus:ring-forest/15",
          className
        )}
        {...props}
      >
        {children}
      </select>
      <svg
        aria-hidden="true"
        viewBox="0 0 12 12"
        className="pointer-events-none absolute right-2.5 top-1/2 h-3 w-3 -translate-y-1/2 text-muted"
      >
        <path
          d="M2.5 4.5 6 8l3.5-3.5"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
}

export function Field({
  label,
  htmlFor,
  hint,
  children,
  className,
}: {
  label: string;
  htmlFor?: string;
  hint?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <label
        htmlFor={htmlFor}
        className="block text-xs font-semibold tracking-wide text-muted uppercase"
      >
        {label}
      </label>
      {children}
      {hint ? <p className="text-xs text-muted">{hint}</p> : null}
    </div>
  );
}

/* -------------------------------- Switch -------------------------------- */

export function Switch({
  checked,
  onChange,
  label,
  disabled,
  describedBy,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
  disabled?: boolean;
  describedBy?: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      aria-describedby={describedBy}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition-colors duration-150",
        checked ? "border-forest bg-forest" : "border-line bg-inform-bg",
        disabled && "cursor-not-allowed opacity-50"
      )}
    >
      <span
        className={cn(
          "inline-block h-4.5 w-4.5 rounded-full bg-white shadow-card transition-transform duration-150",
          checked ? "translate-x-5.5" : "translate-x-1"
        )}
      />
    </button>
  );
}

/* ------------------------------ Empty state ----------------------------- */

export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-3 px-6 py-12 text-center",
        className
      )}
    >
      {icon ? (
        <span className="flex h-11 w-11 items-center justify-center rounded-full border border-line bg-forest-50 text-forest">
          {icon}
        </span>
      ) : null}
      <div className="space-y-1">
        <p className="text-sm font-semibold text-ink">{title}</p>
        {description ? (
          <p className="mx-auto max-w-sm text-sm text-muted">{description}</p>
        ) : null}
      </div>
      {action}
    </div>
  );
}

export function SkeletonRow() {
  return (
    <div className="flex items-start gap-3 border-b border-line px-4 py-4 last:border-b-0 sm:px-5">
      <div className="h-9 w-9 shrink-0 animate-pulse rounded-lg bg-forest-50" />
      <div className="w-full space-y-2">
        <div className="h-3 w-1/3 animate-pulse rounded bg-forest-50" />
        <div className="h-3 w-2/3 animate-pulse rounded bg-forest-50/80" />
      </div>
    </div>
  );
}
