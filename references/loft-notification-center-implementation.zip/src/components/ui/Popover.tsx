import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useLocation } from "react-router-dom";
import { cn } from "@/utils/cn";

/**
 * Lightweight, accessible popover used for menus and the notification bell.
 * Closes on outside pointer down, Escape, focus leaving the popover, and
 * navigation.
 */
export function Popover({
  trigger,
  children,
  align = "end",
  widthClass = "w-72",
  panelClassName,
  ariaLabel,
}: {
  trigger: (props: {
    open: boolean;
    toggle: () => void;
    ref: (node: HTMLElement | null) => void;
  }) => ReactNode;
  children: (close: () => void) => ReactNode;
  align?: "start" | "end";
  widthClass?: string;
  panelClassName?: string;
  ariaLabel: string;
}) {
  const [open, setOpen] = useState(false);
  const [topAligned, setTopAligned] = useState(false);
  const triggerRef = useRef<HTMLElement | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const location = useLocation();

  const close = useCallback(() => setOpen(false), []);
  const toggle = useCallback(() => setOpen((prev) => !prev), []);

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: PointerEvent) => {
      const target = event.target as Node;
      if (triggerRef.current?.contains(target)) return;
      if (panelRef.current?.contains(target)) return;
      setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.stopPropagation();
        setOpen(false);
        triggerRef.current?.focus();
      }
    };
    const onFocusIn = (event: FocusEvent) => {
      const target = event.target as Node | null;
      if (!target) return;
      if (panelRef.current?.contains(target)) return;
      if (triggerRef.current?.contains(target)) return;
      setOpen(false);
    };
    document.addEventListener("pointerdown", onPointerDown, true);
    document.addEventListener("keydown", onKeyDown, true);
    document.addEventListener("focusin", onFocusIn, true);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown, true);
      document.removeEventListener("keydown", onKeyDown, true);
      document.removeEventListener("focusin", onFocusIn, true);
    };
  }, [open]);

  // Close on navigation.
  useEffect(() => {
    setOpen(false);
  }, [location.pathname, location.search]);

  // Flip the panel above the trigger when it would overflow the viewport.
  useLayoutEffect(() => {
    if (!open || !triggerRef.current) return;
    const rect = triggerRef.current.getBoundingClientRect();
    setTopAligned(rect.bottom + 360 > window.innerHeight && rect.top > 380);
  }, [open]);

  return (
    <div className="relative">
      {trigger({ open, toggle, ref: (node) => (triggerRef.current = node) })}
      {open ? (
        <div
          ref={panelRef}
          role="dialog"
          aria-label={ariaLabel}
          className={cn(
            "absolute z-50 animate-pop-in rounded-xl border border-line bg-white shadow-pop",
            widthClass,
            align === "end" ? "right-0" : "left-0",
            topAligned ? "bottom-full mb-2" : "top-full mt-2",
            panelClassName
          )}
        >
          {children(close)}
        </div>
      ) : null}
    </div>
  );
}
