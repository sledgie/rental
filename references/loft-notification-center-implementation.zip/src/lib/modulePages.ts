import type { Permission } from "./types";
import {
  APPLICATIONS,
  COMMUNICATIONS,
  DOCUMENTS,
  EXPENSES,
  INVOICES,
  LEASES,
  MAINTENANCE_REQUESTS,
  PROJECTS,
  PROPERTIES,
  TEAM,
  TENANTS,
  formatCurrency,
} from "./mockData";

export interface ModuleColumn {
  key: string;
  label: string;
  align?: "right";
}

export interface ModuleRow {
  id: string;
  href?: string;
  cells: Record<string, string>;
}

export interface ModuleConfig {
  title: string;
  description: string;
  permission?: Permission;
  columns: ModuleColumn[];
  rows: ModuleRow[];
  note?: string;
}

const ACTIVITY_ROWS: ModuleRow[] = [
  { id: "act-1", cells: { event: "Lease record updated", actor: "Daniel Osei", record: "LSE-4368", when: "Today, 8:42 AM" } },
  { id: "act-2", cells: { event: "Expense approved", actor: "Priya Raman", record: "EXP-561", when: "Today, 8:05 AM" } },
  { id: "act-3", cells: { event: "Maintenance request assigned", actor: "Tom Whitfield", record: "MR-1184", when: "Yesterday, 4:18 PM" } },
  { id: "act-4", cells: { event: "Document uploaded", actor: "Amara Okafor", record: "doc-7752", when: "Yesterday, 11:02 AM" } },
  { id: "act-5", cells: { event: "Bank feed import ran", actor: "System · bank-integration", record: "Evergreen Operating", when: "Yesterday, 3:00 AM" } },
];

const SCHEDULED_ROWS: ModuleRow[] = [
  { id: "task-1", cells: { task: "Rent charge generation", schedule: "Monthly · 1st, 12:05 AM", next: "Oct 1, 2026", status: "Scheduled" } },
  { id: "task-2", cells: { task: "Late fee assessment", schedule: "Monthly · 6th, 1:00 AM", next: "Oct 6, 2026", status: "Scheduled" } },
  { id: "task-3", cells: { task: "Lease expiration sweep", schedule: "Daily · 5:30 AM", next: "Tomorrow, 5:30 AM", status: "Scheduled" } },
  { id: "task-4", cells: { task: "Bank feed reconciliation pull", schedule: "Daily · 3:00 AM", next: "Tomorrow, 3:00 AM", status: "Failed" } },
  { id: "task-5", cells: { task: "Preventive maintenance review", schedule: "Weekly · Mon, 7:00 AM", next: "Mon, 7:00 AM", status: "Paused" } },
];

const WORKFLOW_ROWS: ModuleRow[] = [
  { id: "wf-1", cells: { rule: "Overdue invoice follow-up", trigger: "Invoice becomes overdue", action: "Create follow-up task + notify owner", status: "Active" } },
  { id: "wf-2", cells: { rule: "Emergency request escalation", trigger: "Maintenance priority = emergency", action: "Notify maintenance lead and owner", status: "Active" } },
  { id: "wf-3", cells: { rule: "Lease renewal reminder", trigger: "30 days before lease end", action: "Notify property manager", status: "Active" } },
  { id: "wf-4", cells: { rule: "Insurance document check", trigger: "Document marked needs review", action: "Notify property manager", status: "Draft" } },
];

export const MODULE_CONFIG: Record<string, ModuleConfig> = {
  "/properties": {
    title: "Properties",
    description: "Portfolio performance, occupancy, and unit mix for your organization.",
    permission: "properties:read",
    columns: [
      { key: "name", label: "Property" },
      { key: "address", label: "Address" },
      { key: "units", label: "Units", align: "right" },
      { key: "occupancy", label: "Occupancy", align: "right" },
      { key: "manager", label: "Manager" },
    ],
    rows: PROPERTIES.map((p) => ({
      id: p.id,
      href: `/properties/${p.id}`,
      cells: {
        name: p.name,
        address: `${p.address}, ${p.city}, ${p.state}`,
        units: String(p.unitCount),
        occupancy: `${p.occupancy}%`,
        manager: p.manager,
      },
    })),
  },
  "/tenants": {
    title: "Tenants",
    description: "Current residents, contact details, and messaging consent.",
    permission: "leases:read",
    columns: [
      { key: "name", label: "Tenant" },
      { key: "unit", label: "Property / Unit" },
      { key: "phone", label: "Phone" },
      { key: "sms", label: "SMS consent" },
    ],
    rows: TENANTS.map((t) => ({
      id: t.id,
      href: `/tenants/${t.id}`,
      cells: {
        name: t.name,
        unit: `${PROPERTIES.find((p) => p.id === t.propertyId)?.name ?? ""} · ${t.unitLabel}`,
        phone: t.phone,
        sms: t.smsOptIn ? "Opted in" : "Opted out",
      },
    })),
  },
  "/leases": {
    title: "Leases",
    description: "Active, expiring, and pending lease agreements.",
    permission: "leases:read",
    columns: [
      { key: "reference", label: "Lease" },
      { key: "tenant", label: "Tenant" },
      { key: "unit", label: "Property / Unit" },
      { key: "end", label: "Ends" },
      { key: "rent", label: "Monthly rent", align: "right" },
    ],
    rows: LEASES.map((l) => ({
      id: l.id,
      href: `/leases/${l.id}`,
      cells: {
        reference: l.reference,
        tenant: TENANTS.find((t) => t.id === l.tenantId)?.name ?? "—",
        unit: `${PROPERTIES.find((p) => p.id === l.propertyId)?.name ?? ""} · ${l.unitLabel}`,
        end: l.endDate,
        rent: formatCurrency(l.monthlyRent),
      },
    })),
  },
  "/accounting": {
    title: "Accounting",
    description: "Invoices, payments, expenses, and reconciliation status.",
    permission: "accounting:read",
    columns: [
      { key: "reference", label: "Reference" },
      { key: "kind", label: "Type" },
      { key: "party", label: "Tenant / Vendor" },
      { key: "property", label: "Property" },
      { key: "amount", label: "Amount", align: "right" },
      { key: "status", label: "Status" },
    ],
    rows: [
      ...INVOICES.map((i) => ({
        id: i.id,
        href: `/accounting/invoices/${i.id}`,
        cells: {
          reference: i.number,
          kind: "Invoice",
          party: TENANTS.find((t) => t.id === i.tenantId)?.name ?? "—",
          property: PROPERTIES.find((p) => p.id === i.propertyId)?.name ?? "—",
          amount: formatCurrency(i.amount),
          status: i.status,
        },
      })),
      ...EXPENSES.map((e) => ({
        id: e.id,
        href: `/accounting/expenses/${e.id}`,
        cells: {
          reference: e.reference,
          kind: "Expense",
          party: e.vendor,
          property: PROPERTIES.find((p) => p.id === e.propertyId)?.name ?? "—",
          amount: formatCurrency(e.amount),
          status: e.status,
        },
      })),
    ],
  },
  "/maintenance": {
    title: "Maintenance",
    description: "Requests and work orders across your portfolio.",
    permission: "maintenance:read",
    columns: [
      { key: "reference", label: "Reference" },
      { key: "property", label: "Property / Unit" },
      { key: "summary", label: "Summary" },
      { key: "priority", label: "Priority" },
      { key: "status", label: "Status" },
    ],
    rows: MAINTENANCE_REQUESTS.map((m) => ({
      id: m.id,
      href: `/maintenance/${m.id}`,
      cells: {
        reference: m.reference,
        property: `${PROPERTIES.find((p) => p.id === m.propertyId)?.name ?? ""} · ${m.unitLabel}`,
        summary: m.summary,
        priority: m.priority,
        status: m.status,
      },
    })),
  },
  "/projects": {
    title: "Projects",
    description: "Capital projects, budgets, and milestones.",
    permission: "projects:read",
    columns: [
      { key: "name", label: "Project" },
      { key: "property", label: "Property" },
      { key: "budget", label: "Budget", align: "right" },
      { key: "progress", label: "Progress", align: "right" },
      { key: "milestone", label: "Next milestone" },
    ],
    rows: PROJECTS.map((p) => ({
      id: p.id,
      href: `/projects/${p.id}`,
      cells: {
        name: p.name,
        property: PROPERTIES.find((x) => x.id === p.propertyId)?.name ?? "—",
        budget: formatCurrency(p.budget),
        progress: `${p.progress}%`,
        milestone: p.nextMilestone,
      },
    })),
  },
  "/documents": {
    title: "Documents",
    description: "Lease files, insurance certificates, and inspections.",
    permission: "documents:read",
    columns: [
      { key: "name", label: "Document" },
      { key: "category", label: "Category" },
      { key: "unit", label: "Property / Unit" },
      { key: "status", label: "Status" },
    ],
    rows: DOCUMENTS.map((d) => ({
      id: d.id,
      href: `/documents/${d.id}`,
      cells: {
        name: d.name,
        category: d.category,
        unit: `${PROPERTIES.find((p) => p.id === d.propertyId)?.name ?? ""}${d.unitLabel ? ` · ${d.unitLabel}` : ""}`,
        status: d.status,
      },
    })),
  },
  "/communications": {
    title: "Communications",
    description: "Tenant messaging activity and delivery status.",
    permission: "communications:read",
    columns: [
      { key: "reference", label: "Reference" },
      { key: "channel", label: "Channel" },
      { key: "tenant", label: "Tenant" },
      { key: "status", label: "Delivery" },
    ],
    rows: COMMUNICATIONS.map((c) => ({
      id: c.id,
      href: `/communications/${c.id}`,
      cells: {
        reference: c.reference,
        channel: c.channel.toUpperCase(),
        tenant: TENANTS.find((t) => t.id === c.tenantId)?.name ?? "—",
        status: c.status,
      },
    })),
  },
  "/team": {
    title: "Team",
    description: "Members, roles, and pending invitations.",
    permission: "team:read",
    columns: [
      { key: "name", label: "Member" },
      { key: "role", label: "Role" },
      { key: "email", label: "Email" },
      { key: "status", label: "Status" },
    ],
    rows: TEAM.map((t) => ({
      id: t.id,
      href: `/team/${t.id}`,
      cells: { name: t.name, role: t.role, email: t.email, status: t.status },
    })),
  },
  "/activity-logs": {
    title: "Activity Logs",
    description: "What happened, who performed it, and when.",
    columns: [
      { key: "event", label: "Event" },
      { key: "actor", label: "Actor" },
      { key: "record", label: "Record" },
      { key: "when", label: "When" },
    ],
    rows: ACTIVITY_ROWS,
    note: "Activity Logs record completed actions with an actor. Notifications tell you what needs your attention next.",
  },
  "/scheduled-tasks": {
    title: "Scheduled Tasks",
    description: "Recurring jobs and the next time each one runs.",
    columns: [
      { key: "task", label: "Task" },
      { key: "schedule", label: "Schedule" },
      { key: "next", label: "Next run" },
      { key: "status", label: "Status" },
    ],
    rows: SCHEDULED_ROWS,
    note: "Scheduled Tasks define when work runs. A task run can create a notification, but the two are separate modules.",
  },
  "/workflow-automation": {
    title: "Workflow Automation",
    description: "Event-driven rules that trigger follow-up work.",
    columns: [
      { key: "rule", label: "Rule" },
      { key: "trigger", label: "Trigger" },
      { key: "action", label: "Action" },
      { key: "status", label: "Status" },
    ],
    rows: WORKFLOW_ROWS,
    note: "Workflow rules decide what should happen when an event occurs. Notifications are one possible action.",
  },
};

export const APPLICATION_ROWS: ModuleRow[] = APPLICATIONS.map((a) => ({
  id: a.id,
  href: `/applications/${a.id}`,
  cells: {
    reference: a.reference,
    applicant: a.applicantName,
    unit: `${PROPERTIES.find((p) => p.id === a.propertyId)?.name ?? ""} · ${a.unitLabel}`,
    status: a.status,
  },
}));
