import type { Membership, Permission, Role } from "./types";
import { MEMBERSHIPS } from "./mockData";

/**
 * Role-based permission matrix. The Notification Center uses this to decide
 * whether a row may be shown and whether its primary action is available.
 *
 * Frontend gating is a UX affordance only — production authorization must be
 * enforced at the database layer (RLS) once notifications are persisted.
 */
export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  owner: [
    "properties:read",
    "leases:read",
    "accounting:read",
    "accounting:write",
    "maintenance:read",
    "maintenance:write",
    "projects:read",
    "documents:read",
    "pii:read",
    "communications:read",
    "team:read",
    "team:manage",
    "system:manage",
  ],
  property_manager: [
    "properties:read",
    "leases:read",
    "accounting:read",
    "maintenance:read",
    "maintenance:write",
    "projects:read",
    "documents:read",
    "pii:read",
    "communications:read",
    "team:read",
  ],
  accountant: [
    "accounting:read",
    "accounting:write",
    "properties:read",
    "documents:read",
    "projects:read",
  ],
  maintenance_lead: ["maintenance:read", "maintenance:write", "projects:read", "properties:read"],
  read_only_investor: ["properties:read", "leases:read", "accounting:read", "projects:read"],
};

export function getMembership(userId: string, organizationId: string): Membership | undefined {
  return MEMBERSHIPS.find(
    (m) => m.userId === userId && m.organizationId === organizationId
  );
}

export function permissionsFor(userId: string, organizationId: string): Permission[] {
  const membership = getMembership(userId, organizationId);
  return membership ? ROLE_PERMISSIONS[membership.role] : [];
}

export function roleFor(userId: string, organizationId: string): Role | undefined {
  return getMembership(userId, organizationId)?.role;
}

export function can(
  permission: Permission | undefined,
  granted: Permission[]
): boolean {
  if (!permission) return true;
  return granted.includes(permission);
}
