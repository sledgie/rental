import type { Permission } from "./types";

/**
 * Route registry for the L.O.F.T. application.
 *
 * `NAV_SECTIONS` drives the sidebar; `ENTITY_ROUTES` resolves a notification's
 * related record to a route. Entity types without a built surface resolve to
 * the controlled placeholder route `/record/:entityType/:entityId` so a
 * notification never links to an unrelated screen.
 */

export interface NavItem {
  label: string;
  to: string;
  icon: string; // lucide icon name resolved in the sidebar
  permission?: Permission;
  badge?: "notifications";
}

export interface NavSection {
  label: string;
  items: NavItem[];
}

export const NAV_SECTIONS: NavSection[] = [
  {
    label: "Overview",
    items: [
      { label: "Dashboard", to: "/dashboard", icon: "LayoutDashboard" },
      { label: "Notifications", to: "/notifications", icon: "Bell", badge: "notifications" },
    ],
  },
  {
    label: "Portfolio",
    items: [
      { label: "Properties", to: "/properties", icon: "Building2", permission: "properties:read" },
      { label: "Tenants", to: "/tenants", icon: "Users", permission: "leases:read" },
      { label: "Leases", to: "/leases", icon: "FileSignature", permission: "leases:read" },
    ],
  },
  {
    label: "Accounting",
    items: [
      { label: "Accounting", to: "/accounting", icon: "Landmark", permission: "accounting:read" },
    ],
  },
  {
    label: "Operations",
    items: [
      { label: "Maintenance", to: "/maintenance", icon: "Wrench", permission: "maintenance:read" },
      { label: "Projects", to: "/projects", icon: "ClipboardList", permission: "projects:read" },
      { label: "Documents", to: "/documents", icon: "FileText", permission: "documents:read" },
      { label: "Communications", to: "/communications", icon: "MessageSquare", permission: "communications:read" },
    ],
  },
  {
    label: "Workspace",
    items: [
      { label: "Team", to: "/team", icon: "UserCog", permission: "team:read" },
      { label: "Activity Logs", to: "/activity-logs", icon: "History" },
      { label: "Scheduled Tasks", to: "/scheduled-tasks", icon: "CalendarClock" },
      { label: "Workflow Automation", to: "/workflow-automation", icon: "Workflow" },
    ],
  },
];

export const PLACEHOLDER_ROUTE = "/record";

export interface EntityRouteTarget {
  permission: Permission;
  label: string;
  build: (entityId: string) => string;
}

export const ENTITY_ROUTES: Record<string, EntityRouteTarget> = {
  property: { permission: "properties:read", label: "Property", build: (id) => `/properties/${id}` },
  unit: { permission: "properties:read", label: "Unit", build: (id) => `/properties/${id}` },
  tenant: { permission: "leases:read", label: "Tenant", build: (id) => `/tenants/${id}` },
  lease: { permission: "leases:read", label: "Lease", build: (id) => `/leases/${id}` },
  application: { permission: "leases:read", label: "Application", build: (id) => `/applications/${id}` },
  invoice: {
    permission: "accounting:read",
    label: "Invoice",
    build: (id) => `/accounting/invoices/${id}`,
  },
  payment: {
    permission: "accounting:read",
    label: "Payment",
    build: (id) => `/accounting/payments/${id}`,
  },
  expense: {
    permission: "accounting:read",
    label: "Expense",
    build: (id) => `/accounting/expenses/${id}`,
  },
  maintenance_request: {
    permission: "maintenance:read",
    label: "Maintenance request",
    build: (id) => `/maintenance/${id}`,
  },
  work_order: {
    permission: "maintenance:read",
    label: "Work order",
    build: (id) => `/maintenance/${id}`,
  },
  project: { permission: "projects:read", label: "Project", build: (id) => `/projects/${id}` },
  document: { permission: "documents:read", label: "Document", build: (id) => `/documents/${id}` },
  communication: {
    permission: "communications:read",
    label: "Message",
    build: (id) => `/communications/${id}`,
  },
  team_member: { permission: "team:read", label: "Team member", build: (id) => `/team/${id}` },
  invitation: { permission: "team:read", label: "Invitation", build: (id) => `/team/${id}` },
  integration: {
    permission: "system:manage",
    label: "Integration",
    build: (id) => `${PLACEHOLDER_ROUTE}/integration/${id}`,
  },
  service: {
    permission: "system:manage",
    label: "Service",
    build: (id) => `${PLACEHOLDER_ROUTE}/service/${id}`,
  },
  configuration: {
    permission: "system:manage",
    label: "Configuration",
    build: (id) => `${PLACEHOLDER_ROUTE}/configuration/${id}`,
  },
  bank_account: {
    permission: "accounting:read",
    label: "Bank account",
    build: (id) => `${PLACEHOLDER_ROUTE}/bank_account/${id}`,
  },
  accounting_period: {
    permission: "accounting:read",
    label: "Accounting period",
    build: (id) => `${PLACEHOLDER_ROUTE}/accounting_period/${id}`,
  },
  refund: {
    permission: "accounting:read",
    label: "Refund",
    build: (id) => `${PLACEHOLDER_ROUTE}/refund/${id}`,
  },
};

export function getEntityRouteTarget(entityType?: string) {
  if (!entityType) return undefined;
  return ENTITY_ROUTES[entityType];
}

export function buildEntityRoute(entityType?: string, entityId?: string): string | undefined {
  if (!entityType || !entityId) return undefined;
  return ENTITY_ROUTES[entityType]?.build(entityId);
}

export const ENTITY_TYPE_OPTIONS: Array<{ value: string; label: string }> = [
  { value: "lease", label: "Lease" },
  { value: "application", label: "Application" },
  { value: "tenant", label: "Tenant" },
  { value: "property", label: "Property" },
  { value: "invoice", label: "Invoice" },
  { value: "payment", label: "Payment" },
  { value: "expense", label: "Expense" },
  { value: "maintenance_request", label: "Maintenance request" },
  { value: "work_order", label: "Work order" },
  { value: "project", label: "Project" },
  { value: "document", label: "Document" },
  { value: "communication", label: "Message" },
  { value: "team_member", label: "Team member" },
  { value: "integration", label: "Integration" },
  { value: "bank_account", label: "Bank account" },
];
