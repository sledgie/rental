import type {
  Application,
  CommunicationRecord,
  DocumentRecord,
  EntityRecord,
  Expense,
  Invoice,
  Lease,
  MaintenanceRequest,
  Membership,
  Organization,
  Payment,
  Project,
  Property,
  Role,
  TeamRecord,
  Tenant,
  User,
} from "./types";

/* ------------------------------------------------------------------ */
/* Organizations, users, memberships                                   */
/* ------------------------------------------------------------------ */

export const ORGANIZATIONS: Organization[] = [
  {
    id: "org-evergreen",
    name: "Evergreen Residential Group",
    slug: "evergreen",
    plan: "Portfolio",
    propertyCount: 5,
  },
  {
    id: "org-northline",
    name: "Northline Commercial Partners",
    slug: "northline",
    plan: "Growth",
    propertyCount: 2,
  },
];

export const USERS: User[] = [
  {
    id: "user-maya",
    name: "Maya Alvarez",
    initials: "MA",
    email: "maya@evergreenres.com",
    jobTitle: "Managing Partner",
  },
  {
    id: "user-daniel",
    name: "Daniel Osei",
    initials: "DO",
    email: "daniel@evergreenres.com",
    jobTitle: "Property Manager",
  },
  {
    id: "user-priya",
    name: "Priya Raman",
    initials: "PR",
    email: "priya@evergreenres.com",
    jobTitle: "Staff Accountant",
  },
  {
    id: "user-tom",
    name: "Tom Whitfield",
    initials: "TW",
    email: "tom@evergreenres.com",
    jobTitle: "Maintenance Lead",
  },
  {
    id: "user-anita",
    name: "Anita Roy",
    initials: "AR",
    email: "anita@northlinecp.com",
    jobTitle: "Portfolio Administrator",
  },
  {
    id: "user-hana",
    name: "Hana Ito",
    initials: "HI",
    email: "hana.ito@evergreenres.com",
    jobTitle: "Investor · read-only",
  },
];

export const MEMBERSHIPS: Membership[] = [
  { userId: "user-maya", organizationId: "org-evergreen", role: "owner" },
  { userId: "user-daniel", organizationId: "org-evergreen", role: "property_manager" },
  { userId: "user-priya", organizationId: "org-evergreen", role: "accountant" },
  { userId: "user-tom", organizationId: "org-evergreen", role: "maintenance_lead" },
  { userId: "user-hana", organizationId: "org-evergreen", role: "read_only_investor" },
  { userId: "user-maya", organizationId: "org-northline", role: "owner" },
  { userId: "user-anita", organizationId: "org-northline", role: "property_manager" },
];

/* ------------------------------------------------------------------ */
/* Properties, tenants, leases                                         */
/* ------------------------------------------------------------------ */

export const PROPERTIES: Property[] = [
  {
    id: "prop-maplewood",
    organizationId: "org-evergreen",
    name: "Maplewood Court Apartments",
    address: "1420 Maplewood Ave",
    city: "Portland",
    state: "OR",
    unitCount: 24,
    type: "Multifamily",
    manager: "Daniel Osei",
    occupancy: 96,
  },
  {
    id: "prop-harborview",
    organizationId: "org-evergreen",
    name: "Harborview Lofts",
    address: "88 Harbor Way",
    city: "Portland",
    state: "OR",
    unitCount: 12,
    type: "Lofts",
    manager: "Daniel Osei",
    occupancy: 83,
  },
  {
    id: "prop-cedarridge",
    organizationId: "org-evergreen",
    name: "Cedar Ridge Townhomes",
    address: "500 Cedar Ridge Dr",
    city: "Beaverton",
    state: "OR",
    unitCount: 18,
    type: "Townhomes",
    manager: "Maya Alvarez",
    occupancy: 100,
  },
  {
    id: "prop-willowpark",
    organizationId: "org-evergreen",
    name: "Willow Park Gardens",
    address: "2200 Willow Park Blvd",
    city: "Gresham",
    state: "OR",
    unitCount: 30,
    type: "Multifamily",
    manager: "Daniel Osei",
    occupancy: 90,
  },
  {
    id: "prop-foundry",
    organizationId: "org-evergreen",
    name: "The Foundry District",
    address: "15 Foundry Ln",
    city: "Portland",
    state: "OR",
    unitCount: 9,
    type: "Lofts",
    manager: "Maya Alvarez",
    occupancy: 78,
  },
  {
    id: "prop-northline-warehouse",
    organizationId: "org-northline",
    name: "Northline Warehouse Row",
    address: "4 Industrial Pkwy",
    city: "Vancouver",
    state: "WA",
    unitCount: 6,
    type: "Commercial",
    manager: "Anita Roy",
    occupancy: 67,
  },
];

export const TENANTS: Tenant[] = [
  {
    id: "tenant-elena",
    name: "Elena Vasquez",
    email: "elena.vasquez@example.com",
    phone: "(503) 555-0142",
    propertyId: "prop-maplewood",
    unitLabel: "Unit 4B",
    smsOptIn: true,
  },
  {
    id: "tenant-whitfield",
    name: "Marcus & Dana Whitfield",
    email: "whitfield.hh@example.com",
    phone: "(503) 555-0198",
    propertyId: "prop-harborview",
    unitLabel: "Loft 9",
    smsOptIn: true,
  },
  {
    id: "tenant-sofia",
    name: "Sofia Lang",
    email: "sofia.lang@example.com",
    phone: "(971) 555-0110",
    propertyId: "prop-maplewood",
    unitLabel: "Unit 12",
    smsOptIn: false,
  },
  {
    id: "tenant-jordan",
    name: "Jordan Kim",
    email: "jordan.kim@example.com",
    phone: "(503) 555-0177",
    propertyId: "prop-cedarridge",
    unitLabel: "Townhome 7",
    smsOptIn: true,
  },
  {
    id: "tenant-amara",
    name: "Amara Okafor",
    email: "amara.okafor@example.com",
    phone: "(503) 555-0164",
    propertyId: "prop-willowpark",
    unitLabel: "Unit 21C",
    smsOptIn: true,
  },
  {
    id: "tenant-ravi",
    name: "Ravi Patel",
    email: "ravi.patel@example.com",
    phone: "(971) 555-0125",
    propertyId: "prop-foundry",
    unitLabel: "Unit 2",
    smsOptIn: false,
  },
];

export const LEASES: Lease[] = [
  {
    id: "lease-4412",
    reference: "LSE-4412",
    tenantId: "tenant-elena",
    propertyId: "prop-maplewood",
    unitLabel: "Unit 4B",
    startDate: "2023-09-01",
    endDate: "2026-09-30",
    monthlyRent: 1845,
    status: "active",
  },
  {
    id: "lease-4405",
    reference: "LSE-4405",
    tenantId: "tenant-whitfield",
    propertyId: "prop-harborview",
    unitLabel: "Loft 9",
    startDate: "2024-08-01",
    endDate: "2026-08-31",
    monthlyRent: 2650,
    status: "active",
  },
  {
    id: "lease-4397",
    reference: "LSE-4397",
    tenantId: "tenant-sofia",
    propertyId: "prop-maplewood",
    unitLabel: "Unit 12",
    startDate: "2024-10-15",
    endDate: "2026-10-14",
    monthlyRent: 1720,
    status: "active",
  },
  {
    id: "lease-4368",
    reference: "LSE-4368",
    tenantId: "tenant-jordan",
    propertyId: "prop-cedarridge",
    unitLabel: "Townhome 7",
    startDate: "2024-09-16",
    endDate: "2026-09-15",
    monthlyRent: 2280,
    status: "expiring",
  },
  {
    id: "lease-4321",
    reference: "LSE-4321",
    tenantId: "tenant-amara",
    propertyId: "prop-willowpark",
    unitLabel: "Unit 21C",
    startDate: "2025-10-01",
    endDate: "2026-09-30",
    monthlyRent: 1595,
    status: "expiring",
  },
  {
    id: "lease-4298",
    reference: "LSE-4298",
    tenantId: "tenant-ravi",
    propertyId: "prop-foundry",
    unitLabel: "Unit 2",
    startDate: "2025-08-01",
    endDate: "2026-07-31",
    monthlyRent: 2110,
    status: "active",
  },
];

/* ------------------------------------------------------------------ */
/* Accounting                                                          */
/* ------------------------------------------------------------------ */

export const INVOICES: Invoice[] = [
  {
    id: "inv-2041",
    number: "INV-2041",
    tenantId: "tenant-sofia",
    propertyId: "prop-maplewood",
    unitLabel: "Unit 12",
    amount: 1720,
    dueDate: "2026-08-01",
    status: "overdue",
  },
  {
    id: "inv-2063",
    number: "INV-2063",
    tenantId: "tenant-amara",
    propertyId: "prop-willowpark",
    unitLabel: "Unit 21C",
    amount: 1595,
    dueDate: "2026-09-05",
    status: "open",
  },
  {
    id: "inv-2071",
    number: "INV-2071",
    tenantId: "tenant-elena",
    propertyId: "prop-maplewood",
    unitLabel: "Unit 4B",
    amount: 1845,
    dueDate: "2026-09-01",
    status: "paid",
  },
  {
    id: "inv-2058",
    number: "INV-2058",
    tenantId: "tenant-whitfield",
    propertyId: "prop-harborview",
    unitLabel: "Loft 9",
    amount: 2650,
    dueDate: "2026-09-01",
    status: "partial",
  },
];

export const PAYMENTS: Payment[] = [
  {
    id: "pay-8841",
    reference: "PMT-8841",
    invoiceId: "inv-2071",
    tenantId: "tenant-elena",
    propertyId: "prop-maplewood",
    amount: 1845,
    method: "ACH",
    postedAt: "2026-09-01T09:12:00",
    status: "completed",
  },
  {
    id: "pay-8866",
    reference: "PMT-8866",
    invoiceId: "inv-2041",
    tenantId: "tenant-sofia",
    propertyId: "prop-maplewood",
    amount: 430,
    method: "Card",
    postedAt: "2026-09-03T18:41:00",
    status: "failed",
  },
  {
    id: "pay-8872",
    reference: "PMT-8872",
    invoiceId: "inv-2063",
    tenantId: "tenant-amara",
    propertyId: "prop-willowpark",
    amount: 1595,
    method: "Portal",
    postedAt: "2026-09-05T08:05:00",
    status: "completed",
  },
];

export const EXPENSES: Expense[] = [
  {
    id: "exp-552",
    reference: "EXP-552",
    propertyId: "prop-harborview",
    vendor: "Cascade Plumbing Co.",
    amount: 1284.5,
    status: "submitted",
    submittedBy: "Tom Whitfield",
  },
  {
    id: "exp-561",
    reference: "EXP-561",
    propertyId: "prop-willowpark",
    vendor: "Rivera Landscape LLC",
    amount: 3120,
    status: "submitted",
    submittedBy: "Daniel Osei",
  },
];

/* ------------------------------------------------------------------ */
/* Maintenance, projects                                               */
/* ------------------------------------------------------------------ */

export const MAINTENANCE_REQUESTS: MaintenanceRequest[] = [
  {
    id: "mr-1188",
    reference: "MR-1188",
    propertyId: "prop-harborview",
    unitLabel: "Loft 9",
    tenantId: "tenant-whitfield",
    category: "Plumbing",
    priority: "emergency",
    status: "new",
    summary: "Water leaking from under the kitchen island into the hallway",
  },
  {
    id: "mr-1184",
    reference: "MR-1184",
    propertyId: "prop-maplewood",
    unitLabel: "Unit 12",
    tenantId: "tenant-sofia",
    category: "HVAC",
    priority: "high",
    status: "assigned",
    assigneeId: "user-tom",
    assigneeName: "Tom Whitfield",
    summary: "Bedroom heater cycling without warming the unit",
    dueDate: "2026-09-09",
  },
  {
    id: "mr-1179",
    reference: "MR-1179",
    propertyId: "prop-willowpark",
    unitLabel: "Unit 21C",
    tenantId: "tenant-amara",
    category: "Appliance",
    priority: "normal",
    status: "scheduled",
    assigneeId: "user-tom",
    assigneeName: "Tom Whitfield",
    summary: "Dishwasher not draining after cycle",
    dueDate: "2026-09-11",
  },
  {
    id: "wo-4471",
    reference: "WO-4471",
    propertyId: "prop-cedarridge",
    unitLabel: "Townhome 7",
    tenantId: "tenant-jordan",
    category: "Roofing",
    priority: "high",
    status: "in_progress",
    assigneeId: "user-tom",
    assigneeName: "Tom Whitfield",
    summary: "Replace damaged flashing above the rear deck",
    dueDate: "2026-09-06",
  },
  {
    id: "wo-4465",
    reference: "WO-4465",
    propertyId: "prop-foundry",
    unitLabel: "Unit 2",
    tenantId: "tenant-ravi",
    category: "Electrical",
    priority: "normal",
    status: "in_progress",
    assigneeId: "user-tom",
    assigneeName: "Tom Whitfield",
    summary: "Replace two failed GFCI outlets in the kitchen",
    dueDate: "2026-09-04",
  },
];

export const PROJECTS: Project[] = [
  {
    id: "proj-302",
    name: "Harborview Lobby Renovation",
    propertyId: "prop-harborview",
    status: "at_risk",
    budget: 148000,
    spent: 121400,
    progress: 68,
    nextMilestone: "Millwork install — Sep 18",
  },
  {
    id: "proj-297",
    name: "Willow Park Roof Recoat",
    propertyId: "prop-willowpark",
    status: "active",
    budget: 96000,
    spent: 44200,
    progress: 42,
    nextMilestone: "Crew mobilization — Sep 12",
  },
];

export const DOCUMENTS: DocumentRecord[] = [
  {
    id: "doc-7741",
    name: "Proof of Renter's Insurance — S. Lang",
    propertyId: "prop-maplewood",
    unitLabel: "Unit 12",
    tenantId: "tenant-sofia",
    category: "Insurance",
    status: "needs_review",
    uploadedBy: "Sofia Lang",
  },
  {
    id: "doc-7748",
    name: "Signed Lease Addendum — Townhome 7",
    propertyId: "prop-cedarridge",
    unitLabel: "Townhome 7",
    tenantId: "tenant-jordan",
    category: "Lease",
    status: "uploaded",
    uploadedBy: "Daniel Osei",
  },
  {
    id: "doc-7752",
    name: "Move-in Inspection Photos — Unit 21C",
    propertyId: "prop-willowpark",
    unitLabel: "Unit 21C",
    tenantId: "tenant-amara",
    category: "Inspection",
    status: "uploaded",
    uploadedBy: "Amara Okafor",
  },
];

export const APPLICATIONS: Application[] = [
  {
    id: "app-3301",
    reference: "APP-3301",
    applicantName: "Naomi Castellanos",
    propertyId: "prop-harborview",
    unitLabel: "Loft 4",
    status: "received",
    submittedAt: "2026-09-05T14:22:00",
  },
  {
    id: "app-3297",
    reference: "APP-3297",
    applicantName: "Ethan Brooks",
    propertyId: "prop-maplewood",
    unitLabel: "Unit 18A",
    status: "screening",
    submittedAt: "2026-09-02T10:05:00",
  },
];

export const TEAM: TeamRecord[] = [
  { id: "user-daniel", name: "Daniel Osei", role: "property_manager", email: "daniel@evergreenres.com", status: "active", lastActiveAt: "2026-09-05T16:40:00" },
  { id: "user-priya", name: "Priya Raman", role: "accountant", email: "priya@evergreenres.com", status: "active", lastActiveAt: "2026-09-05T11:02:00" },
  { id: "user-tom", name: "Tom Whitfield", role: "maintenance_lead", email: "tom@evergreenres.com", status: "active", lastActiveAt: "2026-09-04T07:45:00" },
  { id: "invite-jules", name: "Jules Ferreira", role: "property_manager", email: "jules.ferreira@example.com", status: "invited" },
  { id: "invite-hana", name: "Hana Ito", role: "read_only_investor", email: "hana.ito@example.com", status: "expired" },
];

export const COMMUNICATIONS: CommunicationRecord[] = [
  {
    id: "msg-4410",
    reference: "MSG-4410",
    channel: "sms",
    tenantId: "tenant-ravi",
    propertyId: "prop-foundry",
    direction: "outbound",
    status: "failed",
    preview: "Reminder: your September rent statement is available in the portal.",
  },
  {
    id: "msg-4402",
    reference: "MSG-4402",
    channel: "sms",
    tenantId: "tenant-sofia",
    propertyId: "prop-maplewood",
    direction: "outbound",
    status: "opted_out",
    preview: "Maintenance window notice for Unit 12.",
  },
];

/* ------------------------------------------------------------------ */
/* Lookup helpers                                                      */
/* ------------------------------------------------------------------ */

export const PROPERTY_BY_ID = new Map(PROPERTIES.map((p) => [p.id, p]));
export const TENANT_BY_ID = new Map(TENANTS.map((t) => [t.id, t]));
export const LEASE_BY_ID = new Map(LEASES.map((l) => [l.id, l]));
export const INVOICE_BY_ID = new Map(INVOICES.map((i) => [i.id, i]));

export function tenantName(id?: string): string | undefined {
  return id ? TENANT_BY_ID.get(id)?.name : undefined;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: amount % 1 === 0 ? 0 : 2,
  }).format(amount);
}

/* ------------------------------------------------------------------ */
/* Entity registry — powers deep links from notifications              */
/* ------------------------------------------------------------------ */

const record = (r: EntityRecord): EntityRecord => r;

export const ENTITY_REGISTRY: Record<string, EntityRecord> = {
  "invoice:inv-2041": record({
    entityType: "invoice",
    entityId: "inv-2041",
    label: "INV-2041 · $1,720.00",
    subtitle: "Rent — Unit 12, Maplewood Court Apartments",
    propertyName: "Maplewood Court Apartments",
    unitLabel: "Unit 12",
    statusLabel: "Overdue 6 days",
    statusTone: "critical",
    fields: [
      { label: "Tenant", value: "Sofia Lang" },
      { label: "Issue date", value: "Aug 1, 2026" },
      { label: "Due date", value: "Aug 1, 2026" },
      { label: "Balance", value: "$1,290.00" },
      { label: "Late fee", value: "$75.00" },
    ],
    timeline: [
      { label: "Invoice issued", value: "Aug 1, 2026" },
      { label: "Partial card payment failed", value: "Sep 3, 2026" },
      { label: "Late fee applied", value: "Aug 6, 2026" },
    ],
  }),
  "payment:pay-8841": record({
    entityType: "payment",
    entityId: "pay-8841",
    label: "PMT-8841 · $1,845.00",
    subtitle: "Rent payment — Unit 4B, Maplewood Court Apartments",
    propertyName: "Maplewood Court Apartments",
    unitLabel: "Unit 4B",
    statusLabel: "Completed",
    statusTone: "normal",
    fields: [
      { label: "Tenant", value: "Elena Vasquez" },
      { label: "Method", value: "ACH transfer" },
      { label: "Applied to", value: "INV-2071" },
      { label: "Deposited to", value: "Evergreen Operating · Umpqua Bank" },
    ],
    timeline: [
      { label: "Payment received", value: "Sep 1, 2026, 9:12 AM" },
      { label: "Applied to invoice", value: "Sep 1, 2026, 9:12 AM" },
    ],
  }),
  "lease:lease-4368": record({
    entityType: "lease",
    entityId: "lease-4368",
    label: "LSE-4368 · Townhome 7",
    subtitle: "Jordan Kim — Cedar Ridge Townhomes",
    propertyName: "Cedar Ridge Townhomes",
    unitLabel: "Townhome 7",
    statusLabel: "Expiring in 27 days",
    statusTone: "high",
    fields: [
      { label: "Tenant", value: "Jordan Kim" },
      { label: "Term", value: "Sep 16, 2024 — Sep 15, 2026" },
      { label: "Monthly rent", value: "$2,280.00" },
      { label: "Security deposit", value: "$2,280.00" },
      { label: "Renewal offer", value: "Not sent" },
    ],
    timeline: [
      { label: "Lease signed", value: "Sep 9, 2024" },
      { label: "Last rent increase", value: "Sep 1, 2025" },
    ],
  }),
  "maintenance_request:mr-1188": record({
    entityType: "maintenance_request",
    entityId: "mr-1188",
    label: "MR-1188 · Plumbing",
    subtitle: "Loft 9, Harborview Lofts",
    propertyName: "Harborview Lofts",
    unitLabel: "Loft 9",
    statusLabel: "New · Emergency",
    statusTone: "critical",
    fields: [
      { label: "Reported by", value: "Marcus & Dana Whitfield" },
      { label: "Reported", value: "Today, 6:12 AM" },
      { label: "Priority", value: "Emergency" },
      { label: "Assignee", value: "Unassigned" },
      { label: "Summary", value: "Water leaking from under the kitchen island into the hallway" },
    ],
    timeline: [{ label: "Request received", value: "Today, 6:12 AM" }],
  }),
  "project:proj-302": record({
    entityType: "project",
    entityId: "proj-302",
    label: "Harborview Lobby Renovation",
    subtitle: "Harborview Lofts · Capital project",
    propertyName: "Harborview Lofts",
    statusLabel: "At risk",
    statusTone: "high",
    fields: [
      { label: "Budget", value: "$148,000.00" },
      { label: "Committed", value: "$121,400.00 (82%)" },
      { label: "Progress", value: "68%" },
      { label: "Next milestone", value: "Millwork install — Sep 18" },
    ],
    timeline: [
      { label: "Project approved", value: "May 4, 2026" },
      { label: "Demo complete", value: "Jun 21, 2026" },
      { label: "Budget threshold crossed", value: "Sep 4, 2026" },
    ],
  }),
  "document:doc-7741": record({
    entityType: "document",
    entityId: "doc-7741",
    label: "Proof of Renter's Insurance — S. Lang",
    subtitle: "Insurance · Unit 12, Maplewood Court Apartments",
    propertyName: "Maplewood Court Apartments",
    unitLabel: "Unit 12",
    statusLabel: "Needs review",
    statusTone: "high",
    fields: [
      { label: "Uploaded by", value: "Sofia Lang" },
      { label: "Uploaded", value: "Sep 4, 2026" },
      { label: "Category", value: "Insurance" },
      { label: "Required by lease", value: "Yes — Section 12.2" },
    ],
    timeline: [{ label: "Uploaded to tenant portal", value: "Sep 4, 2026" }],
  }),
  "application:app-3301": record({
    entityType: "application",
    entityId: "app-3301",
    label: "APP-3301 · Naomi Castellanos",
    subtitle: "Application for Loft 4, Harborview Lofts",
    propertyName: "Harborview Lofts",
    unitLabel: "Loft 4",
    statusLabel: "Received",
    statusTone: "normal",
    fields: [
      { label: "Applicant", value: "Naomi Castellanos" },
      { label: "Submitted", value: "Sep 5, 2026, 2:22 PM" },
      { label: "Monthly income", value: "$7,400.00" },
      { label: "Screening", value: "Not started" },
    ],
    timeline: [{ label: "Application received", value: "Sep 5, 2026" }],
  }),
  "team_member:invite-jules": record({
    entityType: "team_member",
    entityId: "invite-jules",
    label: "Invitation · Jules Ferreira",
    subtitle: "Property Manager invite",
    statusLabel: "Pending acceptance",
    statusTone: "normal",
    fields: [
      { label: "Email", value: "jules.ferreira@example.com" },
      { label: "Role", value: "Property Manager" },
      { label: "Invited by", value: "Maya Alvarez" },
      { label: "Expires", value: "Sep 12, 2026" },
    ],
    timeline: [{ label: "Invitation sent", value: "Sep 5, 2026" }],
  }),
  "expense:exp-552": record({
    entityType: "expense",
    entityId: "exp-552",
    label: "EXP-552 · $1,284.50",
    subtitle: "Cascade Plumbing Co. — Harborview Lofts",
    propertyName: "Harborview Lofts",
    statusLabel: "Awaiting review",
    statusTone: "normal",
    fields: [
      { label: "Vendor", value: "Cascade Plumbing Co." },
      { label: "Submitted by", value: "Tom Whitfield" },
      { label: "Category", value: "Repairs & maintenance" },
      { label: "GL account", value: "6210 — R&M: Plumbing" },
    ],
    timeline: [{ label: "Submitted for review", value: "Sep 4, 2026" }],
  }),
  "communication:msg-4410": record({
    entityType: "communication",
    entityId: "msg-4410",
    label: "MSG-4410 · SMS failed",
    subtitle: "Unit 2, The Foundry District",
    propertyName: "The Foundry District",
    unitLabel: "Unit 2",
    statusLabel: "Delivery failed",
    statusTone: "critical",
    fields: [
      { label: "Recipient", value: "Ravi Patel" },
      { label: "Channel", value: "SMS" },
      { label: "Sent", value: "Sep 5, 2026, 8:02 AM" },
      { label: "Error", value: "Carrier returned code 30006 — messages to this number are blocked" },
    ],
    timeline: [{ label: "Delivery attempt", value: "Sep 5, 2026, 8:02 AM" }],
  }),
  "tenant:tenant-elena": record({
    entityType: "tenant",
    entityId: "tenant-elena",
    label: "Elena Vasquez",
    subtitle: "Unit 4B · Maplewood Court Apartments",
    propertyName: "Maplewood Court Apartments",
    unitLabel: "Unit 4B",
    statusLabel: "Active lease",
    statusTone: "normal",
    fields: [
      { label: "Lease", value: "LSE-4412 · through Sep 30, 2026" },
      { label: "Monthly rent", value: "$1,845.00" },
      { label: "Balance", value: "$0.00" },
      { label: "SMS consent", value: "Opted in (Aug 12, 2025)" },
    ],
    timeline: [
      { label: "Lease started", value: "Sep 1, 2023" },
      { label: "Last payment", value: "Sep 1, 2026" },
    ],
  }),
};

export function getEntityRecord(entityType?: string, entityId?: string) {
  if (!entityType || !entityId) return undefined;
  return ENTITY_REGISTRY[`${entityType}:${entityId}`];
}

export const ROLE_LABEL: Record<Role, string> = {
  owner: "Owner",
  property_manager: "Property Manager",
  accountant: "Accountant",
  maintenance_lead: "Maintenance Lead",
  read_only_investor: "Read-only Investor",
};
