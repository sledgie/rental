/**
 * L.O.F.T. — core domain types.
 *
 * These types describe the records the Notification Center references. They are
 * intentionally kept separate from the notification data model so the mock
 * data access layer can later be swapped for Supabase-backed repositories.
 */

export type Role =
  | "owner"
  | "property_manager"
  | "accountant"
  | "maintenance_lead"
  | "read_only_investor";

export type Permission =
  | "properties:read"
  | "leases:read"
  | "accounting:read"
  | "accounting:write"
  | "maintenance:read"
  | "maintenance:write"
  | "projects:read"
  | "documents:read"
  | "pii:read"
  | "communications:read"
  | "team:read"
  | "team:manage"
  | "system:manage";

export interface Organization {
  id: string;
  name: string;
  slug: string;
  plan: "Growth" | "Portfolio" | "Enterprise";
  propertyCount: number;
}

export interface User {
  id: string;
  name: string;
  initials: string;
  email: string;
  jobTitle: string;
}

export interface Membership {
  userId: string;
  organizationId: string;
  role: Role;
}

export interface Unit {
  id: string;
  label: string;
  bedrooms: number;
  bathrooms: number;
  status: "occupied" | "vacant" | "notice" | "renovation";
}

export interface Property {
  id: string;
  organizationId: string;
  name: string;
  address: string;
  city: string;
  state: string;
  unitCount: number;
  type: "Multifamily" | "Townhomes" | "Lofts" | "Commercial";
  manager: string;
  occupancy: number;
}

export interface Tenant {
  id: string;
  name: string;
  email: string;
  phone: string;
  propertyId: string;
  unitLabel: string;
  smsOptIn: boolean;
}

export interface Lease {
  id: string;
  reference: string;
  tenantId: string;
  propertyId: string;
  unitLabel: string;
  startDate: string;
  endDate: string;
  monthlyRent: number;
  status: "active" | "expiring" | "pending" | "ended";
}

export interface Invoice {
  id: string;
  number: string;
  tenantId: string;
  propertyId: string;
  unitLabel: string;
  amount: number;
  dueDate: string;
  status: "paid" | "open" | "overdue" | "partial";
}

export interface Payment {
  id: string;
  reference: string;
  invoiceId: string;
  tenantId: string;
  propertyId: string;
  amount: number;
  method: "ACH" | "Card" | "Check" | "Portal";
  postedAt: string;
  status: "completed" | "pending" | "failed";
}

export interface Expense {
  id: string;
  reference: string;
  propertyId: string;
  vendor: string;
  amount: number;
  status: "submitted" | "approved" | "paid";
  submittedBy: string;
}

export interface MaintenanceRequest {
  id: string;
  reference: string;
  propertyId: string;
  unitLabel: string;
  tenantId: string;
  category: string;
  priority: "emergency" | "high" | "normal" | "low";
  status: "new" | "assigned" | "scheduled" | "in_progress" | "completed";
  assigneeId?: string;
  assigneeName?: string;
  summary: string;
  dueDate?: string;
}

export interface Project {
  id: string;
  name: string;
  propertyId: string;
  status: "planning" | "active" | "at_risk" | "closed";
  budget: number;
  spent: number;
  progress: number;
  nextMilestone: string;
}

export interface DocumentRecord {
  id: string;
  name: string;
  propertyId?: string;
  unitLabel?: string;
  tenantId?: string;
  category: string;
  status: "uploaded" | "needs_review" | "signed" | "failed";
  uploadedBy: string;
}

export interface Application {
  id: string;
  reference: string;
  applicantName: string;
  propertyId: string;
  unitLabel: string;
  status: "received" | "screening" | "approved" | "declined";
  submittedAt: string;
}

export interface TeamRecord {
  id: string;
  name: string;
  role: Role;
  email: string;
  status: "active" | "invited" | "suspended" | "expired";
  lastActiveAt?: string;
}

export interface CommunicationRecord {
  id: string;
  reference: string;
  channel: "sms" | "email" | "portal";
  tenantId: string;
  propertyId: string;
  direction: "outbound" | "inbound";
  status: "delivered" | "failed" | "opted_out";
  preview: string;
}

/**
 * Generic record shape used by the entity detail pages so notifications can
 * deep-link into a readable surface without every module being fully built.
 */
export interface EntityRecord {
  entityType: string;
  entityId: string;
  label: string;
  subtitle?: string;
  propertyName?: string;
  unitLabel?: string;
  statusLabel?: string;
  statusTone?: "critical" | "high" | "normal" | "informational";
  fields: Array<{ label: string; value: string }>;
  timeline: Array<{ label: string; value: string }>;
}
