/**
 * Central configuration for the L.O.F.T. marketing page.
 * Routes, navigation and footer links live here so they can be wired to the
 * real application without touching the section components.
 */

export const SITE_NAME = "L.O.F.T.";
export const SITE_TAGLINE = "Property management with the accounting built in.";

/* -------------------------------------------------------------------------- */
/* Authentication routes                                                      */
/* -------------------------------------------------------------------------- */
/**
 * PLACEHOLDER ROUTES — this landing page is not yet connected to an
 * authentication flow, and this project has no sign-up or log-in routes.
 *
 * While `enabled` is `false`, every sign-up / log-in call to action opens a
 * clearly labelled placeholder notice instead of navigating. Nothing is
 * submitted, and a successful sign-up or log-in is never simulated.
 *
 * To integrate: point `href` at the real routes and set `enabled: true`.
 */
export type AuthRouteKey = "signup" | "login";

export interface AuthRoute {
  href: string;
  enabled: boolean;
  /** Human-readable name used in the placeholder notice. */
  name: string;
}

export const AUTH_ROUTES: Record<AuthRouteKey, AuthRoute> = {
  signup: { href: "/signup", enabled: false, name: "sign-up" },
  login: { href: "/login", enabled: false, name: "log-in" },
};

/* -------------------------------------------------------------------------- */
/* Primary navigation                                                         */
/* -------------------------------------------------------------------------- */
/**
 * Pricing is intentionally omitted: no verified plans or prices exist yet, so
 * there is no pricing section to link to. Add it here once one is published.
 */
export const NAV_ITEMS = [
  { label: "Platform", id: "platform" },
  { label: "Accounting", id: "accounting" },
  { label: "Features", id: "features" },
  { label: "How It Works", id: "how-it-works" },
  { label: "Security", id: "security" },
] as const;

export const NAV_SECTION_IDS: readonly string[] = NAV_ITEMS.map((item) => item.id);

/* -------------------------------------------------------------------------- */
/* Footer                                                                     */
/* -------------------------------------------------------------------------- */
export interface FooterLink {
  label: string;
  /** Links without an href are not rendered (the page doesn't exist yet). */
  href?: string;
}

export const FOOTER_PRODUCT_LINKS: FooterLink[] = [
  { label: "Platform", href: "#platform" },
  { label: "Properties and Units", href: "#feature-properties" },
  { label: "Accounting", href: "#accounting" },
  { label: "Maintenance and Projects", href: "#feature-maintenance" },
  { label: "Reports", href: "#feature-reports" },
];

export const FOOTER_EXPLORE_LINKS: FooterLink[] = [
  { label: "How It Works", href: "#how-it-works" },
  { label: "Teams and Roles", href: "#teams" },
  { label: "Security", href: "#security" },
  { label: "Who It's For", href: "#who-its-for" },
];

/**
 * Company and legal pages have not been published yet. Add an `href` to each
 * entry once the page exists — only entries with an href are displayed.
 */
export const FOOTER_COMPANY_LINKS: FooterLink[] = [{ label: "About" }, { label: "Contact" }];

export const FOOTER_LEGAL_LINKS: FooterLink[] = [{ label: "Privacy Policy" }, { label: "Terms of Service" }];
