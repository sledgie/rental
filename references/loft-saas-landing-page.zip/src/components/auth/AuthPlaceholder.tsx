import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { Unplug, X } from "lucide-react";
import { AUTH_ROUTES, type AuthRouteKey } from "@/config/site";
import { buttonStyles } from "@/components/ui/button";

/**
 * Placeholder notice for authentication calls to action.
 * Shown only while the matching route in `AUTH_ROUTES` is disabled. It
 * explains that the flow is not connected — it never simulates success.
 */

type OpenPlaceholder = (route: AuthRouteKey) => void;

const AuthPlaceholderContext = createContext<OpenPlaceholder | null>(null);

export function useAuthPlaceholder() {
  const context = useContext(AuthPlaceholderContext);
  if (!context) throw new Error("useAuthPlaceholder must be used within <AuthPlaceholderProvider>.");
  return context;
}

const COPY: Record<AuthRouteKey, { title: string; outcome: string }> = {
  signup: {
    title: "Sign-up isn't connected yet",
    outcome: "No workspace has been created and no information has been collected.",
  },
  login: {
    title: "Log-in isn't connected yet",
    outcome: "You have not been signed in and no credentials have been requested.",
  },
};

export function AuthPlaceholderProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<AuthRouteKey | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const returnFocusRef = useRef<HTMLElement | null>(null);

  const open = useCallback<OpenPlaceholder>((next) => {
    returnFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setRoute(next);
  }, []);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (route && dialog && !dialog.open) dialog.showModal();
  }, [route]);

  const close = () => dialogRef.current?.close();

  const handleClosed = () => {
    setRoute(null);
    const target = returnFocusRef.current;
    returnFocusRef.current = null;
    if (target && target.isConnected && target.offsetParent !== null) target.focus({ preventScroll: true });
  };

  const config = route ? AUTH_ROUTES[route] : null;

  return (
    <AuthPlaceholderContext.Provider value={open}>
      {children}
      <dialog
        ref={dialogRef}
        onClose={handleClosed}
        onClick={(event) => {
          // Clicking the backdrop (the dialog element itself) closes the notice.
          if (event.target === event.currentTarget) close();
        }}
        aria-labelledby="auth-placeholder-title"
        aria-describedby="auth-placeholder-description"
        className="m-auto w-[min(calc(100%-2rem),30rem)] max-w-none rounded-card border border-line bg-white p-0 text-ink shadow-float backdrop:bg-evergreen-deep/50 backdrop:backdrop-blur-[2px] open:animate-fade-up"
      >
        {route && config && (
          <div className="relative p-6 sm:p-7">
            <button
              type="button"
              onClick={close}
              aria-label="Close notice"
              className="absolute right-3 top-3 inline-flex size-10 items-center justify-center rounded-control text-muted transition-colors hover:bg-sage-soft hover:text-evergreen"
            >
              <X className="size-4" aria-hidden="true" />
            </button>

            <span className="inline-flex size-10 items-center justify-center rounded-xl bg-amber-soft text-amber-ink">
              <Unplug className="size-5" aria-hidden="true" strokeWidth={1.75} />
            </span>
            <p className="mt-5 text-eyebrow font-semibold uppercase text-amber-ink">Placeholder</p>
            <h2 id="auth-placeholder-title" className="mt-2 pr-8 text-xl font-semibold tracking-tight text-evergreen">
              {COPY[route].title}
            </h2>
            <div id="auth-placeholder-description" className="mt-3 space-y-3 text-[15px] leading-relaxed text-muted">
              <p>
                This button is a placeholder for the L.O.F.T. {config.name} route (
                <code className="rounded bg-sage-soft px-1 py-0.5 font-mono text-[13px] text-evergreen">
                  {config.href}
                </code>
                ). The authentication flow hasn&rsquo;t been connected to this page yet.
              </p>
              <p>{COPY[route].outcome}</p>
            </div>

            <div className="mt-7 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <button type="button" onClick={close} className={buttonStyles({ variant: "secondary" })}>
                Close
              </button>
              <a
                href="#platform"
                onClick={() => {
                  returnFocusRef.current = null;
                  close();
                }}
                className={buttonStyles()}
              >
                Explore the Platform
              </a>
            </div>
          </div>
        )}
      </dialog>
    </AuthPlaceholderContext.Provider>
  );
}
