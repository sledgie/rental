import type { AnchorHTMLAttributes, MouseEvent, ReactNode } from "react";
import { AUTH_ROUTES, type AuthRouteKey } from "@/config/site";
import { buttonStyles, type ButtonSize, type ButtonVariant } from "@/components/ui/button";
import { useAuthPlaceholder } from "./AuthPlaceholder";

type AuthLinkProps = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href" | "children"> & {
  route: AuthRouteKey;
  /** "plain" renders an unstyled text link (e.g. in the footer). */
  variant?: ButtonVariant | "plain";
  size?: ButtonSize;
  children: ReactNode;
};

/**
 * Link to the sign-up / log-in route configured in `src/config/site.ts`.
 * While the route is a placeholder it opens an explanatory notice instead of
 * navigating to a page that doesn't exist.
 */
export function AuthLink({ route, variant = "primary", size = "md", className, onClick, children, ...rest }: AuthLinkProps) {
  const openPlaceholder = useAuthPlaceholder();
  const config = AUTH_ROUTES[route];
  const isPlaceholder = !config.enabled;

  const handleClick = (event: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(event);
    if (isPlaceholder) {
      event.preventDefault();
      openPlaceholder(route);
    }
  };

  return (
    <a
      {...rest}
      href={config.href}
      onClick={handleClick}
      aria-haspopup={isPlaceholder ? "dialog" : undefined}
      data-placeholder-route={isPlaceholder ? "true" : undefined}
      className={variant === "plain" ? className : buttonStyles({ variant, size, className })}
    >
      {children}
    </a>
  );
}
