import { AuthPlaceholderProvider } from "@/components/auth/AuthPlaceholder";
import { Header } from "@/components/sections/Header";
import { Hero } from "@/components/sections/Hero";
import { ProblemSolution } from "@/components/sections/ProblemSolution";
import { Showcase } from "@/components/sections/Showcase";
import { Accounting } from "@/components/sections/Accounting";
import { Features } from "@/components/sections/Features";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { Teams } from "@/components/sections/Teams";
import { Security } from "@/components/sections/Security";
import { Audience } from "@/components/sections/Audience";
import { FinalCta } from "@/components/sections/FinalCta";
import { Footer } from "@/components/sections/Footer";

/**
 * L.O.F.T. marketing landing page.
 * Section order: hero → problem → platform showcase → accounting (core
 * differentiator) → features → how it works → teams → security → audience →
 * final call to action.
 */
export default function App() {
  return (
    <AuthPlaceholderProvider>
      <Header />
      <main id="main-content" tabIndex={-1} className="focus:outline-none">
        <Hero />
        <ProblemSolution />
        <Showcase />
        <Accounting />
        <Features />
        <HowItWorks />
        <Teams />
        <Security />
        <Audience />
        <FinalCta />
      </main>
      <Footer />
    </AuthPlaceholderProvider>
  );
}
