import { useEffect, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import { PROPERTIES, SEGMENT_META } from "@/lib/data";
import { Icon, type IconName } from "./Icon";
import { Badge, IconButton, Logo, ProgressBar, useDismiss } from "./ui";

interface NavItem {
  label: string;
  icon: IconName;
  href?: string;
  badge?: string;
}

const NAV_SECTIONS: { title: string; items: NavItem[] }[] = [
  {
    title: "Insights",
    items: [
      { label: "Overview", icon: "grid", href: "#overview" },
      { label: "Performance", icon: "trend", href: "#performance" },
      { label: "Channel mix", icon: "target", href: "#channels" },
      { label: "Reports", icon: "report" },
    ],
  },
  {
    title: "Manage",
    items: [
      { label: "Properties", icon: "home", href: "#properties" },
      { label: "Bookings", icon: "calendar", href: "#weekday" },
      { label: "Guests", icon: "users" },
      { label: "Maintenance", icon: "wrench", badge: "3" },
    ],
  },
];

export function Sidebar({
  active,
  onNavigate,
  onUpgrade,
  onHelp,
  onClose,
  mobile = false,
}: {
  active: string;
  onNavigate: (item: { label: string; href?: string }) => void;
  onUpgrade: () => void;
  onHelp: () => void;
  onClose?: () => void;
  mobile?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex h-full w-full flex-col border-r border-line bg-surface",
        mobile ? "w-[272px] shadow-pop" : "fixed inset-y-0 left-0 z-40 hidden w-[252px] lg:flex"
      )}
    >
      <div className="flex h-16 shrink-0 items-center justify-between px-4">
        <button type="button" onClick={() => onNavigate({ label: "Overview", href: "#overview" })} aria-label="Keyline home">
          <Logo />
        </button>
        {mobile && onClose && (
          <IconButton icon="x" label="Close navigation" onClick={onClose} />
        )}
      </div>

      <div className="px-3">
        <button
          type="button"
          onClick={() => onNavigate({ label: "Workspace" })}
          className="group flex w-full items-center gap-2.5 rounded-xl border border-line bg-surface-2 p-2 text-left transition-colors duration-200 hover:bg-surface-3"
        >
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand text-[13px] font-bold text-white dark:text-[#07130d]">
            RP
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[12px] font-semibold text-ink">Rental portfolio</span>
            <span className="block truncate text-[10.5px] text-muted tnum">12 properties · 188 units</span>
          </span>
          <Icon name="chevronDown" size={13} className="shrink-0 text-muted" />
        </button>
      </div>

      <nav className="mt-5 flex-1 overflow-y-auto px-3 pb-4">
        {NAV_SECTIONS.map((section) => (
          <div key={section.title} className="mb-5">
            <p className="mb-1.5 px-2 text-[9.5px] font-semibold uppercase tracking-[0.14em] text-muted">
              {section.title}
            </p>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const isActive = active === item.label;
                return (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => onNavigate(item)}
                    aria-current={isActive ? "page" : undefined}
                    className={cn(
                      "group flex w-full items-center gap-2.5 rounded-lg px-2 py-[7px] text-left transition-all duration-200",
                      isActive
                        ? "bg-brand-soft text-brand-ink"
                        : "text-ink-2 hover:bg-surface-2 hover:text-ink"
                    )}
                  >
                    <Icon
                      name={item.icon}
                      size={16}
                      strokeWidth={isActive ? 2 : 1.75}
                      className={isActive ? "text-brand" : "text-muted group-hover:text-ink-2"}
                    />
                    <span className={cn("flex-1 text-[12.5px]", isActive ? "font-semibold" : "font-medium")}>
                      {item.label}
                    </span>
                    {item.badge && (
                      <span
                        className={cn(
                          "rounded-full px-1.5 py-0.5 text-[9.5px] font-bold leading-none",
                          item.badge === "New"
                            ? "bg-[var(--lime)] text-[#1a2413]"
                            : "bg-surface-3 text-ink-2"
                        )}
                      >
                        {item.badge}
                      </span>
                    )}
                    {isActive && <span className="h-1 w-1 rounded-full bg-brand" />}
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        <div className="rounded-xl border border-line bg-surface-2 p-3">
          <div className="flex items-center justify-between">
            <span className="text-[11.5px] font-semibold text-ink">Growth plan</span>
            <Badge tone="brand">Active</Badge>
          </div>
          <p className="mt-1 text-[10.5px] leading-relaxed text-muted">
            You&apos;re using <span className="font-semibold text-ink-2 tnum">8 of 10</span> team seats.
          </p>
          <ProgressBar value={0.8} className="mt-2 h-1" />
          <button
            type="button"
            onClick={onUpgrade}
            className="mt-2.5 flex h-7 w-full items-center justify-center gap-1.5 rounded-md bg-[var(--lime)] text-[10.5px] font-semibold text-[#18220f] transition hover:brightness-95"
          >
            <Icon name="sparkles" size={12} strokeWidth={2} />
            Upgrade workspace
          </button>
        </div>
      </nav>

      <div className="shrink-0 border-t border-line px-3 py-3">
        <button
          type="button"
          onClick={onHelp}
          className="flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left text-ink-2 transition-colors hover:bg-surface-2 hover:text-ink"
        >
          <Icon name="help" size={15} className="text-muted" />
          <span className="flex-1 text-[12px] font-medium">Help &amp; support</span>
          <Icon name="arrowUpRight" size={12} className="text-muted" />
        </button>
        <div className="mt-1.5 flex items-center gap-2.5 rounded-lg px-2 py-1.5">
          <span className="relative flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#2f8267] to-[#163c2e] text-[11px] font-semibold text-[var(--lime)]">
            MC
            <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-surface bg-positive" />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[12px] font-semibold text-ink">Maya Chen</span>
            <span className="block truncate text-[10px] text-muted">Portfolio manager</span>
          </span>
          <IconButton icon="logout" label="Sign out — demo only" className="h-7 w-7" onClick={onHelp} />
        </div>
      </div>
    </div>
  );
}

interface Notification {
  id: number;
  icon: IconName;
  title: string;
  detail: string;
  time: string;
  unread: boolean;
}

const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 1,
    icon: "star",
    title: "New 5-star review",
    detail: "Harborline Residences · San Diego",
    time: "12 min ago",
    unread: true,
  },
  {
    id: 2,
    icon: "wrench",
    title: "Maintenance ticket resolved",
    detail: "Lumen Studio Suites · Unit 11",
    time: "1 hr ago",
    unread: true,
  },
  {
    id: 3,
    icon: "wallet",
    title: "June payouts are scheduled",
    detail: "$184,200 arriving Jul 3",
    time: "4 hrs ago",
    unread: false,
  },
];

export function TopBar({
  dark,
  onToggleDark,
  onMenu,
  search,
  onSearchChange,
  onShowToast,
}: {
  dark: boolean;
  onToggleDark: () => void;
  onMenu: () => void;
  search: string;
  onSearchChange: (value: string) => void;
  onShowToast: (message: string) => void;
}) {
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState(INITIAL_NOTIFICATIONS);
  const [searchOpen, setSearchOpen] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const searchContainerRef = useDismiss<HTMLDivElement>(searchOpen, () => setSearchOpen(false));
  const notificationsRef = useDismiss<HTMLDivElement>(notificationsOpen, () => setNotificationsOpen(false));
  const unread = notifications.filter((notification) => notification.unread).length;
  const query = search.trim().toLowerCase();
  const matches = query
    ? PROPERTIES.filter((property) =>
        `${property.name} ${property.city} ${property.state} ${property.type} ${property.segment}`
          .toLowerCase()
          .includes(query)
      )
    : [];
  const goToTable = () => {
    setSearchOpen(false);
    document.querySelector("#properties")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-canvas/85 backdrop-blur-xl">
      <div className="flex h-16 items-center gap-2 px-4 sm:gap-3 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={onMenu}
          aria-label="Open navigation"
          className="flex h-9 w-9 items-center justify-center rounded-lg text-ink transition hover:bg-surface-2 lg:hidden"
        >
          <Icon name="menu" size={19} />
        </button>
        <button
          type="button"
          onClick={() => searchRef.current?.focus()}
          className="lg:hidden"
          aria-label="Keyline dashboard"
        >
          <Logo compact />
        </button>

        <div className="hidden items-center gap-1.5 text-[11.5px] text-muted lg:flex">
          <span>Workspace</span>
          <Icon name="chevronRight" size={11} />
          <span className="font-medium text-ink-2">Analytics</span>
          <span className="ml-2 flex items-center gap-1.5 rounded-full bg-positive-soft px-2 py-0.5 text-[10px] font-semibold text-positive">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-positive" />
            Live
          </span>
        </div>

        <div ref={searchContainerRef} className="relative ml-auto hidden md:block">
          <Icon
            name="search"
            size={15}
            className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted"
          />
          <input
            ref={searchRef}
            type="search"
            value={search}
            onFocus={() => setSearchOpen(true)}
            onChange={(event) => {
              onSearchChange(event.target.value);
              setSearchOpen(true);
            }}
            placeholder="Search properties…"
            aria-label="Search properties"
            aria-expanded={searchOpen && Boolean(query)}
            className="h-9 w-[190px] rounded-lg border border-line bg-surface pl-8 pr-14 text-xs text-ink outline-none transition-all duration-200 placeholder:text-muted focus:w-[260px] focus:border-brand focus:shadow-sm"
          />
          <kbd className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 rounded border border-line bg-surface-2 px-1.5 py-0.5 text-[9.5px] font-medium text-muted">
            ⌘K
          </kbd>
          {searchOpen && query && (
            <div className="pop-in absolute right-0 top-[calc(100%+8px)] z-50 w-[308px] overflow-hidden rounded-xl border border-line bg-surface shadow-pop">
              <div className="flex items-center justify-between border-b border-line px-3 py-2">
                <span className="text-[10px] font-semibold uppercase tracking-[0.08em] text-muted">Properties</span>
                <span className="text-[10px] text-muted tnum">{matches.length} matches</span>
              </div>
              {matches.length ? (
                <div className="max-h-[248px] overflow-y-auto p-1.5">
                  {matches.slice(0, 5).map((property) => (
                    <button
                      key={property.id}
                      type="button"
                      onClick={() => {
                        onSearchChange(property.name);
                        setSearchOpen(false);
                        goToTable();
                        onShowToast(`Filtered performance table to ${property.name}`);
                      }}
                      className="flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-left transition hover:bg-surface-2"
                    >
                      <span
                        className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-surface-2 text-[9px] font-bold"
                        style={{ color: SEGMENT_META[property.segment].color }}
                      >
                        {property.name
                          .replace(/^The\s+/i, "")
                          .split(" ")
                          .slice(0, 2)
                          .map((word) => word[0])
                          .join("")}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[11.5px] font-medium text-ink">{property.name}</span>
                        <span className="block truncate text-[10px] text-muted">
                          {property.city}, {property.state} · {property.type}
                        </span>
                      </span>
                      <Icon name="arrowUpRight" size={12} className="text-muted" />
                    </button>
                  ))}
                </div>
              ) : (
                <p className="px-3 py-5 text-center text-[11px] text-muted">
                  No properties match “{search.trim()}”.
                </p>
              )}
              <button
                type="button"
                onClick={goToTable}
                className="flex w-full items-center justify-between border-t border-line bg-surface-2 px-3 py-2 text-[10.5px] font-semibold text-ink-2 transition hover:text-ink"
              >
                View matches in table
                <Icon name="arrowRight" size={12} />
              </button>
            </div>
          )}
        </div>

        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <IconButton
            icon={dark ? "sun" : "moon"}
            label={dark ? "Switch to light mode" : "Switch to dark mode"}
            onClick={onToggleDark}
            className="text-ink-2"
          />
          <div className="relative" ref={notificationsRef}>
            <IconButton
              icon="bell"
              label="Notifications"
              badge={unread || undefined}
              onClick={() => setNotificationsOpen((value) => !value)}
              className={cn("text-ink-2", notificationsOpen && "border-line bg-surface-2 text-ink")}
            />
            {notificationsOpen && (
              <div className="pop-in absolute right-0 top-[calc(100%+8px)] z-50 w-[326px] max-w-[calc(100vw-2rem)] overflow-hidden rounded-2xl border border-line bg-surface shadow-pop">
                <div className="flex items-center justify-between border-b border-line px-4 py-3">
                  <div>
                    <p className="text-[13px] font-semibold text-ink">Notifications</p>
                    <p className="text-[10.5px] text-muted">{unread} unread updates</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setNotifications((items) => items.map((item) => ({ ...item, unread: false })));
                      onShowToast("All notifications marked as read");
                    }}
                    className="text-[10.5px] font-semibold text-brand hover:underline"
                  >
                    Mark all read
                  </button>
                </div>
                <div className="max-h-[320px] overflow-y-auto p-1.5">
                  {notifications.map((notification) => (
                    <button
                      key={notification.id}
                      type="button"
                      onClick={() => {
                        setNotifications((items) =>
                          items.map((item) =>
                            item.id === notification.id ? { ...item, unread: false } : item
                          )
                        );
                        onShowToast(notification.title);
                      }}
                      className="flex w-full items-start gap-2.5 rounded-xl p-2.5 text-left transition hover:bg-surface-2"
                    >
                      <span
                        className={cn(
                          "mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg",
                          notification.unread ? "bg-brand-soft text-brand-ink" : "bg-surface-3 text-muted"
                        )}
                      >
                        <Icon name={notification.icon} size={14} />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-1.5">
                          <span className="truncate text-[12px] font-semibold text-ink">{notification.title}</span>
                          {notification.unread && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-brand" />}
                        </span>
                        <span className="mt-0.5 block truncate text-[10.5px] text-muted">{notification.detail}</span>
                        <span className="mt-1 block text-[9.5px] text-muted">{notification.time}</span>
                      </span>
                    </button>
                  ))}
                </div>
                <div className="border-t border-line bg-surface-2 px-3 py-2 text-center">
                  <button
                    type="button"
                    onClick={() => {
                      setNotificationsOpen(false);
                      onShowToast("You're all caught up");
                    }}
                    className="text-[10.5px] font-semibold text-ink-2 hover:text-ink"
                  >
                    View activity log
                  </button>
                </div>
              </div>
            )}
          </div>
          <div className="mx-1.5 hidden h-5 w-px bg-line sm:block" />
          <button
            type="button"
            onClick={() => onShowToast("Signed in as Maya Chen · Portfolio manager")}
            className="hidden items-center gap-2 rounded-lg py-1 pl-1 pr-2 transition hover:bg-surface-2 sm:flex"
          >
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-[#2f8267] to-[#163c2e] text-[10px] font-semibold text-[var(--lime)]">
              MC
            </span>
            <span className="hidden text-left lg:block">
              <span className="block text-[11.5px] font-semibold leading-tight text-ink">Maya Chen</span>
              <span className="block text-[9.5px] leading-tight text-muted">Portfolio manager</span>
            </span>
            <Icon name="chevronDown" size={12} className="hidden text-muted lg:block" />
          </button>
        </div>
      </div>
    </header>
  );
}
