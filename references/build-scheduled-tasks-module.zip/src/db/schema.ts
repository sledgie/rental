import {
  pgTable,
  uuid,
  text,
  varchar,
  integer,
  boolean,
  timestamp,
  date,
  jsonb,
  real,
  pgEnum,
} from "drizzle-orm/pg-core";

// ---------- Enums ----------
export const userRoleEnum = pgEnum("user_role", [
  "administrator",
  "property_manager",
  "landlord",
  "maintenance_staff",
  "accountant",
]);

export const taskPriorityEnum = pgEnum("task_priority", ["Low", "Normal", "High", "Urgent"]);
export const taskStatusEnum = pgEnum("task_status", [
  "Not Started",
  "In Progress",
  "Blocked",
  "Completed",
  "Cancelled",
]);
export const recurrenceFreqEnum = pgEnum("recurrence_freq", [
  "daily",
  "weekly",
  "monthly",
  "quarterly",
  "yearly",
  "custom",
]);
export const recurrenceStatusEnum = pgEnum("recurrence_status", [
  "active",
  "paused",
  "cancelled",
  "completed",
]);
export const reminderChannelEnum = pgEnum("reminder_channel", ["email", "in_app", "sms"]);
export const reminderStatusEnum = pgEnum("reminder_status", [
  "scheduled",
  "sent",
  "cancelled",
  "failed",
]);

// ---------- Core directory ----------
export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  role: userRoleEnum("role").notNull().default("property_manager"),
  phone: varchar("phone", { length: 32 }),
  avatarColor: varchar("avatar_color", { length: 16 }).default("#2563eb"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const properties = pgTable("properties", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  city: varchar("city", { length: 120 }).notNull(),
  state: varchar("state", { length: 8 }).notNull(),
  zip: varchar("zip", { length: 12 }).notNull(),
  type: varchar("type", { length: 40 }).notNull().default("Apartment"),
  status: varchar("status", { length: 24 }).notNull().default("Active"),
  managerId: uuid("manager_id").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const units = pgTable("units", {
  id: uuid("id").defaultRandom().primaryKey(),
  propertyId: uuid("property_id")
    .references(() => properties.id, { onDelete: "cascade" })
    .notNull(),
  unitNumber: varchar("unit_number", { length: 24 }).notNull(),
  bedrooms: integer("bedrooms").default(1),
  bathrooms: real("bathrooms").default(1),
  sqft: integer("sqft").default(800),
  rent: integer("rent").default(1500),
  status: varchar("status", { length: 24 }).notNull().default("Occupied"),
});

export const tenants = pgTable("tenants", {
  id: uuid("id").defaultRandom().primaryKey(),
  firstName: varchar("first_name", { length: 80 }).notNull(),
  lastName: varchar("last_name", { length: 80 }).notNull(),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 32 }),
  propertyId: uuid("property_id").references(() => properties.id),
  unitId: uuid("unit_id").references(() => units.id),
  status: varchar("status", { length: 24 }).notNull().default("Active"),
  leaseStart: date("lease_start"),
  leaseEnd: date("lease_end"),
});

export const leases = pgTable("leases", {
  id: uuid("id").defaultRandom().primaryKey(),
  propertyId: uuid("property_id").references(() => properties.id),
  unitId: uuid("unit_id").references(() => units.id),
  tenantId: uuid("tenant_id").references(() => tenants.id),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  rent: integer("rent").notNull().default(1500),
  status: varchar("status", { length: 24 }).notNull().default("Active"),
});

export const vendors = pgTable("vendors", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  trade: varchar("trade", { length: 80 }).notNull().default("General"),
  email: varchar("email", { length: 255 }),
  phone: varchar("phone", { length: 32 }),
  rating: real("rating").default(4.5),
  isActive: boolean("is_active").notNull().default(true),
});

export const maintenanceRequests = pgTable("maintenance_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  referenceNumber: varchar("reference_number", { length: 24 }).notNull(),
  title: text("title").notNull(),
  propertyId: uuid("property_id").references(() => properties.id),
  unitId: uuid("unit_id").references(() => units.id),
  tenantId: uuid("tenant_id").references(() => tenants.id),
  status: varchar("status", { length: 32 }).notNull().default("Open"),
  priority: varchar("priority", { length: 16 }).notNull().default("Normal"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const projects = pgTable("projects", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  propertyId: uuid("property_id").references(() => properties.id),
  status: varchar("status", { length: 32 }).notNull().default("In Progress"),
  dueDate: date("due_date"),
  progress: integer("progress").default(40),
});

// ---------- Scheduled Tasks ----------
export const taskCategories = pgTable("task_categories", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 80 }).notNull().unique(),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  color: varchar("color", { length: 16 }).notNull().default("#2563eb"),
  icon: varchar("icon", { length: 32 }).notNull().default("clipboard"),
  isSystem: boolean("is_system").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  createdById: uuid("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const taskRecurrences = pgTable("task_recurrences", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  frequency: recurrenceFreqEnum("frequency").notNull().default("weekly"),
  interval: integer("interval").notNull().default(1),
  daysOfWeek: jsonb("days_of_week").$type<number[]>().default([]),
  monthDay: integer("month_day"),
  monthWeek: integer("month_week"),
  monthWeekday: integer("month_weekday"),
  customRule: text("custom_rule"),
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  timezone: varchar("timezone", { length: 64 }).notNull().default("America/New_York"),
  advanceReminderDays: integer("advance_reminder_days").default(1),
  status: recurrenceStatusEnum("status").notNull().default("active"),
  nextOccurrenceDate: date("next_occurrence_date"),
  lastGeneratedDate: date("last_generated_date"),
  template: jsonb("template").$type<Record<string, unknown>>().default({}),
  createdById: uuid("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const tasks = pgTable("tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  referenceNumber: varchar("reference_number", { length: 24 }).notNull().unique(),
  title: text("title").notNull(),
  description: text("description").default(""),
  categoryId: uuid("category_id").references(() => taskCategories.id),
  priority: taskPriorityEnum("priority").notNull().default("Normal"),
  status: taskStatusEnum("status").notNull().default("Not Started"),
  propertyId: uuid("property_id").references(() => properties.id),
  unitId: uuid("unit_id").references(() => units.id),
  tenantId: uuid("tenant_id").references(() => tenants.id),
  leaseId: uuid("lease_id").references(() => leases.id),
  maintenanceRequestId: uuid("maintenance_request_id").references(() => maintenanceRequests.id),
  vendorId: uuid("vendor_id").references(() => vendors.id),
  projectId: uuid("project_id").references(() => projects.id),
  assigneeId: uuid("assignee_id").references(() => users.id),
  collaboratorIds: jsonb("collaborator_ids").$type<string[]>().default([]),
  startDate: date("start_date"),
  dueDate: date("due_date"),
  dueTime: varchar("due_time", { length: 8 }),
  timezone: varchar("timezone", { length: 64 }).notNull().default("America/New_York"),
  isRecurring: boolean("is_recurring").notNull().default(false),
  recurrenceId: uuid("recurrence_id").references(() => taskRecurrences.id, {
    onDelete: "set null",
  }),
  occurrenceDate: date("occurrence_date"),
  completionNotes: text("completion_notes").default(""),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  completedById: uuid("completed_by_id").references(() => users.id),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  cancelReason: text("cancel_reason").default(""),
  reminderPrefs: jsonb("reminder_prefs")
    .$type<{ daysBefore?: number[]; channels?: string[]; enabled?: boolean }>()
    .default({}),
  createdById: uuid("created_by_id").references(() => users.id),
  updatedById: uuid("updated_by_id").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const taskChecklistItems = pgTable("task_checklist_items", {
  id: uuid("id").defaultRandom().primaryKey(),
  taskId: uuid("task_id")
    .references(() => tasks.id, { onDelete: "cascade" })
    .notNull(),
  title: text("title").notNull(),
  isDone: boolean("is_done").notNull().default(false),
  doneById: uuid("done_by_id").references(() => users.id),
  doneAt: timestamp("done_at", { withTimezone: true }),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const taskComments = pgTable("task_comments", {
  id: uuid("id").defaultRandom().primaryKey(),
  taskId: uuid("task_id")
    .references(() => tasks.id, { onDelete: "cascade" })
    .notNull(),
  authorId: uuid("author_id").references(() => users.id),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const taskAttachments = pgTable("task_attachments", {
  id: uuid("id").defaultRandom().primaryKey(),
  taskId: uuid("task_id")
    .references(() => tasks.id, { onDelete: "cascade" })
    .notNull(),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size").default(0),
  mimeType: varchar("mime_type", { length: 120 }).default("application/octet-stream"),
  url: text("url").default(""),
  uploadedById: uuid("uploaded_by_id").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const taskReminders = pgTable("task_reminders", {
  id: uuid("id").defaultRandom().primaryKey(),
  taskId: uuid("task_id")
    .references(() => tasks.id, { onDelete: "cascade" })
    .notNull(),
  remindAt: timestamp("remind_at", { withTimezone: true }).notNull(),
  channel: reminderChannelEnum("channel").notNull().default("in_app"),
  status: reminderStatusEnum("status").notNull().default("scheduled"),
  recipientId: uuid("recipient_id").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const taskActivities = pgTable("task_activities", {
  id: uuid("id").defaultRandom().primaryKey(),
  taskId: uuid("task_id")
    .references(() => tasks.id, { onDelete: "cascade" })
    .notNull(),
  recurrenceId: uuid("recurrence_id").references(() => taskRecurrences.id, {
    onDelete: "set null",
  }),
  actorId: uuid("actor_id").references(() => users.id),
  action: varchar("action", { length: 64 }).notNull(),
  summary: text("summary").notNull(),
  priorValue: text("prior_value"),
  newValue: text("new_value"),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// ---------- Workflow Automation (separate module, integration boundary) ----------
export const workflowAutomations = pgTable("workflow_automations", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  description: text("description").default(""),
  triggerEvent: varchar("trigger_event", { length: 80 }).notNull(),
  conditions: jsonb("conditions").$type<Record<string, unknown>>().default({}),
  actions: jsonb("actions").$type<Record<string, unknown>>().default({}),
  isActive: boolean("is_active").notNull().default(true),
  runCount: integer("run_count").notNull().default(0),
  lastRunAt: timestamp("last_run_at", { withTimezone: true }),
  createdById: uuid("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const workflowRuns = pgTable("workflow_runs", {
  id: uuid("id").defaultRandom().primaryKey(),
  automationId: uuid("automation_id").references(() => workflowAutomations.id, {
    onDelete: "cascade",
  }),
  triggerEvent: varchar("trigger_event", { length: 80 }).notNull(),
  payload: jsonb("payload").$type<Record<string, unknown>>().default({}),
  status: varchar("status", { length: 24 }).notNull().default("succeeded"),
  detail: text("detail").default(""),
  executedAt: timestamp("executed_at", { withTimezone: true }).defaultNow().notNull(),
});

export const domainEvents = pgTable("domain_events", {
  id: uuid("id").defaultRandom().primaryKey(),
  type: varchar("type", { length: 64 }).notNull(),
  taskId: uuid("task_id").references(() => tasks.id, { onDelete: "set null" }),
  recurrenceId: uuid("recurrence_id").references(() => taskRecurrences.id, {
    onDelete: "set null",
  }),
  payload: jsonb("payload").$type<Record<string, unknown>>().default({}),
  emittedAt: timestamp("emitted_at", { withTimezone: true }).defaultNow().notNull(),
});
