import { db } from "./index";
import {
  users,
  properties,
  units,
  tenants,
  leases,
  vendors,
  maintenanceRequests,
  projects,
  taskCategories,
  taskRecurrences,
  tasks,
  taskChecklistItems,
  taskComments,
  taskAttachments,
  taskReminders,
  taskActivities,
  workflowAutomations,
  domainEvents,
} from "./schema";
import { sql } from "drizzle-orm";

const CATS = [
  { name: "Property Inspection", slug: "property-inspection", color: "#2563eb", icon: "search" },
  { name: "Preventive Maintenance", slug: "preventive-maintenance", color: "#059669", icon: "wrench" },
  { name: "Repairs and Follow-up", slug: "repairs-follow-up", color: "#ea580c", icon: "hammer" },
  { name: "Lease Renewal and Expiration", slug: "lease-renewal", color: "#7c3aed", icon: "file" },
  { name: "Tenant Follow-up", slug: "tenant-follow-up", color: "#0284c7", icon: "users" },
  { name: "Financial Review", slug: "financial-review", color: "#0d9488", icon: "chart" },
  { name: "Vendor Appointment", slug: "vendor-appointment", color: "#db2777", icon: "truck" },
  { name: "Compliance and Documentation", slug: "compliance", color: "#b45309", icon: "shield" },
  { name: "Project Milestone", slug: "project-milestone", color: "#4f46e5", icon: "flag" },
  { name: "Administrative", slug: "administrative", color: "#64748b", icon: "clipboard" },
  { name: "Custom", slug: "custom", color: "#0f172a", icon: "star" },
];

function dayOffset(base: Date, n: number): string {
  const d = new Date(base);
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

export async function seed() {
  // wipe (order matters)
  await db.execute(sql`truncate table domain_events, workflow_runs, workflow_automations, task_activities, task_reminders, task_attachments, task_comments, task_checklist_items, tasks, task_recurrences, task_categories, maintenance_requests, projects, leases, tenants, units, properties, users restart identity cascade`);

  const [admin, manager, maint, landlord, accountant] = await db
    .insert(users)
    .values([
      { name: "Ava Thompson", email: "ava@rentops.io", role: "administrator", avatarColor: "#2563eb" },
      { name: "Marcus Chen", email: "marcus@rentops.io", role: "property_manager", avatarColor: "#059669" },
      { name: "Diego Ramirez", email: "diego@rentops.io", role: "maintenance_staff", avatarColor: "#ea580c" },
      { name: "Sarah Whitfield", email: "sarah@whitfieldprop.com", role: "landlord", avatarColor: "#7c3aed" },
      { name: "Priya Nair", email: "priya@rentops.io", role: "accountant", avatarColor: "#0d9488" },
    ])
    .returning();

  const [p1, p2, p3] = await db
    .insert(properties)
    .values([
      { name: "Maple Court Apartments", address: "1240 Maple Ave", city: "Austin", state: "TX", zip: "78704", type: "Apartment", managerId: manager.id },
      { name: "Cedar Grove Townhomes", address: "88 Cedar Grove Ln", city: "Denver", state: "CO", zip: "80209", type: "Townhome", managerId: manager.id },
      { name: "Harbor View Residences", address: "500 Harbor Blvd", city: "Seattle", state: "WA", zip: "98101", type: "Condo", managerId: manager.id },
    ])
    .returning();

  const unitRows = await db
    .insert(units)
    .values([
      { propertyId: p1.id, unitNumber: "101", bedrooms: 2, bathrooms: 2, sqft: 980, rent: 1850, status: "Occupied" },
      { propertyId: p1.id, unitNumber: "204", bedrooms: 1, bathrooms: 1, sqft: 720, rent: 1450, status: "Occupied" },
      { propertyId: p1.id, unitNumber: "305", bedrooms: 3, bathrooms: 2, sqft: 1240, rent: 2300, status: "Vacant" },
      { propertyId: p2.id, unitNumber: "A2", bedrooms: 3, bathrooms: 2.5, sqft: 1420, rent: 2600, status: "Occupied" },
      { propertyId: p2.id, unitNumber: "B1", bedrooms: 2, bathrooms: 2, sqft: 1100, rent: 2100, status: "Occupied" },
      { propertyId: p3.id, unitNumber: "1204", bedrooms: 2, bathrooms: 2, sqft: 1050, rent: 2950, status: "Occupied" },
    ])
    .returning();

  const [t1, t2, t3, t4] = await db
    .insert(tenants)
    .values([
      { firstName: "James", lastName: "Carter", email: "james.carter@mail.com", phone: "(512) 555-0142", propertyId: p1.id, unitId: unitRows[0].id, status: "Active", leaseStart: dayOffset(new Date(), -200), leaseEnd: dayOffset(new Date(), 165) },
      { firstName: "Maria", lastName: "Gonzalez", email: "maria.g@mail.com", phone: "(512) 555-0188", propertyId: p1.id, unitId: unitRows[1].id, status: "Active", leaseStart: dayOffset(new Date(), -100), leaseEnd: dayOffset(new Date(), 28) },
      { firstName: "Robert", lastName: "Kim", email: "robert.kim@mail.com", phone: "(303) 555-0119", propertyId: p2.id, unitId: unitRows[3].id, status: "Active", leaseStart: dayOffset(new Date(), -300), leaseEnd: dayOffset(new Date(), 65) },
      { firstName: "Emily", lastName: "Nguyen", email: "emily.n@mail.com", phone: "(206) 555-0134", propertyId: p3.id, unitId: unitRows[5].id, status: "Active", leaseStart: dayOffset(new Date(), -60), leaseEnd: dayOffset(new Date(), 305) },
    ])
    .returning();

  const [l1, l2] = await db
    .insert(leases)
    .values([
      { propertyId: p1.id, unitId: unitRows[1].id, tenantId: t2.id, startDate: dayOffset(new Date(), -100), endDate: dayOffset(new Date(), 28), rent: 1450, status: "Active" },
      { propertyId: p2.id, unitId: unitRows[3].id, tenantId: t3.id, startDate: dayOffset(new Date(), -300), endDate: dayOffset(new Date(), 65), rent: 2600, status: "Active" },
    ])
    .returning();

  const [v1, v2, v3] = await db
    .insert(vendors)
    .values([
      { name: "Apex HVAC Services", trade: "HVAC", email: "dispatch@apexhavc.com", phone: "(512) 555-0201", rating: 4.8 },
      { name: "Brightline Plumbing", trade: "Plumbing", email: "hello@brightline.com", phone: "(512) 555-0277", rating: 4.6 },
      { name: "Summit Fire Safety", trade: "Fire Safety", email: "service@summitfire.com", phone: "(303) 555-0245", rating: 4.9 },
    ])
    .returning();

  const [m1, m2] = await db
    .insert(maintenanceRequests)
    .values([
      { referenceNumber: "MNT-1042", title: "AC not cooling — Unit 101", propertyId: p1.id, unitId: unitRows[0].id, tenantId: t1.id, status: "Approved", priority: "High" },
      { referenceNumber: "MNT-1048", title: "Leaky faucet — Unit A2", propertyId: p2.id, unitId: unitRows[3].id, tenantId: t3.id, status: "Open", priority: "Normal" },
    ])
    .returning();

  const [proj1, proj2] = await db
    .insert(projects)
    .values([
      { name: "Maple Court Roof Replacement", propertyId: p1.id, status: "In Progress", dueDate: dayOffset(new Date(), 45), progress: 55 },
      { name: "Cedar Grove Exterior Paint", propertyId: p2.id, status: "Planning", dueDate: dayOffset(new Date(), 90), progress: 15 },
    ])
    .returning();

  const catRows = await db
    .insert(taskCategories)
    .values(CATS.map((c) => ({ ...c, isSystem: true, createdById: admin.id })))
    .returning();
  const cat = (slug: string) => catRows.find((c) => c.slug === slug)!.id;

  const today = new Date();
  const D = (n: number) => dayOffset(today, n);

  // Recurring series
  const [rec1, rec2] = await db
    .insert(taskRecurrences)
    .values([
      {
        title: "Monthly HVAC filter replacement",
        frequency: "monthly" as const,
        interval: 1,
        monthDay: 1,
        startDate: D(-90),
        timezone: "America/New_York",
        advanceReminderDays: 3,
        status: "active" as const,
        nextOccurrenceDate: D(10),
        lastGeneratedDate: D(0),
        template: { categoryId: cat("preventive-maintenance"), priority: "Normal", propertyId: p1.id, assigneeId: maint.id, vendorId: v1.id },
        createdById: manager.id,
      },
      {
        title: "Weekly common-area inspection",
        frequency: "weekly" as const,
        interval: 1,
        daysOfWeek: [1],
        startDate: D(-60),
        timezone: "America/New_York",
        advanceReminderDays: 1,
        status: "active" as const,
        nextOccurrenceDate: D(5),
        lastGeneratedDate: D(0),
        template: { categoryId: cat("property-inspection"), priority: "Normal", propertyId: p1.id, assigneeId: maint.id },
        createdById: manager.id,
      },
    ])
    .returning();

  // One-off + occurrence tasks
  const taskSeed: Record<string, string> = {};
  const mk = async (ref: string, vals: Record<string, unknown>) => {
    const rows = await db
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .insert(tasks)
      .values({ referenceNumber: ref, ...(vals as unknown as any) })
      .returning();
    taskSeed[ref] = rows[0].id;
    return rows[0];
  };

  await mk("TSK-1001", {
    title: "Quarterly fire extinguisher inspection — Maple Court",
    description: "Walk all floors, check tags, photograph each unit, log expirations. Coordinate with Summit Fire Safety for recharges.",
    categoryId: cat("property-inspection"), priority: "High", status: "In Progress",
    propertyId: p1.id, assigneeId: maint.id, collaboratorIds: [manager.id],
    vendorId: v3.id, startDate: D(-6), dueDate: D(0), dueTime: "14:00", timezone: "America/New_York",
    createdById: manager.id,
  });
  await mk("TSK-1002", {
    title: "Follow up on AC repair — Unit 101 (MNT-1042)",
    description: "Vendor completed compressor swap. Verify cooling with tenant James Carter, collect invoice from Apex HVAC.",
    categoryId: cat("repairs-follow-up"), priority: "Urgent", status: "Not Started",
    propertyId: p1.id, unitId: unitRows[0].id, tenantId: t1.id, maintenanceRequestId: m1.id,
    assigneeId: maint.id, vendorId: v1.id, startDate: D(-1), dueDate: D(0), dueTime: "17:00",
    createdById: manager.id,
  });
  await mk("TSK-1003", {
    title: "Lease renewal discussion — Maria Gonzalez (Unit 204)",
    description: "Lease expires in 28 days. Present renewal options, confirm rent adjustment, schedule signing.",
    categoryId: cat("lease-renewal"), priority: "High", status: "Not Started",
    propertyId: p1.id, unitId: unitRows[1].id, tenantId: t2.id, leaseId: l1.id,
    assigneeId: manager.id, startDate: D(-3), dueDate: D(-2),
    createdById: manager.id,
  });
  await mk("TSK-1004", {
    title: "Overdue: Balcony railing repair — Cedar Grove B1",
    description: "Tenant reported loose railing. Safety priority — inspect and schedule welding crew.",
    categoryId: cat("repairs-follow-up"), priority: "Urgent", status: "Blocked",
    propertyId: p2.id, unitId: unitRows[4].id, assigneeId: maint.id,
    startDate: D(-12), dueDate: D(-5), createdById: manager.id,
  });
  await mk("TSK-1005", {
    title: "October rent roll & delinquency review",
    description: "Reconcile rent roll, flag >5 day delinquencies, prepare late notices for approval.",
    categoryId: cat("financial-review"), priority: "Normal", status: "Not Started",
    assigneeId: accountant.id, startDate: D(0), dueDate: D(3), createdById: manager.id,
  });
  await mk("TSK-1006", {
    title: "Apex HVAC vendor walkthrough — Boiler room",
    description: "Quarterly vendor appointment. Escort tech, provide roof access, confirm service report.",
    categoryId: cat("vendor-appointment"), priority: "Normal", status: "Not Started",
    propertyId: p1.id, vendorId: v1.id, assigneeId: maint.id, startDate: D(1), dueDate: D(4), dueTime: "09:30",
    createdById: manager.id,
  });
  await mk("TSK-1007", {
    title: "Smoke & CO detector compliance log — Q4",
    description: "Update compliance binder for all 3 properties. Attach test photos per unit.",
    categoryId: cat("compliance"), priority: "High", status: "Not Started",
    assigneeId: manager.id, startDate: D(0), dueDate: D(9), isRecurring: true, recurrenceId: rec1.id, occurrenceDate: D(9),
    createdById: manager.id,
  });
  await mk("TSK-1008", {
    title: "Roof replacement — Phase 2 milestone sign-off",
    description: "Walk with contractor, verify punch list, release progress payment per contract.",
    categoryId: cat("project-milestone"), priority: "High", status: "In Progress",
    propertyId: p1.id, projectId: proj1.id, assigneeId: manager.id, collaboratorIds: [landlord.id],
    startDate: D(-2), dueDate: D(6), createdById: manager.id,
  });
  await mk("TSK-1009", {
    title: "Tenant check-in call — Robert Kim (A2 faucet leak)",
    description: "Confirm plumber visit window works, note any additional issues.",
    categoryId: cat("tenant-follow-up"), priority: "Normal", status: "Completed",
    propertyId: p2.id, unitId: unitRows[3].id, tenantId: t3.id, maintenanceRequestId: m2.id,
    assigneeId: manager.id, startDate: D(-9), dueDate: D(-7),
    completionNotes: "Tenant confirmed faucet fixed; no further issues.", completedAt: new Date(Date.now() - 6 * 864e5), completedById: manager.id,
    createdById: manager.id,
  });
  await mk("TSK-1010", {
    title: "File estoppel certificates — Harbor View refinance",
    description: "Collect signed estoppels, scan to document vault, update admin tracker.",
    categoryId: cat("administrative"), priority: "Low", status: "Not Started",
    propertyId: p3.id, assigneeId: accountant.id, startDate: D(2), dueDate: D(12), createdById: manager.id,
  });
  await mk("TSK-1011", {
    title: "HVAC filter replacement — October occurrence",
    description: "Monthly occurrence. Replace filters in common areas + vacant Unit 305.",
    categoryId: cat("preventive-maintenance"), priority: "Normal", status: "Completed",
    propertyId: p1.id, assigneeId: maint.id, vendorId: v1.id,
    startDate: D(-30), dueDate: D(-28), isRecurring: true, recurrenceId: rec1.id, occurrenceDate: D(-28),
    completionNotes: "All filters replaced; 2 spares ordered.", completedAt: new Date(Date.now() - 27 * 864e5), completedById: maint.id,
    createdById: manager.id,
  });
  await mk("TSK-1012", {
    title: "HVAC filter replacement — November occurrence",
    description: "Monthly occurrence generated from series.",
    categoryId: cat("preventive-maintenance"), priority: "Normal", status: "Not Started",
    propertyId: p1.id, assigneeId: maint.id, vendorId: v1.id,
    startDate: D(8), dueDate: D(10), isRecurring: true, recurrenceId: rec1.id, occurrenceDate: D(10),
    createdById: manager.id,
  });
  await mk("TSK-1013", {
    title: "Common-area inspection — weekly occurrence",
    description: "Lobby, garage, laundry rooms. Log issues with photos.",
    categoryId: cat("property-inspection"), priority: "Normal", status: "Not Started",
    propertyId: p1.id, assigneeId: maint.id, collaboratorIds: [],
    startDate: D(3), dueDate: D(5), isRecurring: true, recurrenceId: rec2.id, occurrenceDate: D(5),
    createdById: manager.id,
  });
  await mk("TSK-1014", {
    title: "Cancelled: Carpet cleaning — Unit 305 turnover",
    description: "Cancelled — owner deferred turnover to next quarter.",
    categoryId: cat("vendor-appointment"), priority: "Low", status: "Cancelled",
    propertyId: p1.id, unitId: unitRows[2].id, assigneeId: manager.id,
    startDate: D(-15), dueDate: D(-10), cancelledAt: new Date(Date.now() - 9 * 864e5), cancelReason: "Owner deferred turnover.",
    createdById: manager.id,
  });

  // checklist, comments, attachments, reminders, activity
  const t1001 = taskSeed["TSK-1001"];
  await db.insert(taskChecklistItems).values([
    { taskId: t1001, title: "Inspect floors 1–3 extinguishers", isDone: true, doneById: maint.id, doneAt: new Date(Date.now() - 2 * 864e5), position: 0 },
    { taskId: t1001, title: "Photograph tags", isDone: true, doneById: maint.id, doneAt: new Date(Date.now() - 1 * 864e5), position: 1 },
    { taskId: t1001, title: "Send recharge list to Summit Fire", isDone: false, position: 2 },
    { taskId: t1001, title: "File compliance log", isDone: false, position: 3 },
  ]);
  await db.insert(taskComments).values([
    { taskId: t1001, authorId: maint.id, body: "Floors 1–2 done. Two units need recharge — waiting on vendor quote." },
    { taskId: t1001, authorId: manager.id, body: "Thanks Diego — please attach photos before EOD so I can file the log." },
  ]);
  await db.insert(taskAttachments).values([
    { taskId: t1001, fileName: "extinguisher-floor1.jpg", fileSize: 482112, mimeType: "image/jpeg", url: "#", uploadedById: maint.id },
    { taskId: t1001, fileName: "inspection-checklist.pdf", fileSize: 96120, mimeType: "application/pdf", url: "#", uploadedById: manager.id },
  ]);
  await db.insert(taskReminders).values([
    { taskId: taskSeed["TSK-1002"], remindAt: new Date(Date.now() + 4 * 36e5), channel: "email", status: "scheduled", recipientId: maint.id },
    { taskId: taskSeed["TSK-1005"], remindAt: new Date(Date.now() + 2 * 864e5), channel: "in_app", status: "scheduled", recipientId: accountant.id },
  ]);

  const act = async (taskId: string, action: string, summary: string, actorId?: string, daysAgo = 1) => {
    await db.insert(taskActivities).values({
      taskId, actorId: actorId ?? manager.id, action, summary,
      createdAt: new Date(Date.now() - daysAgo * 864e5),
    } as never);
  };
  await act(t1001, "created", "Task created and assigned to Diego Ramirez", manager.id, 6);
  await act(t1001, "status_changed", "Status changed from Not Started → In Progress", maint.id, 4);
  await act(t1001, "commented", "Diego Ramirez added a comment", maint.id, 2);
  await act(taskSeed["TSK-1009"], "created", "Task created", manager.id, 9);
  await act(taskSeed["TSK-1009"], "completed", "Task completed with notes", manager.id, 6);
  await act(taskSeed["TSK-1003"], "rescheduled", "Due date changed", manager.id, 2);
  await act(taskSeed["TSK-1004"], "status_changed", "Status changed to Blocked — waiting on welding crew", maint.id, 3);

  await db.insert(workflowAutomations).values([
    {
      name: "Maintenance approval → follow-up task",
      description: "When a maintenance request is approved, create a Repairs follow-up assigned to maintenance staff.",
      triggerEvent: "maintenance.approved",
      conditions: { priority: ["High", "Urgent"] },
      actions: { createTask: { category: "repairs-follow-up", assigneeRole: "maintenance_staff", dueInDays: 2 } },
      isActive: true, runCount: 3, lastRunAt: new Date(Date.now() - 864e5), createdById: admin.id,
    },
    {
      name: "Lease expiring → renewal task",
      description: "60/30/14 days before lease end, create a Lease Renewal task for the manager.",
      triggerEvent: "lease.expiring",
      conditions: { daysBeforeEnd: [60, 30, 14] },
      actions: { createTask: { category: "lease-renewal", assigneeRole: "property_manager", dueInDays: 7 } },
      isActive: true, runCount: 5, lastRunAt: new Date(Date.now() - 2 * 864e5), createdById: admin.id,
    },
    {
      name: "Task overdue → escalate to manager",
      description: "Subscribes to TaskOverdue. Sends notification and reassigns per escalation policy.",
      triggerEvent: "TaskOverdue",
      conditions: { overdueHours: 24 },
      actions: { notify: ["property_manager"], escalate: true },
      isActive: true, runCount: 2, lastRunAt: new Date(Date.now() - 3 * 864e5), createdById: admin.id,
    },
    {
      name: "Task completed → notify requester",
      description: "Subscribes to TaskCompleted to notify landlord and close linked maintenance loop.",
      triggerEvent: "TaskCompleted",
      conditions: {},
      actions: { notify: ["landlord", "requester"] },
      isActive: false, runCount: 11, lastRunAt: new Date(Date.now() - 6 * 864e5), createdById: admin.id,
    },
  ]);

  await db.insert(domainEvents).values([
    { type: "TaskCreated", taskId: t1001, payload: { title: "Quarterly fire extinguisher inspection" } },
    { type: "TaskAssigned", taskId: t1001, payload: { assignee: "Diego Ramirez" } },
    { type: "TaskCompleted", taskId: taskSeed["TSK-1009"], payload: { title: "Tenant check-in call" } },
  ]);

  return { users: { admin, manager, maint, landlord, accountant } };
}

if (require.main === module) {
  seed()
    .then(() => {
      // eslint-disable-next-line no-console
      console.log("Seed complete");
      process.exit(0);
    })
    .catch((e) => {
      // eslint-disable-next-line no-console
      console.error(e);
      process.exit(1);
    });
}
