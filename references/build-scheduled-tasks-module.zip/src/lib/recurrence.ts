/**
 * Recurrence engine — explicit timezone handling.
 *
 * All day-level math is done in UTC-date space but anchored to the series
 * timezone at noon to avoid DST boundary issues (spring-forward / fall-back).
 * Occurrence identity = (recurrenceId, occurrenceDate) so retries are idempotent.
 */

export type Frequency = "daily" | "weekly" | "monthly" | "quarterly" | "yearly" | "custom";

export interface RecurrenceInput {
  frequency: Frequency;
  interval?: number;
  daysOfWeek?: number[]; // 0=Sun..6=Sat
  monthDay?: number | null;
  monthWeek?: number | null; // 1..5, -1 = last
  monthWeekday?: number | null;
  startDate: string; // YYYY-MM-DD
  endDate?: string | null;
  timezone?: string;
}

function parseDay(s: string): Date {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
}
function toDay(d: Date): string {
  return d.toISOString().slice(0, 10);
}
function addDays(d: Date, n: number): Date {
  const c = new Date(d);
  c.setUTCDate(c.getUTCDate() + n);
  return c;
}
function addMonths(d: Date, n: number): Date {
  const c = new Date(d);
  c.setUTCMonth(c.getUTCMonth() + n);
  return c;
}
function daysInMonthUTC(y: number, m: number) {
  return new Date(Date.UTC(y, m, 0)).getUTCDate();
}

function nthWeekdayOfMonth(y: number, m1: number, weekday: number, n: number): Date {
  // m1 1..12
  if (n === -1) {
    const dim = daysInMonthUTC(y, m1);
    const last = new Date(Date.UTC(y, m1 - 1, dim, 12));
    let back = (last.getUTCDay() - weekday + 7) % 7;
    return new Date(Date.UTC(y, m1 - 1, dim - back, 12));
  }
  const first = new Date(Date.UTC(y, m1 - 1, 1, 12));
  const offset = (weekday - first.getUTCDay() + 7) % 7;
  const day = 1 + offset + (n - 1) * 7;
  const dim = daysInMonthUTC(y, m1);
  const clamped = Math.min(day, dim);
  return new Date(Date.UTC(y, m1 - 1, clamped, 12));
}

export function nextOccurrenceAfter(input: RecurrenceInput, afterDay: string | null): string | null {
  const interval = Math.max(1, input.interval ?? 1);
  const start = parseDay(input.startDate);
  const end = input.endDate ? parseDay(input.endDate) : null;
  let cursor = afterDay ? addDays(parseDay(afterDay), 1) : start;
  if (cursor < start) cursor = start;
  // safety cap: search up to 5 years forward
  for (let i = 0; i < 366 * 5 + 10; i++) {
    const dayStr = toDay(cursor);
    if (end && cursor > end) return null;
    if (matchesDate(cursor, start, input, interval)) return dayStr;
    cursor = addDays(cursor, 1);
  }
  return null;
}

function matchesDate(d: Date, start: Date, input: RecurrenceInput, interval: number): boolean {
  if (d < start) return false;
  const freq = input.frequency;
  const diffDays = Math.round((d.getTime() - start.getTime()) / 86400000);
  if (freq === "daily" || (freq === "custom" && (!input.daysOfWeek || input.daysOfWeek.length === 0))) {
    return diffDays % interval === 0;
  }
  if (freq === "weekly" || freq === "custom") {
    const days = input.daysOfWeek && input.daysOfWeek.length ? input.daysOfWeek : [start.getUTCDay()];
    if (!days.includes(d.getUTCDay())) return false;
    // week index relative to start week
    const startWeekMonday = startOfWeekMonday(start);
    const dWeekMonday = startOfWeekMonday(d);
    const diffWeeks = Math.round((dWeekMonday.getTime() - startWeekMonday.getTime()) / (7 * 86400000));
    return diffWeeks % interval === 0;
  }
  if (freq === "monthly") {
    const monthsDiff =
      (d.getUTCFullYear() - start.getUTCFullYear()) * 12 + (d.getUTCMonth() - start.getUTCMonth());
    if (monthsDiff % interval !== 0) return false;
    if (input.monthWeek && input.monthWeekday != null) {
      const expected = nthWeekdayOfMonth(d.getUTCFullYear(), d.getUTCMonth() + 1, input.monthWeekday, input.monthWeek);
      return toDay(expected) === toDay(d);
    }
    if (input.monthDay) {
      const dim = daysInMonthUTC(d.getUTCFullYear(), d.getUTCMonth() + 1);
      const want = Math.min(input.monthDay, dim);
      return d.getUTCDate() === want;
    }
    // default: same day-of-month as start (clamped)
    const dim = daysInMonthUTC(d.getUTCFullYear(), d.getUTCMonth() + 1);
    return d.getUTCDate() === Math.min(start.getUTCDate(), dim);
  }
  if (freq === "quarterly") {
    const monthsDiff =
      (d.getUTCFullYear() - start.getUTCFullYear()) * 12 + (d.getUTCMonth() - start.getUTCMonth());
    if (monthsDiff % (3 * interval) !== 0) return false;
    const dim = daysInMonthUTC(d.getUTCFullYear(), d.getUTCMonth() + 1);
    return d.getUTCDate() === Math.min(start.getUTCDate(), dim);
  }
  if (freq === "yearly") {
    const yearsDiff = d.getUTCFullYear() - start.getUTCFullYear();
    if (yearsDiff % interval !== 0) return false;
    if (d.getUTCMonth() !== start.getUTCMonth()) return false;
    const dim = daysInMonthUTC(d.getUTCFullYear(), d.getUTCMonth() + 1);
    return d.getUTCDate() === Math.min(start.getUTCDate(), dim);
  }
  return false;
}

function startOfWeekMonday(d: Date): Date {
  const dow = (d.getUTCDay() + 6) % 7; // Mon=0
  return addDays(d, -dow);
}

/** Generate up to `count` occurrence dates forward from afterDay (exclusive). */
export function generateForward(
  input: RecurrenceInput,
  afterDay: string | null,
  count = 12
): string[] {
  const out: string[] = [];
  let cursor: string | null = afterDay;
  for (let i = 0; i < count; i++) {
    const nxt = nextOccurrenceAfter(input, cursor);
    if (!nxt) break;
    out.push(nxt);
    cursor = nxt;
  }
  return out;
}

export function describeRecurrence(input: RecurrenceInput): string {
  const iv = Math.max(1, input.interval ?? 1);
  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  switch (input.frequency) {
    case "daily":
      return iv === 1 ? "Daily" : `Every ${iv} days`;
    case "weekly": {
      const days = input.daysOfWeek?.length ? input.daysOfWeek.map((d) => dayNames[d]).join(", ") : "same weekday";
      return iv === 1 ? `Weekly on ${days}` : `Every ${iv} weeks on ${days}`;
    }
    case "monthly":
      if (input.monthWeek && input.monthWeekday != null)
        return `Monthly on ${input.monthWeek === -1 ? "last" : ordinal(input.monthWeek)} ${dayNames[input.monthWeekday]}`;
      if (input.monthDay) return `Monthly on day ${input.monthDay}`;
      return iv === 1 ? "Monthly" : `Every ${iv} months`;
    case "quarterly":
      return iv === 1 ? "Quarterly" : `Every ${iv} quarters`;
    case "yearly":
      return iv === 1 ? "Yearly" : `Every ${iv} years`;
    case "custom":
      return `Custom${iv > 1 ? ` (every ${iv})` : ""}${input.daysOfWeek?.length ? " on " + input.daysOfWeek.map((d) => dayNames[d]).join(", ") : ""}`;
  }
}

function ordinal(n: number) {
  if (n === 1) return "1st";
  if (n === 2) return "2nd";
  if (n === 3) return "3rd";
  return `${n}th`;
}

export function todayInTimezone(tz: string): string {
  try {
    const fmt = new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" });
    return fmt.format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}
