/**
 * Service boundary between Scheduled Tasks and Workflow Automation.
 *
 * Ownership rule (enforced by design):
 * - Scheduled Tasks OWNS task records, recurrence generation, status
 *   transitions, reminders, and history. It EMITS domain events.
 * - Workflow Automation SUBSCRIBES to those events and may CALL BACK into
 *   the task service (create/update) through the functions below — it must
 *   never write to task tables directly.
 *
 * Supported emitted events:
 * TaskCreated | TaskAssigned | TaskDueDateChanged | TaskOverdue |
 * TaskCompleted | TaskCancelled | TaskStatusChanged | TaskRescheduled
 */

export const TASK_DOMAIN_EVENTS = [
  "TaskCreated",
  "TaskAssigned",
  "TaskDueDateChanged",
  "TaskOverdue",
  "TaskCompleted",
  "TaskCancelled",
  "TaskStatusChanged",
  "TaskRescheduled",
] as const;

export type TaskDomainEventType = (typeof TASK_DOMAIN_EVENTS)[number];

/** Events Workflow Automation can use as triggers to create/update tasks. */
export const WORKFLOW_TASK_TRIGGERS = [
  { event: "maintenance.approved", label: "Maintenance approved → create follow-up task" },
  { event: "lease.expiring", label: "Lease expiring → create lease review task" },
  { event: "TaskOverdue", label: "Task overdue → escalate / reassign" },
  { event: "TaskCompleted", label: "Task completed → notify / close linked work" },
  { event: "TaskCreated", label: "Task created → notify assignee" },
  { event: "TaskAssigned", label: "Task assigned → notify new assignee" },
] as const;

export function buildTaskEventPayload(task: Record<string, unknown>, extra?: Record<string, unknown>) {
  return {
    taskId: task.id,
    referenceNumber: task.referenceNumber,
    title: task.title,
    status: task.status,
    priority: task.priority,
    assigneeId: task.assigneeId,
    dueDate: task.dueDate,
    propertyId: task.propertyId,
    recurrenceId: (task as { recurrenceId?: unknown }).recurrenceId ?? null,
    ...extra,
  };
}
