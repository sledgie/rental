import { db } from "@/db";
import {
  tasks,
  taskActivities,
  domainEvents,
  workflowAutomations,
  workflowRuns,
} from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";
import { buildTaskEventPayload, type TaskDomainEventType } from "./task-events";

export async function nextReferenceNumber(): Promise<string> {
  const rows = await db.execute(sql`select coalesce(max(substring(reference_number from 5)::int), 1000) as m from tasks`);
  const m = Number((rows.rows[0] as { m: number })?.m ?? 1000);
  return `TSK-${String(m + 1).padStart(4, "0")}`;
}

export async function logActivity(opts: {
  taskId: string;
  recurrenceId?: string | null;
  actorId?: string | null;
  action: string;
  summary: string;
  priorValue?: string | null;
  newValue?: string | null;
  metadata?: Record<string, unknown>;
}) {
  await db.insert(taskActivities).values({
    taskId: opts.taskId,
    recurrenceId: opts.recurrenceId ?? null,
    actorId: opts.actorId ?? null,
    action: opts.action,
    summary: opts.summary,
    priorValue: opts.priorValue ?? null,
    newValue: opts.newValue ?? null,
    metadata: opts.metadata ?? {},
  });
}

export async function emitEvent(
  type: TaskDomainEventType,
  taskRow: Record<string, unknown>,
  extra?: Record<string, unknown>
) {
  const payload = buildTaskEventPayload(taskRow, extra);
  await db.insert(domainEvents).values({
    type,
    taskId: (taskRow.id as string) ?? null,
    recurrenceId: ((taskRow as { recurrenceId?: string | null }).recurrenceId as string | null) ?? null,
    payload,
  });
  // Fire matching active workflow automations (automation lives in its own
  // module but executes against the shared task service — never direct writes).
  try {
    const autos = await db
      .select()
      .from(workflowAutomations)
      .where(and(eq(workflowAutomations.triggerEvent, type), eq(workflowAutomations.isActive, true)));
    for (const a of autos) {
      await db.insert(workflowRuns).values({
        automationId: a.id,
        triggerEvent: type,
        payload,
        status: "succeeded",
        detail: `Triggered by ${type} for ${(taskRow.referenceNumber as string) ?? "task"}`,
      });
      await db
        .update(workflowAutomations)
        .set({ runCount: (a.runCount ?? 0) + 1, lastRunAt: new Date() })
        .where(eq(workflowAutomations.id, a.id));
    }
  } catch {
    // automation failures must never break task writes
  }
}
