export type Role =
  | "administrator"
  | "property_manager"
  | "landlord"
  | "maintenance_staff"
  | "accountant";

export type PermissionKey =
  | "task.viewAll"
  | "task.viewAssigned"
  | "task.create"
  | "task.assign"
  | "task.edit"
  | "task.reschedule"
  | "task.complete"
  | "task.cancel"
  | "task.manageRecurrence"
  | "task.viewHistory"
  | "task.viewAttachments"
  | "task.manageCategories";

const MATRIX: Record<Role, Record<PermissionKey, boolean>> = {
  administrator: {
    "task.viewAll": true,
    "task.viewAssigned": true,
    "task.create": true,
    "task.assign": true,
    "task.edit": true,
    "task.reschedule": true,
    "task.complete": true,
    "task.cancel": true,
    "task.manageRecurrence": true,
    "task.viewHistory": true,
    "task.viewAttachments": true,
    "task.manageCategories": true,
  },
  property_manager: {
    "task.viewAll": true,
    "task.viewAssigned": true,
    "task.create": true,
    "task.assign": true,
    "task.edit": true,
    "task.reschedule": true,
    "task.complete": true,
    "task.cancel": true,
    "task.manageRecurrence": true,
    "task.viewHistory": true,
    "task.viewAttachments": true,
    "task.manageCategories": true,
  },
  landlord: {
    "task.viewAll": true,
    "task.viewAssigned": true,
    "task.create": true,
    "task.assign": false,
    "task.edit": true,
    "task.reschedule": false,
    "task.complete": true,
    "task.cancel": false,
    "task.manageRecurrence": false,
    "task.viewHistory": true,
    "task.viewAttachments": true,
    "task.manageCategories": false,
  },
  maintenance_staff: {
    "task.viewAll": false,
    "task.viewAssigned": true,
    "task.create": true,
    "task.assign": false,
    "task.edit": true,
    "task.reschedule": false,
    "task.complete": true,
    "task.cancel": false,
    "task.manageRecurrence": false,
    "task.viewHistory": true,
    "task.viewAttachments": true,
    "task.manageCategories": false,
  },
  accountant: {
    "task.viewAll": true,
    "task.viewAssigned": true,
    "task.create": true,
    "task.assign": false,
    "task.edit": true,
    "task.reschedule": false,
    "task.complete": false,
    "task.cancel": false,
    "task.manageRecurrence": false,
    "task.viewHistory": true,
    "task.viewAttachments": true,
    "task.manageCategories": false,
  },
};

export function can(role: Role | string | null | undefined, perm: PermissionKey): boolean {
  if (!role) return false;
  const row = MATRIX[role as Role];
  if (!row) return false;
  return row[perm] === true;
}

export function roleLabel(role: string) {
  return role
    .split("_")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

export const PERMISSION_DESCRIPTIONS: { key: PermissionKey; label: string }[] = [
  { key: "task.viewAll", label: "View all tasks (vs. only assigned)" },
  { key: "task.viewAssigned", label: "View assigned tasks" },
  { key: "task.create", label: "Create tasks" },
  { key: "task.assign", label: "Assign tasks to other users" },
  { key: "task.edit", label: "Edit tasks" },
  { key: "task.reschedule", label: "Reschedule tasks" },
  { key: "task.complete", label: "Complete tasks" },
  { key: "task.cancel", label: "Cancel tasks" },
  { key: "task.manageRecurrence", label: "Manage recurring series" },
  { key: "task.viewHistory", label: "View history & activity" },
  { key: "task.viewAttachments", label: "View attachments" },
  { key: "task.manageCategories", label: "Manage categories (admin)" },
];
