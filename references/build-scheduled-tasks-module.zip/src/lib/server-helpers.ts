import { headers } from "next/headers";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export interface ActingUser {
  id: string;
  name: string;
  email: string;
  role: string;
}

/** Resolve acting user from `x-user-id` header; fall back to first administrator. */
export async function getActingUser(): Promise<ActingUser | null> {
  const h = await headers();
  const requested = h.get("x-user-id");
  if (requested) {
    const rows = await db.select().from(users).where(eq(users.id, requested)).limit(1);
    if (rows[0]) {
      return { id: rows[0].id, name: rows[0].name, email: rows[0].email, role: rows[0].role };
    }
  }
  const admins = await db.select().from(users).limit(1);
  if (admins[0]) return { id: admins[0].id, name: admins[0].name, email: admins[0].email, role: admins[0].role };
  return null;
}

export function json(data: unknown, status = 200) {
  return Response.json(data, { status });
}

export function err(message: string, status = 400, extra?: Record<string, unknown>) {
  return Response.json({ error: message, ...extra }, { status });
}
