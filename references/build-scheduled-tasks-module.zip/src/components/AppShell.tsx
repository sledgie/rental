"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  LayoutDashboard,
  Building2,
  Users,
  FileText,
  Wrench,
  Wallet,
  CalendarClock,
  Zap,
  FolderKanban,
  Settings,
  Menu,
  X,
  Bell,
  Search,
  ChevronDown,
} from "lucide-react";
import { useUser } from "./UserContext";
import { Avatar } from "./ui";
import { roleLabel } from "@/lib/permissions";
import { cx } from "@/lib/format";

const NAV = [
  {
    section: "Overview",
    items: [{ href: "/", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    section: "Portfolio",
    items: [
      { href: "/properties", label: "Properties", icon: Building2 },
      { href: "/tenants", label: "Tenants & Leases", icon: Users },
      { href: "/maintenance", label: "Maintenance", icon: Wrench },
      { href: "/financials", label: "Financials", icon: Wallet },
    ],
  },
  {
    section: "Operations",
    items: [
      { href: "/scheduled-tasks", label: "Scheduled Tasks", icon: CalendarClock, badge: "New" },
      { href: "/workflow-automation", label: "Workflow Automation", icon: Zap },
      { href: "/projects", label: "Projects", icon: FolderKanban },
    ],
  },
  {
    section: "System",
    items: [
      { href: "/reports", label: "Documents", icon: FileText },
      { href: "/settings", label: "Settings", icon: Settings },
    ],
  },
];

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, users, setUserId } = useUser();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenu, setUserMenu] = useState(false);

  const sidebar = (
    <div className="flex h-full flex-col bg-[#0f1e33]">
      <div className="flex items-center gap-2.5 px-5 pb-5 pt-6">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600 text-lg font-bold text-white">R</div>
        <div>
          <p className="text-[15px] font-bold leading-tight text-white">RentOps</p>
          <p className="text-[11px] leading-tight text-slate-400">Property Management</p>
        </div>
      </div>
      <nav className="flex-1 space-y-5 overflow-y-auto px-3 pb-6">
        {NAV.map((group) => (
          <div key={group.section}>
            <p className="px-2 pb-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-slate-500">{group.section}</p>
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
                const Icon = item.icon;
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={() => setMobileOpen(false)}
                      className={cx(
                        "group flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13.5px] font-medium transition",
                        active ? "bg-blue-600 text-white shadow-sm" : "text-slate-300 hover:bg-white/5 hover:text-white"
                      )}
                    >
                      <Icon size={17} className={active ? "text-white" : "text-slate-400 group-hover:text-slate-200"} />
                      <span className="flex-1">{item.label}</span>
                      {"badge" in item && item.badge && (
                        <span className="rounded-full bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300 ring-1 ring-emerald-400/30">
                          {item.badge}
                        </span>
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
      <div className="border-t border-white/10 p-3">
        <div className="rounded-xl bg-white/5 p-3">
          <p className="text-[11px] font-semibold text-slate-300">Acting as (RBAC demo)</p>
          <p className="mt-0.5 truncate text-xs text-slate-400">{user ? `${user.name} · ${roleLabel(user.role)}` : "Loading…"}</p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-100">
      {/* mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/50" onClick={() => setMobileOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72">{sidebar}</div>
        </div>
      )}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 lg:block">{sidebar}</aside>

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
          <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
            <button className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menu">
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div className="hidden min-w-0 flex-1 items-center md:flex">
              <div className="relative w-full max-w-md">
                <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  placeholder="Search tasks, properties, tenants… (use task workspace search)"
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm outline-none placeholder:text-slate-400 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-100"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      const v = (e.target as HTMLInputElement).value;
                      window.location.href = `/scheduled-tasks?search=${encodeURIComponent(v)}`;
                    }
                  }}
                />
              </div>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <button className="relative rounded-lg p-2 text-slate-500 hover:bg-slate-100" title="Notifications are delivered by Workflow Automation subscriptions">
                <Bell size={19} />
                <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />
              </button>
              <div className="relative">
                <button onClick={() => setUserMenu(!userMenu)} className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white py-1.5 pl-1.5 pr-2.5 hover:bg-slate-50">
                  {user && <Avatar name={user.name} color={user.avatarColor} size="sm" />}
                  <span className="hidden text-left sm:block">
                    <span className="block max-w-32 truncate text-[13px] font-semibold leading-tight text-slate-800">{user?.name ?? "…"}</span>
                    <span className="block text-[11px] leading-tight text-slate-500">{user ? roleLabel(user.role) : ""}</span>
                  </span>
                  <ChevronDown size={15} className="text-slate-400" />
                </button>
                {userMenu && (
                  <div className="absolute right-0 top-full z-30 mt-2 w-72 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl">
                    <p className="border-b border-slate-100 px-4 py-2.5 text-[11px] font-bold uppercase tracking-wide text-slate-500">Switch role — permissions enforced server-side</p>
                    <ul className="max-h-80 overflow-y-auto py-1">
                      {users.map((u) => (
                        <li key={u.id}>
                          <button
                            onClick={() => { setUserId(u.id); setUserMenu(false); window.location.reload(); }}
                            className={cx("flex w-full items-center gap-2.5 px-4 py-2 text-left hover:bg-slate-50", u.id === user?.id && "bg-blue-50/60")}
                          >
                            <Avatar name={u.name} color={u.avatarColor} size="sm" />
                            <span className="min-w-0 flex-1">
                              <span className="block truncate text-[13px] font-semibold text-slate-800">{u.name}</span>
                              <span className="block text-[11px] text-slate-500">{roleLabel(u.role)} · {u.email}</span>
                            </span>
                            {u.id === user?.id && <span className="text-xs font-bold text-blue-600">●</span>}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>
        <main className="mx-auto w-full max-w-[1400px] px-4 py-6 sm:px-6">{children}</main>
      </div>
    </div>
  );
}
