"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "./UserContext";
import { Empty } from "./ui";

export default function EntityPage({
  title,
  blurb,
  collection,
  columns,
}: {
  title: string;
  blurb: string;
  collection: string;
  columns: { key: string; label: string; render?: (row: Record<string, unknown>) => string }[];
}) {
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch("/api/lookups")
      .then((r) => r.json())
      .then((j) => setRows(j[collection] ?? []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [collection]);

  const cell = (row: Record<string, unknown>, key: string, render?: (r: Record<string, unknown>) => string) => {
    if (render) return render(row);
    const v = row[key];
    if (v == null) return "—";
    if (typeof v === "object") return "—";
    return String(v);
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-900 sm:text-2xl">{title}</h1>
        <p className="mt-0.5 text-[13px] text-slate-500">{blurb}</p>
      </div>
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] uppercase tracking-wide text-slate-500">
                {columns.map((c) => <th key={c.key} className="px-4 py-3 font-bold">{c.label}</th>)}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {rows.map((r, i) => (
                <tr key={(r.id as string) ?? i} className="hover:bg-slate-50/60">
                  {columns.map((c) => <td key={c.key} className="px-4 py-2.5 text-[13px] text-slate-700">{cell(r, c.key, c.render)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {loading && <p className="p-6 text-center text-sm text-slate-400">Loading…</p>}
        {!loading && rows.length === 0 && <div className="p-6"><Empty title="No records" /></div>}
        <p className="border-t border-slate-100 bg-slate-50/60 px-4 py-2 text-[11px] text-slate-400">Existing portfolio data — reused by Scheduled Tasks via linked records (no duplicates). Tasks link to these rows by ID.</p>
      </div>
    </div>
  );
}
