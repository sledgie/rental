"use client";

import { cx } from "@/lib/format";

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    "Not Started": "bg-slate-100 text-slate-700 ring-slate-200",
    "In Progress": "bg-blue-50 text-blue-700 ring-blue-200",
    Blocked: "bg-red-50 text-red-700 ring-red-200",
    Completed: "bg-emerald-50 text-emerald-700 ring-emerald-200",
    Cancelled: "bg-zinc-100 text-zinc-500 ring-zinc-200",
  };
  const dot: Record<string, string> = {
    "Not Started": "bg-slate-400",
    "In Progress": "bg-blue-500",
    Blocked: "bg-red-500",
    Completed: "bg-emerald-500",
    Cancelled: "bg-zinc-400",
  };
  return (
    <span className={cx("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset", map[status] ?? map["Not Started"])}>
      <span className={cx("h-1.5 w-1.5 rounded-full", dot[status] ?? "bg-slate-400")} />
      {status}
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: string }) {
  const map: Record<string, string> = {
    Low: "bg-slate-100 text-slate-600",
    Normal: "bg-sky-100 text-sky-700",
    High: "bg-amber-100 text-amber-800",
    Urgent: "bg-red-100 text-red-700",
  };
  return (
    <span className={cx("inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold", map[priority] ?? map.Normal)}>
      {priority === "Urgent" ? "▲ " : ""}
      {priority}
    </span>
  );
}

export function Avatar({ name, color, size = "md" }: { name: string; color?: string | null; size?: "sm" | "md" | "lg" }) {
  const initials = name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
  const sz = size === "sm" ? "h-6 w-6 text-[10px]" : size === "lg" ? "h-10 w-10 text-sm" : "h-8 w-8 text-xs";
  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center rounded-full font-semibold text-white ${sz}`}
      style={{ backgroundColor: color ?? "#2563eb" }}
      title={name}
    >
      {initials}
    </span>
  );
}

export function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
        {label} {required && <span className="text-red-500">*</span>}
      </span>
      {children}
    </label>
  );
}

export const inputCls =
  "w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100";

export function Empty({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-200 bg-slate-50/60 px-6 py-12 text-center">
      <p className="text-sm font-semibold text-slate-700">{title}</p>
      {hint && <p className="mt-1 max-w-sm text-xs text-slate-500">{hint}</p>}
    </div>
  );
}
