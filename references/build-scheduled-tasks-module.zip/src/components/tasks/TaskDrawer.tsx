"use client";

import { useEffect, useMemo, useState } from "react";
import { X, Repeat, Plus, Trash2 } from "lucide-react";
import { apiFetch, useUser } from "../UserContext";
import { Field, inputCls } from "../ui";
import { can } from "@/lib/permissions";
import { cx } from "@/lib/format";

export interface LookupData {
  properties: { id: string; name: string }[];
  units: { id: string; propertyId: string; unitNumber: string }[];
  tenants: { id: string; firstName: string; lastName: string }[];
  leases: { id: string; unitId: string | null }[];
  vendors: { id: string; name: string }[];
  maintenanceRequests: { id: string; referenceNumber: string; title: string }[];
  projects: { id: string; name: string }[];
}

interface Props {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  editing?: Record<string, unknown> | null;
  categories: { id: string; name: string }[];
  users: { id: string; name: string; role: string }[];
  lookups: LookupData | null;
}

const PRIORITIES = ["Low", "Normal", "High", "Urgent"];
const STATUSES = ["Not Started", "In Progress", "Blocked", "Completed", "Cancelled"];
const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default function TaskDrawer({ open, onClose, onSaved, editing, categories, users, lookups }: Props) {
  const { user } = useUser();
  const isEdit = Boolean(editing);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editScope, setEditScope] = useState<"single" | "future" | "all">("single");
  const [showScope, setShowScope] = useState(false);

  const [form, setForm] = useState<Record<string, unknown>>({});
  const [recurring, setRecurring] = useState(false);
  const [rec, setRec] = useState({
    frequency: "weekly",
    interval: 1,
    daysOfWeek: [1] as number[],
    monthDay: 1,
    monthMode: "day" as "day" | "relative",
    monthWeek: 1,
    monthWeekday: 1,
    endDate: "",
    advanceReminderDays: 1,
  });
  const [checklist, setChecklist] = useState<string[]>([]);
  const [newItem, setNewItem] = useState("");
  const [remindDays, setRemindDays] = useState("1");
  const [remindEnabled, setRemindEnabled] = useState(true);

  useEffect(() => {
    if (!open) return;
    setError(null);
    setShowScope(false);
    setEditScope("single");
    if (editing) {
      setForm({
        title: editing.title ?? "",
        description: editing.description ?? "",
        categoryId: (editing.categoryId as string) ?? "",
        priority: (editing.priority as string) ?? "Normal",
        status: (editing.status as string) ?? "Not Started",
        propertyId: (editing.propertyId as string) ?? "",
        unitId: (editing.unitId as string) ?? "",
        tenantId: (editing.tenantId as string) ?? "",
        leaseId: (editing.leaseId as string) ?? "",
        maintenanceRequestId: (editing.maintenanceRequestId as string) ?? "",
        vendorId: (editing.vendorId as string) ?? "",
        projectId: (editing.projectId as string) ?? "",
        assigneeId: (editing.assigneeId as string) ?? "",
        startDate: (editing.startDate as string) ?? "",
        dueDate: (editing.dueDate as string) ?? "",
        dueTime: (editing.dueTime as string) ?? "",
        completionNotes: (editing.completionNotes as string) ?? "",
      });
      setRecurring(Boolean(editing.isRecurring));
      setChecklist([]);
      const rp = editing.reminderPrefs as { daysBefore?: number[]; enabled?: boolean } | null;
      setRemindDays(String(rp?.daysBefore?.[0] ?? 1));
      setRemindEnabled(rp?.enabled !== false);
    } else {
      const today = new Date().toISOString().slice(0, 10);
      setForm({
        title: "", description: "", categoryId: "", priority: "Normal", status: "Not Started",
        propertyId: "", unitId: "", tenantId: "", leaseId: "", maintenanceRequestId: "",
        vendorId: "", projectId: "", assigneeId: user?.id ?? "", startDate: today, dueDate: today,
        dueTime: "", completionNotes: "",
      });
      setRecurring(false);
      setChecklist([]);
    }
  }, [open, editing, user?.id]);

  const set = (k: string, v: unknown) => setForm((f) => ({ ...f, [k]: v }));

  const unitsForProperty = useMemo(() => {
    if (!lookups || !form.propertyId) return lookups?.units ?? [];
    return lookups.units.filter((u) => u.propertyId === form.propertyId);
  }, [lookups, form.propertyId]);

  if (!open) return null;

  const canAssignOthers = user ? can(user.role, "task.assign") : false;

  async function save(scope?: "single" | "future" | "all") {
    setError(null);
    if (!String(form.title ?? "").trim()) return setError("Task title is required.");
    if (!recurring && !form.dueDate) return setError("Due date is required for one-time tasks.");
    if (form.startDate && form.dueDate && (form.dueDate as string) < (form.startDate as string))
      return setError("Due date cannot be earlier than start date.");
    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        ...Object.fromEntries(Object.entries(form).map(([k, v]) => [k, v === "" ? null : v])),
        checklist: checklist.map((t) => ({ title: t })),
        reminderPrefs: { enabled: remindEnabled, daysBefore: [Number(remindDays) || 1], channels: ["in_app", "email"] },
      };
      if (!isEdit && recurring) {
        payload.recurrence = {
          frequency: rec.frequency,
          interval: rec.interval,
          daysOfWeek: rec.frequency === "weekly" ? rec.daysOfWeek : [],
          monthDay: rec.frequency === "monthly" && rec.monthMode === "day" ? rec.monthDay : null,
          monthWeek: rec.frequency === "monthly" && rec.monthMode === "relative" ? rec.monthWeek : null,
          monthWeekday: rec.frequency === "monthly" && rec.monthMode === "relative" ? rec.monthWeekday : null,
          startDate: (form.dueDate as string) ?? (form.startDate as string),
          endDate: rec.endDate || null,
          advanceReminderDays: rec.advanceReminderDays,
        };
      }
      if (isEdit && editing) {
        if ((editing as { recurrenceId?: string }).recurrenceId && !scope) {
          setShowScope(true);
          setSaving(false);
          return;
        }
        payload.editScope = scope ?? "single";
        const r = await apiFetch(`/api/tasks/${editing.id as string}`, { method: "PATCH", body: JSON.stringify(payload) });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? "Save failed");
      } else {
        const r = await apiFetch("/api/tasks", { method: "POST", body: JSON.stringify(payload) });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? "Create failed");
      }
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  const isRecurrenceOccurrence = Boolean((editing as { recurrenceId?: string } | null)?.recurrenceId);

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-slate-900/45" onClick={onClose} />
      <aside className="absolute inset-y-0 right-0 flex w-full max-w-2xl flex-col bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">{isEdit ? "Edit task" : "Create task"}</h2>
            <p className="text-xs text-slate-500">
              {isEdit ? `Ref ${(editing?.referenceNumber as string) ?? ""}` : "Assignments, schedule, checklist and reminders"}
            </p>
          </div>
          <button onClick={onClose} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100" aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto px-5 py-5">
          {error && <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>}

          {showScope && (
            <div className="rounded-xl border border-amber-300 bg-amber-50 p-4">
              <p className="text-sm font-bold text-amber-900">This task is part of a recurring series. Apply changes to:</p>
              <div className="mt-2 space-y-1.5">
                {(
                  [
                    ["single", "This occurrence only", "Completed history is never overwritten."],
                    ["future", "This and future occurrences", "Only open occurrences are updated; completed history preserved."],
                    ["all", "Entire series", "Updates the series template + all open occurrences."],
                  ] as const
                ).map(([v, label, hint]) => (
                  <label key={v} className={cx("flex cursor-pointer items-start gap-2.5 rounded-lg border px-3 py-2 text-sm", editScope === v ? "border-blue-500 bg-white" : "border-amber-200 bg-white/60")}>
                    <input type="radio" checked={editScope === v} onChange={() => setEditScope(v)} className="mt-1" />
                    <span>
                      <span className="block font-semibold text-slate-800">{label}</span>
                      <span className="block text-xs text-slate-500">{hint}</span>
                    </span>
                  </label>
                ))}
              </div>
              <div className="mt-3 flex gap-2">
                <button onClick={() => save(editScope)} disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50">
                  {saving ? "Saving…" : "Apply"}
                </button>
                <button onClick={() => setShowScope(false)} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50">Back</button>
              </div>
            </div>
          )}

          <div className="grid gap-4">
            <Field label="Task title" required>
              <input className={inputCls} value={String(form.title ?? "")} onChange={(e) => set("title", e.target.value)} placeholder="e.g. Quarterly fire extinguisher inspection" />
            </Field>
            <Field label="Description">
              <textarea className={inputCls} rows={3} value={String(form.description ?? "")} onChange={(e) => set("description", e.target.value)} placeholder="Scope, acceptance criteria, access notes…" />
            </Field>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
              <Field label="Category">
                <select className={inputCls} value={String(form.categoryId ?? "")} onChange={(e) => set("categoryId", e.target.value)}>
                  <option value="">Select…</option>
                  {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </Field>
              <Field label="Priority">
                <select className={inputCls} value={String(form.priority ?? "Normal")} onChange={(e) => set("priority", e.target.value)}>
                  {PRIORITIES.map((p) => <option key={p}>{p}</option>)}
                </select>
              </Field>
              <Field label="Status">
                <select className={inputCls} value={String(form.status ?? "Not Started")} onChange={(e) => set("status", e.target.value)}>
                  {STATUSES.map((s) => <option key={s}>{s}</option>)}
                </select>
              </Field>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
            <p className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-500">Assignment</p>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Assigned user" required>
                <select className={inputCls} value={String(form.assigneeId ?? "")} onChange={(e) => set("assigneeId", e.target.value)}>
                  <option value="">Select…</option>
                  {users.map((u) => <option key={u.id} value={u.id} disabled={u.id !== user?.id && !canAssignOthers}>{u.name} — {u.role.replace(/_/g, " ")}{u.id !== user?.id && !canAssignOthers ? " (no permission)" : ""}</option>)}
                </select>
                {!canAssignOthers && <p className="mt-1 text-[11px] text-slate-500">Your role can only assign to yourself. Assignment to others requires elevated permission.</p>}
              </Field>
              <Field label="Due time (optional)">
                <input type="time" className={inputCls} value={String(form.dueTime ?? "")} onChange={(e) => set("dueTime", e.target.value)} />
              </Field>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3">
              <Field label="Start date">
                <input type="date" className={inputCls} value={String(form.startDate ?? "")} onChange={(e) => set("startDate", e.target.value)} />
              </Field>
              <Field label="Due date" required={!recurring}>
                <input type="date" className={inputCls} value={String(form.dueDate ?? "")} onChange={(e) => set("dueDate", e.target.value)} />
              </Field>
              <Field label="Reminder">
                <div className="flex items-center gap-2">
                  <input type="checkbox" checked={remindEnabled} onChange={(e) => setRemindEnabled(e.target.checked)} />
                  <select className={inputCls} value={remindDays} onChange={(e) => setRemindDays(e.target.value)} disabled={!remindEnabled}>
                    <option value="0">On due date</option>
                    <option value="1">1 day before</option>
                    <option value="3">3 days before</option>
                    <option value="7">7 days before</option>
                  </select>
                </div>
              </Field>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
            <p className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-500">Linked records</p>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Property">
                <select className={inputCls} value={String(form.propertyId ?? "")} onChange={(e) => { set("propertyId", e.target.value); set("unitId", ""); }}>
                  <option value="">Select…</option>
                  {lookups?.properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </Field>
              <Field label="Unit (optional)">
                <select className={inputCls} value={String(form.unitId ?? "")} onChange={(e) => set("unitId", e.target.value)}>
                  <option value="">Select…</option>
                  {unitsForProperty.map((u) => <option key={u.id} value={u.id}>{u.unitNumber}</option>)}
                </select>
              </Field>
              <Field label="Tenant (optional)">
                <select className={inputCls} value={String(form.tenantId ?? "")} onChange={(e) => set("tenantId", e.target.value)}>
                  <option value="">Select…</option>
                  {lookups?.tenants.map((t) => <option key={t.id} value={t.id}>{t.firstName} {t.lastName}</option>)}
                </select>
              </Field>
              <Field label="Lease (optional)">
                <select className={inputCls} value={String(form.leaseId ?? "")} onChange={(e) => set("leaseId", e.target.value)}>
                  <option value="">Select…</option>
                  {lookups?.leases.map((l) => <option key={l.id} value={l.id}>{l.id.slice(0, 8)}…</option>)}
                </select>
              </Field>
              <Field label="Maintenance request (optional)">
                <select className={inputCls} value={String(form.maintenanceRequestId ?? "")} onChange={(e) => set("maintenanceRequestId", e.target.value)}>
                  <option value="">Select…</option>
                  {lookups?.maintenanceRequests.map((m) => <option key={m.id} value={m.id}>{m.referenceNumber} — {m.title}</option>)}
                </select>
              </Field>
              <Field label="Vendor (optional)">
                <select className={inputCls} value={String(form.vendorId ?? "")} onChange={(e) => set("vendorId", e.target.value)}>
                  <option value="">Select…</option>
                  {lookups?.vendors.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
                </select>
              </Field>
              <Field label="Project (optional)">
                <select className={inputCls} value={String(form.projectId ?? "")} onChange={(e) => set("projectId", e.target.value)}>
                  <option value="">Select…</option>
                  {lookups?.projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </Field>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 p-4">
            <div className="flex items-center justify-between">
              <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-slate-500"><Repeat size={14} /> Recurring schedule</p>
              {!isEdit && (
                <label className="flex items-center gap-2 text-sm text-slate-700">
                  <input type="checkbox" checked={recurring} onChange={(e) => setRecurring(e.target.checked)} />
                  Repeat this task
                </label>
              )}
              {isEdit && isRecurrenceOccurrence && <span className="rounded-full bg-violet-100 px-2 py-0.5 text-[11px] font-bold text-violet-700">Part of series</span>}
            </div>
            {(recurring && !isEdit) && (
              <div className="mt-3 grid gap-4 sm:grid-cols-2">
                <Field label="Frequency">
                  <select className={inputCls} value={rec.frequency} onChange={(e) => setRec({ ...rec, frequency: e.target.value })}>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="quarterly">Quarterly</option>
                    <option value="yearly">Yearly</option>
                    <option value="custom">Custom</option>
                  </select>
                </Field>
                <Field label="Every (interval)">
                  <input type="number" min={1} max={12} className={inputCls} value={rec.interval} onChange={(e) => setRec({ ...rec, interval: Math.max(1, Number(e.target.value)) })} />
                </Field>
                {(rec.frequency === "weekly" || rec.frequency === "custom") && (
                  <div className="sm:col-span-2">
                    <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">Days of week</span>
                    <div className="flex flex-wrap gap-1.5">
                      {DAYS.map((d, i) => (
                        <button key={d} type="button" onClick={() => setRec({ ...rec, daysOfWeek: rec.daysOfWeek.includes(i) ? rec.daysOfWeek.filter((x) => x !== i) : [...rec.daysOfWeek, i] })}
                          className={cx("rounded-lg border px-2.5 py-1.5 text-xs font-semibold", rec.daysOfWeek.includes(i) ? "border-blue-600 bg-blue-600 text-white" : "border-slate-200 bg-white text-slate-600")}>{d}</button>
                      ))}
                    </div>
                  </div>
                )}
                {rec.frequency === "monthly" && (
                  <div className="sm:col-span-2 space-y-2">
                    <div className="flex gap-2">
                      <button type="button" onClick={() => setRec({ ...rec, monthMode: "day" })} className={cx("rounded-lg border px-3 py-1.5 text-xs font-semibold", rec.monthMode === "day" ? "border-blue-600 bg-blue-50 text-blue-700" : "border-slate-200 text-slate-600")}>Day of month</button>
                      <button type="button" onClick={() => setRec({ ...rec, monthMode: "relative" })} className={cx("rounded-lg border px-3 py-1.5 text-xs font-semibold", rec.monthMode === "relative" ? "border-blue-600 bg-blue-50 text-blue-700" : "border-slate-200 text-slate-600")}>Relative (e.g. 2nd Mon)</button>
                    </div>
                    {rec.monthMode === "day" ? (
                      <input type="number" min={1} max={31} className={inputCls} value={rec.monthDay} onChange={(e) => setRec({ ...rec, monthDay: Number(e.target.value) })} />
                    ) : (
                      <div className="grid grid-cols-2 gap-2">
                        <select className={inputCls} value={rec.monthWeek} onChange={(e) => setRec({ ...rec, monthWeek: Number(e.target.value) })}>
                          <option value={1}>First</option><option value={2}>Second</option><option value={3}>Third</option><option value={4}>Fourth</option><option value={-1}>Last</option>
                        </select>
                        <select className={inputCls} value={rec.monthWeekday} onChange={(e) => setRec({ ...rec, monthWeekday: Number(e.target.value) })}>
                          {DAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}
                        </select>
                      </div>
                    )}
                  </div>
                )}
                <Field label="End date (optional)">
                  <input type="date" className={inputCls} value={rec.endDate} onChange={(e) => setRec({ ...rec, endDate: e.target.value })} />
                </Field>
                <Field label="Advance reminder (days)">
                  <input type="number" min={0} max={30} className={inputCls} value={rec.advanceReminderDays} onChange={(e) => setRec({ ...rec, advanceReminderDays: Number(e.target.value) })} />
                </Field>
                <p className="text-[11px] text-slate-500 sm:col-span-2">Occurrences generate independently with their own status, assignee, comments and history. DST-safe: dates anchor at noon in the series timezone. Retries are idempotent (one row per series + date).</p>
              </div>
            )}
            {isEdit && isRecurrenceOccurrence && (
              <p className="mt-2 text-xs text-slate-500">Manage pause / resume / cancel and upcoming occurrences from the <strong>Series</strong> tab. Editing here asks whether to apply to this occurrence, future ones, or the whole series — completed history is never overwritten.</p>
            )}
          </div>

          {!isEdit && (
            <div className="rounded-xl border border-slate-200 p-4">
              <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">Checklist</p>
              <div className="flex gap-2">
                <input className={inputCls} value={newItem} onChange={(e) => setNewItem(e.target.value)} placeholder="Add checklist item…" onKeyDown={(e) => { if (e.key === "Enter" && newItem.trim()) { setChecklist([...checklist, newItem.trim()]); setNewItem(""); } }} />
                <button onClick={() => { if (newItem.trim()) { setChecklist([...checklist, newItem.trim()]); setNewItem(""); } }} className="rounded-lg bg-slate-900 px-3 text-white"><Plus size={16} /></button>
              </div>
              <ul className="mt-2 space-y-1.5">
                {checklist.map((c, i) => (
                  <li key={i} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-1.5 text-sm">
                    <span>☐ {c}</span>
                    <button onClick={() => setChecklist(checklist.filter((_, j) => j !== i))} className="text-slate-400 hover:text-red-600"><Trash2 size={14} /></button>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {isEdit && (
            <Field label="Completion notes">
              <textarea className={inputCls} rows={2} value={String(form.completionNotes ?? "")} onChange={(e) => set("completionNotes", e.target.value)} placeholder="Filled on completion…" />
            </Field>
          )}
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-slate-200 px-5 py-4">
          <button onClick={onClose} className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={() => save()} disabled={saving} className="rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50">
            {saving ? "Saving…" : isEdit ? "Save changes" : "Create task"}
          </button>
        </div>
      </aside>
    </div>
  );
}
