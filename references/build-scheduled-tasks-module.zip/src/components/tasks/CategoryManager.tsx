"use client";

import { useState } from "react";
import { Plus, Pencil, Ban } from "lucide-react";
import { apiFetch, useUser } from "../UserContext";
import { inputCls } from "../ui";
import { can } from "@/lib/permissions";

export interface Category {
  id: string;
  name: string;
  slug: string;
  color: string;
  icon: string;
  isSystem: boolean;
  isActive: boolean;
}

const COLORS = ["#2563eb", "#059669", "#ea580c", "#7c3aed", "#0284c7", "#0d9488", "#db2777", "#b45309", "#4f46e5", "#64748b"];

export default function CategoryManager({ categories, onChanged }: { categories: Category[]; onChanged: () => void }) {
  const { user } = useUser();
  const [name, setName] = useState("");
  const [color, setColor] = useState(COLORS[0]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editColor, setEditColor] = useState(COLORS[0]);
  const [msg, setMsg] = useState<string | null>(null);

  const allowed = user ? can(user.role, "task.manageCategories") : false;

  async function create() {
    if (!name.trim()) return;
    const r = await apiFetch("/api/categories", { method: "POST", body: JSON.stringify({ name: name.trim(), color }) });
    const j = await r.json();
    if (!r.ok) return setMsg(j.error ?? "Create failed");
    setName("");
    setMsg(`Category “${j.name}” created.`);
    onChanged();
  }

  async function saveEdit(id: string) {
    const r = await apiFetch(`/api/categories/${id}`, { method: "PATCH", body: JSON.stringify({ name: editName, color: editColor }) });
    const j = await r.json();
    if (!r.ok) return setMsg(j.error ?? "Update failed");
    setEditingId(null);
    onChanged();
  }

  async function toggleActive(c: Category) {
    const r = await apiFetch(`/api/categories/${c.id}`, { method: "PATCH", body: JSON.stringify({ isActive: !c.isActive }) });
    if (!r.ok) {
      const j = await r.json();
      return setMsg(j.error ?? "Update failed");
    }
    onChanged();
  }

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Task categories</h3>
          <p className="text-xs text-slate-500">11 system defaults ship with the module. Administrators can add custom categories and deactivate unused ones (system categories can&apos;t be deleted).</p>
        </div>
      </div>
      {msg && <p className="mt-2 rounded-lg bg-blue-50 px-3 py-1.5 text-xs text-blue-800">{msg}</p>}
      {!allowed && <p className="mt-2 rounded-lg bg-amber-50 px-3 py-1.5 text-xs text-amber-800">Your role ({user?.role.replace(/_/g, " ")}) can view but not manage categories. Switch to administrator / property manager to edit.</p>}

      {allowed && (
        <div className="mt-3 flex flex-wrap items-end gap-2 rounded-xl bg-slate-50 p-3">
          <div>
            <span className="mb-1 block text-[11px] font-bold uppercase text-slate-500">New category</span>
            <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Turnover Cleaning" />
          </div>
          <div>
            <span className="mb-1 block text-[11px] font-bold uppercase text-slate-500">Color</span>
            <div className="flex gap-1">
              {COLORS.map((c) => (
                <button key={c} onClick={() => setColor(c)} className={`h-6 w-6 rounded-full ring-2 ring-offset-1 ${color === c ? "ring-slate-900" : "ring-transparent"}`} style={{ backgroundColor: c }} aria-label={c} />
              ))}
            </div>
          </div>
          <button onClick={create} className="flex items-center gap-1 rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-700"><Plus size={14} /> Add</button>
        </div>
      )}

      <ul className="mt-3 divide-y divide-slate-100">
        {categories.map((c) => (
          <li key={c.id} className="flex items-center gap-3 py-2.5">
            <span className="h-8 w-1.5 rounded-full" style={{ backgroundColor: c.color }} />
            <div className="min-w-0 flex-1">
              {editingId === c.id ? (
                <div className="flex flex-wrap items-center gap-2">
                  <input className={inputCls} value={editName} onChange={(e) => setEditName(e.target.value)} />
                  <div className="flex gap-1">
                    {COLORS.slice(0, 6).map((cc) => (
                      <button key={cc} onClick={() => setEditColor(cc)} className={`h-5 w-5 rounded-full ${editColor === cc ? "ring-2 ring-slate-900" : ""}`} style={{ backgroundColor: cc }} />
                    ))}
                  </div>
                  <button onClick={() => saveEdit(c.id)} className="rounded-lg bg-blue-600 px-2.5 py-1 text-xs font-semibold text-white">Save</button>
                  <button onClick={() => setEditingId(null)} className="rounded-lg border px-2.5 py-1 text-xs">Cancel</button>
                </div>
              ) : (
                <>
                  <p className="truncate text-sm font-semibold text-slate-800">{c.name} {!c.isActive && <span className="ml-1 rounded bg-zinc-100 px-1.5 py-0.5 text-[10px] font-bold text-zinc-500">INACTIVE</span>}</p>
                  <p className="text-[11px] text-slate-500">{c.isSystem ? "System default" : "Custom"} · {c.slug}</p>
                </>
              )}
            </div>
            {allowed && editingId !== c.id && (
              <div className="flex gap-1">
                <button onClick={() => { setEditingId(c.id); setEditName(c.name); setEditColor(c.color); }} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700" title="Rename"><Pencil size={14} /></button>
                <button onClick={() => toggleActive(c)} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-amber-600" title={c.isActive ? "Deactivate" : "Activate"}><Ban size={14} /></button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
