"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Pause, Play, XOctagon, RefreshCw, Repeat } from "lucide-react";
import { apiFetch, useUser } from "../UserContext";
import { StatusBadge } from "../ui";
import { can } from "@/lib/permissions";
import { fmtDate, cx } from "@/lib/format";

interface Series {
  id: string;
  title: string;
  frequency: string;
  interval: number;
  status: string;
  startDate: string;
  endDate: string | null;
  nextOccurrenceDate: string | null;
  lastGeneratedDate: string | null;
  occurrenceCount: number;
  description: string;
  timezone: string;
}

export default function SeriesManager() {
  const { user } = useUser();
  const [rows, setRows] = useState<Series[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [occ, setOcc] = useState<Record<string, { id: string; dueDate: string | null; status: string; title: string }[]>>({});

  const load = () => {
    setLoading(true);
    apiFetch("/api/recurrences").then((r) => r.json()).then((j) => { setRows(j); setLoading(false); }).catch(() => setLoading(false));
  };
  useEffect(load, []);

  const allowed = user ? can(user.role, "task.manageRecurrence") : false;

  async function act(id: string, action: string) {
    const r = await apiFetch(`/api/recurrences/${id}`, { method: "PATCH", body: JSON.stringify({ action }) });
    const j = await r.json();
    if (!r.ok) return setMsg(j.error ?? "Action failed");
    setMsg(action === "generate" ? `Generated ${j.created ?? 0} new occurrence(s) — idempotent, no duplicates.` : `Series ${action}d.`);
    load();
  }

  async function expand(id: string) {
    if (expanded === id) return setExpanded(null);
    setExpanded(id);
    if (!occ[id]) {
      const r = await apiFetch(`/api/recurrences/${id}`).then((x) => x.json());
      setOcc((o) => ({ ...o, [id]: r.occurrences ?? [] }));
    }
  }

  if (loading) return <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">Loading recurring series…</div>;

  return (
    <div className="space-y-3">
      {msg && <p className="rounded-lg bg-blue-50 px-3 py-2 text-xs text-blue-800">{msg}</p>}
      {!allowed && <p className="rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-800">Your role can view series but not pause / resume / cancel them.</p>}
      <div className="flex items-center justify-between">
        <p className="text-xs text-slate-500">{rows.length} series · each occurrence is independently trackable (own status, assignee, due date, comments, history) · missed occurrences stay open for catch-up · DST-anchored dates</p>
        <button onClick={() => apiFetch("/api/cron/process", { method: "POST" }).then(() => { setMsg("Background processor ran: overdue check + recurrence generation complete."); load(); })} className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50">
          <RefreshCw size={13} /> Run due-date & recurrence check
        </button>
      </div>
      {rows.map((s) => (
        <div key={s.id} className="overflow-hidden rounded-xl border border-slate-200 bg-white">
          <div className="flex flex-wrap items-center gap-3 px-4 py-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-violet-100 text-violet-700"><Repeat size={17} /></span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold text-slate-900">{s.title}</p>
              <p className="text-xs text-slate-500">{s.description} · {s.occurrenceCount} occurrences · TZ {s.timezone} · start {fmtDate(s.startDate)}{s.endDate ? ` → ${fmtDate(s.endDate)}` : " · no end"}</p>
            </div>
            <span className={cx("rounded-full px-2.5 py-0.5 text-xs font-bold", s.status === "active" ? "bg-emerald-100 text-emerald-700" : s.status === "paused" ? "bg-amber-100 text-amber-800" : "bg-zinc-100 text-zinc-500")}>{s.status.toUpperCase()}</span>
            <div className="text-right text-xs">
              <p className="font-semibold text-slate-700">Next: {s.nextOccurrenceDate ? fmtDate(s.nextOccurrenceDate) : "—"}</p>
              <p className="text-slate-400">Last generated: {s.lastGeneratedDate ? fmtDate(s.lastGeneratedDate) : "—"}</p>
            </div>
            <div className="flex gap-1.5">
              <button onClick={() => expand(s.id)} className="rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50">{expanded === s.id ? "Hide" : "Occurrences"}</button>
              {allowed && s.status === "active" && <button onClick={() => act(s.id, "pause")} className="flex items-center gap-1 rounded-lg border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-xs font-semibold text-amber-700 hover:bg-amber-100"><Pause size={13} /> Pause</button>}
              {allowed && s.status === "paused" && <button onClick={() => act(s.id, "resume")} className="flex items-center gap-1 rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-xs font-semibold text-emerald-700 hover:bg-emerald-100"><Play size={13} /> Resume</button>}
              {allowed && s.status !== "cancelled" && <button onClick={() => act(s.id, "generate")} className="flex items-center gap-1 rounded-lg border border-blue-200 bg-blue-50 px-2.5 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100" title="Generate next occurrences (idempotent)"><RefreshCw size={13} /> Generate</button>}
              {allowed && s.status !== "cancelled" && <button onClick={() => { if (confirm("Cancel this series? Open occurrences will be cancelled; completed history is preserved.")) act(s.id, "cancel"); }} className="flex items-center gap-1 rounded-lg border border-red-200 bg-red-50 px-2.5 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-100"><XOctagon size={13} /> Cancel</button>}
            </div>
          </div>
          {expanded === s.id && (
            <div className="border-t border-slate-100 bg-slate-50/60 px-4 py-3">
              <div className="grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
                {(occ[s.id] ?? []).map((o) => (
                  <Link key={o.id} href={`/scheduled-tasks/${o.id}`} className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 hover:border-blue-300">
                    <span className="min-w-0">
                      <span className="block truncate text-xs font-semibold text-slate-800">{o.title}</span>
                      <span className="block text-[11px] text-slate-500">Due {fmtDate(o.dueDate)}</span>
                    </span>
                    <StatusBadge status={o.status} />
                  </Link>
                ))}
                {(occ[s.id] ?? []).length === 0 && <p className="text-xs text-slate-400">Loading occurrences…</p>}
              </div>
            </div>
          )}
        </div>
      ))}
      {rows.length === 0 && <p className="rounded-xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm text-slate-500">No recurring series yet. Create a task with “Repeat this task” enabled.</p>}
    </div>
  );
}
