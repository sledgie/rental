"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cx, fmtDate } from "@/lib/format";

export interface CalTask {
  id: string;
  title: string;
  dueDate: string | null;
  startDate?: string | null;
  status: string;
  priority: string;
  referenceNumber?: string;
  category?: { color?: string; name?: string } | null;
}

function parseDay(s: string) {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12));
}
function toDay(d: Date) {
  return d.toISOString().slice(0, 10);
}
function addDaysStr(s: string, n: number) {
  const d = parseDay(s);
  d.setUTCDate(d.getUTCDate() + n);
  return toDay(d);
}

export default function TaskCalendar({ tasks }: { tasks: CalTask[] }) {
  const [mode, setMode] = useState<"month" | "week" | "day">("month");
  const [cursor, setCursor] = useState(() => new Date().toISOString().slice(0, 10));

  const byDay = useMemo(() => {
    const m = new Map<string, CalTask[]>();
    for (const t of tasks) {
      if (!t.dueDate) continue;
      const arr = m.get(t.dueDate) ?? [];
      arr.push(t);
      m.set(t.dueDate, arr);
    }
    return m;
  }, [tasks]);

  const monthCells = useMemo(() => {
    const cur = parseDay(cursor);
    const first = new Date(Date.UTC(cur.getUTCFullYear(), cur.getUTCMonth(), 1, 12));
    const startOffset = first.getUTCDay();
    const start = new Date(first);
    start.setUTCDate(start.getUTCDate() - startOffset);
    return Array.from({ length: 42 }, (_, i) => {
      const d = new Date(start);
      d.setUTCDate(d.getUTCDate() + i);
      return toDay(d);
    });
  }, [cursor]);

  const weekDays = useMemo(() => {
    const cur = parseDay(cursor);
    const start = new Date(cur);
    start.setUTCDate(start.getUTCDate() - start.getUTCDay());
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(start);
      d.setUTCDate(d.getUTCDate() + i);
      return toDay(d);
    });
  }, [cursor]);

  const title =
    mode === "month"
      ? parseDay(cursor).toLocaleDateString("en-US", { month: "long", year: "numeric", timeZone: "UTC" })
      : mode === "week"
        ? `Week of ${fmtDate(weekDays[0])}`
        : fmtDate(cursor);

  const nav = (n: number) => {
    if (mode === "month") {
      const d = parseDay(cursor);
      d.setUTCMonth(d.getUTCMonth() + n);
      setCursor(toDay(d));
    } else if (mode === "week") setCursor(addDaysStr(cursor, n * 7));
    else setCursor(addDaysStr(cursor, n));
  };

  const chip = (t: CalTask) => (
    <Link
      key={t.id}
      href={`/scheduled-tasks/${t.id}`}
      className={cx(
        "block truncate rounded-md border-l-[3px] px-1.5 py-0.5 text-[11px] font-medium hover:brightness-95",
        t.status === "Completed" ? "bg-emerald-50 text-emerald-800 line-through" : t.status === "Cancelled" ? "bg-zinc-100 text-zinc-500 line-through" : "bg-blue-50/70 text-slate-700"
      )}
      style={{ borderLeftColor: t.category?.color ?? "#2563eb" }}
      title={`${t.referenceNumber ?? ""} · ${t.title}`}
    >
      {t.title}
    </Link>
  );

  const todayStr = new Date().toISOString().slice(0, 10);

  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 px-4 py-3">
        <div className="flex items-center gap-1">
          <button onClick={() => nav(-1)} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100" aria-label="Previous"><ChevronLeft size={17} /></button>
          <button onClick={() => setCursor(new Date().toISOString().slice(0, 10))} className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100">Today</button>
          <button onClick={() => nav(1)} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100" aria-label="Next"><ChevronRight size={17} /></button>
        </div>
        <h3 className="text-sm font-bold text-slate-900">{title}</h3>
        <div className="ml-auto flex rounded-lg border border-slate-200 p-0.5">
          {(["month", "week", "day"] as const).map((m) => (
            <button key={m} onClick={() => setMode(m)} className={cx("rounded-md px-3 py-1 text-xs font-semibold capitalize", mode === m ? "bg-slate-900 text-white" : "text-slate-500 hover:text-slate-800")}>{m}</button>
          ))}
        </div>
      </div>

      {mode === "month" && (
        <div>
          <div className="task-cal-grid border-b border-slate-100 bg-slate-50/70">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
              <div key={d} className="px-2 py-1.5 text-center text-[11px] font-bold uppercase tracking-wide text-slate-500">{d}</div>
            ))}
          </div>
          <div className="task-cal-grid">
            {monthCells.map((day) => {
              const inMonth = day.slice(0, 7) === cursor.slice(0, 7);
              const list = (byDay.get(day) ?? []).slice(0, 4);
              const extra = (byDay.get(day) ?? []).length - list.length;
              return (
                <div key={day} className={cx("min-h-24 border-b border-r border-slate-100 p-1.5 align-top [&:nth-child(7n)]:border-r-0", !inMonth && "bg-slate-50/50")}>
                  <button onClick={() => { setCursor(day); setMode("day"); }} className={cx("mb-1 flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold", day === todayStr ? "bg-blue-600 text-white" : inMonth ? "text-slate-700 hover:bg-slate-100" : "text-slate-400")}>
                    {Number(day.slice(8, 10))}
                  </button>
                  <div className="space-y-1">{list.map(chip)}</div>
                  {extra > 0 && <p className="mt-0.5 px-1 text-[10px] font-semibold text-slate-400">+{extra} more</p>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {mode === "week" && (
        <div className="task-cal-grid">
          {weekDays.map((day) => (
            <div key={day} className="min-h-64 border-r border-slate-100 p-2 last:border-r-0">
              <p className={cx("mb-2 text-center text-xs font-bold", day === todayStr ? "text-blue-700" : "text-slate-500")}>
                {parseDay(day).toLocaleDateString("en-US", { weekday: "short", timeZone: "UTC" })} · {day.slice(8, 10)}
              </p>
              <div className="space-y-1.5">{(byDay.get(day) ?? []).map(chip)}</div>
              {(byDay.get(day) ?? []).length === 0 && <p className="text-center text-[11px] text-slate-300">—</p>}
            </div>
          ))}
        </div>
      )}

      {mode === "day" && (
        <div className="p-4">
          <div className="space-y-2">
            {(byDay.get(cursor) ?? []).length === 0 && <p className="py-8 text-center text-sm text-slate-400">No tasks due on {fmtDate(cursor)}.</p>}
            {(byDay.get(cursor) ?? []).map((t) => (
              <Link key={t.id} href={`/scheduled-tasks/${t.id}`} className="flex items-center gap-3 rounded-xl border border-slate-200 px-4 py-3 hover:border-blue-300 hover:bg-blue-50/40">
                <span className="h-9 w-1.5 rounded-full" style={{ backgroundColor: t.category?.color ?? "#2563eb" }} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold text-slate-900">{t.title}</span>
                  <span className="block text-xs text-slate-500">{t.referenceNumber} · {t.status} · {t.priority}</span>
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}
      <p className="border-t border-slate-100 bg-slate-50/60 px-4 py-2 text-[11px] text-slate-500">Calendar and list views read the same task data — rescheduling in either view updates both.</p>
    </div>
  );
}
