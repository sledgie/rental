"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  Plus, Search, SlidersHorizontal, ChevronLeft, ChevronRight,
  CheckCircle2, Clock, AlertTriangle, CalendarDays, Archive,
  LayoutList, Calendar as CalendarIcon, Repeat, Tags, Radio, Columns3, X,
} from "lucide-react";
import { apiFetch, useUser } from "../UserContext";
import { StatusBadge, PriorityBadge, Avatar, Empty } from "../ui";
import TaskDrawer, { type LookupData } from "./TaskDrawer";
import TaskCalendar from "./TaskCalendar";
import CategoryManager, { type Category } from "./CategoryManager";
import SeriesManager from "./SeriesManager";
import { can } from "@/lib/permissions";
import { fmtDate, cx } from "@/lib/format";

interface TaskRow {
  id: string;
  referenceNumber: string;
  title: string;
  description?: string;
  priority: string;
  status: string;
  dueDate: string | null;
  startDate: string | null;
  dueTime?: string | null;
  isRecurring?: boolean;
  recurrenceId?: string | null;
  category?: { id: string; name: string; color: string } | null;
  property?: { id: string; name: string } | null;
  unit?: { id: string; unitNumber: string } | null;
  tenant?: { fullName?: string } | null;
  assignee?: { id: string; name: string; avatarColor?: string } | null;
}

const QUICK = [
  { key: "my", label: "My Tasks" },
  { key: "all", label: "All Tasks" },
  { key: "overdue", label: "Overdue" },
  { key: "today", label: "Due Today" },
  { key: "upcoming", label: "Upcoming" },
  { key: "completed", label: "Completed" },
  { key: "recurring", label: "Recurring" },
];

const ALL_COLUMNS = [
  { key: "ref", label: "Ref" },
  { key: "category", label: "Category" },
  { key: "property", label: "Property" },
  { key: "unit", label: "Unit" },
  { key: "tenant", label: "Tenant" },
  { key: "assignee", label: "Assignee" },
  { key: "priority", label: "Priority" },
  { key: "status", label: "Status" },
  { key: "due", label: "Due date" },
];

export default function TaskWorkspace({ initialSearch = "", initialQuick = "" }: { initialSearch?: string; initialQuick?: string }) {
  const { user, users } = useUser();
  const [tab, setTab] = useState<"list" | "calendar" | "series" | "categories" | "events">("list");
  const [summary, setSummary] = useState({ totalOpen: 0, dueToday: 0, overdue: 0, upcoming: 0, completedThisMonth: 0, today: "" });
  const [items, setItems] = useState<TaskRow[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(12);
  const [pageCount, setPageCount] = useState(1);
  const [loading, setLoading] = useState(true);
  const [quick, setQuick] = useState(["my","all","overdue","today","upcoming","completed","recurring"].includes(initialQuick) ? initialQuick : "all");
  const [search, setSearch] = useState(initialSearch);
  const [debounced, setDebounced] = useState(initialSearch);
  const [filters, setFilters] = useState({ categoryId: "", priority: "", status: "", propertyId: "", assigneeId: "", dueFrom: "", dueTo: "" });
  const [showFilters, setShowFilters] = useState(false);
  const [sort, setSort] = useState("dueDate");
  const [dir, setDir] = useState("asc");
  const [cols, setCols] = useState<string[]>(["ref", "category", "property", "assignee", "priority", "status", "due"]);
  const [showCols, setShowCols] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [lookups, setLookups] = useState<LookupData | null>(null);
  const [events, setEvents] = useState<{ id: string; type: string; emittedAt: string; payload: Record<string, unknown> }[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editing, setEditing] = useState<Record<string, unknown> | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(search), 350);
    return () => clearTimeout(t);
  }, [search]);

  const loadMeta = useCallback(() => {
    apiFetch("/api/categories").then((r) => r.json()).then(setCategories).catch(() => {});
    apiFetch("/api/lookups").then((r) => r.json()).then(setLookups).catch(() => {});
    apiFetch("/api/events").then((r) => r.json()).then(setEvents).catch(() => {});
  }, []);

  useEffect(loadMeta, [loadMeta]);

  const load = useCallback(() => {
    setLoading(true);
    const effectivePageSize = tab === "calendar" ? 200 : pageSize;
    const p = new URLSearchParams({
      quick, search: debounced, sort, dir,
      page: String(tab === "calendar" ? 1 : page), pageSize: String(effectivePageSize),
      ...Object.fromEntries(Object.entries(filters).filter(([, v]) => v)),
    });
    Promise.all([
      apiFetch(`/api/tasks?${p}`).then((r) => r.json()),
      apiFetch("/api/tasks/summary").then((r) => r.json()),
    ])
      .then(([list, sum]) => {
        setItems(list.items ?? []);
        setTotal(list.total ?? 0);
        setPageCount(list.pageCount ?? 1);
        setSummary(sum);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [quick, debounced, sort, dir, page, pageSize, filters, tab]);

  useEffect(load, [load]);

  const visibleCols = useMemo(() => ALL_COLUMNS.filter((c) => cols.includes(c.key)), [cols]);

  function toggleSort(key: string) {
    if (sort === key) setDir(dir === "asc" ? "desc" : "asc");
    else { setSort(key); setDir("asc"); }
  }

  async function quickComplete(id: string) {
    const r = await apiFetch(`/api/tasks/${id}`, { method: "PATCH", body: JSON.stringify({ action: "complete" }) });
    if (!r.ok) {
      const j = await r.json();
      setToast(j.error ?? "Could not complete task");
    } else {
      setToast("Task completed — history recorded.");
      load();
    }
    setTimeout(() => setToast(null), 3000);
  }

  async function openEdit(id: string) {
    const t = await apiFetch(`/api/tasks/${id}`).then((r) => r.json());
    setEditing(t);
    setDrawerOpen(true);
  }

  const canCreate = user ? can(user.role, "task.create") : false;

  const cards = [
    { label: "Total Open", value: summary.totalOpen, icon: Archive, tint: "bg-blue-50 text-blue-700", sub: "Not completed / cancelled" },
    { label: "Due Today", value: summary.dueToday, icon: Clock, tint: "bg-amber-50 text-amber-700", sub: summary.today ? `Due ${summary.today}` : "" },
    { label: "Overdue", value: summary.overdue, icon: AlertTriangle, tint: "bg-red-50 text-red-700", sub: "Needs attention" },
    { label: "Upcoming", value: summary.upcoming, icon: CalendarDays, tint: "bg-violet-50 text-violet-700", sub: "After today" },
    { label: "Completed This Month", value: summary.completedThisMonth, icon: CheckCircle2, tint: "bg-emerald-50 text-emerald-700", sub: "Done this calendar month" },
  ];

  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  return (
    <div className="space-y-4">
      {/* header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 sm:text-2xl">Scheduled Tasks</h1>
          <p className="mt-0.5 max-w-2xl text-[13px] text-slate-500">
            Work assignments with due dates, recurrence and accountability — separate from <Link href="/workflow-automation" className="font-semibold text-blue-600 hover:underline">Workflow Automation</Link>, which handles event triggers and automated actions.
          </p>
        </div>
        <button
          onClick={() => { setEditing(null); setDrawerOpen(true); }}
          disabled={!canCreate}
          title={canCreate ? "Create task" : "Your role cannot create tasks"}
          className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-40"
        >
          <Plus size={17} /> Create Task
        </button>
      </div>

      {toast && <div className="rounded-lg border border-blue-200 bg-blue-50 px-4 py-2 text-sm text-blue-800">{toast}</div>}

      {/* summary cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
        {cards.map((c) => (
          <div key={c.label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-[0_1px_2px_rgba(16,24,40,0.05)]">
            <div className="flex items-center justify-between">
              <span className={`flex h-9 w-9 items-center justify-center rounded-lg ${c.tint}`}><c.icon size={18} /></span>
              <span className="text-2xl font-bold text-slate-900">{c.value}</span>
            </div>
            <p className="mt-2 text-[13px] font-semibold text-slate-800">{c.label}</p>
            <p className="text-[11px] text-slate-500">{c.sub}</p>
          </div>
        ))}
      </div>

      {/* tabs */}
      <div className="flex flex-wrap items-center gap-1 rounded-xl border border-slate-200 bg-white p-1.5">
        {(
          [
            ["list", "List", LayoutList],
            ["calendar", "Calendar", CalendarIcon],
            ["series", "Recurring Series", Repeat],
            ["categories", "Categories", Tags],
            ["events", "Domain Events", Radio],
          ] as const
        ).map(([k, label, Icon]) => (
          <button key={k} onClick={() => setTab(k)} className={cx("flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-[13px] font-semibold", tab === k ? "bg-slate-900 text-white" : "text-slate-500 hover:bg-slate-100 hover:text-slate-800")}>
            <Icon size={15} /> {label}
          </button>
        ))}
      </div>

      {tab === "series" && <SeriesManager />}
      {tab === "categories" && <CategoryManager categories={categories} onChanged={loadMeta} />}
      {tab === "events" && (
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-1">
            <h3 className="text-sm font-bold text-slate-900">Integration boundary</h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-500">
              Scheduled Tasks <strong>emits</strong> domain events and <strong>owns</strong> all task writes. Workflow Automation <strong>subscribes</strong> to these events and calls back through <code className="rounded bg-slate-100 px-1">POST /api/workflow/trigger</code> — the only documented write path. Reminder & escalation rules live in one place to avoid duplication.
            </p>
            <ul className="mt-3 space-y-1">
              {["TaskCreated", "TaskAssigned", "TaskDueDateChanged", "TaskOverdue", "TaskCompleted", "TaskCancelled"].map((e) => (
                <li key={e} className="flex items-center gap-2 rounded-lg bg-slate-50 px-2.5 py-1.5 text-xs font-mono text-slate-700"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />{e}</li>
              ))}
            </ul>
            <Link href="/workflow-automation" className="mt-3 inline-block rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50">Open Workflow Automation →</Link>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-2">
            <h3 className="text-sm font-bold text-slate-900">Recent domain events</h3>
            <ul className="mt-3 max-h-96 space-y-2 overflow-y-auto">
              {events.map((e) => (
                <li key={e.id} className="rounded-lg border border-slate-100 bg-slate-50/60 px-3 py-2">
                  <p className="text-xs font-bold text-slate-800">{e.type} <span className="ml-1 font-normal text-slate-400">{new Date(e.emittedAt).toLocaleString()}</span></p>
                  <p className="truncate font-mono text-[11px] text-slate-500">{JSON.stringify(e.payload)}</p>
                </li>
              ))}
              {events.length === 0 && <Empty title="No events yet" hint="Events are emitted as tasks are created, assigned, rescheduled, completed or cancelled." />}
            </ul>
          </div>
        </div>
      )}

      {(tab === "list" || tab === "calendar") && (
        <>
          {/* quick filters */}
          <div className="flex flex-wrap gap-1.5">
            {QUICK.map((f) => (
              <button key={f.key} onClick={() => { setQuick(f.key); setPage(1); }}
                className={cx("rounded-full border px-3.5 py-1.5 text-[13px] font-semibold transition", quick === f.key ? "border-slate-900 bg-slate-900 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:text-slate-900")}>
                {f.label}
                {f.key === "overdue" && summary.overdue > 0 && <span className="ml-1.5 rounded-full bg-red-500 px-1.5 py-0.5 text-[10px] font-bold text-white">{summary.overdue}</span>}
                {f.key === "today" && summary.dueToday > 0 && <span className="ml-1.5 rounded-full bg-amber-500 px-1.5 py-0.5 text-[10px] font-bold text-white">{summary.dueToday}</span>}
              </button>
            ))}
          </div>

          {/* search + filter bar */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-52 flex-1">
              <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Search title, description, property, unit, tenant, assignee, reference…"
                className="w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-8 text-sm outline-none placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100" />
              {search && <button onClick={() => setSearch("")} className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-slate-400 hover:bg-slate-100"><X size={14} /></button>}
            </div>
            <button onClick={() => setShowFilters(!showFilters)} className={cx("flex items-center gap-1.5 rounded-lg border px-3.5 py-2.5 text-sm font-semibold", showFilters || activeFilterCount ? "border-blue-300 bg-blue-50 text-blue-700" : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50")}>
              <SlidersHorizontal size={15} /> Filters {activeFilterCount > 0 && <span className="rounded-full bg-blue-600 px-1.5 text-[11px] font-bold text-white">{activeFilterCount}</span>}
            </button>
            {tab === "list" && (
              <div className="relative">
                <button onClick={() => setShowCols(!showCols)} className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-50">
                  <Columns3 size={15} /> Columns
                </button>
                {showCols && (
                  <div className="absolute right-0 top-full z-20 mt-2 w-52 rounded-xl border border-slate-200 bg-white p-3 shadow-xl">
                    {ALL_COLUMNS.map((c) => (
                      <label key={c.key} className="flex cursor-pointer items-center gap-2 rounded px-1 py-1.5 text-sm text-slate-700 hover:bg-slate-50">
                        <input type="checkbox" checked={cols.includes(c.key)} onChange={() => setCols(cols.includes(c.key) ? cols.filter((x) => x !== c.key) : [...cols, c.key])} />
                        {c.label}
                      </label>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {showFilters && (
            <div className="grid grid-cols-2 gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:grid-cols-4 lg:grid-cols-7">
              <label className="block text-xs font-semibold text-slate-600">Category
                <select value={filters.categoryId} onChange={(e) => { setFilters({ ...filters, categoryId: e.target.value }); setPage(1); }} className="mt-1 w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm">
                  <option value="">All</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </label>
              <label className="block text-xs font-semibold text-slate-600">Priority
                <select value={filters.priority} onChange={(e) => { setFilters({ ...filters, priority: e.target.value }); setPage(1); }} className="mt-1 w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm">
                  <option value="">All</option>{["Low", "Normal", "High", "Urgent"].map((p) => <option key={p}>{p}</option>)}
                </select>
              </label>
              <label className="block text-xs font-semibold text-slate-600">Status
                <select value={filters.status} onChange={(e) => { setFilters({ ...filters, status: e.target.value }); setPage(1); }} className="mt-1 w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm">
                  <option value="">All</option>{["Not Started", "In Progress", "Blocked", "Completed", "Cancelled"].map((s) => <option key={s}>{s}</option>)}
                </select>
              </label>
              <label className="block text-xs font-semibold text-slate-600">Property
                <select value={filters.propertyId} onChange={(e) => { setFilters({ ...filters, propertyId: e.target.value }); setPage(1); }} className="mt-1 w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm">
                  <option value="">All</option>{lookups?.properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </label>
              <label className="block text-xs font-semibold text-slate-600">Assignee
                <select value={filters.assigneeId} onChange={(e) => { setFilters({ ...filters, assigneeId: e.target.value }); setPage(1); }} className="mt-1 w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm">
                  <option value="">All</option>{users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
              </label>
              <label className="block text-xs font-semibold text-slate-600">Due from
                <input type="date" value={filters.dueFrom} onChange={(e) => { setFilters({ ...filters, dueFrom: e.target.value }); setPage(1); }} className="mt-1 w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm" />
              </label>
              <label className="block text-xs font-semibold text-slate-600">Due to
                <input type="date" value={filters.dueTo} onChange={(e) => { setFilters({ ...filters, dueTo: e.target.value }); setPage(1); }} className="mt-1 w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm" />
              </label>
              <div className="col-span-2 flex items-end sm:col-span-4 lg:col-span-7">
                <button onClick={() => { setFilters({ categoryId: "", priority: "", status: "", propertyId: "", assigneeId: "", dueFrom: "", dueTo: "" }); setSearch(""); setQuick("all"); setPage(1); }} className="text-xs font-semibold text-slate-500 hover:text-slate-800">Reset all filters</button>
                <span className="ml-auto text-xs text-slate-400">{total} result{total === 1 ? "" : "s"}</span>
              </div>
            </div>
          )}

          {tab === "calendar" && <TaskCalendar tasks={items.map((t) => ({ id: t.id, title: t.title, dueDate: t.dueDate, status: t.status, priority: t.priority, referenceNumber: t.referenceNumber, category: t.category }))} />}

          {tab === "list" && (
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[900px] text-left text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/80 text-[11px] uppercase tracking-wide text-slate-500">
                      <th className="px-4 py-3 font-bold">
                        <button onClick={() => toggleSort("title")} className="hover:text-slate-800">Task {sort === "title" ? (dir === "asc" ? "↑" : "↓") : ""}</button>
                      </th>
                      {visibleCols.map((c) => (
                        <th key={c.key} className="px-3 py-3 font-bold">
                          {c.key === "due" ? <button onClick={() => toggleSort("dueDate")} className="hover:text-slate-800">Due date {sort === "dueDate" ? (dir === "asc" ? "↑" : "↓") : ""}</button>
                          : c.key === "priority" ? <button onClick={() => toggleSort("priority")} className="hover:text-slate-800">Priority {sort === "priority" ? (dir === "asc" ? "↑" : "↓") : ""}</button>
                          : c.key === "status" ? <button onClick={() => toggleSort("status")} className="hover:text-slate-800">Status {sort === "status" ? (dir === "asc" ? "↑" : "↓") : ""}</button>
                          : c.label}
                        </th>
                      ))}
                      <th className="px-3 py-3 text-right font-bold">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {items.map((t) => {
                      const overdue = t.dueDate && t.dueDate < summary.today && !["Completed", "Cancelled"].includes(t.status);
                      return (
                        <tr key={t.id} className="transition hover:bg-blue-50/40">
                          <td className="max-w-72 px-4 py-3">
                            <Link href={`/scheduled-tasks/${t.id}`} className="block truncate font-semibold text-slate-900 hover:text-blue-700">
                              {t.isRecurring && <span className="mr-1 text-violet-500" title="Recurring">⟳</span>}{t.title}
                            </Link>
                            <p className="truncate text-[11px] text-slate-400">{t.referenceNumber}{overdue ? <span className="ml-1.5 font-bold text-red-600">OVERDUE</span> : ""}</p>
                          </td>
                          {cols.includes("ref") && <td className="px-3 py-3 font-mono text-xs text-slate-500">{t.referenceNumber}</td>}
                          {cols.includes("category") && (
                            <td className="px-3 py-3">
                              {t.category ? <span className="inline-flex items-center gap-1.5 whitespace-nowrap text-xs font-medium text-slate-700"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: t.category.color }} />{t.category.name}</span> : <span className="text-slate-300">—</span>}
                            </td>
                          )}
                          {cols.includes("property") && <td className="whitespace-nowrap px-3 py-3 text-xs text-slate-600">{t.property?.name ?? "—"}</td>}
                          {cols.includes("unit") && <td className="px-3 py-3 text-xs text-slate-600">{t.unit ? `Unit ${t.unit.unitNumber}` : "—"}</td>}
                          {cols.includes("tenant") && <td className="whitespace-nowrap px-3 py-3 text-xs text-slate-600">{t.tenant?.fullName ?? "—"}</td>}
                          {cols.includes("assignee") && (
                            <td className="px-3 py-3">
                              {t.assignee ? <span className="flex items-center gap-1.5 whitespace-nowrap text-xs text-slate-700"><Avatar name={t.assignee.name} color={t.assignee.avatarColor} size="sm" />{t.assignee.name.split(" ")[0]}</span> : <span className="text-slate-300">Unassigned</span>}
                            </td>
                          )}
                          {cols.includes("priority") && <td className="px-3 py-3"><PriorityBadge priority={t.priority} /></td>}
                          {cols.includes("status") && <td className="px-3 py-3"><StatusBadge status={t.status} /></td>}
                          {cols.includes("due") && (
                            <td className="whitespace-nowrap px-3 py-3 text-xs">
                              <span className={overdue ? "font-bold text-red-600" : "text-slate-700"}>{fmtDate(t.dueDate)}</span>
                              {t.dueTime ? <span className="text-slate-400"> · {t.dueTime}</span> : null}
                            </td>
                          )}
                          <td className="whitespace-nowrap px-3 py-3 text-right">
                            <div className="flex justify-end gap-1">
                              {!["Completed", "Cancelled"].includes(t.status) && (
                                <button onClick={() => quickComplete(t.id)} title="Complete" className="rounded-lg p-1.5 text-emerald-600 hover:bg-emerald-50"><CheckCircle2 size={16} /></button>
                              )}
                              <button onClick={() => openEdit(t.id)} title="Edit" className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100">✎</button>
                              <Link href={`/scheduled-tasks/${t.id}`} title="Open details" className="rounded-lg p-1.5 text-blue-600 hover:bg-blue-50">→</Link>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {loading && <p className="px-4 py-8 text-center text-sm text-slate-400">Loading tasks…</p>}
              {!loading && items.length === 0 && <div className="p-6"><Empty title="No tasks match these filters" hint="Try widening the date range, clearing search, or creating a new task." /></div>}
              <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-200 bg-slate-50/60 px-4 py-3">
                <p className="text-xs text-slate-500">Page {page} of {pageCount} · {total} tasks · sorted by {sort} ({dir})</p>
                <div className="flex gap-1">
                  <button disabled={page <= 1} onClick={() => setPage(page - 1)} className="rounded-lg border border-slate-200 bg-white p-1.5 text-slate-600 disabled:opacity-40"><ChevronLeft size={16} /></button>
                  {Array.from({ length: Math.min(5, pageCount) }, (_, i) => {
                    const p = Math.max(1, Math.min(pageCount - 4, page - 2)) + i;
                    if (p > pageCount) return null;
                    return <button key={p} onClick={() => setPage(p)} className={cx("rounded-lg px-3 py-1.5 text-xs font-bold", p === page ? "bg-slate-900 text-white" : "border border-slate-200 bg-white text-slate-600")}>{p}</button>;
                  })}
                  <button disabled={page >= pageCount} onClick={() => setPage(page + 1)} className="rounded-lg border border-slate-200 bg-white p-1.5 text-slate-600 disabled:opacity-40"><ChevronRight size={16} /></button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      <TaskDrawer
        open={drawerOpen}
        onClose={() => { setDrawerOpen(false); setEditing(null); }}
        onSaved={() => { load(); loadMeta(); }}
        editing={editing}
        categories={categories}
        users={users}
        lookups={lookups}
      />
    </div>
  );
}
