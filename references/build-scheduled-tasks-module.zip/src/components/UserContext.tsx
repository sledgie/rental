"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export interface AppUser {
  id: string;
  name: string;
  email: string;
  role: string;
  avatarColor?: string | null;
}

const Ctx = createContext<{
  user: AppUser | null;
  users: AppUser[];
  setUserId: (id: string) => void;
  refresh: () => void;
}>({ user: null, users: [], setUserId: () => {}, refresh: () => {} });

export function useUser() {
  return useContext(Ctx);
}

export function apiFetch(path: string, init?: RequestInit, userId?: string) {
  const headers: Record<string, string> = { "Content-Type": "application/json", ...(init?.headers as Record<string, string> ?? {}) };
  const stored = typeof window !== "undefined" ? localStorage.getItem("rtm-user-id") : null;
  if (userId ?? stored) headers["x-user-id"] = (userId ?? stored) as string;
  return fetch(path, { ...init, headers });
}

export function UserProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<AppUser[]>([]);
  const [userId, setUserIdState] = useState<string | null>(null);

  const refresh = () => {
    fetch("/api/users")
      .then((r) => r.json())
      .then((rows: AppUser[]) => {
        setUsers(rows);
        const stored = localStorage.getItem("rtm-user-id");
        if (stored && rows.some((u) => u.id === stored)) {
          setUserIdState(stored);
        } else if (rows.length) {
          const admin = rows.find((u) => u.role === "administrator") ?? rows[0];
          setUserIdState(admin.id);
          localStorage.setItem("rtm-user-id", admin.id);
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    const stored = localStorage.getItem("rtm-user-id");
    if (stored) setUserIdState(stored);
    refresh();
  }, []);

  const setUserId = (id: string) => {
    setUserIdState(id);
    localStorage.setItem("rtm-user-id", id);
  };

  const user = users.find((u) => u.id === userId) ?? null;
  return <Ctx.Provider value={{ user, users, setUserId, refresh }}>{children}</Ctx.Provider>;
}
