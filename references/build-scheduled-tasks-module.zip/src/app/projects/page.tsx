"use client";
import EntityPage from "@/components/EntityPage";
export default function ProjectsPage() {
  return <EntityPage title="Projects" blurb="Capital projects. Project Milestone tasks link here for sign-offs and phase tracking." collection="projects" columns={[
    { key: "name", label: "Project" },
    { key: "status", label: "Status" },
    { key: "dueDate", label: "Due" },
    { key: "progress", label: "Progress", render: (r) => `${r.progress}%` },
  ]} />;
}
