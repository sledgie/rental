"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Zap, Plus, Play, Pause, Trash2, ArrowRight } from "lucide-react";
import { apiFetch, useUser } from "@/components/UserContext";
import { inputCls, Field, Empty } from "@/components/ui";
import { WORKFLOW_TASK_TRIGGERS } from "@/lib/task-events";
import { cx } from "@/lib/format";

interface Automation {
  id: string;
  name: string;
  description: string;
  triggerEvent: string;
  conditions: Record<string, unknown>;
  actions: Record<string, unknown>;
  isActive: boolean;
  runCount: number;
  lastRunAt: string | null;
}

export default function WorkflowPage() {
  const { user } = useUser();
  const [autos, setAutos] = useState<Automation[]>([]);
  const [runs, setRuns] = useState<{ id: string; triggerEvent: string; status: string; detail: string; executedAt: string; automationName: string }[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", triggerEvent: "TaskOverdue", createTitle: "", categorySlug: "repairs-follow-up", dueInDays: "2" });
  const [simEvent, setSimEvent] = useState("maintenance.approved");
  const [simTitle, setSimTitle] = useState("Follow-up: verify vendor completion");
  const [msg, setMsg] = useState<string | null>(null);

  const load = () => {
    apiFetch("/api/workflow/automations").then((r) => r.json()).then(setAutos).catch(() => {});
    apiFetch("/api/workflow/runs").then((r) => r.json()).then(setRuns).catch(() => {});
  };
  useEffect(load, []);

  const canManage = user?.role === "administrator" || user?.role === "property_manager";

  async function create() {
    if (!form.name.trim()) return setMsg("Name is required");
    const r = await apiFetch("/api/workflow/automations", {
      method: "POST",
      body: JSON.stringify({
        name: form.name, description: form.description, triggerEvent: form.triggerEvent,
        conditions: {}, actions: form.createTitle ? { createTask: { title: form.createTitle, category: form.categorySlug, dueInDays: Number(form.dueInDays) } } : { notify: ["property_manager"] },
      }),
    });
    if (!r.ok) return setMsg((await r.json()).error ?? "Create failed");
    setShowForm(false);
    setForm({ name: "", description: "", triggerEvent: "TaskOverdue", createTitle: "", categorySlug: "repairs-follow-up", dueInDays: "2" });
    setMsg("Automation created. It subscribes to Scheduled Tasks events — it never writes task tables directly.");
    load();
  }

  async function toggle(a: Automation) {
    await apiFetch(`/api/workflow/automations/${a.id}`, { method: "PATCH", body: JSON.stringify({ isActive: !a.isActive }) });
    load();
  }

  async function remove(id: string) {
    if (!confirm("Delete this automation?")) return;
    const r = await apiFetch(`/api/workflow/automations/${id}`, { method: "DELETE" });
    if (!r.ok) return setMsg((await r.json()).error ?? "Delete failed");
    load();
  }

  async function simulate() {
    setMsg(null);
    const r = await apiFetch("/api/workflow/trigger", {
      method: "POST",
      body: JSON.stringify({
        event: simEvent,
        task: { title: simTitle, description: `Simulated from Workflow Automation (${simEvent})`, categorySlug: "repairs-follow-up", priority: "High", dueDate: new Date(Date.now() + 2 * 864e5).toISOString().slice(0, 10) },
      }),
    });
    const j = await r.json();
    if (!r.ok) return setMsg(j.error ?? "Trigger failed");
    setMsg(`Automation boundary exercised: task ${j.task.referenceNumber} created via POST /api/workflow/trigger — ${j.automationsMatched} automation(s) matched. See it in Scheduled Tasks.`);
    load();
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-xl font-bold text-slate-900 sm:text-2xl"><Zap size={22} className="text-amber-500" /> Workflow Automation</h1>
          <p className="mt-0.5 max-w-2xl text-[13px] text-slate-500">Event triggers, conditions and automated system actions. Preserved as its own module — it creates or updates <Link href="/scheduled-tasks" className="font-semibold text-blue-600 hover:underline">Scheduled Tasks</Link> only through the documented service boundary.</p>
        </div>
        {canManage && <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-slate-700"><Plus size={16} /> New Automation</button>}
      </div>

      {msg && <div className="rounded-lg border border-blue-200 bg-blue-50 px-4 py-2 text-sm text-blue-800">{msg}</div>}

      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <h2 className="text-sm font-bold text-slate-900">Supported task triggers</h2>
        <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {WORKFLOW_TASK_TRIGGERS.map((t) => (
            <div key={t.event} className="rounded-lg bg-slate-50 px-3 py-2">
              <p className="font-mono text-xs font-bold text-slate-800">{t.event}</p>
              <p className="text-[11px] text-slate-500">{t.label}</p>
            </div>
          ))}
        </div>
      </div>

      {showForm && (
        <div className="grid gap-4 rounded-xl border border-slate-200 bg-white p-5 sm:grid-cols-2">
          <Field label="Automation name"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Escalate overdue inspections" /></Field>
          <Field label="Trigger event">
            <select className={inputCls} value={form.triggerEvent} onChange={(e) => setForm({ ...form, triggerEvent: e.target.value })}>
              <option>TaskOverdue</option><option>TaskCreated</option><option>TaskAssigned</option><option>TaskCompleted</option><option>TaskCancelled</option>
              <option>maintenance.approved</option><option>lease.expiring</option>
            </select>
          </Field>
          <div className="sm:col-span-2"><Field label="Description"><input className={inputCls} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What does this automation do?" /></Field></div>
          <Field label="Auto-create task title (optional)"><input className={inputCls} value={form.createTitle} onChange={(e) => setForm({ ...form, createTitle: e.target.value })} placeholder="Leave blank for notify-only" /></Field>
          <Field label="Due in (days)"><input type="number" className={inputCls} value={form.dueInDays} onChange={(e) => setForm({ ...form, dueInDays: e.target.value })} /></Field>
          <div className="sm:col-span-2 flex gap-2">
            <button onClick={create} className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Save automation</button>
            <button onClick={() => setShowForm(false)} className="rounded-lg border px-4 py-2 text-sm">Cancel</button>
          </div>
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="space-y-3">
          <h2 className="text-sm font-bold text-slate-900">Automations ({autos.length})</h2>
          {autos.map((a) => (
            <div key={a.id} className="rounded-xl border border-slate-200 bg-white p-4">
              <div className="flex items-start gap-2">
                <span className={cx("mt-0.5 h-2.5 w-2.5 rounded-full", a.isActive ? "bg-emerald-500" : "bg-slate-300")} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold text-slate-900">{a.name}</p>
                  <p className="text-xs text-slate-500">{a.description || "—"}</p>
                  <p className="mt-1 font-mono text-[11px] text-slate-400">on {a.triggerEvent} · {a.runCount} runs · last {a.lastRunAt ? new Date(a.lastRunAt).toLocaleDateString() : "never"}</p>
                </div>
                {canManage && (
                  <div className="flex gap-1">
                    <button onClick={() => toggle(a)} title={a.isActive ? "Pause" : "Activate"} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100">{a.isActive ? <Pause size={15} /> : <Play size={15} />}</button>
                    <button onClick={() => remove(a.id)} title="Delete" className="rounded-lg p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600"><Trash2 size={15} /></button>
                  </div>
                )}
              </div>
            </div>
          ))}
          {autos.length === 0 && <Empty title="No automations" />}
        </div>

        <div className="space-y-3">
          <div className="rounded-xl border border-dashed border-blue-300 bg-blue-50/50 p-4">
            <h2 className="text-sm font-bold text-slate-900">Simulate trigger → creates a real task</h2>
            <p className="text-xs text-slate-500">Exercises the documented write path (<code className="font-mono">POST /api/workflow/trigger</code>).</p>
            <div className="mt-2 grid gap-2 sm:grid-cols-2">
              <select value={simEvent} onChange={(e) => setSimEvent(e.target.value)} className={inputCls}>
                <option value="maintenance.approved">maintenance.approved</option>
                <option value="lease.expiring">lease.expiring</option>
                <option value="TaskOverdue">TaskOverdue</option>
              </select>
              <input value={simTitle} onChange={(e) => setSimTitle(e.target.value)} className={inputCls} />
            </div>
            <button onClick={simulate} className="mt-2 flex items-center gap-1 rounded-lg bg-blue-600 px-3 py-2 text-xs font-semibold text-white hover:bg-blue-700">Fire trigger <ArrowRight size={13} /></button>
          </div>
          <h2 className="text-sm font-bold text-slate-900">Recent runs</h2>
          <ul className="space-y-2">
            {runs.slice(0, 12).map((r) => (
              <li key={r.id} className="rounded-xl border border-slate-200 bg-white px-3 py-2">
                <p className="text-xs font-bold text-slate-800">{r.automationName} <span className="ml-1 rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] text-emerald-700">{r.status}</span></p>
                <p className="text-[11px] text-slate-500">{r.detail} · {new Date(r.executedAt).toLocaleString()}</p>
              </li>
            ))}
            {runs.length === 0 && <Empty title="No runs yet" />}
          </ul>
        </div>
      </div>
    </div>
  );
}
