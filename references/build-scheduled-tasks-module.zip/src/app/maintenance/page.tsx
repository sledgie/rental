"use client";
import EntityPage from "@/components/EntityPage";
export default function MaintenancePage() {
  return <EntityPage title="Maintenance Requests" blurb="Work orders from tenants. Approvals can trigger follow-up tasks via Workflow Automation." collection="maintenanceRequests" columns={[
    { key: "referenceNumber", label: "Ref" },
    { key: "title", label: "Title" },
    { key: "status", label: "Status" },
    { key: "priority", label: "Priority" },
  ]} />;
}
