"use client";

import { useEffect, useState } from "react";
import { ShieldCheck, RefreshCw } from "lucide-react";
import { apiFetch } from "@/components/UserContext";
import { PERMISSION_DESCRIPTIONS, type PermissionKey, type Role } from "@/lib/permissions";

const ROLES: Role[] = ["administrator", "property_manager", "landlord", "maintenance_staff", "accountant"];

// Mirror of server MATRIX for display (server is source of truth; this duplicates labels only)
const DISPLAY: Record<Role, Record<PermissionKey, boolean>> = {
  administrator: { "task.viewAll": true, "task.viewAssigned": true, "task.create": true, "task.assign": true, "task.edit": true, "task.reschedule": true, "task.complete": true, "task.cancel": true, "task.manageRecurrence": true, "task.viewHistory": true, "task.viewAttachments": true, "task.manageCategories": true },
  property_manager: { "task.viewAll": true, "task.viewAssigned": true, "task.create": true, "task.assign": true, "task.edit": true, "task.reschedule": true, "task.complete": true, "task.cancel": true, "task.manageRecurrence": true, "task.viewHistory": true, "task.viewAttachments": true, "task.manageCategories": true },
  landlord: { "task.viewAll": true, "task.viewAssigned": true, "task.create": true, "task.assign": false, "task.edit": true, "task.reschedule": false, "task.complete": true, "task.cancel": false, "task.manageRecurrence": false, "task.viewHistory": true, "task.viewAttachments": true, "task.manageCategories": false },
  maintenance_staff: { "task.viewAll": false, "task.viewAssigned": true, "task.create": true, "task.assign": false, "task.edit": true, "task.reschedule": false, "task.complete": true, "task.cancel": false, "task.manageRecurrence": false, "task.viewHistory": true, "task.viewAttachments": true, "task.manageCategories": false },
  accountant: { "task.viewAll": true, "task.viewAssigned": true, "task.create": true, "task.assign": false, "task.edit": true, "task.reschedule": false, "task.complete": false, "task.cancel": false, "task.manageRecurrence": false, "task.viewHistory": true, "task.viewAttachments": true, "task.manageCategories": false },
};

export default function SettingsPage() {
  const [msg, setMsg] = useState<string | null>(null);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold text-slate-900 sm:text-2xl">Settings & Administration</h1>
        <p className="mt-0.5 text-[13px] text-slate-500">Role-based permissions are enforced in backend operations — UI controls reflect the same rules but never replace them.</p>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <h2 className="flex items-center gap-1.5 text-sm font-bold text-slate-900"><ShieldCheck size={16} className="text-blue-600" /> Scheduled Tasks permission matrix</h2>
        <p className="mt-1 text-xs text-slate-500">Switch roles from the top-right avatar menu to verify enforcement. Maintenance staff, for example, only see assigned tasks and cannot assign to others or cancel series.</p>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] uppercase tracking-wide text-slate-500">
                <th className="px-3 py-2">Permission</th>
                {ROLES.map((r) => <th key={r} className="px-3 py-2 text-center">{r.replace(/_/g, " ")}</th>)}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {PERMISSION_DESCRIPTIONS.map((p) => (
                <tr key={p.key}>
                  <td className="px-3 py-2 font-medium text-slate-700">{p.label}</td>
                  {ROLES.map((r) => (
                    <td key={r} className="px-3 py-2 text-center">
                      {DISPLAY[r][p.key] ? <span className="text-emerald-600">●</span> : <span className="text-slate-300">○</span>}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <h2 className="flex items-center gap-1.5 text-sm font-bold text-slate-900"><RefreshCw size={15} /> Background processing</h2>
        <p className="mt-1 text-xs leading-relaxed text-slate-500">
          Due-date checks and recurrence generation run through <code className="rounded bg-slate-100 px-1 font-mono">POST /api/cron/process</code> (overdue detection → TaskOverdue events; series generation → idempotent per series + date, unique per occurrence). Timezone handling is explicit — every task and series stores its IANA timezone (default America/New_York) and recurrence math anchors at noon to stay consistent across daylight-saving changes. In production, wire this endpoint to a scheduler (cron / pg-boss / Inngest).
        </p>
        <button onClick={() => apiFetch("/api/cron/process", { method: "POST" }).then((r) => r.json()).then((j) => setMsg(`Processor ran: ${j.overdueFlagged} overdue flagged, ${j.occurrencesCreated} occurrence(s) created across ${j.seriesProcessed} series.`))} className="mt-2 rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-700">Run processor now</button>
        {msg && <p className="mt-2 rounded-lg bg-emerald-50 px-3 py-1.5 text-xs text-emerald-800">{msg}</p>}
      </div>

      <BackendStatus />
    </div>
  );
}

function BackendStatus() {
  const [health, setHealth] = useState<string>("checking…");
  useEffect(() => {
    fetch("/api/health").then((r) => r.json()).then((j) => setHealth(j.ok ? "Connected — PostgreSQL via Drizzle ORM. All persistence is real; nothing is mocked." : "Unhealthy")).catch(() => setHealth("Unreachable"));
  }, []);
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5">
      <h2 className="text-sm font-bold text-slate-900">Backend status</h2>
      <p className="mt-1 text-xs text-slate-500">{health}</p>
      <p className="mt-2 text-[11px] leading-relaxed text-slate-400">Nothing in this module is stubbed: tasks, recurrences, checklist, comments, attachments (metadata), reminders, activity, automations, runs and domain events all persist to PostgreSQL. Attachment binaries are metadata-only by design (use S3 / Uploadthing for blobs in production).</p>
    </div>
  );
}
