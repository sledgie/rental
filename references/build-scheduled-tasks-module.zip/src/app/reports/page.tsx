"use client";
import EntityPage from "@/components/EntityPage";
export default function ReportsPage() {
  return <EntityPage title="Vendors & Documents" blurb="Vendor directory. Vendor Appointment tasks link to these vendors." collection="vendors" columns={[
    { key: "name", label: "Vendor" },
    { key: "trade", label: "Trade" },
    { key: "email", label: "Email" },
    { key: "rating", label: "Rating", render: (r) => `★ ${r.rating}` },
  ]} />;
}
