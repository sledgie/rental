"use client";
import EntityPage from "@/components/EntityPage";
export default function FinancialsPage() {
  return <EntityPage title="Financials" blurb="Leases with rent schedules. Financial Review tasks reference these records." collection="leases" columns={[
    { key: "id", label: "Lease", render: (r) => String(r.id).slice(0, 8) + "…" },
    { key: "rent", label: "Rent", render: (r) => `$${r.rent}` },
    { key: "startDate", label: "Start" },
    { key: "endDate", label: "End" },
    { key: "status", label: "Status" },
  ]} />;
}
