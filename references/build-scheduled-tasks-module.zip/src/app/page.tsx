"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { CalendarClock, AlertTriangle, Building2, Users, Wrench, ArrowRight, Zap } from "lucide-react";
import { apiFetch } from "@/components/UserContext";

export default function DashboardPage() {
  const [summary, setSummary] = useState({ totalOpen: 0, dueToday: 0, overdue: 0, upcoming: 0, completedThisMonth: 0 });
  const [lookups, setLookups] = useState<{ properties: unknown[]; tenants: unknown[]; maintenanceRequests: unknown[] } | null>(null);

  useEffect(() => {
    apiFetch("/api/tasks/summary").then((r) => r.json()).then(setSummary).catch(() => {});
    apiFetch("/api/lookups").then((r) => r.json()).then(setLookups).catch(() => {});
  }, []);

  const tiles = [
    { label: "Open tasks", value: summary.totalOpen, href: "/scheduled-tasks", icon: CalendarClock, color: "bg-blue-600" },
    { label: "Overdue", value: summary.overdue, href: "/scheduled-tasks?quick=overdue", icon: AlertTriangle, color: "bg-red-500" },
    { label: "Properties", value: (lookups?.properties as unknown[] ?? []).length, href: "/properties", icon: Building2, color: "bg-emerald-600" },
    { label: "Tenants", value: (lookups?.tenants as unknown[] ?? []).length, href: "/tenants", icon: Users, color: "bg-violet-600" },
    { label: "Maintenance", value: (lookups?.maintenanceRequests as unknown[] ?? []).length, href: "/maintenance", icon: Wrench, color: "bg-amber-500" },
  ];

  return (
    <div className="space-y-5">
      <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-[#0f1e33] via-[#16305a] to-[#1d4ed8] p-6 text-white sm:p-8">
        <p className="text-xs font-bold uppercase tracking-[0.16em] text-blue-200">RentOps · Rental Property Management</p>
        <h1 className="mt-2 max-w-xl text-2xl font-bold leading-tight sm:text-3xl">Operations at a glance — tasks, properties and automations in one place.</h1>
        <div className="mt-4 flex flex-wrap gap-2">
          <Link href="/scheduled-tasks" className="flex items-center gap-1.5 rounded-lg bg-white px-4 py-2.5 text-sm font-bold text-slate-900 hover:bg-blue-50"><CalendarClock size={16} /> Open Scheduled Tasks <ArrowRight size={15} /></Link>
          <Link href="/workflow-automation" className="flex items-center gap-1.5 rounded-lg bg-white/10 px-4 py-2.5 text-sm font-semibold text-white ring-1 ring-white/25 hover:bg-white/20"><Zap size={16} /> Workflow Automation</Link>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {tiles.map((t) => (
          <Link key={t.label} href={t.href} className="rounded-xl border border-slate-200 bg-white p-4 transition hover:border-blue-300 hover:shadow-sm">
            <span className={`flex h-9 w-9 items-center justify-center rounded-lg text-white ${t.color}`}><t.icon size={18} /></span>
            <p className="mt-2 text-2xl font-bold text-slate-900">{t.value}</p>
            <p className="text-[13px] font-medium text-slate-500">{t.label}</p>
          </Link>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-bold text-slate-900">Scheduled Tasks module</h2>
          <p className="mt-1 text-[13px] text-slate-500">Due Today <strong className="text-slate-800">{summary.dueToday}</strong> · Upcoming <strong className="text-slate-800">{summary.upcoming}</strong> · Completed this month <strong className="text-slate-800">{summary.completedThisMonth}</strong></p>
          <ul className="mt-3 space-y-1.5 text-[13px] text-slate-600">
            {["List with sorting, pagination & configurable columns", "Month / week / day calendar on the same data", "Recurring series with independently trackable occurrences", "Checklist, comments, attachments, reminders & audit timeline", "Role-based permissions enforced in every API route"].map((x) => (
              <li key={x} className="flex gap-2"><span className="text-emerald-500">✓</span>{x}</li>
            ))}
          </ul>
          <Link href="/scheduled-tasks" className="mt-3 inline-flex items-center gap-1 text-sm font-bold text-blue-600 hover:underline">Go to workspace <ArrowRight size={14} /></Link>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-bold text-slate-900">How the two modules differ</h2>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <div className="rounded-lg bg-blue-50/70 p-3">
              <p className="text-xs font-bold text-blue-800">SCHEDULED TASKS</p>
              <p className="mt-1 text-xs text-slate-600">Owns work assignments, due dates, recurrence, completion and accountability. Emits TaskCreated, TaskAssigned, TaskOverdue, TaskCompleted…</p>
            </div>
            <div className="rounded-lg bg-amber-50/70 p-3">
              <p className="text-xs font-bold text-amber-800">WORKFLOW AUTOMATION</p>
              <p className="mt-1 text-xs text-slate-600">Owns event triggers, conditions and automated actions. Subscribes to task events; writes tasks only via POST /api/workflow/trigger.</p>
            </div>
          </div>
          <Link href="/settings" className="mt-3 inline-flex items-center gap-1 text-sm font-bold text-blue-600 hover:underline">Permissions & ownership <ArrowRight size={14} /></Link>
        </div>
      </div>
    </div>
  );
}
