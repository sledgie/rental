"use client";
import EntityPage from "@/components/EntityPage";
export default function TenantsPage() {
  return <EntityPage title="Tenants & Leases" blurb="Tenants and their leases. Tasks can reference a tenant and lease for renewal and follow-up work." collection="tenants" columns={[
    { key: "name", label: "Tenant", render: (r) => `${r.firstName} ${r.lastName}` },
    { key: "email", label: "Email" },
    { key: "phone", label: "Phone" },
    { key: "status", label: "Status" },
    { key: "leaseEnd", label: "Lease ends" },
  ]} />;
}
