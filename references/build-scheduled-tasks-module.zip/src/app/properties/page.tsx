"use client";
import EntityPage from "@/components/EntityPage";
export default function PropertiesPage() {
  return <EntityPage title="Properties" blurb="Portfolio properties. Scheduled Tasks links to these records instead of duplicating them." collection="properties" columns={[
    { key: "name", label: "Property" },
    { key: "address", label: "Address" },
    { key: "city", label: "City" },
    { key: "state", label: "State" },
    { key: "type", label: "Type" },
    { key: "status", label: "Status" },
  ]} />;
}
