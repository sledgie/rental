import { db } from "@/db";
import { tasks } from "@/db/schema";
import { and, eq, gte, lte, sql, or } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { can } from "@/lib/permissions";

export const dynamic = "force-dynamic";

function todayStr(): string {
  try {
    return new Intl.DateTimeFormat("en-CA", { timeZone: "America/New_York", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

export async function GET() {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  const today = todayStr();
  const monthStart = today.slice(0, 7) + "-01";
  const scope = !can(me.role, "task.viewAll")
    ? or(eq(tasks.assigneeId, me.id), eq(tasks.createdById, me.id))
    : undefined;
  const open = and(sql`${tasks.status} not in ('Completed','Cancelled')`, scope);
  const count = async (extra?: ReturnType<typeof eq>) => {
    const rows = await db
      .select({ c: sql<number>`count(*)` })
      .from(tasks)
      .where(extra ? and(open, extra) : open);
    return Number(rows[0]?.c ?? 0);
  };
  const completedRows = await db
    .select({ c: sql<number>`count(*)` })
    .from(tasks)
    .where(and(eq(tasks.status, "Completed"), gte(tasks.completedAt, new Date(`${monthStart}T00:00:00Z`)), scope));
  const [totalOpen, dueToday, overdue, upcoming] = await Promise.all([
    count(),
    count(eq(tasks.dueDate, today)),
    count(lte(tasks.dueDate, todayMinus(today, 1))),
    count(gte(tasks.dueDate, todayPlus(today, 1))),
  ]);
  return json({
    totalOpen,
    dueToday,
    overdue,
    upcoming,
    completedThisMonth: Number(completedRows[0]?.c ?? 0),
    today,
  });
}

function todayMinus(today: string, n: number): string {
  const d = new Date(`${today}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() - n);
  return d.toISOString().slice(0, 10);
}
function todayPlus(today: string, n: number): string {
  const d = new Date(`${today}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
