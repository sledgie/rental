import { db } from "@/db";
import {
  tasks,
  taskCategories,
  properties,
  units,
  tenants,
  leases,
  vendors,
  maintenanceRequests,
  projects,
  users,
  taskRecurrences,
} from "@/db/schema";
import { eq, and, gte } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { can } from "@/lib/permissions";
import { logActivity, emitEvent } from "@/lib/task-service";

export const dynamic = "force-dynamic";

async function loadTask(id: string) {
  const rows = await db
    .select({
      task: tasks,
      category: taskCategories,
      property: properties,
      unit: units,
      tenant: tenants,
      lease: leases,
      vendor: vendors,
      maint: maintenanceRequests,
      project: projects,
      assignee: users,
      recurrence: taskRecurrences,
    })
    .from(tasks)
    .leftJoin(taskCategories, eq(tasks.categoryId, taskCategories.id))
    .leftJoin(properties, eq(tasks.propertyId, properties.id))
    .leftJoin(units, eq(tasks.unitId, units.id))
    .leftJoin(tenants, eq(tasks.tenantId, tenants.id))
    .leftJoin(leases, eq(tasks.leaseId, leases.id))
    .leftJoin(vendors, eq(tasks.vendorId, vendors.id))
    .leftJoin(maintenanceRequests, eq(tasks.maintenanceRequestId, maintenanceRequests.id))
    .leftJoin(projects, eq(tasks.projectId, projects.id))
    .leftJoin(users, eq(tasks.assigneeId, users.id))
    .leftJoin(taskRecurrences, eq(tasks.recurrenceId, taskRecurrences.id))
    .where(eq(tasks.id, id))
    .limit(1);
  return rows[0] ?? null;
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  const { id } = await params;
  const row = await loadTask(id);
  if (!row) return err("Task not found", 404);
  if (!can(me.role, "task.viewAll")) {
    const t = row.task;
    const collabs = (t.collaboratorIds as string[] | null) ?? [];
    if (t.assigneeId !== me.id && t.createdById !== me.id && !collabs.includes(me.id))
      return err("Permission denied: you can only view assigned tasks", 403);
  }
  return json({
    ...row.task,
    category: row.category,
    property: row.property,
    unit: row.unit,
    tenant: row.tenant ? { ...row.tenant, fullName: `${row.tenant.firstName} ${row.tenant.lastName}` } : null,
    lease: row.lease,
    vendor: row.vendor,
    maintenanceRequest: row.maint,
    project: row.project,
    assignee: row.assignee,
    recurrence: row.recurrence,
  });
}

const EDITABLE = [
  "title", "description", "categoryId", "priority", "propertyId", "unitId", "tenantId",
  "leaseId", "maintenanceRequestId", "vendorId", "projectId", "assigneeId", "collaboratorIds",
  "startDate", "dueDate", "dueTime", "timezone", "completionNotes",
] as const;

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  const { id } = await params;
  const body = await req.json();
  const action: string | undefined = body.action; // complete|cancel|reopen|edit|reschedule|reassign|recurrence-scope ops
  const editScope: "single" | "future" | "all" | undefined = body.editScope;

  const rows = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
  if (!rows[0]) return err("Task not found", 404);
  const task = rows[0];

  const isTerminal = task.status === "Completed" || task.status === "Cancelled";

  // ---- Complete ----
  if (action === "complete") {
    if (!can(me.role, "task.complete")) return err("Permission denied: cannot complete tasks", 403);
    if (task.status === "Completed") return err("Task is already completed", 400);
    const updated = await db
      .update(tasks)
      .set({
        status: "Completed",
        completionNotes: body.completionNotes ?? task.completionNotes,
        completedAt: new Date(),
        completedById: me.id,
        updatedById: me.id,
        updatedAt: new Date(),
      })
      .where(eq(tasks.id, id))
      .returning();
    await logActivity({ taskId: id, recurrenceId: task.recurrenceId, actorId: me.id, action: "completed", summary: `Task completed by ${me.name}`, newValue: "Completed", priorValue: task.status });
    await emitEvent("TaskCompleted", updated[0] as unknown as Record<string, unknown>);
    return json(updated[0]);
  }

  // ---- Cancel ----
  if (action === "cancel") {
    if (!can(me.role, "task.cancel")) return err("Permission denied: cannot cancel tasks", 403);
    if (task.status === "Cancelled") return err("Task is already cancelled", 400);
    const updated = await db
      .update(tasks)
      .set({ status: "Cancelled", cancelReason: body.reason ?? "", cancelledAt: new Date(), updatedById: me.id, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    await logActivity({ taskId: id, recurrenceId: task.recurrenceId, actorId: me.id, action: "cancelled", summary: `Task cancelled by ${me.name}${body.reason ? `: ${body.reason}` : ""}`, priorValue: task.status, newValue: "Cancelled" });
    await emitEvent("TaskCancelled", updated[0] as unknown as Record<string, unknown>, { reason: body.reason ?? "" });
    return json(updated[0]);
  }

  // ---- Reopen ----
  if (action === "reopen") {
    if (!can(me.role, "task.edit")) return err("Permission denied", 403);
    const updated = await db
      .update(tasks)
      .set({ status: "Not Started", completedAt: null, cancelledAt: null, updatedById: me.id, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    await logActivity({ taskId: id, recurrenceId: task.recurrenceId, actorId: me.id, action: "status_changed", summary: `Task reopened by ${me.name}`, priorValue: task.status, newValue: "Not Started" });
    return json(updated[0]);
  }

  // ---- Status change ----
  if (action === "status" && body.status) {
    if (!can(me.role, "task.edit")) return err("Permission denied", 403);
    if (["Completed", "Cancelled"].includes(body.status)) return err("Use complete/cancel actions for terminal states", 400);
    const updated = await db
      .update(tasks)
      .set({ status: body.status, updatedById: me.id, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    await logActivity({ taskId: id, recurrenceId: task.recurrenceId, actorId: me.id, action: "status_changed", summary: `Status changed from ${task.status} → ${body.status}`, priorValue: task.status, newValue: body.status });
    await emitEvent("TaskStatusChanged", updated[0] as unknown as Record<string, unknown>, { from: task.status, to: body.status });
    return json(updated[0]);
  }

  // ---- Generic edit (with recurrence scope) ----
  // Drawer may submit terminal status directly — route through proper transitions
  if (!action && body.status === "Completed" && task.status !== "Completed") {
    if (!can(me.role, "task.complete")) return err("Permission denied: cannot complete tasks", 403);
    const updated = await db.update(tasks).set({ status: "Completed", completionNotes: body.completionNotes ?? task.completionNotes, completedAt: new Date(), completedById: me.id, updatedById: me.id, updatedAt: new Date() }).where(eq(tasks.id, id)).returning();
    await logActivity({ taskId: id, recurrenceId: task.recurrenceId, actorId: me.id, action: "completed", summary: `Task completed by ${me.name}`, priorValue: task.status, newValue: "Completed" });
    await emitEvent("TaskCompleted", updated[0] as unknown as Record<string, unknown>);
    return json(updated[0]);
  }
  if (!action && body.status === "Cancelled" && task.status !== "Cancelled") {
    if (!can(me.role, "task.cancel")) return err("Permission denied: cannot cancel tasks", 403);
    const updated = await db.update(tasks).set({ status: "Cancelled", cancelledAt: new Date(), updatedById: me.id, updatedAt: new Date() }).where(eq(tasks.id, id)).returning();
    await logActivity({ taskId: id, recurrenceId: task.recurrenceId, actorId: me.id, action: "cancelled", summary: `Task cancelled by ${me.name}`, priorValue: task.status, newValue: "Cancelled" });
    await emitEvent("TaskCancelled", updated[0] as unknown as Record<string, unknown>);
    return json(updated[0]);
  }
  if (!can(me.role, "task.edit")) return err("Permission denied: cannot edit tasks", 403);

  const patch: Record<string, unknown> = {};
  for (const k of EDITABLE) {
    if (body[k] !== undefined) patch[k] = body[k] === "" ? null : body[k];
  }
  if (body.status && !["Completed", "Cancelled"].includes(body.status)) patch.status = body.status;
  if (patch.startDate && patch.dueDate && (patch.dueDate as string) < (patch.startDate as string))
    return err("Due date cannot be earlier than start date");
  // reschedule permission check
  if ((patch.dueDate !== undefined || patch.startDate !== undefined) && !can(me.role, "task.reschedule") && me.id !== task.assigneeId && me.id !== task.createdById)
    return err("Permission denied: cannot reschedule tasks", 403);
  if (patch.assigneeId !== undefined && patch.assigneeId !== task.assigneeId) {
    if (patch.assigneeId !== me.id && !can(me.role, "task.assign"))
      return err("Permission denied: assigning to other users", 403);
  }
  if (isTerminal && !body.allowHistoricalEdit) {
    // Guard: never silently overwrite completed history — require explicit flag
    if (Object.keys(patch).length && action !== "edit-history-ok") {
      // Allow completionNotes edits but warn for core fields
      const core = Object.keys(patch).filter((k) => !["completionNotes"].includes(k));
      if (core.length) return err("This occurrence is completed/cancelled. Historical records are preserved — reopen the task to edit core fields.", 400);
    }
  }

  const dueChanged = patch.dueDate !== undefined && patch.dueDate !== task.dueDate;
  const assigneeChanged = patch.assigneeId !== undefined && patch.assigneeId !== task.assigneeId;

  // Recurring scope handling: single (default) | future | all
  if (task.recurrenceId && editScope && editScope !== "single") {
    if (!can(me.role, "task.manageRecurrence")) return err("Permission denied: managing recurring series", 403);
    const where =
      editScope === "future"
        ? and(eq(tasks.recurrenceId, task.recurrenceId), gte(tasks.dueDate, task.dueDate ?? "9999-12-31"))
        : eq(tasks.recurrenceId, task.recurrenceId);
    // Never overwrite completed historical occurrences for future/all edits:
    // only apply to non-terminal occurrences, count skipped.
    const targets = await db.select().from(tasks).where(where);
    let applied = 0;
    let skipped = 0;
    for (const t of targets) {
      if (t.status === "Completed" || t.status === "Cancelled") {
        skipped++;
        continue;
      }
      await db.update(tasks).set({ ...patch, updatedById: me.id, updatedAt: new Date() }).where(eq(tasks.id, t.id));
      await logActivity({ taskId: t.id, recurrenceId: t.recurrenceId, actorId: me.id, action: "edited", summary: `Series edit (${editScope}) applied by ${me.name}` });
      applied++;
    }
    // also update series template snapshot
    const rec = await db.select().from(taskRecurrences).where(eq(taskRecurrences.id, task.recurrenceId)).limit(1);
    if (rec[0]) {
      await db.update(taskRecurrences).set({ template: { ...(rec[0].template as object ?? {}), ...patch }, updatedAt: new Date() }).where(eq(taskRecurrences.id, task.recurrenceId));
    }
    const fresh = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
    return json({ ...fresh[0], _seriesEdit: { scope: editScope, applied, skipped } });
  }

  const updated = await db.update(tasks).set({ ...patch, updatedById: me.id, updatedAt: new Date() }).where(eq(tasks.id, id)).returning();
  const changes = Object.keys(patch);
  if (changes.length) {
    await logActivity({
      taskId: id, recurrenceId: task.recurrenceId, actorId: me.id, action: dueChanged ? "rescheduled" : assigneeChanged ? "reassigned" : "edited",
      summary: dueChanged
        ? `Rescheduled from ${task.dueDate ?? "—"} → ${patch.dueDate as string} by ${me.name}`
        : assigneeChanged
          ? `Reassigned by ${me.name}`
          : `Edited (${changes.join(", ")}) by ${me.name}`,
      priorValue: dueChanged ? task.dueDate : assigneeChanged ? task.assigneeId : null,
      newValue: dueChanged ? (patch.dueDate as string) : assigneeChanged ? (patch.assigneeId as string) : null,
      metadata: { fields: changes },
    });
    if (dueChanged) await emitEvent("TaskDueDateChanged", updated[0] as unknown as Record<string, unknown>, { from: task.dueDate, to: patch.dueDate });
    if (dueChanged) await emitEvent("TaskRescheduled", updated[0] as unknown as Record<string, unknown>, { from: task.dueDate, to: patch.dueDate });
    if (assigneeChanged) await emitEvent("TaskAssigned", updated[0] as unknown as Record<string, unknown>, { assigneeId: patch.assigneeId });
  }
  return json(updated[0]);
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.cancel")) return err("Permission denied", 403);
  const { id } = await params;
  await db.delete(tasks).where(eq(tasks.id, id));
  return json({ ok: true });
}
