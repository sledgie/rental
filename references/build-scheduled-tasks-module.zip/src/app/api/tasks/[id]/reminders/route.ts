import { db } from "@/db";
import { taskReminders } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(taskReminders).where(eq(taskReminders.taskId, id)).orderBy(asc(taskReminders.remindAt));
  return json(rows);
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  const { id } = await params;
  const body = await req.json();
  if (!body.remindAt) return err("remindAt is required");
  const rows = await db
    .insert(taskReminders)
    .values({
      taskId: id,
      remindAt: new Date(body.remindAt),
      channel: body.channel ?? "in_app",
      recipientId: body.recipientId ?? me.id,
    })
    .returning();
  return json(rows[0], 201);
}
