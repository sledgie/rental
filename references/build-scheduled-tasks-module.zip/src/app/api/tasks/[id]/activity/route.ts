import { db } from "@/db";
import { taskActivities, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { can } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.viewHistory")) return err("Permission denied", 403);
  const { id } = await params;
  const rows = await db
    .select({ activity: taskActivities, actor: users })
    .from(taskActivities)
    .leftJoin(users, eq(taskActivities.actorId, users.id))
    .where(eq(taskActivities.taskId, id))
    .orderBy(desc(taskActivities.createdAt))
    .limit(200);
  return json(rows.map((r) => ({ ...r.activity, actor: r.actor })));
}
