import { db } from "@/db";
import { taskChecklistItems, tasks } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { can } from "@/lib/permissions";
import { logActivity } from "@/lib/task-service";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(taskChecklistItems).where(eq(taskChecklistItems.taskId, id)).orderBy(asc(taskChecklistItems.position));
  return json(rows);
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.edit")) return err("Permission denied", 403);
  const { id } = await params;
  const body = await req.json();
  if (body.toggleId) {
    const cur = await db.select().from(taskChecklistItems).where(eq(taskChecklistItems.id, body.toggleId)).limit(1);
    if (!cur[0]) return err("Item not found", 404);
    const done = !cur[0].isDone;
    const rows = await db
      .update(taskChecklistItems)
      .set({ isDone: done, doneById: done ? me.id : null, doneAt: done ? new Date() : null })
      .where(eq(taskChecklistItems.id, body.toggleId))
      .returning();
    const t = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
    await logActivity({ taskId: id, recurrenceId: t[0]?.recurrenceId ?? null, actorId: me.id, action: "checklist_updated", summary: `${me.name} ${done ? "checked" : "unchecked"} “${cur[0].title}”` });
    return json(rows[0]);
  }
  if (body.deleteId) {
    await db.delete(taskChecklistItems).where(eq(taskChecklistItems.id, body.deleteId));
    return json({ ok: true });
  }
  if (!String(body.title ?? "").trim()) return err("Checklist title is required");
  const existing = await db.select().from(taskChecklistItems).where(eq(taskChecklistItems.taskId, id));
  const rows = await db
    .insert(taskChecklistItems)
    .values({ taskId: id, title: String(body.title).slice(0, 300), position: existing.length })
    .returning();
  return json(rows[0], 201);
}
