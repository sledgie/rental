import { db } from "@/db";
import { taskAttachments, tasks } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { can } from "@/lib/permissions";
import { logActivity } from "@/lib/task-service";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.viewAttachments")) return err("Permission denied", 403);
  const { id } = await params;
  const rows = await db.select().from(taskAttachments).where(eq(taskAttachments.taskId, id)).orderBy(desc(taskAttachments.createdAt));
  return json(rows);
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.edit")) return err("Permission denied", 403);
  const { id } = await params;
  const body = await req.json();
  // Metadata-only upload placeholder: files are recorded, binary storage is out of scope for this module.
  if (!String(body.fileName ?? "").trim()) return err("fileName is required");
  const rows = await db
    .insert(taskAttachments)
    .values({
      taskId: id,
      fileName: String(body.fileName).slice(0, 255),
      fileSize: Number(body.fileSize ?? 0),
      mimeType: String(body.mimeType ?? "application/octet-stream"),
      url: String(body.url ?? "#"),
      uploadedById: me.id,
    })
    .returning();
  const t = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
  await logActivity({ taskId: id, recurrenceId: t[0]?.recurrenceId ?? null, actorId: me.id, action: "attachment_added", summary: `${me.name} attached ${rows[0].fileName}` });
  return json(rows[0], 201);
}
