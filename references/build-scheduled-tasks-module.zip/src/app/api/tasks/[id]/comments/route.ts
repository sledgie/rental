import { db } from "@/db";
import { taskComments, users, tasks } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { logActivity } from "@/lib/task-service";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db
    .select({ comment: taskComments, author: users })
    .from(taskComments)
    .leftJoin(users, eq(taskComments.authorId, users.id))
    .where(eq(taskComments.taskId, id))
    .orderBy(asc(taskComments.createdAt));
  return json(rows.map((r) => ({ ...r.comment, author: r.author })));
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  const { id } = await params;
  const body = await req.json();
  if (!String(body.body ?? "").trim()) return err("Comment body is required");
  const rows = await db
    .insert(taskComments)
    .values({ taskId: id, authorId: me.id, body: String(body.body).slice(0, 5000) })
    .returning();
  const t = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
  await logActivity({ taskId: id, recurrenceId: t[0]?.recurrenceId ?? null, actorId: me.id, action: "commented", summary: `${me.name} added a comment` });
  return json(rows[0], 201);
}
