import { db } from "@/db";
import {
  tasks,
  taskCategories,
  properties,
  units,
  tenants,
  users,
  taskRecurrences,
  taskChecklistItems,
  taskReminders,
} from "@/db/schema";
import { eq, and, or, gte, lte, sql, desc, asc } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { can } from "@/lib/permissions";
import { nextReferenceNumber, logActivity, emitEvent } from "@/lib/task-service";
import { nextOccurrenceAfter, generateForward, type Frequency } from "@/lib/recurrence";

export const dynamic = "force-dynamic";

function todayStr(tz = "America/New_York"): string {
  try {
    return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

export async function GET(req: Request) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  const url = new URL(req.url);
  const q = (k: string) => url.searchParams.get(k);

  const search = q("search")?.trim() ?? "";
  const quick = q("quick") ?? "all"; // my|all|overdue|today|upcoming|completed|recurring
  const categoryId = q("categoryId");
  const priority = q("priority");
  const status = q("status");
  const propertyId = q("propertyId");
  const assigneeId = q("assigneeId");
  const dueFrom = q("dueFrom");
  const dueTo = q("dueTo");
  const sort = q("sort") ?? "dueDate";
  const dir = q("dir") ?? "asc";
  const page = Math.max(1, Number(q("page") ?? 1));
  const pageSize = Math.min(100, Math.max(5, Number(q("pageSize") ?? 15)));

  const conds: ReturnType<typeof eq>[] = [];
  const today = todayStr();

  // Permission scoping: without viewAll, only assigned/collaborating/created
  if (!can(me.role, "task.viewAll")) {
    conds.push(
      or(
        eq(tasks.assigneeId, me.id),
        eq(tasks.createdById, me.id),
        sql`${tasks.collaboratorIds} @> ${JSON.stringify([me.id])}::jsonb`
      ) as never
    );
  }

  if (quick === "my") {
    conds.push(
      or(
        eq(tasks.assigneeId, me.id),
        sql`${tasks.collaboratorIds} @> ${JSON.stringify([me.id])}::jsonb`
      ) as never
    );
  } else if (quick === "overdue") {
    conds.push(lte(tasks.dueDate, today) as never);
    conds.push(sql`${tasks.status} not in ('Completed','Cancelled')` as never);
  } else if (quick === "today") {
    conds.push(eq(tasks.dueDate, today) as never);
    conds.push(sql`${tasks.status} not in ('Completed','Cancelled')` as never);
  } else if (quick === "upcoming") {
    conds.push(gte(tasks.dueDate, today) as never);
    conds.push(sql`${tasks.status} not in ('Completed','Cancelled')` as never);
  } else if (quick === "completed") {
    conds.push(eq(tasks.status, "Completed") as never);
  } else if (quick === "recurring") {
    conds.push(eq(tasks.isRecurring, true) as never);
  }

  if (categoryId) conds.push(eq(tasks.categoryId, categoryId) as never);
  if (priority) conds.push(eq(tasks.priority, priority as never) as never);
  if (status) conds.push(eq(tasks.status, status as never) as never);
  if (propertyId) conds.push(eq(tasks.propertyId, propertyId) as never);
  if (assigneeId) conds.push(eq(tasks.assigneeId, assigneeId) as never);
  if (dueFrom) conds.push(gte(tasks.dueDate, dueFrom) as never);
  if (dueTo) conds.push(lte(tasks.dueDate, dueTo) as never);

  // NOTE: `search` is applied after the scoped query (see below) so it can
  // match joined fields: property, unit, tenant, assignee, category.
  void search;

  const baseWhere = conds.length ? and(...conds) : undefined;

  const sortCol =
    sort === "title" ? tasks.title
    : sort === "priority" ? tasks.priority
    : sort === "status" ? tasks.status
    : sort === "createdAt" ? tasks.createdAt
    : sort === "startDate" ? tasks.startDate
    : tasks.dueDate;
  const orderBy = dir === "desc" ? desc(sortCol) : asc(sortCol);

  const shape = {
    task: tasks,
    category: taskCategories,
    property: properties,
    unit: units,
    tenant: tenants,
    assignee: users,
  } as const;

  type Joined = {
    task: typeof tasks.$inferSelect;
    category: typeof taskCategories.$inferSelect | null;
    property: typeof properties.$inferSelect | null;
    unit: typeof units.$inferSelect | null;
    tenant: (typeof tenants.$inferSelect & { fullName?: string }) | null;
    assignee: typeof users.$inferSelect | null;
  };

  const toItem = (r: {
    task: typeof tasks.$inferSelect;
    category: typeof taskCategories.$inferSelect | null;
    property: typeof properties.$inferSelect | null;
    unit: typeof units.$inferSelect | null;
    tenant: typeof tenants.$inferSelect | null;
    assignee: typeof users.$inferSelect | null;
  }) => ({
    ...r.task,
    category: r.category,
    property: r.property,
    unit: r.unit,
    tenant: r.tenant ? { ...r.tenant, fullName: `${r.tenant.firstName} ${r.tenant.lastName}` } : null,
    assignee: r.assignee,
  });

  const matchesSearch = (t: ReturnType<typeof toItem>, s: string) =>
    (t.title ?? "").toLowerCase().includes(s) ||
    (t.description ?? "").toLowerCase().includes(s) ||
    (t.referenceNumber ?? "").toLowerCase().includes(s) ||
    (t.completionNotes ?? "").toLowerCase().includes(s) ||
    (t.category?.name ?? "").toLowerCase().includes(s) ||
    (t.property?.name ?? "").toLowerCase().includes(s) ||
    (t.unit?.unitNumber ?? "").toLowerCase().includes(s) ||
    ((t.tenant as { fullName?: string } | null)?.fullName ?? "").toLowerCase().includes(s) ||
    (t.assignee?.name ?? "").toLowerCase().includes(s);

  if (search) {
    // Joined-field search (property, unit, tenant, assignee, category) can't be
    // expressed with a single ilike, so filter the scoped set in JS and paginate.
    const s = search.toLowerCase();
    const scoped = await db
      .select(shape)
      .from(tasks)
      .leftJoin(taskCategories, eq(tasks.categoryId, taskCategories.id))
      .leftJoin(properties, eq(tasks.propertyId, properties.id))
      .leftJoin(units, eq(tasks.unitId, units.id))
      .leftJoin(tenants, eq(tasks.tenantId, tenants.id))
      .leftJoin(users, eq(tasks.assigneeId, users.id))
      .where(baseWhere)
      .orderBy(orderBy)
      .limit(500);
    const filtered = scoped.map(toItem).filter((t) => matchesSearch(t, s));
    const items = filtered.slice((page - 1) * pageSize, page * pageSize);
    void ({} as Joined | null);
    return json({ items, total: filtered.length, page, pageSize, pageCount: Math.max(1, Math.ceil(filtered.length / pageSize)) });
  }

  const totalRows = await db.select({ c: sql<number>`count(*)` }).from(tasks).where(baseWhere);
  const total = Number(totalRows[0]?.c ?? 0);

  const rows = await db
    .select(shape)
    .from(tasks)
    .leftJoin(taskCategories, eq(tasks.categoryId, taskCategories.id))
    .leftJoin(properties, eq(tasks.propertyId, properties.id))
    .leftJoin(units, eq(tasks.unitId, units.id))
    .leftJoin(tenants, eq(tasks.tenantId, tenants.id))
    .leftJoin(users, eq(tasks.assigneeId, users.id))
    .where(baseWhere)
    .orderBy(orderBy)
    .limit(pageSize)
    .offset((page - 1) * pageSize);

  const items = rows.map(toItem);
  return json({ items, total, page, pageSize, pageCount: Math.max(1, Math.ceil(total / pageSize)) });
}

export async function POST(req: Request) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.create")) return err("Permission denied: cannot create tasks", 403);
  const body = await req.json();

  const title = String(body.title ?? "").trim();
  if (!title) return err("Task title is required");
  if (!body.dueDate && !body.recurrence) return err("Due date is required for one-time tasks", 400);
  if (body.startDate && body.dueDate && body.dueDate < body.startDate)
    return err("Due date cannot be earlier than start date");

  if (body.assigneeId && body.assigneeId !== me.id && !can(me.role, "task.assign"))
    return err("Permission denied: assigning tasks to other users requires elevated permission", 403);

  const ref = await nextReferenceNumber();
  const recurrenceInput = body.recurrence as
    | {
        frequency: Frequency;
        interval?: number;
        daysOfWeek?: number[];
        monthDay?: number | null;
        monthWeek?: number | null;
        monthWeekday?: number | null;
        startDate?: string;
        endDate?: string | null;
        advanceReminderDays?: number;
      }
    | undefined;

  let recurrenceId: string | null = null;

  // Create recurrence series first (if requested)
  if (recurrenceInput) {
    if (!can(me.role, "task.manageRecurrence")) return err("Permission denied: managing recurring series", 403);
    const rStart = recurrenceInput.startDate ?? body.startDate ?? body.dueDate;
    if (!rStart) return err("Recurrence start date is required");
    const recRows = await db
      .insert(taskRecurrences)
      .values({
        title: `${title} (series)`,
        frequency: recurrenceInput.frequency,
        interval: recurrenceInput.interval ?? 1,
        daysOfWeek: recurrenceInput.daysOfWeek ?? [],
        monthDay: recurrenceInput.monthDay ?? null,
        monthWeek: recurrenceInput.monthWeek ?? null,
        monthWeekday: recurrenceInput.monthWeekday ?? null,
        startDate: rStart,
        endDate: recurrenceInput.endDate ?? null,
        timezone: body.timezone ?? "America/New_York",
        advanceReminderDays: recurrenceInput.advanceReminderDays ?? 1,
        status: "active",
        template: {
          title, description: body.description ?? "", categoryId: body.categoryId ?? null,
          priority: body.priority ?? "Normal", propertyId: body.propertyId ?? null,
          unitId: body.unitId ?? null, tenantId: body.tenantId ?? null, leaseId: body.leaseId ?? null,
          maintenanceRequestId: body.maintenanceRequestId ?? null, vendorId: body.vendorId ?? null,
          projectId: body.projectId ?? null, assigneeId: body.assigneeId ?? me.id,
          collaboratorIds: body.collaboratorIds ?? [], dueTime: body.dueTime ?? null,
          timezone: body.timezone ?? "America/New_York",
        },
      })
      .returning();
    recurrenceId = recRows[0].id;
  }

  const dueDate: string | null = body.dueDate ?? recurrenceInput?.startDate ?? null;

  const rows = await db
    .insert(tasks)
    .values({
      referenceNumber: ref,
      title,
      description: body.description ?? "",
      categoryId: body.categoryId ?? null,
      priority: body.priority ?? "Normal",
      status: body.status ?? "Not Started",
      propertyId: body.propertyId ?? null,
      unitId: body.unitId ?? null,
      tenantId: body.tenantId ?? null,
      leaseId: body.leaseId ?? null,
      maintenanceRequestId: body.maintenanceRequestId ?? null,
      vendorId: body.vendorId ?? null,
      projectId: body.projectId ?? null,
      assigneeId: body.assigneeId ?? me.id,
      collaboratorIds: body.collaboratorIds ?? [],
      startDate: body.startDate ?? null,
      dueDate,
      dueTime: body.dueTime ?? null,
      timezone: body.timezone ?? "America/New_York",
      isRecurring: Boolean(recurrenceId),
      recurrenceId,
      occurrenceDate: recurrenceId ? dueDate : null,
      reminderPrefs: body.reminderPrefs ?? { enabled: true, daysBefore: [1], channels: ["in_app", "email"] },
      createdById: me.id,
    })
    .returning();
  const task = rows[0];

  // checklist
  const checklist: { title: string }[] = Array.isArray(body.checklist) ? body.checklist : [];
  if (checklist.length) {
    await db.insert(taskChecklistItems).values(
      checklist.slice(0, 50).map((c, i) => ({ taskId: task.id, title: String(c.title ?? c).slice(0, 300), position: i }))
    );
  }
  // reminders from prefs
  if (dueDate && body.reminderPrefs?.enabled !== false) {
    const days: number[] = body.reminderPrefs?.daysBefore ?? [1];
    const channels: string[] = body.reminderPrefs?.channels ?? ["in_app"];
    const vals = [];
    for (const d of days.slice(0, 3)) {
      const base = new Date(`${dueDate}T09:00:00Z`);
      base.setUTCDate(base.getUTCDate() - Number(d));
      for (const ch of channels.slice(0, 2)) {
        vals.push({ taskId: task.id, remindAt: base, channel: ch as "in_app", recipientId: task.assigneeId });
      }
    }
    if (vals.length) await db.insert(taskReminders).values(vals as never);
  }

  await logActivity({
    taskId: task.id, recurrenceId, actorId: me.id, action: "created",
    summary: `Task created${recurrenceId ? " with recurring series" : ""} and assigned`,
    newValue: task.assigneeId,
  });
  await emitEvent("TaskCreated", task as unknown as Record<string, unknown>);
  if (task.assigneeId && task.assigneeId !== me.id) {
    await emitEvent("TaskAssigned", task as unknown as Record<string, unknown>, { assigneeId: task.assigneeId });
  }

  // Pre-generate upcoming occurrences for the series (idempotent by unique date check)
  if (recurrenceId && recurrenceInput) {
    const fwd = generateForward(
      {
        frequency: recurrenceInput.frequency,
        interval: recurrenceInput.interval ?? 1,
        daysOfWeek: recurrenceInput.daysOfWeek ?? [],
        monthDay: recurrenceInput.monthDay ?? null,
        monthWeek: recurrenceInput.monthWeek ?? null,
        monthWeekday: recurrenceInput.monthWeekday ?? null,
        startDate: recurrenceInput.startDate ?? dueDate!,
        endDate: recurrenceInput.endDate ?? null,
      },
      dueDate,
      5
    );
    for (const occ of fwd) {
      const exists = await db
        .select({ id: tasks.id })
        .from(tasks)
        .where(and(eq(tasks.recurrenceId, recurrenceId), eq(tasks.occurrenceDate, occ)))
        .limit(1);
      if (exists.length) continue;
      const oref = await nextReferenceNumber();
      const occRows = await db
        .insert(tasks)
        .values({
          referenceNumber: oref, title, description: body.description ?? "",
          categoryId: body.categoryId ?? null, priority: body.priority ?? "Normal", status: "Not Started",
          propertyId: body.propertyId ?? null, unitId: body.unitId ?? null, tenantId: body.tenantId ?? null,
          leaseId: body.leaseId ?? null, maintenanceRequestId: body.maintenanceRequestId ?? null,
          vendorId: body.vendorId ?? null, projectId: body.projectId ?? null,
          assigneeId: body.assigneeId ?? me.id, collaboratorIds: body.collaboratorIds ?? [],
          startDate: occ, dueDate: occ, dueTime: body.dueTime ?? null,
          timezone: body.timezone ?? "America/New_York",
          isRecurring: true, recurrenceId, occurrenceDate: occ, createdById: me.id,
        })
        .returning();
      await logActivity({ taskId: occRows[0].id, recurrenceId, actorId: me.id, action: "created", summary: `Occurrence generated for ${occ}` });
    }
    const nxt = nextOccurrenceAfter(
      {
        frequency: recurrenceInput.frequency,
        interval: recurrenceInput.interval ?? 1,
        daysOfWeek: recurrenceInput.daysOfWeek ?? [],
        monthDay: recurrenceInput.monthDay ?? null,
        monthWeek: recurrenceInput.monthWeek ?? null,
        monthWeekday: recurrenceInput.monthWeekday ?? null,
        startDate: recurrenceInput.startDate ?? dueDate!,
        endDate: recurrenceInput.endDate ?? null,
      },
      fwd.length ? fwd[fwd.length - 1] : dueDate
    );
    await db.update(taskRecurrences).set({ nextOccurrenceDate: nxt, lastGeneratedDate: fwd.length ? fwd[fwd.length - 1] : dueDate }).where(eq(taskRecurrences.id, recurrenceId));
  }

  return json(task, 201);
}
