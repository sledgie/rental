import { db } from "@/db";
import { taskRecurrences, tasks } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { can } from "@/lib/permissions";
import { logActivity, nextReferenceNumber } from "@/lib/task-service";
import { nextOccurrenceAfter, type Frequency } from "@/lib/recurrence";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rec = await db.select().from(taskRecurrences).where(eq(taskRecurrences.id, id)).limit(1);
  if (!rec[0]) return err("Series not found", 404);
  const occ = await db.select().from(tasks).where(eq(tasks.recurrenceId, id)).orderBy(tasks.dueDate);
  return json({ series: rec[0], occurrences: occ });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.manageRecurrence")) return err("Permission denied: managing recurring series", 403);
  const { id } = await params;
  const body = await req.json();
  const rec = await db.select().from(taskRecurrences).where(eq(taskRecurrences.id, id)).limit(1);
  if (!rec[0]) return err("Series not found", 404);

  const action = body.action as string | undefined;

  if (action === "pause") {
    const rows = await db.update(taskRecurrences).set({ status: "paused", updatedAt: new Date() }).where(eq(taskRecurrences.id, id)).returning();
    const occ = await db.select().from(tasks).where(eq(tasks.recurrenceId, id)).limit(1);
    if (occ[0]) await logActivity({ taskId: occ[0].id, recurrenceId: id, actorId: me.id, action: "recurrence_paused", summary: `Series paused by ${me.name}` });
    return json(rows[0]);
  }
  if (action === "resume") {
    // recompute next occurrence from last generated
    const r = rec[0];
    const nxt = nextOccurrenceAfter(
      {
        frequency: r.frequency as Frequency,
        interval: r.interval ?? 1,
        daysOfWeek: (r.daysOfWeek as number[]) ?? [],
        monthDay: r.monthDay, monthWeek: r.monthWeek, monthWeekday: r.monthWeekday,
        startDate: r.startDate, endDate: r.endDate,
      },
      r.lastGeneratedDate
    );
    const rows = await db.update(taskRecurrences).set({ status: "active", nextOccurrenceDate: nxt, updatedAt: new Date() }).where(eq(taskRecurrences.id, id)).returning();
    const occ = await db.select().from(tasks).where(eq(tasks.recurrenceId, id)).limit(1);
    if (occ[0]) await logActivity({ taskId: occ[0].id, recurrenceId: id, actorId: me.id, action: "recurrence_resumed", summary: `Series resumed by ${me.name}; next ${nxt ?? "—"}` });
    return json(rows[0]);
  }
  if (action === "cancel") {
    const rows = await db.update(taskRecurrences).set({ status: "cancelled", updatedAt: new Date() }).where(eq(taskRecurrences.id, id)).returning();
    // Cancel pending (non-terminal) future occurrences; preserve completed history
    const future = await db.select().from(tasks).where(eq(tasks.recurrenceId, id));
    let cancelled = 0;
    for (const t of future) {
      if (t.status === "Completed" || t.status === "Cancelled") continue;
      await db.update(tasks).set({ status: "Cancelled", cancelReason: "Series cancelled", cancelledAt: new Date(), updatedById: me.id }).where(eq(tasks.id, t.id));
      await logActivity({ taskId: t.id, recurrenceId: id, actorId: me.id, action: "cancelled", summary: `Occurrence cancelled — series cancelled by ${me.name}`, priorValue: t.status, newValue: "Cancelled" });
      cancelled++;
    }
    return json({ ...rows[0], _cancelledOccurrences: cancelled });
  }
  if (action === "generate") {
    // Idempotent generation of next N occurrences (unique by recurrenceId+occurrenceDate)
    const r = rec[0];
    const { nextOccurrenceAfter: nextFn, generateForward } = await import("@/lib/recurrence");
    void nextFn;
    const fwd = generateForward(
      {
        frequency: r.frequency as Frequency,
        interval: r.interval ?? 1,
        daysOfWeek: (r.daysOfWeek as number[]) ?? [],
        monthDay: r.monthDay, monthWeek: r.monthWeek, monthWeekday: r.monthWeekday,
        startDate: r.startDate, endDate: r.endDate,
      },
      r.lastGeneratedDate,
      Math.min(12, Number(body.count ?? 6))
    );
    const tpl = (r.template as Record<string, unknown>) ?? {};
    let created = 0;
    for (const occ of fwd) {
      const exists = await db.select({ id: tasks.id }).from(tasks).where(and(eq(tasks.recurrenceId, id), eq(tasks.occurrenceDate, occ))).limit(1);
      if (exists.length) continue; // idempotency guard
      const oref = await nextReferenceNumber();
      const occRows = await db.insert(tasks).values({
        referenceNumber: oref,
        title: String(tpl.title ?? r.title),
        description: String(tpl.description ?? ""),
        categoryId: (tpl.categoryId as string) ?? null,
        priority: ((tpl.priority as string) ?? "Normal") as never,
        status: "Not Started" as never,
        propertyId: (tpl.propertyId as string) ?? null,
        unitId: (tpl.unitId as string) ?? null,
        tenantId: (tpl.tenantId as string) ?? null,
        leaseId: (tpl.leaseId as string) ?? null,
        maintenanceRequestId: (tpl.maintenanceRequestId as string) ?? null,
        vendorId: (tpl.vendorId as string) ?? null,
        projectId: (tpl.projectId as string) ?? null,
        assigneeId: (tpl.assigneeId as string) ?? me.id,
        collaboratorIds: ((tpl.collaboratorIds as string[]) ?? []) as never,
        startDate: occ, dueDate: occ, dueTime: (tpl.dueTime as string) ?? null,
        timezone: (tpl.timezone as string) ?? r.timezone,
        isRecurring: true, recurrenceId: id, occurrenceDate: occ, createdById: me.id,
      }).returning();
      await logActivity({ taskId: occRows[0].id, recurrenceId: id, actorId: me.id, action: "created", summary: `Occurrence generated for ${occ}` });
      created++;
    }
    const last = fwd.length ? fwd[fwd.length - 1] : r.lastGeneratedDate;
    const nxt = nextOccurrenceAfter(
      {
        frequency: r.frequency as Frequency,
        interval: r.interval ?? 1,
        daysOfWeek: (r.daysOfWeek as number[]) ?? [],
        monthDay: r.monthDay, monthWeek: r.monthWeek, monthWeekday: r.monthWeekday,
        startDate: r.startDate, endDate: r.endDate,
      },
      last
    );
    const rows = await db.update(taskRecurrences).set({ lastGeneratedDate: last, nextOccurrenceDate: nxt, updatedAt: new Date() }).where(eq(taskRecurrences.id, id)).returning();
    return json({ series: rows[0], created });
  }

  // generic series edit (template + schedule)
  const patch: Record<string, unknown> = {};
  for (const k of ["title", "frequency", "interval", "daysOfWeek", "monthDay", "monthWeek", "monthWeekday", "startDate", "endDate", "timezone", "advanceReminderDays", "template"]) {
    if (body[k] !== undefined) patch[k] = body[k];
  }
  const rows = await db.update(taskRecurrences).set({ ...patch, updatedAt: new Date() }).where(eq(taskRecurrences.id, id)).returning();
  return json(rows[0]);
}
