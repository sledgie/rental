import { db } from "@/db";
import { taskRecurrences, tasks } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { describeRecurrence } from "@/lib/recurrence";

export const dynamic = "force-dynamic";

export async function GET() {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  const recs = await db.select().from(taskRecurrences).orderBy(desc(taskRecurrences.createdAt));
  const counts = await db
    .select({ recurrenceId: tasks.recurrenceId, c: sql<number>`count(*)` })
    .from(tasks)
    .groupBy(tasks.recurrenceId);
  const map = new Map(counts.map((c) => [c.recurrenceId, Number(c.c)]));
  return json(
    recs.map((r) => ({
      ...r,
      occurrenceCount: map.get(r.id) ?? 0,
      description: describeRecurrence({
        frequency: r.frequency as never,
        interval: r.interval ?? 1,
        daysOfWeek: (r.daysOfWeek as number[]) ?? [],
        monthDay: r.monthDay,
        monthWeek: r.monthWeek,
        monthWeekday: r.monthWeekday,
        startDate: r.startDate,
        endDate: r.endDate,
      }),
    }))
  );
}
