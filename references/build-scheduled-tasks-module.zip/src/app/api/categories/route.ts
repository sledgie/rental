import { db } from "@/db";
import { taskCategories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { can } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(taskCategories);
  rows.sort((a, b) => a.name.localeCompare(b.name));
  return json(rows);
}

export async function POST(req: Request) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.manageCategories")) return err("Permission denied: managing categories requires administrator or property manager", 403);
  const body = await req.json();
  const name = String(body.name ?? "").trim();
  if (!name) return err("Category name is required");
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || `cat-${Date.now()}`;
  try {
    const rows = await db
      .insert(taskCategories)
      .values({
        name,
        slug,
        color: body.color ?? "#2563eb",
        icon: body.icon ?? "star",
        isSystem: false,
        isActive: body.isActive ?? true,
        createdById: me.id,
      })
      .returning();
    return json(rows[0], 201);
  } catch {
    return err("Category name already exists", 409);
  }
}
