import { db } from "@/db";
import { taskCategories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { can } from "@/lib/permissions";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.manageCategories")) return err("Permission denied", 403);
  const { id } = await params;
  const body = await req.json();
  const existing = await db.select().from(taskCategories).where(eq(taskCategories.id, id)).limit(1);
  if (!existing[0]) return err("Category not found", 404);
  const rows = await db
    .update(taskCategories)
    .set({
      name: body.name ?? existing[0].name,
      color: body.color ?? existing[0].color,
      icon: body.icon ?? existing[0].icon,
      isActive: body.isActive ?? existing[0].isActive,
    })
    .where(eq(taskCategories.id, id))
    .returning();
  return json(rows[0]);
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (!can(me.role, "task.manageCategories")) return err("Permission denied", 403);
  const { id } = await params;
  const existing = await db.select().from(taskCategories).where(eq(taskCategories.id, id)).limit(1);
  if (!existing[0]) return err("Category not found", 404);
  if (existing[0].isSystem) return err("System categories cannot be deleted (deactivate instead)", 400);
  await db.delete(taskCategories).where(eq(taskCategories.id, id));
  return json({ ok: true });
}
