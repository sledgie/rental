import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { json } from "@/lib/server-helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(users).where(eq(users.isActive, true));
  return json(rows);
}
