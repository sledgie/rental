import { db } from "@/db";
import { tasks, taskRecurrences } from "@/db/schema";
import { eq, and, lte, sql } from "drizzle-orm";
import { getActingUser, json } from "@/lib/server-helpers";
import { nextOccurrenceAfter, generateForward, type Frequency } from "@/lib/recurrence";
import { nextReferenceNumber, logActivity, emitEvent } from "@/lib/task-service";

/**
 * POST /api/cron/process — reliable background processing entrypoint.
 * Runs: (1) overdue detection → emits TaskOverdue events;
 *       (2) recurrence generation → idempotent occurrence creation.
 * Safe to retry: occurrences are unique per (recurrenceId, occurrenceDate).
 */
export const dynamic = "force-dynamic";

function todayStr(): string {
  try {
    return new Intl.DateTimeFormat("en-CA", { timeZone: "America/New_York", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

export async function POST() {
  const me = await getActingUser();
  const today = todayStr();

  // 1) Overdue detection
  const overdue = await db
    .select()
    .from(tasks)
    .where(and(lte(tasks.dueDate, todayMinus(today, 1)), sql`${tasks.status} not in ('Completed','Cancelled')`))
    .limit(200);
  let overdueFlagged = 0;
  for (const t of overdue) {
    const meta = t as unknown as Record<string, unknown>;
    if ((meta as { _overdueEmitted?: boolean })._overdueEmitted) continue;
    await emitEvent("TaskOverdue", t as unknown as Record<string, unknown>, { dueDate: t.dueDate, today });
    overdueFlagged++;
  }

  // 2) Recurrence generation for active series
  const series = await db.select().from(taskRecurrences).where(eq(taskRecurrences.status, "active")).limit(100);
  let occurrencesCreated = 0;
  const horizon = (() => {
    const d = new Date(`${today}T12:00:00Z`);
    d.setUTCDate(d.getUTCDate() + 30);
    return d.toISOString().slice(0, 10);
  })();

  for (const r of series) {
    const input = {
      frequency: r.frequency as Frequency,
      interval: r.interval ?? 1,
      daysOfWeek: (r.daysOfWeek as number[]) ?? [],
      monthDay: r.monthDay, monthWeek: r.monthWeek, monthWeekday: r.monthWeekday,
      startDate: r.startDate, endDate: r.endDate,
    };
    let cursor = r.lastGeneratedDate;
    for (let i = 0; i < 12; i++) {
      const nxt = nextOccurrenceAfter(input, cursor);
      if (!nxt || nxt > horizon) break;
      const exists = await db.select({ id: tasks.id }).from(tasks).where(and(eq(tasks.recurrenceId, r.id), eq(tasks.occurrenceDate, nxt))).limit(1);
      if (!exists.length) {
        const tpl = (r.template as Record<string, unknown>) ?? {};
        const oref = await nextReferenceNumber();
        const occRows = await db.insert(tasks).values({
          referenceNumber: oref,
          title: String(tpl.title ?? r.title),
          description: String(tpl.description ?? ""),
          categoryId: (tpl.categoryId as string) ?? null,
          priority: ((tpl.priority as string) ?? "Normal") as never,
          status: "Not Started" as never,
          propertyId: (tpl.propertyId as string) ?? null,
          unitId: (tpl.unitId as string) ?? null,
          tenantId: (tpl.tenantId as string) ?? null,
          leaseId: (tpl.leaseId as string) ?? null,
          maintenanceRequestId: (tpl.maintenanceRequestId as string) ?? null,
          vendorId: (tpl.vendorId as string) ?? null,
          projectId: (tpl.projectId as string) ?? null,
          assigneeId: (tpl.assigneeId as string) ?? me?.id ?? null,
          collaboratorIds: ((tpl.collaboratorIds as string[]) ?? []) as never,
          startDate: nxt, dueDate: nxt, dueTime: (tpl.dueTime as string) ?? null,
          timezone: (tpl.timezone as string) ?? r.timezone,
          isRecurring: true, recurrenceId: r.id, occurrenceDate: nxt, createdById: me?.id ?? null,
        }).returning();
        await logActivity({ taskId: occRows[0].id, recurrenceId: r.id, actorId: me?.id ?? null, action: "created", summary: `Occurrence auto-generated for ${nxt} (cron)` });
        occurrencesCreated++;
        void generateForward;
      }
      cursor = nxt;
      await db.update(taskRecurrences).set({ lastGeneratedDate: cursor, updatedAt: new Date() }).where(eq(taskRecurrences.id, r.id));
    }
    const finalNext = nextOccurrenceAfter(input, cursor);
    await db.update(taskRecurrences).set({ nextOccurrenceDate: finalNext, updatedAt: new Date() }).where(eq(taskRecurrences.id, r.id));
  }

  return json({ ok: true, today, overdueFlagged, occurrencesCreated, seriesProcessed: series.length });
}

function todayMinus(today: string, n: number): string {
  const d = new Date(`${today}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() - n);
  return d.toISOString().slice(0, 10);
}
