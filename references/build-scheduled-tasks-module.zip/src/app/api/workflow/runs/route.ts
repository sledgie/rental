import { db } from "@/db";
import { workflowRuns, workflowAutomations } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { json } from "@/lib/server-helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db
    .select({ run: workflowRuns, automation: workflowAutomations })
    .from(workflowRuns)
    .leftJoin(workflowAutomations, eq(workflowRuns.automationId, workflowAutomations.id))
    .orderBy(desc(workflowRuns.executedAt))
    .limit(100);
  return json(rows.map((r) => ({ ...r.run, automationName: r.automation?.name ?? "—" })));
}
