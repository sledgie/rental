import { db } from "@/db";
import { tasks, taskCategories, users, workflowRuns, workflowAutomations } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";
import { nextReferenceNumber, logActivity, emitEvent } from "@/lib/task-service";

/**
 * POST /api/workflow/trigger
 * Documented service boundary: the ONLY way Workflow Automation creates or
 * updates Scheduled Tasks. Automations never write to task tables directly.
 *
 * Body:
 * {
 *   "event": "maintenance.approved" | "lease.expiring" | ...,
 *   "task": { title, description?, categorySlug?, priority?, propertyId?, unitId?,
 *             tenantId?, leaseId?, maintenanceRequestId?, vendorId?, projectId?,
 *             assigneeId?, dueDate?, startDate?, dueTime? },
 *   "updateTaskId"?: string,   // alternatively update an existing task
 *   "update"?: { status?, dueDate?, assigneeId?, priority? }
 * }
 */
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  const body = await req.json();
  const event = String(body.event ?? "");
  if (!event) return err("event is required");

  // audit the trigger itself
  const matched = await db
    .select()
    .from(workflowAutomations)
    .where(and(eq(workflowAutomations.triggerEvent, event), eq(workflowAutomations.isActive, true)));

  // --- Update path ---
  if (body.updateTaskId) {
    const cur = await db.select().from(tasks).where(eq(tasks.id, body.updateTaskId)).limit(1);
    if (!cur[0]) return err("Task not found", 404);
    const u = body.update ?? {};
    const patch: Record<string, unknown> = {};
    for (const k of ["status", "dueDate", "assigneeId", "priority", "description"]) {
      if (u[k] !== undefined) patch[k] = u[k];
    }
    const updated = await db.update(tasks).set({ ...patch, updatedById: me.id, updatedAt: new Date() }).where(eq(tasks.id, body.updateTaskId)).returning();
    await logActivity({ taskId: body.updateTaskId, recurrenceId: cur[0].recurrenceId, actorId: me.id, action: "edited", summary: `Updated via Workflow Automation (trigger: ${event})`, metadata: { via: "workflow", event } });
    for (const a of matched) {
      await db.insert(workflowRuns).values({ automationId: a.id, triggerEvent: event, payload: { updateTaskId: body.updateTaskId, ...u }, status: "succeeded", detail: `Updated ${cur[0].referenceNumber} via service boundary` });
      await db.update(workflowAutomations).set({ runCount: (a.runCount ?? 0) + 1, lastRunAt: new Date() }).where(eq(workflowAutomations.id, a.id));
    }
    return json({ task: updated[0], automationsMatched: matched.length });
  }

  // --- Create path ---
  const t = body.task ?? {};
  if (!t.title?.trim()) return err("task.title is required");
  let categoryId: string | null = t.categoryId ?? null;
  if (!categoryId && t.categorySlug) {
    const c = await db.select().from(taskCategories).where(eq(taskCategories.slug, t.categorySlug)).limit(1);
    categoryId = c[0]?.id ?? null;
  }
  let assigneeId: string | null = t.assigneeId ?? null;
  if (!assigneeId && t.assigneeRole) {
    const u = await db.select().from(users).where(eq(users.role, t.assigneeRole)).limit(1);
    assigneeId = u[0]?.id ?? me.id;
  }
  const ref = await nextReferenceNumber();
  const rows = await db.insert(tasks).values({
    referenceNumber: ref,
    title: String(t.title).slice(0, 300),
    description: String(t.description ?? `Created by Workflow Automation on ${event}`),
    categoryId, priority: t.priority ?? "Normal", status: "Not Started",
    propertyId: t.propertyId ?? null, unitId: t.unitId ?? null, tenantId: t.tenantId ?? null,
    leaseId: t.leaseId ?? null, maintenanceRequestId: t.maintenanceRequestId ?? null,
    vendorId: t.vendorId ?? null, projectId: t.projectId ?? null,
    assigneeId: assigneeId ?? me.id, collaboratorIds: [],
    startDate: t.startDate ?? null, dueDate: t.dueDate ?? null, dueTime: t.dueTime ?? null,
    timezone: "America/New_York", createdById: me.id,
  }).returning();
  await logActivity({ taskId: rows[0].id, actorId: me.id, action: "created", summary: `Created via Workflow Automation (trigger: ${event})`, metadata: { via: "workflow", event } });
  await emitEvent("TaskCreated", rows[0] as unknown as Record<string, unknown>, { via: "workflow", trigger: event });
  for (const a of matched) {
    await db.insert(workflowRuns).values({ automationId: a.id, triggerEvent: event, payload: { taskId: rows[0].id, title: rows[0].title }, status: "succeeded", detail: `Created ${ref} via service boundary` });
    await db.update(workflowAutomations).set({ runCount: (a.runCount ?? 0) + 1, lastRunAt: new Date() }).where(eq(workflowAutomations.id, a.id));
  }
  return json({ task: rows[0], automationsMatched: matched.length }, 201);
}
