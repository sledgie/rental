import { db } from "@/db";
import { workflowAutomations } from "@/db/schema";
import { desc } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(workflowAutomations).orderBy(desc(workflowAutomations.createdAt));
  return json(rows);
}

export async function POST(req: Request) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (me.role !== "administrator" && me.role !== "property_manager") return err("Only administrators / managers can manage automations", 403);
  const body = await req.json();
  if (!body.name?.trim()) return err("Automation name is required");
  if (!body.triggerEvent) return err("triggerEvent is required");
  const rows = await db
    .insert(workflowAutomations)
    .values({
      name: String(body.name).slice(0, 200),
      description: String(body.description ?? ""),
      triggerEvent: String(body.triggerEvent),
      conditions: body.conditions ?? {},
      actions: body.actions ?? {},
      isActive: body.isActive ?? true,
      createdById: me.id,
    })
    .returning();
  return json(rows[0], 201);
}
