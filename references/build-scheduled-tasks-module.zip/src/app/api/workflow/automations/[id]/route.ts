import { db } from "@/db";
import { workflowAutomations } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getActingUser, json, err } from "@/lib/server-helpers";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (me.role !== "administrator" && me.role !== "property_manager") return err("Forbidden", 403);
  const { id } = await params;
  const body = await req.json();
  const patch: Record<string, unknown> = {};
  for (const k of ["name", "description", "triggerEvent", "conditions", "actions", "isActive"]) {
    if (body[k] !== undefined) patch[k] = body[k];
  }
  const rows = await db.update(workflowAutomations).set({ ...patch, updatedAt: new Date() }).where(eq(workflowAutomations.id, id)).returning();
  if (!rows[0]) return err("Not found", 404);
  return json(rows[0]);
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const me = await getActingUser();
  if (!me) return err("No acting user", 401);
  if (me.role !== "administrator") return err("Only administrators can delete automations", 403);
  const { id } = await params;
  await db.delete(workflowAutomations).where(eq(workflowAutomations.id, id));
  return json({ ok: true });
}
