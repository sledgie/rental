import { db } from "@/db";
import { properties, units, tenants, leases, vendors, maintenanceRequests, projects } from "@/db/schema";
import { json } from "@/lib/server-helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  const [p, u, t, l, v, m, pr] = await Promise.all([
    db.select().from(properties),
    db.select().from(units),
    db.select().from(tenants),
    db.select().from(leases),
    db.select().from(vendors),
    db.select().from(maintenanceRequests),
    db.select().from(projects),
  ]);
  return json({ properties: p, units: u, tenants: t, leases: l, vendors: v, maintenanceRequests: m, projects: pr });
}
