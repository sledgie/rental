import { db } from "@/db";
import { domainEvents } from "@/db/schema";
import { desc } from "drizzle-orm";
import { json } from "@/lib/server-helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(domainEvents).orderBy(desc(domainEvents.emittedAt)).limit(150);
  return json(rows);
}
