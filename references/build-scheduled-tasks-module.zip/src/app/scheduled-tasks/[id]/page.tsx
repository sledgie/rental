"use client";

import { use, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, CheckCircle2, XOctagon, RotateCcw, Pencil, Plus, Paperclip, MessageSquare, History, Repeat } from "lucide-react";
import { apiFetch, useUser } from "@/components/UserContext";
import { StatusBadge, PriorityBadge, Avatar, Field, inputCls, Empty } from "@/components/ui";
import TaskDrawer from "@/components/tasks/TaskDrawer";
import { can } from "@/lib/permissions";
import { fmtDate, fmtDateTime, timeAgo, fileSize, cx } from "@/lib/format";

export default function TaskDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { user, users } = useUser();
  const [task, setTask] = useState<Record<string, unknown> | null>(null);
  const [checklist, setChecklist] = useState<{ id: string; title: string; isDone: boolean }[]>([]);
  const [comments, setComments] = useState<{ id: string; body: string; createdAt: string; author: { name: string; avatarColor?: string } | null }[]>([]);
  const [attachments, setAttachments] = useState<{ id: string; fileName: string; fileSize: number; mimeType: string; createdAt: string }[]>([]);
  const [activity, setActivity] = useState<{ id: string; action: string; summary: string; createdAt: string; actor: { name: string; avatarColor?: string } | null }[]>([]);
  const [reminders, setReminders] = useState<{ id: string; remindAt: string; channel: string; status: string }[]>([]);
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [lookups, setLookups] = useState(null);
  const [drawer, setDrawer] = useState(false);
  const [comment, setComment] = useState("");
  const [newItem, setNewItem] = useState("");
  const [attachName, setAttachName] = useState("");
  const [cancelReason, setCancelReason] = useState("");
  const [showCancel, setShowCancel] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(() => {
    apiFetch(`/api/tasks/${id}`).then((r) => r.json()).then(setTask).catch(() => {});
    apiFetch(`/api/tasks/${id}/checklist`).then((r) => r.json()).then(setChecklist).catch(() => {});
    apiFetch(`/api/tasks/${id}/comments`).then((r) => r.json()).then(setComments).catch(() => {});
    apiFetch(`/api/tasks/${id}/attachments`).then((r) => r.json()).then(setAttachments).catch(() => {});
    apiFetch(`/api/tasks/${id}/activity`).then((r) => r.json()).then(setActivity).catch(() => {});
    apiFetch(`/api/tasks/${id}/reminders`).then((r) => r.json()).then(setReminders).catch(() => {});
  }, [id]);

  useEffect(load, [load]);
  useEffect(() => {
    apiFetch("/api/categories").then((r) => r.json()).then(setCategories).catch(() => {});
    apiFetch("/api/lookups").then((r) => r.json()).then(setLookups).catch(() => {});
  }, []);

  async function act(action: string, extra?: Record<string, unknown>) {
    const r = await apiFetch(`/api/tasks/${id}`, { method: "PATCH", body: JSON.stringify({ action, ...extra }) });
    const j = await r.json();
    if (!r.ok) setMsg(j.error ?? "Action failed");
    else { setMsg(action === "complete" ? "Task completed — event emitted for Workflow Automation." : `Task ${action}d.`); setShowCancel(false); load(); }
    setTimeout(() => setMsg(null), 3500);
  }

  async function postComment() {
    if (!comment.trim()) return;
    await apiFetch(`/api/tasks/${id}/comments`, { method: "POST", body: JSON.stringify({ body: comment }) });
    setComment("");
    load();
  }

  async function addItem() {
    if (!newItem.trim()) return;
    await apiFetch(`/api/tasks/${id}/checklist`, { method: "POST", body: JSON.stringify({ title: newItem }) });
    setNewItem("");
    load();
  }

  async function toggleItem(itemId: string) {
    await apiFetch(`/api/tasks/${id}/checklist`, { method: "POST", body: JSON.stringify({ toggleId: itemId }) });
    load();
  }

  async function addAttachment() {
    if (!attachName.trim()) return;
    await apiFetch(`/api/tasks/${id}/attachments`, { method: "POST", body: JSON.stringify({ fileName: attachName.trim(), fileSize: 128000, mimeType: "application/octet-stream", url: "#" }) });
    setAttachName("");
    load();
  }

  if (!task) return <div className="rounded-xl border border-slate-200 bg-white p-10 text-center text-sm text-slate-500">Loading task…</div>;

  const t = task as Record<string, never> & {
    title: string; referenceNumber: string; status: string; priority: string;
    description: string; dueDate: string | null; startDate: string | null; dueTime: string | null;
    category: { name: string; color: string } | null; property: { name: string; address: string } | null;
    unit: { unitNumber: string } | null; tenant: { fullName: string } | null; lease: { id: string } | null;
    vendor: { name: string } | null; maintenanceRequest: { referenceNumber: string; title: string } | null;
    project: { name: string } | null; assignee: { name: string; avatarColor?: string } | null;
    recurrence: { id: string; title: string; status: string; frequency: string; nextOccurrenceDate: string | null } | null;
    completionNotes: string; isRecurring: boolean; recurrenceId: string | null;
  };

  const canEdit = user ? can(user.role, "task.edit") : false;
  const canComplete = user ? can(user.role, "task.complete") : false;
  const canCancel = user ? can(user.role, "task.cancel") : false;
  const done = checklist.filter((c) => c.isDone).length;

  return (
    <div className="space-y-4">
      <Link href="/scheduled-tasks" className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-slate-500 hover:text-slate-900"><ArrowLeft size={15} /> Back to Scheduled Tasks</Link>
      {msg && <div className="rounded-lg border border-blue-200 bg-blue-50 px-4 py-2 text-sm text-blue-800">{msg}</div>}

      <div className="grid gap-4 lg:grid-cols-3">
        {/* main */}
        <div className="space-y-4 lg:col-span-2">
          <div className="rounded-xl border border-slate-200 bg-white p-5 sm:p-6">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-xs text-slate-400">{t.referenceNumber}</span>
              {t.isRecurring && <span className="flex items-center gap-1 rounded-full bg-violet-100 px-2 py-0.5 text-[11px] font-bold text-violet-700"><Repeat size={11} /> Recurring</span>}
              <span className="ml-auto flex gap-2"><StatusBadge status={t.status} /><PriorityBadge priority={t.priority} /></span>
            </div>
            <h1 className="mt-2 text-xl font-bold text-slate-900 sm:text-2xl">{t.title}</h1>
            <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-slate-600">{t.description || "No description."}</p>

            <div className="mt-4 flex flex-wrap gap-2">
              {canEdit && <button onClick={() => setDrawer(true)} className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-[13px] font-semibold text-slate-700 hover:bg-slate-50"><Pencil size={14} /> Edit / Reschedule</button>}
              {canComplete && !["Completed", "Cancelled"].includes(t.status) && <button onClick={() => act("complete")} className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-[13px] font-semibold text-white hover:bg-emerald-700"><CheckCircle2 size={14} /> Complete</button>}
              {canCancel && !["Completed", "Cancelled"].includes(t.status) && <button onClick={() => setShowCancel(!showCancel)} className="flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-[13px] font-semibold text-red-700 hover:bg-red-100"><XOctagon size={14} /> Cancel</button>}
              {["Completed", "Cancelled"].includes(t.status) && canEdit && <button onClick={() => act("reopen")} className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-2 text-[13px] font-semibold text-slate-700 hover:bg-slate-50"><RotateCcw size={14} /> Reopen</button>}
            </div>
            {showCancel && (
              <div className="mt-3 flex gap-2 rounded-xl bg-red-50/60 p-3">
                <input value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} placeholder="Cancellation reason…" className={inputCls} />
                <button onClick={() => act("cancel", { reason: cancelReason })} className="shrink-0 rounded-lg bg-red-600 px-4 text-sm font-semibold text-white">Confirm</button>
              </div>
            )}
            {t.completionNotes ? <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50/60 p-3 text-sm text-emerald-900"><strong>Completion notes:</strong> {t.completionNotes}</div> : null}
          </div>

          {/* checklist */}
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Checklist & subtasks</h2>
              <span className="text-xs text-slate-500">{done}/{checklist.length} done</span>
            </div>
            {checklist.length > 0 && (
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
                <div className="h-full rounded-full bg-emerald-500 transition-all" style={{ width: `${checklist.length ? (done / checklist.length) * 100 : 0}%` }} />
              </div>
            )}
            <ul className="mt-3 space-y-1.5">
              {checklist.map((c) => (
                <li key={c.id}>
                  <button onClick={() => toggleItem(c.id)} className={cx("flex w-full items-center gap-2.5 rounded-lg border px-3 py-2 text-left text-sm", c.isDone ? "border-emerald-200 bg-emerald-50/50 text-slate-500 line-through" : "border-slate-200 text-slate-800 hover:border-slate-300")}>
                    <span className={cx("flex h-5 w-5 items-center justify-center rounded-md border text-xs", c.isDone ? "border-emerald-500 bg-emerald-500 text-white" : "border-slate-300")}>{c.isDone ? "✓" : ""}</span>
                    {c.title}
                  </button>
                </li>
              ))}
              {checklist.length === 0 && <Empty title="No checklist items" hint="Break the work into verifiable steps." />}
            </ul>
            {canEdit && (
              <div className="mt-3 flex gap-2">
                <input value={newItem} onChange={(e) => setNewItem(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addItem()} placeholder="Add item…" className={inputCls} />
                <button onClick={addItem} className="shrink-0 rounded-lg bg-slate-900 px-3 text-white"><Plus size={16} /></button>
              </div>
            )}
          </div>

          {/* comments */}
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="flex items-center gap-1.5 text-sm font-bold text-slate-900"><MessageSquare size={15} /> Comments ({comments.length})</h2>
            <ul className="mt-3 space-y-3">
              {comments.map((c) => (
                <li key={c.id} className="flex gap-2.5">
                  <Avatar name={c.author?.name ?? "?"} color={c.author?.avatarColor} size="sm" />
                  <div className="min-w-0 flex-1 rounded-xl bg-slate-50 px-3 py-2">
                    <p className="text-xs"><strong className="text-slate-800">{c.author?.name ?? "Unknown"}</strong> <span className="text-slate-400">· {timeAgo(c.createdAt)}</span></p>
                    <p className="mt-0.5 text-sm text-slate-700">{c.body}</p>
                  </div>
                </li>
              ))}
              {comments.length === 0 && <Empty title="No comments yet" />}
            </ul>
            <div className="mt-3 flex gap-2">
              <input value={comment} onChange={(e) => setComment(e.target.value)} onKeyDown={(e) => e.key === "Enter" && postComment()} placeholder="Write a comment…" className={inputCls} />
              <button onClick={postComment} className="shrink-0 rounded-lg bg-blue-600 px-4 text-sm font-semibold text-white hover:bg-blue-700">Post</button>
            </div>
          </div>

          {/* attachments */}
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="flex items-center gap-1.5 text-sm font-bold text-slate-900"><Paperclip size={15} /> Attachments ({attachments.length})</h2>
            <ul className="mt-3 space-y-1.5">
              {attachments.map((a) => (
                <li key={a.id} className="flex items-center gap-2.5 rounded-lg border border-slate-100 px-3 py-2 text-sm">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-500">📎</span>
                  <span className="min-w-0 flex-1"><span className="block truncate font-medium text-slate-800">{a.fileName}</span><span className="text-[11px] text-slate-400">{fileSize(a.fileSize)} · {a.mimeType}</span></span>
                </li>
              ))}
              {attachments.length === 0 && <Empty title="No attachments" hint="Photos, reports and compliance documents are recorded here (metadata only in this build)." />}
            </ul>
            {canEdit && (
              <div className="mt-3 flex gap-2">
                <input value={attachName} onChange={(e) => setAttachName(e.target.value)} placeholder="File name, e.g. inspection-photo.jpg…" className={inputCls} />
                <button onClick={addAttachment} className="shrink-0 rounded-lg border border-slate-200 px-3 text-sm font-semibold text-slate-700 hover:bg-slate-50">Record</button>
              </div>
            )}
          </div>

          {/* activity */}
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="flex items-center gap-1.5 text-sm font-bold text-slate-900"><History size={15} /> Activity timeline</h2>
            <ol className="relative mt-4 space-y-4 border-l-2 border-slate-100 pl-5">
              {activity.map((a) => (
                <li key={a.id} className="relative">
                  <span className="absolute -left-[27px] top-0.5 h-3 w-3 rounded-full bg-blue-500 ring-4 ring-blue-50" />
                  <p className="text-[13px] text-slate-800">{a.summary}</p>
                  <p className="text-[11px] text-slate-400">{a.actor?.name ?? "System"} · {fmtDateTime(a.createdAt)} · <span className="font-mono">{a.action}</span></p>
                </li>
              ))}
              {activity.length === 0 && <Empty title="No activity yet" />}
            </ol>
            <p className="mt-3 text-[11px] text-slate-400">Audit trail records who created, assigned, edited, rescheduled, completed or cancelled each task and when. Tenant identification data and document contents are never logged here.</p>
          </div>
        </div>

        {/* side */}
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="text-xs font-bold uppercase tracking-wide text-slate-500">Details</h2>
            <dl className="mt-3 space-y-2.5 text-sm">
              <div className="flex justify-between gap-2"><dt className="text-slate-500">Category</dt><dd className="font-semibold text-slate-800">{t.category ? <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: t.category.color }} />{t.category.name}</span> : "—"}</dd></div>
              <div className="flex justify-between gap-2"><dt className="text-slate-500">Assignee</dt><dd className="font-semibold text-slate-800">{t.assignee ? <span className="inline-flex items-center gap-1.5"><Avatar name={t.assignee.name} color={t.assignee.avatarColor} size="sm" />{t.assignee.name}</span> : "Unassigned"}</dd></div>
              <div className="flex justify-between gap-2"><dt className="text-slate-500">Start</dt><dd className="font-semibold">{fmtDate(t.startDate)}</dd></div>
              <div className="flex justify-between gap-2"><dt className="text-slate-500">Due</dt><dd className="font-semibold">{fmtDate(t.dueDate)}{t.dueTime ? ` · ${t.dueTime}` : ""}</dd></div>
              <div className="flex justify-between gap-2"><dt className="text-slate-500">Property</dt><dd className="text-right font-semibold">{t.property?.name ?? "—"}</dd></div>
              {t.unit && <div className="flex justify-between gap-2"><dt className="text-slate-500">Unit</dt><dd className="font-semibold">{t.unit.unitNumber}</dd></div>}
              {t.tenant && <div className="flex justify-between gap-2"><dt className="text-slate-500">Tenant</dt><dd className="font-semibold">{t.tenant.fullName}</dd></div>}
              {t.vendor && <div className="flex justify-between gap-2"><dt className="text-slate-500">Vendor</dt><dd className="font-semibold">{t.vendor.name}</dd></div>}
              {t.maintenanceRequest && <div className="flex justify-between gap-2"><dt className="text-slate-500">Maint. req.</dt><dd className="font-semibold">{t.maintenanceRequest.referenceNumber}</dd></div>}
              {t.project && <div className="flex justify-between gap-2"><dt className="text-slate-500">Project</dt><dd className="text-right font-semibold">{t.project.name}</dd></div>}
              {t.lease && <div className="flex justify-between gap-2"><dt className="text-slate-500">Lease</dt><dd className="font-mono text-xs font-semibold">{t.lease.id.slice(0, 8)}…</dd></div>}
            </dl>
          </div>

          {t.recurrence && (
            <div className="rounded-xl border border-violet-200 bg-violet-50/50 p-5">
              <h2 className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-violet-700"><Repeat size={13} /> Recurring series</h2>
              <p className="mt-1 text-sm font-semibold text-slate-900">{t.recurrence.title}</p>
              <p className="text-xs text-slate-500">{t.recurrence.frequency} · {t.recurrence.status} · next {fmtDate(t.recurrence.nextOccurrenceDate)}</p>
              <Link href="/scheduled-tasks" className="mt-2 inline-block text-xs font-semibold text-violet-700 hover:underline">Manage in Series tab →</Link>
            </div>
          )}

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="text-xs font-bold uppercase tracking-wide text-slate-500">Reminders ({reminders.length})</h2>
            <ul className="mt-2 space-y-1.5">
              {reminders.map((r) => (
                <li key={r.id} className="flex items-center justify-between rounded-lg bg-slate-50 px-2.5 py-1.5 text-xs">
                  <span className="font-semibold text-slate-700">{fmtDateTime(r.remindAt)} · {r.channel}</span>
                  <span className="rounded-full bg-slate-200 px-1.5 py-0.5 font-bold text-slate-600">{r.status}</span>
                </li>
              ))}
              {reminders.length === 0 && <p className="text-xs text-slate-400">No reminders scheduled.</p>}
            </ul>
            <p className="mt-2 text-[11px] text-slate-400">Delivery (email / in-app / SMS) is executed by Workflow Automation subscriptions to reminder schedules — this module owns the schedule, not the send.</p>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <Field label="Change status">
              <div className="flex flex-wrap gap-1.5">
                {["Not Started", "In Progress", "Blocked"].map((s) => (
                  <button key={s} onClick={() => act("status", { status: s })} className={cx("rounded-lg border px-2.5 py-1.5 text-xs font-semibold", t.status === s ? "border-slate-900 bg-slate-900 text-white" : "border-slate-200 text-slate-600 hover:bg-slate-50")}>{s}</button>
                ))}
              </div>
            </Field>
          </div>
        </div>
      </div>

      <TaskDrawer open={drawer} onClose={() => setDrawer(false)} onSaved={load} editing={task} categories={categories} users={users} lookups={lookups} />
    </div>
  );
}
