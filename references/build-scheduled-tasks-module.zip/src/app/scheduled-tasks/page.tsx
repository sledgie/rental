"use client";

import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import TaskWorkspace from "@/components/tasks/TaskWorkspace";

function Inner() {
  const sp = useSearchParams();
  return <TaskWorkspace initialSearch={sp.get("search") ?? ""} initialQuick={sp.get("quick") ?? ""} />;
}

export default function ScheduledTasksPage() {
  return (
    <Suspense fallback={<div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">Loading workspace…</div>}>
      <Inner />
    </Suspense>
  );
}
