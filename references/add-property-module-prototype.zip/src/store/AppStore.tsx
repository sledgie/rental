import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Owner, PropertyRecord } from "../types/property";
import { INITIAL_OWNERS, SEED_PROPERTIES } from "../data/mockProperties";

interface AppStoreValue {
  properties: PropertyRecord[];
  owners: Owner[];
  addProperty: (p: PropertyRecord) => void;
  updateProperty: (p: PropertyRecord) => void;
  deleteProperty: (id: string) => void;
  addOwner: (o: Owner) => void;
  getProperty: (id: string) => PropertyRecord | undefined;
  getOwner: (id: string) => Owner | undefined;
}

const AppStoreContext = createContext<AppStoreValue | null>(null);

export function useAppStore() {
  const ctx = useContext(AppStoreContext);
  if (!ctx) throw new Error("useAppStore must be used within AppStoreProvider");
  return ctx;
}

const PROPS_KEY = "rentalos.properties.v1";
const OWNERS_KEY = "rentalos.owners.v1";

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function AppStoreProvider({ children }: { children: ReactNode }) {
  const [properties, setProperties] = useState<PropertyRecord[]>(() =>
    load(PROPS_KEY, SEED_PROPERTIES)
  );
  const [owners, setOwners] = useState<Owner[]>(() => load(OWNERS_KEY, INITIAL_OWNERS));

  useEffect(() => {
    try {
      localStorage.setItem(PROPS_KEY, JSON.stringify(properties));
    } catch {
      /* storage may be full (large images) — ignore for prototype */
    }
  }, [properties]);

  useEffect(() => {
    try {
      localStorage.setItem(OWNERS_KEY, JSON.stringify(owners));
    } catch {
      /* ignore */
    }
  }, [owners]);

  const value: AppStoreValue = {
    properties,
    owners,
    addProperty: (p) => setProperties((prev) => [p, ...prev]),
    updateProperty: (p) =>
      setProperties((prev) => prev.map((x) => (x.id === p.id ? p : x))),
    deleteProperty: (id) => setProperties((prev) => prev.filter((x) => x.id !== id)),
    addOwner: (o) => setOwners((prev) => [...prev, o]),
    getProperty: (id) => properties.find((p) => p.id === id),
    getOwner: (id) => owners.find((o) => o.id === id),
  };

  return <AppStoreContext.Provider value={value}>{children}</AppStoreContext.Provider>;
}

export function generatePropertyId(): string {
  const year = new Date().getFullYear();
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `PROP-${year}-${rand}`;
}
