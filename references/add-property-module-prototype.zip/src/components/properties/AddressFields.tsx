import { useEffect, useRef } from "react";
import { MapPin } from "lucide-react";
import { Field } from "../ui/Field";
import { Input, Select } from "../ui/Input";
import { COUNTRIES, REGION_TIMEZONE_MAP, TIME_ZONES } from "../../data/mockProperties";
import type { SectionProps } from "./PropertyFormSection";

export function AddressFields({ form, set, errors }: SectionProps) {
  const tzTouched = useRef(false);

  // Suggest a time zone from the province/state unless the user picked one manually.
  useEffect(() => {
    if (tzTouched.current) return;
    const key = form.provinceState.trim().toLowerCase();
    const suggestion = REGION_TIMEZONE_MAP[key];
    if (suggestion && suggestion !== form.timeZone) {
      set("timeZone", suggestion);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.provinceState]);

  const hasAddress = form.streetAddress && form.city;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-x-5 gap-y-4 md:grid-cols-2">
        <Field label="Country" htmlFor="country" required error={errors.country}>
          <Select
            id="country"
            value={form.country}
            invalid={!!errors.country}
            onChange={(e) => set("country", e.target.value)}
          >
            {COUNTRIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </Select>
        </Field>

        <Field label="Street Address" htmlFor="streetAddress" required error={errors.streetAddress}>
          <Input
            id="streetAddress"
            value={form.streetAddress}
            invalid={!!errors.streetAddress}
            onChange={(e) => set("streetAddress", e.target.value)}
            placeholder="e.g. 2180 Lakeshore Blvd W"
          />
        </Field>

        <Field label="Unit / Suite" htmlFor="unitSuite" hint="Optional — for a specific suite or lot.">
          <Input
            id="unitSuite"
            value={form.unitSuite}
            onChange={(e) => set("unitSuite", e.target.value)}
            placeholder="e.g. Suite 400"
          />
        </Field>

        <Field label="City" htmlFor="city" required error={errors.city}>
          <Input
            id="city"
            value={form.city}
            invalid={!!errors.city}
            onChange={(e) => set("city", e.target.value)}
            placeholder="e.g. Toronto"
          />
        </Field>

        <Field label="Province / State" htmlFor="provinceState" required error={errors.provinceState}>
          <Input
            id="provinceState"
            value={form.provinceState}
            invalid={!!errors.provinceState}
            onChange={(e) => set("provinceState", e.target.value)}
            placeholder="e.g. Ontario"
          />
        </Field>

        <Field label="Postal / ZIP Code" htmlFor="postalCode" required error={errors.postalCode}>
          <Input
            id="postalCode"
            value={form.postalCode}
            invalid={!!errors.postalCode}
            onChange={(e) => set("postalCode", e.target.value)}
            placeholder="e.g. M8V 1A3"
          />
        </Field>

        <Field
          label="Time Zone"
          htmlFor="timeZone"
          hint="Suggested automatically from the property location — adjust if needed."
          className="md:col-span-2"
        >
          <Select
            id="timeZone"
            value={form.timeZone}
            onChange={(e) => {
              tzTouched.current = true;
              set("timeZone", e.target.value);
            }}
          >
            <option value="">Select a time zone…</option>
            {TIME_ZONES.map((tz) => (
              <option key={tz} value={tz}>{tz}</option>
            ))}
          </Select>
        </Field>
      </div>

      {/* Map preview placeholder */}
      <div className="relative flex h-40 items-center justify-center overflow-hidden rounded-lg border border-zinc-800 bg-zinc-900">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "linear-gradient(#27272a 1px, transparent 1px), linear-gradient(90deg, #27272a 1px, transparent 1px)",
            backgroundSize: "28px 28px",
          }}
        />
        <div className="relative flex flex-col items-center gap-1.5 text-center px-4">
          <MapPin size={22} className="text-indigo-400" />
          {hasAddress ? (
            <>
              <p className="text-sm font-medium text-zinc-200">
                {form.streetAddress}
                {form.unitSuite ? `, ${form.unitSuite}` : ""}
              </p>
              <p className="text-xs text-zinc-500">
                {[form.city, form.provinceState, form.postalCode, form.country].filter(Boolean).join(", ")}
              </p>
            </>
          ) : (
            <p className="text-xs text-zinc-500">Map preview — enter an address to see it here.</p>
          )}
        </div>
      </div>
    </div>
  );
}
