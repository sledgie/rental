import { useState } from "react";
import { FileText, Paperclip, Plus, Trash2, UserPlus, X } from "lucide-react";
import { Field } from "../ui/Field";
import { Input, Select } from "../ui/Input";
import { Button } from "../ui/Button";
import { Modal } from "../ui/Modal";
import { useToast } from "../ui/Toast";
import { useAppStore } from "../../store/AppStore";
import { MANAGEMENT_COMPANIES, STAFF } from "../../data/mockProperties";
import type { Owner, OwnershipType } from "../../types/property";
import type { SectionProps } from "./PropertyFormSection";

export function OwnershipFields({ form, set, errors }: SectionProps) {
  const { owners, addOwner } = useAppStore();
  const { toast } = useToast();
  const [modalOpen, setModalOpen] = useState(false);
  const [newOwner, setNewOwner] = useState({ name: "", type: "individual" as Owner["type"], email: "", phone: "" });
  const [ownerErr, setOwnerErr] = useState<string | null>(null);

  const isJoint = form.ownershipType === "joint";

  const createOwner = () => {
    if (!newOwner.name.trim()) {
      setOwnerErr("Owner name is required.");
      return;
    }
    if (newOwner.email && !/^\S+@\S+\.\S+$/.test(newOwner.email)) {
      setOwnerErr("Enter a valid email address.");
      return;
    }
    const owner: Owner = {
      id: `own-${Date.now().toString(36)}`,
      name: newOwner.name.trim(),
      type: newOwner.type,
      email: newOwner.email.trim(),
      phone: newOwner.phone.trim() || undefined,
    };
    addOwner(owner);
    set("ownerId", owner.id);
    setModalOpen(false);
    setNewOwner({ name: "", type: "individual", email: "", phone: "" });
    setOwnerErr(null);
    toast("success", "Owner created", `${owner.name} was added and linked to this property.`);
  };

  const addShare = () => {
    set("ownerShares", [...form.ownerShares, { ownerId: "", percentage: "" }]);
  };

  const updateShare = (idx: number, key: "ownerId" | "percentage", value: string) => {
    const next = form.ownerShares.map((s, i) => (i === idx ? { ...s, [key]: value } : s));
    set("ownerShares", next);
  };

  const removeShare = (idx: number) => {
    set("ownerShares", form.ownerShares.filter((_, i) => i !== idx));
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-x-5 gap-y-4 md:grid-cols-2">
        <Field
          label="Property Owner"
          htmlFor="ownerId"
          required
          error={errors.ownerId}
          hint="Properties reference an existing owner record — details stay in one place."
        >
          <div className="flex gap-2">
            <Select
              id="ownerId"
              value={form.ownerId}
              invalid={!!errors.ownerId}
              onChange={(e) => set("ownerId", e.target.value)}
            >
              <option value="">Select an owner…</option>
              {owners.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.name} {o.type === "organization" ? "(Org)" : ""}
                </option>
              ))}
            </Select>
            <Button type="button" variant="outline" className="shrink-0" onClick={() => setModalOpen(true)}>
              <UserPlus size={15} /> New
            </Button>
          </div>
        </Field>

        <Field label="Ownership Type" htmlFor="ownershipType">
          <Select
            id="ownershipType"
            value={form.ownershipType}
            onChange={(e) => set("ownershipType", e.target.value as OwnershipType)}
          >
            <option value="">Select…</option>
            <option value="individual">Individual</option>
            <option value="joint">Joint Ownership</option>
            <option value="corporation">Corporation</option>
            <option value="other">Other</option>
          </Select>
        </Field>
      </div>

      {isJoint && (
        <div className="rounded-lg border border-zinc-800 bg-zinc-900/70 p-4">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-[13px] font-medium text-zinc-300">Ownership Split</p>
            <Button type="button" variant="outline" size="sm" onClick={addShare}>
              <Plus size={13} /> Add Co-owner
            </Button>
          </div>
          {form.ownerShares.length === 0 ? (
            <p className="text-xs text-zinc-500">
              Add each co-owner and their ownership percentage. Percentages should total 100%.
            </p>
          ) : (
            <div className="space-y-2">
              {form.ownerShares.map((share, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Select
                    aria-label={`Co-owner ${idx + 1}`}
                    value={share.ownerId}
                    onChange={(e) => updateShare(idx, "ownerId", e.target.value)}
                    className="flex-1"
                  >
                    <option value="">Select owner…</option>
                    {owners.map((o) => (
                      <option key={o.id} value={o.id}>{o.name}</option>
                    ))}
                  </Select>
                  <div className="relative w-28 shrink-0">
                    <Input
                      aria-label={`Ownership percentage ${idx + 1}`}
                      type="number"
                      min={0}
                      max={100}
                      value={share.percentage}
                      onChange={(e) => updateShare(idx, "percentage", e.target.value)}
                      placeholder="50"
                      className="pr-7"
                    />
                    <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-500">%</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeShare(idx)}
                    aria-label="Remove co-owner"
                    className="rounded-md p-2 text-zinc-500 hover:bg-zinc-800 hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
            </div>
          )}
          {errors.ownerShares && <p className="mt-2 text-xs text-red-400">{errors.ownerShares}</p>}
        </div>
      )}

      <div className="grid grid-cols-1 gap-x-5 gap-y-4 md:grid-cols-2">
        <Field label="Property Manager" htmlFor="propertyManagerId" hint="Optional — assign from existing staff.">
          <Select
            id="propertyManagerId"
            value={form.propertyManagerId}
            onChange={(e) => set("propertyManagerId", e.target.value)}
          >
            <option value="">Unassigned</option>
            {STAFF.map((s) => (
              <option key={s.id} value={s.id}>{s.name} — {s.role}</option>
            ))}
          </Select>
        </Field>

        <Field label="Management Company" htmlFor="managementCompanyId">
          <Select
            id="managementCompanyId"
            value={form.managementCompanyId}
            onChange={(e) => set("managementCompanyId", e.target.value)}
          >
            <option value="">None / self-managed</option>
            {MANAGEMENT_COMPANIES.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </Select>
        </Field>

        <Field label="Management Start Date" htmlFor="managementStartDate">
          <Input
            id="managementStartDate"
            type="date"
            value={form.managementStartDate}
            onChange={(e) => set("managementStartDate", e.target.value)}
            className="[color-scheme:dark]"
          />
        </Field>

        <div className="hidden md:block" />

        <Field label="Emergency Contact Name" htmlFor="emergencyContactName">
          <Input
            id="emergencyContactName"
            value={form.emergencyContactName}
            onChange={(e) => set("emergencyContactName", e.target.value)}
            placeholder="e.g. On-call superintendent"
          />
        </Field>

        <Field label="Emergency Contact Phone" htmlFor="emergencyContactPhone" error={errors.emergencyContactPhone}>
          <Input
            id="emergencyContactPhone"
            type="tel"
            value={form.emergencyContactPhone}
            invalid={!!errors.emergencyContactPhone}
            onChange={(e) => set("emergencyContactPhone", e.target.value)}
            placeholder="e.g. +1 (416) 555-0100"
          />
        </Field>
      </div>

      <Field label="Management Agreement" hint="Attach the signed management agreement (simulated for this prototype).">
        {form.managementAgreementFile ? (
          <div className="flex items-center gap-3 rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2.5 max-w-md">
            <FileText size={16} className="shrink-0 text-indigo-400" />
            <span className="flex-1 truncate text-sm text-zinc-200">{form.managementAgreementFile}</span>
            <button
              type="button"
              aria-label="Remove agreement"
              onClick={() => set("managementAgreementFile", "")}
              className="text-zinc-500 hover:text-red-400"
            >
              <X size={15} />
            </button>
          </div>
        ) : (
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-zinc-700 px-4 py-2.5 text-sm text-zinc-400 transition-colors hover:border-indigo-500/50 hover:text-zinc-200">
            <Paperclip size={15} />
            Attach agreement document
            <input
              type="file"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) set("managementAgreementFile", f.name);
              }}
            />
          </label>
        )}
      </Field>

      {/* New owner modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title="Create New Owner"
        description="The owner record is stored once and can be linked to any property."
        footer={
          <>
            <Button variant="ghost" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button variant="primary" onClick={createOwner}>Create Owner</Button>
          </>
        }
      >
        <div className="space-y-4">
          {ownerErr && (
            <p className="rounded-lg border border-red-600/40 bg-red-500/10 px-3 py-2 text-xs text-red-400">{ownerErr}</p>
          )}
          <Field label="Owner Name" htmlFor="newOwnerName" required>
            <Input
              id="newOwnerName"
              value={newOwner.name}
              onChange={(e) => setNewOwner({ ...newOwner, name: e.target.value })}
              placeholder="Full name or company name"
            />
          </Field>
          <Field label="Owner Type" htmlFor="newOwnerType">
            <Select
              id="newOwnerType"
              value={newOwner.type}
              onChange={(e) => setNewOwner({ ...newOwner, type: e.target.value as Owner["type"] })}
            >
              <option value="individual">Individual</option>
              <option value="organization">Organization</option>
            </Select>
          </Field>
          <Field label="Email" htmlFor="newOwnerEmail">
            <Input
              id="newOwnerEmail"
              type="email"
              value={newOwner.email}
              onChange={(e) => setNewOwner({ ...newOwner, email: e.target.value })}
              placeholder="owner@example.com"
            />
          </Field>
          <Field label="Phone" htmlFor="newOwnerPhone">
            <Input
              id="newOwnerPhone"
              type="tel"
              value={newOwner.phone}
              onChange={(e) => setNewOwner({ ...newOwner, phone: e.target.value })}
              placeholder="+1 (416) 555-0100"
            />
          </Field>
        </div>
      </Modal>
    </div>
  );
}
