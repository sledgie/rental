import type { ReactNode } from "react";
import { cn } from "../../utils/cn";

type Tone = "green" | "amber" | "red" | "gray" | "indigo";

const tones: Record<Tone, string> = {
  green: "bg-emerald-500/10 text-emerald-400 border-emerald-600/40",
  amber: "bg-amber-500/10 text-amber-400 border-amber-600/40",
  red: "bg-red-500/10 text-red-400 border-red-600/40",
  gray: "bg-zinc-500/10 text-zinc-400 border-zinc-600/40",
  indigo: "bg-indigo-500/10 text-indigo-400 border-indigo-600/40",
};

export function Badge({ tone = "gray", children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

export function statusTone(status: string): Tone {
  switch (status) {
    case "active":
      return "green";
    case "under_renovation":
      return "amber";
    case "sold":
      return "red";
    default:
      return "gray";
  }
}
