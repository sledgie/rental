import type { LucideIcon } from "lucide-react";

interface PlaceholderPageProps {
  title: string;
  description: string;
  icon: LucideIcon;
}

export function PlaceholderPage({ title, description, icon: Icon }: PlaceholderPageProps) {
  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="text-2xl font-semibold tracking-tight text-zinc-50">{title}</h1>
      <p className="mt-1 text-sm text-zinc-400">{description}</p>
      <div className="mt-8 flex flex-col items-center justify-center gap-4 rounded-xl border border-dashed border-zinc-800 py-24 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-zinc-800/80 text-zinc-500">
          <Icon size={26} />
        </div>
        <div>
          <p className="text-sm font-medium text-zinc-200">The {title} module is coming soon</p>
          <p className="mt-1 max-w-sm text-xs leading-relaxed text-zinc-500">
            This area is part of the full RentalOS platform. The current prototype focuses on the
            Properties module.
          </p>
        </div>
      </div>
    </div>
  );
}
