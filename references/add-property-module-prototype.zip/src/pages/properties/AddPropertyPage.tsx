import { useParams } from "react-router-dom";
import { PropertyForm } from "../../components/properties/PropertyForm";
import { useAppStore } from "../../store/AppStore";
import { NotFoundNotice } from "./PropertyDetailPage";

export function AddPropertyPage() {
  return (
    <div className="mx-auto max-w-6xl">
      <PropertyForm />
    </div>
  );
}

export function EditPropertyPage() {
  const { id } = useParams<{ id: string }>();
  const { getProperty } = useAppStore();
  const property = id ? getProperty(id) : undefined;

  if (!property) return <NotFoundNotice />;

  return (
    <div className="mx-auto max-w-6xl">
      <PropertyForm key={property.id} existing={property} />
    </div>
  );
}
