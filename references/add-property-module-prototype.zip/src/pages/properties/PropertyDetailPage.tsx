import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import {
  Building2,
  CalendarDays,
  DollarSign,
  DoorOpen,
  FileText,
  Hammer,
  LayoutGrid,
  MapPin,
  Pencil,
  Plus,
  Receipt,
  Settings,
  ShieldCheck,
  Trash2,
  Users,
  Wrench,
} from "lucide-react";
import { useState } from "react";
import { useAppStore } from "../../store/AppStore";
import { Badge, statusTone } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Modal } from "../../components/ui/Modal";
import { useToast } from "../../components/ui/Toast";
import {
  MANAGEMENT_COMPANIES,
  OWNERSHIP_TYPE_LABELS,
  PROPERTY_TYPE_LABELS,
  STAFF,
  STATUS_LABELS,
} from "../../data/mockProperties";
import { formatCurrency } from "../../components/properties/validation";
import { isMultiUnitType } from "../../types/property";
import { cn } from "../../utils/cn";

export function NotFoundNotice() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center gap-4 py-24 text-center">
      <Building2 size={36} className="text-zinc-600" />
      <h1 className="text-lg font-semibold text-zinc-100">Property not found</h1>
      <p className="text-sm text-zinc-400">
        The property you're looking for doesn't exist or may have been removed.
      </p>
      <Link to="/properties">
        <Button variant="outline">Back to Properties</Button>
      </Link>
    </div>
  );
}

const TABS = [
  { id: "overview", label: "Overview", icon: LayoutGrid },
  { id: "units", label: "Units", icon: DoorOpen },
  { id: "tenants", label: "Tenants & Leases", icon: Users },
  { id: "invoices", label: "Invoices & Expenses", icon: Receipt },
  { id: "maintenance", label: "Maintenance", icon: Wrench },
  { id: "renovations", label: "Renovation Projects", icon: Hammer },
  { id: "documents", label: "Documents", icon: FileText },
  { id: "settings", label: "Settings", icon: Settings },
];

function InfoRow({ label, value }: { label: string; value?: string | null }) {
  return (
    <div className="flex items-start justify-between gap-4 py-2.5">
      <span className="text-[13px] text-zinc-500">{label}</span>
      <span className="text-right text-[13px] font-medium text-zinc-200">{value || "—"}</span>
    </div>
  );
}

function EmptyTab({ icon: Icon, title, body, action }: { icon: typeof Users; title: string; body: string; action?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-zinc-800 py-16 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-zinc-800/80 text-zinc-500">
        <Icon size={22} />
      </div>
      <p className="text-sm font-medium text-zinc-200">{title}</p>
      <p className="max-w-sm text-xs leading-relaxed text-zinc-500">{body}</p>
      {action && (
        <Button variant="outline" size="sm">
          <Plus size={13} /> {action}
        </Button>
      )}
    </div>
  );
}

export function PropertyDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { getProperty, getOwner, deleteProperty } = useAppStore();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [deleteModal, setDeleteModal] = useState(false);

  const property = id ? getProperty(id) : undefined;
  if (!property) return <NotFoundNotice />;

  const tab = searchParams.get("tab") ?? "overview";
  const owner = property.ownerId ? getOwner(property.ownerId) : undefined;
  const manager = STAFF.find((s) => s.id === property.propertyManagerId);
  const mgmtCo = MANAGEMENT_COMPANIES.find((m) => m.id === property.managementCompanyId);
  const cur = property.defaultCurrency || "CAD";
  const multiUnit = isMultiUnitType(property.propertyType);

  const addressLine = [
    property.streetAddress,
    property.unitSuite,
    property.city,
    property.provinceState,
    property.postalCode,
  ]
    .filter(Boolean)
    .join(", ");

  const confirmDelete = () => {
    deleteProperty(property.id);
    toast("success", "Property removed", `${property.name} was deleted from your portfolio.`);
    navigate("/properties");
  };

  return (
    <div className="mx-auto max-w-6xl">
      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="mb-4 flex items-center gap-1.5 text-xs text-zinc-500">
        <Link to="/properties" className="transition-colors hover:text-zinc-300">Properties</Link>
        <span>/</span>
        <span className="text-zinc-300">{property.name}</span>
      </nav>

      {/* Hero */}
      <div className="overflow-hidden rounded-xl border border-zinc-800/80 bg-zinc-900/50">
        <div className="relative h-48 bg-zinc-800 sm:h-60">
          {property.coverImage ? (
            <img src={property.coverImage} alt={property.name} className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full items-center justify-center text-zinc-600">
              <Building2 size={40} />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-zinc-950/20 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 flex flex-wrap items-end justify-between gap-3 p-5">
            <div>
              <div className="mb-1.5 flex flex-wrap items-center gap-2">
                <Badge tone={statusTone(property.status)}>{STATUS_LABELS[property.status] ?? "—"}</Badge>
                {property.isDraft && <Badge tone="amber">Draft</Badge>}
                <span className="font-mono text-[11px] text-zinc-400">{property.id}</span>
              </div>
              <h1 className="text-xl font-semibold tracking-tight text-white sm:text-2xl">{property.name}</h1>
              <p className="mt-1 flex items-center gap-1.5 text-xs text-zinc-300">
                <MapPin size={12} />
                {addressLine || "No address provided"}
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" onClick={() => setDeleteModal(true)} aria-label="Delete property">
                <Trash2 size={14} />
              </Button>
              <Button variant="primary" size="sm" onClick={() => navigate(`/properties/${property.id}/edit`)}>
                <Pencil size={14} /> Edit Property
              </Button>
            </div>
          </div>
        </div>

        {/* Key stats */}
        <div className="grid grid-cols-2 divide-zinc-800/80 border-t border-zinc-800/80 sm:grid-cols-4 sm:divide-x">
          {[
            { label: "Type", value: PROPERTY_TYPE_LABELS[property.propertyType] ?? "—", icon: Building2 },
            { label: "Units", value: property.numberOfUnits || "1", icon: DoorOpen },
            { label: "Owner", value: owner?.name ?? "—", icon: Users },
            {
              label: "Est. Value",
              value: property.currentEstimatedValue ? formatCurrency(property.currentEstimatedValue, cur) : "—",
              icon: DollarSign,
            },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} className="flex items-center gap-3 px-5 py-4">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-indigo-500/10 text-indigo-400">
                <Icon size={16} />
              </div>
              <div className="min-w-0">
                <p className="text-[11px] uppercase tracking-wide text-zinc-500">{label}</p>
                <p className="truncate text-sm font-semibold text-zinc-100">{value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-6 flex gap-1 overflow-x-auto border-b border-zinc-800/80 pb-px">
        {TABS.map(({ id: tid, label, icon: Icon }) => (
          <button
            key={tid}
            onClick={() => setSearchParams(tid === "overview" ? {} : { tab: tid })}
            className={cn(
              "flex shrink-0 items-center gap-2 border-b-2 px-3.5 py-2.5 text-[13px] font-medium transition-colors",
              tab === tid
                ? "border-indigo-500 text-indigo-300"
                : "border-transparent text-zinc-500 hover:text-zinc-200"
            )}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </div>

      <div className="py-6">
        {tab === "overview" && (
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
            <div className="space-y-5 lg:col-span-2">
              {property.description && (
                <div className="rounded-xl border border-zinc-800/80 bg-zinc-900/50 p-5">
                  <h2 className="mb-2 text-sm font-semibold text-zinc-100">About this property</h2>
                  <p className="text-sm leading-relaxed text-zinc-400">{property.description}</p>
                </div>
              )}

              <div className="rounded-xl border border-zinc-800/80 bg-zinc-900/50 p-5">
                <h2 className="mb-1 text-sm font-semibold text-zinc-100">Configuration</h2>
                <div className="divide-y divide-zinc-800/80">
                  <InfoRow label="Building Type" value={property.buildingType} />
                  <InfoRow label="Year Built" value={property.yearBuilt} />
                  <InfoRow
                    label="Building Area"
                    value={property.totalBuildingArea ? `${Number(property.totalBuildingArea).toLocaleString()} ${property.areaUnit === "sqm" ? "sq m" : "sq ft"}` : undefined}
                  />
                  <InfoRow
                    label="Lot Size"
                    value={property.lotSize ? `${Number(property.lotSize).toLocaleString()} ${property.lotSizeUnit}` : undefined}
                  />
                  <InfoRow label="Parking Spaces" value={property.parkingSpaces} />
                  {!multiUnit && <InfoRow label="Bedrooms" value={property.bedrooms} />}
                  {!multiUnit && <InfoRow label="Bathrooms" value={property.bathrooms} />}
                  <InfoRow label="Furnishing" value={property.furnishingStatus ? property.furnishingStatus.replace("_", " ") : undefined} />
                  <InfoRow label="Heating" value={property.heatingType} />
                  <InfoRow label="Time Zone" value={property.timeZone} />
                </div>
                {property.amenities.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5 border-t border-zinc-800/80 pt-4">
                    {property.amenities.map((a) => (
                      <Badge key={a} tone="indigo">{a}</Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-xl border border-zinc-800/80 bg-zinc-900/50 p-5">
                <h2 className="mb-1 flex items-center gap-2 text-sm font-semibold text-zinc-100">
                  <DollarSign size={14} className="text-indigo-400" /> Financial Summary
                </h2>
                <div className="divide-y divide-zinc-800/80">
                  <InfoRow label="Purchase Price" value={property.purchasePrice ? formatCurrency(property.purchasePrice, cur) : undefined} />
                  <InfoRow label="Purchase Date" value={property.purchaseDate} />
                  <InfoRow label="Current Estimated Value" value={property.currentEstimatedValue ? formatCurrency(property.currentEstimatedValue, cur) : undefined} />
                  <InfoRow
                    label="Property Tax"
                    value={property.propertyTaxAmount ? `${formatCurrency(property.propertyTaxAmount, cur)}${property.propertyTaxFrequency ? ` / ${property.propertyTaxFrequency}` : ""}` : undefined}
                  />
                  <InfoRow label="Insurance Provider" value={property.insuranceProvider} />
                  <InfoRow label="Mortgage Lender" value={property.mortgageLender} />
                  <InfoRow label="Currency" value={cur} />
                </div>
              </div>
            </div>

            <div className="space-y-5">
              <div className="rounded-xl border border-zinc-800/80 bg-zinc-900/50 p-5">
                <h2 className="mb-1 flex items-center gap-2 text-sm font-semibold text-zinc-100">
                  <ShieldCheck size={14} className="text-indigo-400" /> Ownership & Management
                </h2>
                <div className="divide-y divide-zinc-800/80">
                  <InfoRow label="Owner" value={owner?.name} />
                  <InfoRow label="Ownership Type" value={property.ownershipType ? OWNERSHIP_TYPE_LABELS[property.ownershipType] : undefined} />
                  <InfoRow label="Property Manager" value={manager?.name} />
                  <InfoRow label="Management Co." value={mgmtCo?.name} />
                  <InfoRow label="Emergency Contact" value={property.emergencyContactName} />
                  <InfoRow label="Emergency Phone" value={property.emergencyContactPhone} />
                </div>
                {property.ownershipType === "joint" && property.ownerShares.length > 0 && (
                  <div className="mt-3 space-y-1.5 border-t border-zinc-800/80 pt-4">
                    <p className="text-xs font-medium text-zinc-400">Ownership Split</p>
                    {property.ownerShares.map((s, i) => {
                      const o = getOwner(s.ownerId);
                      return (
                        <div key={i} className="flex justify-between text-[13px]">
                          <span className="text-zinc-300">{o?.name ?? "Unknown owner"}</span>
                          <span className="font-medium text-indigo-300">{s.percentage}%</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="rounded-xl border border-zinc-800/80 bg-zinc-900/50 p-5">
                <h2 className="mb-1 flex items-center gap-2 text-sm font-semibold text-zinc-100">
                  <CalendarDays size={14} className="text-indigo-400" /> Key Dates
                </h2>
                <div className="divide-y divide-zinc-800/80">
                  <InfoRow label="Date Acquired" value={property.dateAcquired} />
                  <InfoRow label="Insurance Expiry" value={property.insurancePolicyExpiry} />
                  <InfoRow label="Last Inspection" value={property.lastInspectionDate} />
                  <InfoRow label="Next Inspection" value={property.nextInspectionDate} />
                  <InfoRow label="Warranty Expiry" value={property.warrantyExpiryDate} />
                  <InfoRow label="Created" value={new Date(property.createdAt).toLocaleDateString()} />
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === "units" && (
          <EmptyTab
            icon={DoorOpen}
            title={multiUnit ? `No units created yet (${property.numberOfUnits} expected)` : "Single-unit property"}
            body={
              multiUnit
                ? "Create units to track bedrooms, bathrooms, rent amounts, and occupancy individually for each unit in this building."
                : "This property is managed as a single rental unit. Unit-level details are shown on the Overview tab."
            }
            action={multiUnit ? "Create Units" : undefined}
          />
        )}
        {tab === "tenants" && (
          <EmptyTab icon={Users} title="No tenants or leases yet" body="Tenants and lease agreements linked to this property will appear here." action="Add Lease" />
        )}
        {tab === "invoices" && (
          <EmptyTab icon={Receipt} title="No invoices or expenses" body="Rental invoices, expense records, and payment history for this property will appear here." action="Create Invoice" />
        )}
        {tab === "maintenance" && (
          <div className="space-y-5">
            {(property.maintenanceInstructions || property.accessInstructions || property.defaultMaintenanceContact) && (
              <div className="rounded-xl border border-zinc-800/80 bg-zinc-900/50 p-5">
                <h2 className="mb-1 text-sm font-semibold text-zinc-100">Maintenance Defaults</h2>
                <div className="divide-y divide-zinc-800/80">
                  <InfoRow label="Default Contact" value={property.defaultMaintenanceContact} />
                  <InfoRow label="Instructions" value={property.maintenanceInstructions} />
                  <InfoRow label="Access Notes" value={property.accessInstructions} />
                </div>
              </div>
            )}
            <EmptyTab icon={Wrench} title="No maintenance requests" body="Work orders and maintenance requests for this property will appear here." action="New Request" />
          </div>
        )}
        {tab === "renovations" && (
          <EmptyTab icon={Hammer} title="No renovation projects" body="Renovation budgets, contractor invoices, materials, and schedules are managed in the Renovation Projects module and reference this property." action="Start Project" />
        )}
        {tab === "documents" && (
          <>
            {property.documents.length > 0 ? (
              <ul className="space-y-2">
                {property.documents.map((doc) => (
                  <li key={doc.id} className="flex items-center gap-3 rounded-lg border border-zinc-800/80 bg-zinc-900/50 px-4 py-3">
                    <FileText size={16} className="shrink-0 text-indigo-400" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-zinc-100">{doc.fileName}</p>
                      <p className="text-xs text-zinc-500">
                        {doc.category} · Uploaded {new Date(doc.uploadDate).toLocaleDateString()}
                        {doc.expiryDate ? ` · Expires ${doc.expiryDate}` : ""}
                      </p>
                    </div>
                    {doc.notes && <span className="hidden max-w-48 truncate text-xs text-zinc-500 sm:block">{doc.notes}</span>}
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyTab icon={FileText} title="No documents attached" body="Ownership documents, insurance papers, permits, and inspection reports will appear here." action="Upload Document" />
            )}
          </>
        )}
        {tab === "settings" && (
          <EmptyTab icon={Settings} title="Property settings" body="Notification preferences, access rules, and advanced configuration for this property will be available here." />
        )}
      </div>

      {/* Delete confirmation */}
      <Modal
        open={deleteModal}
        onClose={() => setDeleteModal(false)}
        title="Delete this property?"
        description={`${property.name} (${property.id}) will be permanently removed from your portfolio.`}
        size="sm"
        footer={
          <>
            <Button variant="ghost" onClick={() => setDeleteModal(false)}>Cancel</Button>
            <Button variant="danger" onClick={confirmDelete}>
              <Trash2 size={14} /> Delete Property
            </Button>
          </>
        }
      >
        <p className="text-sm text-zinc-400">
          This action cannot be undone in this prototype. Linked units, leases, and documents would
          also be affected.
        </p>
      </Modal>
    </div>
  );
}
