import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Building2, DoorOpen, MapPin, Plus, Search } from "lucide-react";
import { useAppStore } from "../../store/AppStore";
import { Badge, statusTone } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Input, Select } from "../../components/ui/Input";
import { PROPERTY_TYPE_LABELS, STATUS_LABELS } from "../../data/mockProperties";

export function PropertiesPage() {
  const { properties } = useAppStore();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return properties.filter((p) => {
      if (statusFilter && p.status !== statusFilter) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.city.toLowerCase().includes(q) ||
        p.streetAddress.toLowerCase().includes(q) ||
        p.id.toLowerCase().includes(q)
      );
    });
  }, [properties, query, statusFilter]);

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-zinc-50">Properties</h1>
          <p className="mt-1 text-sm text-zinc-400">
            {properties.length} propert{properties.length === 1 ? "y" : "ies"} in your portfolio
          </p>
        </div>
        <Button variant="primary" onClick={() => navigate("/properties/new")}>
          <Plus size={16} /> Add Property
        </Button>
      </div>

      <div className="mb-5 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1 sm:max-w-sm">
          <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <Input
            aria-label="Search properties"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, address, city, or ID…"
            className="pl-9"
          />
        </div>
        <Select
          aria-label="Filter by status"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="sm:w-48"
        >
          <option value="">All statuses</option>
          {Object.entries(STATUS_LABELS).map(([v, l]) => (
            <option key={v} value={v}>{l}</option>
          ))}
        </Select>
      </div>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-zinc-800 py-20 text-center">
          <Building2 size={32} className="text-zinc-600" />
          <p className="text-sm text-zinc-400">No properties match your search.</p>
          <Button variant="outline" size="sm" onClick={() => navigate("/properties/new")}>
            <Plus size={14} /> Add your first property
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((p) => (
            <Link
              key={p.id}
              to={`/properties/${p.id}`}
              className="group overflow-hidden rounded-xl border border-zinc-800/80 bg-zinc-900/50 transition-colors hover:border-zinc-700"
            >
              <div className="relative h-40 bg-zinc-800">
                {p.coverImage ? (
                  <img
                    src={p.coverImage}
                    alt={p.name}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center text-zinc-600">
                    <Building2 size={32} />
                  </div>
                )}
                <div className="absolute left-3 top-3 flex gap-2">
                  <Badge tone={statusTone(p.status)}>{STATUS_LABELS[p.status] ?? p.status}</Badge>
                  {p.isDraft && <Badge tone="amber">Draft</Badge>}
                </div>
              </div>
              <div className="p-4">
                <p className="truncate text-sm font-semibold text-zinc-100">{p.name}</p>
                <p className="mt-1 flex items-center gap-1.5 truncate text-xs text-zinc-500">
                  <MapPin size={12} className="shrink-0" />
                  {[p.streetAddress, p.city, p.provinceState].filter(Boolean).join(", ") || "No address yet"}
                </p>
                <div className="mt-3 flex items-center justify-between border-t border-zinc-800/80 pt-3 text-xs text-zinc-400">
                  <span>{PROPERTY_TYPE_LABELS[p.propertyType] ?? "—"}</span>
                  <span className="inline-flex items-center gap-1.5">
                    <DoorOpen size={13} />
                    {p.numberOfUnits || "1"} unit{Number(p.numberOfUnits) === 1 ? "" : "s"}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
