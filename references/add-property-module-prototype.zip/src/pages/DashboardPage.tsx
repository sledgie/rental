import { Link } from "react-router-dom";
import { ArrowRight, Building2, DoorOpen, DollarSign, Plus, Wrench } from "lucide-react";
import { useAppStore } from "../store/AppStore";
import { Badge, statusTone } from "../components/ui/Badge";
import { Button } from "../components/ui/Button";
import { STATUS_LABELS, PROPERTY_TYPE_LABELS } from "../data/mockProperties";
import { formatCurrency } from "../components/properties/validation";

export function DashboardPage() {
  const { properties } = useAppStore();

  const totalUnits = properties.reduce((acc, p) => acc + (Number(p.numberOfUnits) || 0), 0);
  const totalValue = properties.reduce((acc, p) => acc + (Number(p.currentEstimatedValue) || 0), 0);
  const underReno = properties.filter((p) => p.status === "under_renovation").length;

  const stats = [
    { label: "Properties", value: String(properties.length), icon: Building2 },
    { label: "Total Units", value: String(totalUnits), icon: DoorOpen },
    { label: "Portfolio Value", value: totalValue ? formatCurrency(totalValue) : "—", icon: DollarSign },
    { label: "Under Renovation", value: String(underReno), icon: Wrench },
  ];

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-zinc-50">Dashboard</h1>
          <p className="mt-1 text-sm text-zinc-400">Portfolio overview at a glance.</p>
        </div>
        <Link to="/properties/new">
          <Button variant="primary">
            <Plus size={16} /> Add Property
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map(({ label, value, icon: Icon }) => (
          <div key={label} className="rounded-xl border border-zinc-800/80 bg-zinc-900/50 p-5">
            <div className="flex items-center justify-between">
              <p className="text-xs uppercase tracking-wide text-zinc-500">{label}</p>
              <Icon size={16} className="text-indigo-400" />
            </div>
            <p className="mt-2 text-2xl font-semibold tracking-tight text-zinc-50">{value}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-xl border border-zinc-800/80 bg-zinc-900/50">
        <div className="flex items-center justify-between border-b border-zinc-800/80 px-5 py-4">
          <h2 className="text-sm font-semibold text-zinc-100">Recent Properties</h2>
          <Link to="/properties" className="flex items-center gap-1 text-xs text-indigo-400 hover:text-indigo-300">
            View all <ArrowRight size={12} />
          </Link>
        </div>
        <ul className="divide-y divide-zinc-800/80">
          {properties.slice(0, 5).map((p) => (
            <li key={p.id}>
              <Link to={`/properties/${p.id}`} className="flex items-center gap-4 px-5 py-3.5 transition-colors hover:bg-zinc-800/40">
                <div className="h-10 w-14 shrink-0 overflow-hidden rounded-md bg-zinc-800">
                  {p.coverImage ? (
                    <img src={p.coverImage} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full items-center justify-center text-zinc-600">
                      <Building2 size={14} />
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-zinc-100">{p.name}</p>
                  <p className="truncate text-xs text-zinc-500">
                    {PROPERTY_TYPE_LABELS[p.propertyType] ?? "—"} · {p.city || "No city"}
                  </p>
                </div>
                <Badge tone={statusTone(p.status)}>{STATUS_LABELS[p.status] ?? p.status}</Badge>
              </Link>
            </li>
          ))}
          {properties.length === 0 && (
            <li className="px-5 py-10 text-center text-sm text-zinc-500">
              No properties yet — add your first one to get started.
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}
