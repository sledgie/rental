import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import {
  BarChart3,
  CreditCard,
  DoorOpen,
  FileSignature,
  Hammer,
  Receipt,
  Settings,
  Users,
  Wrench,
} from "lucide-react";
import { AppLayout } from "./components/layout/AppLayout";
import { AppStoreProvider } from "./store/AppStore";
import { ToastProvider } from "./components/ui/Toast";
import { DashboardPage } from "./pages/DashboardPage";
import { PlaceholderPage } from "./pages/PlaceholderPage";
import { PropertiesPage } from "./pages/properties/PropertiesPage";
import { AddPropertyPage, EditPropertyPage } from "./pages/properties/AddPropertyPage";
import { PropertyDetailPage } from "./pages/properties/PropertyDetailPage";

export default function App() {
  return (
    <AppStoreProvider>
      <ToastProvider>
        <HashRouter>
          <Routes>
            <Route element={<AppLayout />}>
              <Route path="/" element={<Navigate to="/properties" replace />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/properties" element={<PropertiesPage />} />
              <Route path="/properties/new" element={<AddPropertyPage />} />
              <Route path="/properties/:id" element={<PropertyDetailPage />} />
              <Route path="/properties/:id/edit" element={<EditPropertyPage />} />
              <Route path="/units" element={<PlaceholderPage title="Units" description="Manage individual rental units across your properties." icon={DoorOpen} />} />
              <Route path="/tenants" element={<PlaceholderPage title="Tenants" description="Tenant profiles, contact details, and history." icon={Users} />} />
              <Route path="/leases" element={<PlaceholderPage title="Leases" description="Lease agreements, renewals, and terms." icon={FileSignature} />} />
              <Route path="/invoices" element={<PlaceholderPage title="Invoices" description="Rental invoices and billing." icon={Receipt} />} />
              <Route path="/payments" element={<PlaceholderPage title="Payments" description="Payment tracking and reconciliation." icon={CreditCard} />} />
              <Route path="/maintenance" element={<PlaceholderPage title="Maintenance" description="Work orders and maintenance requests." icon={Wrench} />} />
              <Route path="/renovations" element={<PlaceholderPage title="Renovation Projects" description="Budgets, contractors, materials, and project schedules." icon={Hammer} />} />
              <Route path="/reports" element={<PlaceholderPage title="Reports" description="Portfolio performance and financial reports." icon={BarChart3} />} />
              <Route path="/settings" element={<PlaceholderPage title="Settings" description="Organization preferences and account settings." icon={Settings} />} />
              <Route path="*" element={<Navigate to="/properties" replace />} />
            </Route>
          </Routes>
        </HashRouter>
      </ToastProvider>
    </AppStoreProvider>
  );
}
