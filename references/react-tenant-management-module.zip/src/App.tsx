import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Archive,
  ArrowUpRight,
  Bell,
  Building2,
  Check,
  ChevronDown,
  ChevronRight,
  ChevronsUpDown,
  CircleDollarSign,
  CircleHelp,
  Download,
  FileCheck2,
  FileText,
  FolderClosed,
  Home,
  LayoutDashboard,
  LifeBuoy,
  Menu,
  Plus,
  Settings,
  ShieldCheck,
  Users,
  Wallet,
  X,
} from "lucide-react";
import type {
  Database,
  LeaseAssociation,
  ProfileTab,
  Tenant,
  TenantInput,
} from "./types";
import { createMockDatabase } from "./data/mockData";
import {
  appendActivity,
  associatePerson,
  createLease,
  dashboardSummary,
  DEFAULT_WARNING_DAYS,
  downloadFile,
  filterTenants,
  fullName,
  leaseStatus,
  money,
  saveTenant,
  tenantCsv,
  today,
  uid,
  type DirectoryFilters,
} from "./lib/domain";
import { Button, IconButton, Overlay, Toast } from "./components/ui";
import { DirectoryControls, TenantTable } from "./components/TenantTable";
import type { DetailActions } from "./components/TenantDetails";
import {
  AddPersonForm,
  AssociateLeaseForm,
  emptyAssociation,
  PaymentForm,
  TenantForm,
  type PersonAssociationInput,
} from "./components/Forms";
import { TenantProfile } from "./components/TenantProfile";
import {
  LeaseDetail,
  PropertyDetail,
  UnitDetail,
} from "./components/EntityDetails";
import { WorkspacePanel, type WorkspaceView } from "./components/Workspace";

type DialogState =
  | { type: "tenant"; tenantId?: string }
  | { type: "person" | "associate" | "archive" | "payment"; tenantId: string }
  | null;
type EntityState = { type: "lease" | "property" | "unit"; id: string } | null;
const initialFilters: DirectoryFilters = {
  search: "",
  status: "All Tenants",
  outstanding: false,
  expiring: false,
  includeArchived: false,
  propertyId: "",
  sort: "default",
  descending: false,
  warningDays: DEFAULT_WARNING_DAYS,
};
const navigation = [
  { name: "Overview", icon: LayoutDashboard },
  { name: "Properties", icon: Building2 },
  { name: "Units", icon: Home },
  { name: "Tenants", icon: Users },
  { name: "Leases", icon: FileText },
  { name: "Financials", icon: Wallet },
  { name: "Documents", icon: FolderClosed },
] as const;

function BrandMark() {
  return (
    <svg
      className="brand-mark"
      width="30"
      height="33"
      viewBox="0 0 30 33"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M3 28V12L10 8V28"
        stroke="currentColor"
        strokeWidth="3.4"
        strokeLinejoin="round"
      />
      <path
        d="M10 28V5L18 2V28"
        stroke="currentColor"
        strokeWidth="3.4"
        strokeLinejoin="round"
      />
      <path
        d="M18 28V13L26 17V28"
        stroke="currentColor"
        strokeWidth="3.4"
        strokeLinejoin="round"
      />
      <path
        d="M2 29H28"
        stroke="currentColor"
        strokeWidth="3.4"
        strokeLinecap="round"
      />
    </svg>
  );
}

export default function App() {
  const [db, setDb] = useState<Database>(createMockDatabase);
  const [filters, setFilters] = useState<DirectoryFilters>(initialFilters);
  const [expandedId, setExpandedId] = useState<string | null>(() =>
    window.matchMedia("(min-width: 1161px)").matches ? "t1" : null,
  );
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(8);
  const [dialog, setDialog] = useState<DialogState>(null);
  const [entity, setEntity] = useState<EntityState>(null);
  const [profile, setProfile] = useState<{
    id: string;
    tab: ProfileTab;
  } | null>(null);
  const [workspace, setWorkspace] = useState<WorkspaceView | null>(null);
  const [toast, setToast] = useState<{
    message: string;
    type: "success" | "error";
  } | null>(null);
  const [mobileNav, setMobileNav] = useState(false);
  const [dense, setDense] = useState(false);
  const [notificationsRead, setNotificationsRead] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const summary = useMemo(() => dashboardSummary(db), [db]);
  const filtered = useMemo(() => filterTenants(db, filters), [db, filters]);
  const expiringCount = db.leases.filter(
    (l) => leaseStatus(l, filters.warningDays) === "Expiring",
  ).length;
  const notify = useCallback(
    (message: string, type: "success" | "error" = "success") =>
      setToast({ message, type }),
    [],
  );
  const dismissToast = useCallback(() => setToast(null), []);
  const tenantById = (id: string) => db.tenants.find((t) => t.id === id)!;
  const changeFilters = (next: DirectoryFilters) => {
    setFilters(next);
    setPage(1);
  };
  const clearFilters = () =>
    changeFilters({ ...initialFilters, warningDays: filters.warningDays });
  const openAddTenant = () => {
    setWorkspace(null);
    setDialog({ type: "tenant" });
    setMobileNav(false);
  };
  const openWorkspace = (view: WorkspaceView) => {
    setWorkspace(view);
    setMobileNav(false);
    if (view === "Notifications") setNotificationsRead(true);
  };

  const actions: DetailActions = {
    onProfile: (id, tab = "Overview") => {
      setProfile({ id, tab });
      setEntity(null);
      setWorkspace(null);
    },
    onLease: (id) => {
      setEntity({ type: "lease", id });
      setWorkspace(null);
    },
    onProperty: (id) => {
      setEntity({ type: "property", id });
      setWorkspace(null);
    },
    onUnit: (id) => {
      setEntity({ type: "unit", id });
      setWorkspace(null);
    },
    onAddPerson: (tenantId) => {
      const eligible = db.leaseParties.some(
        (p) =>
          p.tenantId === tenantId &&
          db.leases.some(
            (l) =>
              l.id === p.leaseId &&
              !["Expired", "Terminated"].includes(leaseStatus(l)),
          ),
      );
      if (!eligible) {
        setDialog({ type: "associate", tenantId });
        notify("Add a current lease first, then connect this household.");
      } else setDialog({ type: "person", tenantId });
    },
    onAddLease: (tenantId) => setDialog({ type: "associate", tenantId }),
  };

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMobileNav(false);
      const target = event.target as HTMLElement;
      if (
        dialog ||
        entity ||
        profile ||
        workspace ||
        target.closest("input, textarea, select, [contenteditable]") ||
        event.ctrlKey ||
        event.metaKey ||
        event.altKey
      )
        return;
      if (event.key === "/") {
        event.preventDefault();
        searchRef.current?.focus();
      }
      if (event.key.toLowerCase() === "n") {
        event.preventDefault();
        setDialog({ type: "tenant" });
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [dialog, entity, profile, workspace]);

  const handleTenantSave = (
    input: TenantInput,
    association: LeaseAssociation,
    editingId?: string,
  ) => {
    const result = saveTenant(db, input, association, editingId);
    setDb(result.db);
    setDialog(null);
    if (!editingId) {
      clearFilters();
      setExpandedId(result.tenant.id);
    }
    notify(
      `${fullName(result.tenant)} ${editingId ? "updated" : "added to your directory"}.`,
    );
  };

  const handleAssociate = (tenantId: string, association: LeaseAssociation) => {
    let next = db;
    if (association.mode === "new" && association.newLease)
      next = createLease(
        db,
        tenantId,
        association.newLease,
        association.role,
        association.isSignatory,
      );
    else if (association.mode === "existing" && association.leaseId)
      next = associatePerson(
        db,
        tenantId,
        association.leaseId,
        association.role,
        association.unitIds,
        association.isSignatory,
      );
    setDb(next);
    setDialog(null);
    notify(
      association.mode === "new"
        ? "Lease created and associated with this tenant."
        : "Existing lease associated with this tenant.",
    );
  };

  const handleAddPerson = (input: PersonAssociationInput) => {
    let next = db;
    let tenantId = input.existingTenantId;
    if (input.newPerson) {
      const result = saveTenant(db, input.newPerson, emptyAssociation());
      next = result.db;
      tenantId = result.tenant.id;
    }
    if (!tenantId)
      throw new Error("Choose an existing person or provide their details.");
    next = associatePerson(
      next,
      tenantId,
      input.leaseId,
      input.role,
      input.unitIds,
      input.isSignatory,
    );
    const person = next.tenants.find((t) => t.id === tenantId)!;
    if (dialog && "tenantId" in dialog && dialog.tenantId)
      next = appendActivity(
        next,
        dialog.tenantId,
        "Household member added",
        `${fullName(person)} joined as ${input.role.toLowerCase()}.`,
      );
    setDb(next);
    setDialog(null);
    notify(`${fullName(person)} added as ${input.role.toLowerCase()}.`);
  };

  const handleArchive = (tenantId: string) => {
    const tenant = tenantById(tenantId);
    if (tenant.archivedAt) {
      const next = {
        ...db,
        tenants: db.tenants.map((t) =>
          t.id === tenantId
            ? {
                ...t,
                archivedAt: undefined,
                updatedAt: new Date().toISOString(),
              }
            : t,
        ),
      };
      setDb(
        appendActivity(
          next,
          tenantId,
          "Tenant restored",
          "Record restored to the directory. Previous lease and financial history is unchanged.",
        ),
      );
      notify(`${fullName(tenant)} restored to the directory.`);
    } else setDialog({ type: "archive", tenantId });
  };

  const confirmArchive = (tenant: Tenant) => {
    const date = new Date().toISOString();
    const next: Database = {
      ...db,
      tenants: db.tenants.map((t) =>
        t.id === tenant.id
          ? { ...t, archivedAt: date, updatedAt: date, tenantStatus: "Former" }
          : t,
      ),
    };
    setDb(
      appendActivity(
        next,
        tenant.id,
        "Tenant archived",
        "Hidden from the default directory. All leases, documents, and transactions retained.",
      ),
    );
    setDialog(null);
    if (expandedId === tenant.id) setExpandedId(null);
    notify(`${fullName(tenant)} archived. All history has been preserved.`);
  };

  const handlePayment = (
    accountId: string,
    amount: number,
    date: string,
    description: string,
  ) => {
    const account = db.accounts.find((a) => a.id === accountId)!;
    const rounded = Math.round(amount * 100) / 100;
    const next: Database = {
      ...db,
      transactions: [
        ...db.transactions,
        {
          id: uid("txn"),
          accountId,
          accountType: account.accountType,
          leaseId: account.leaseId,
          unitId: account.unitId,
          tenantId: account.tenantId,
          transactionType: "Payment",
          description: `Payment - ${description}`,
          amount: rounded,
          transactionDate: date,
          paymentStatus: "Posted",
        },
      ],
    };
    setDb(
      appendActivity(
        next,
        account.tenantId,
        "Payment recorded",
        `${money(rounded)} CAD posted to ${account.label}.`,
      ),
    );
    setDialog(null);
    notify(`${money(rounded)} payment recorded. Account balances updated.`);
  };

  const sortBy = (sort: DirectoryFilters["sort"]) =>
    changeFilters({
      ...filters,
      sort,
      descending:
        filters.sort === sort
          ? !filters.descending
          : ["balance", "units"].includes(sort),
    });
  const profileTenant = profile ? tenantById(profile.id) : undefined;
  const dialogTenant =
    dialog && "tenantId" in dialog && dialog.tenantId
      ? tenantById(dialog.tenantId)
      : undefined;

  return (
    <div className={`app-shell ${dense ? "density-compact" : ""}`}>
      {mobileNav && (
        <div
          className="mobile-nav-backdrop"
          onClick={() => setMobileNav(false)}
        />
      )}
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <button
          className="brand"
          onClick={() => openWorkspace("Overview")}
          aria-label="Rentora workspace overview"
        >
          <BrandMark />
          <span>
            rentora<span className="brand-period">.</span>
          </span>
        </button>
        <IconButton
          className="mobile-nav-close"
          label="Close navigation"
          onClick={() => setMobileNav(false)}
        >
          <X size={19} />
        </IconButton>
        <div className="workspace-label">WORKSPACE</div>
        <nav className="main-navigation" aria-label="Main navigation">
          {navigation.map((item) => (
            <button
              key={item.name}
              className={`nav-item ${item.name === "Tenants" ? "nav-selected" : ""}`}
              aria-current={item.name === "Tenants" ? "page" : undefined}
              onClick={() => {
                if (item.name === "Tenants") {
                  setWorkspace(null);
                  setProfile(null);
                  setEntity(null);
                  setMobileNav(false);
                } else openWorkspace(item.name);
              }}
            >
              <item.icon size={18} strokeWidth={1.7} />
              <span>{item.name}</span>
              {item.name === "Tenants" && (
                <span className="nav-count">{summary.tenants}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-bottom-links">
            <button
              className="nav-item"
              onClick={() => openWorkspace("Help & support")}
            >
              <LifeBuoy size={18} strokeWidth={1.7} />
              <span>Help & support</span>
              <ArrowUpRight size={13} />
            </button>
            <button
              className="nav-item"
              onClick={() => openWorkspace("Settings")}
            >
              <Settings size={18} strokeWidth={1.7} />
              <span>Settings</span>
            </button>
          </div>
          <button
            className="workspace-switcher"
            onClick={() => openWorkspace("Settings")}
          >
            <span className="workspace-avatar">AP</span>
            <span>
              <strong>Acme Properties</strong>
              <small>
                Pro workspace
                <span className="pro-dot" />
              </small>
            </span>
            <ChevronsUpDown size={14} />
          </button>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <div className="topbar-left">
            <IconButton
              className="mobile-menu-button"
              label="Open navigation"
              onClick={() => setMobileNav(true)}
            >
              <Menu size={20} />
            </IconButton>
            <span className="breadcrumb-icon">
              <Building2 size={17} strokeWidth={1.6} />
            </span>
            <button
              className="breadcrumb-link"
              onClick={() => openWorkspace("Overview")}
            >
              Workspace
            </button>
            <ChevronRight size={12} />
            <span className="breadcrumb-current">Tenants</span>
          </div>
          <div className="topbar-right">
            <IconButton
              label="Help and support"
              onClick={() => openWorkspace("Help & support")}
            >
              <CircleHelp size={18} />
            </IconButton>
            <IconButton
              className="notification-button"
              label="Notifications"
              onClick={() => openWorkspace("Notifications")}
            >
              <Bell size={18} />
              {!notificationsRead && <i />}
            </IconButton>
            <div className="topbar-divider" />
            <button
              className="user-menu"
              onClick={() => openWorkspace("Settings")}
            >
              <span className="user-avatar">AM</span>
              <span>
                <strong>Alex Morgan</strong>
                <small>Property manager</small>
              </span>
              <ChevronDown size={13} />
            </button>
          </div>
        </header>
        <main className="main-content">
          <div className="page-heading">
            <div>
              <div className="page-title-line">
                <h1>Tenants</h1>
              </div>
              <p>Manage tenants, leases, occupants, and balances.</p>
            </div>
            <div className="page-heading-actions">
              <Button
                onClick={() => {
                  downloadFile(
                    `rentora-tenants-${today()}.csv`,
                    tenantCsv(db, filtered),
                    "text/csv;charset=utf-8",
                  );
                  notify(
                    `Exported ${filtered.length} tenant record${filtered.length === 1 ? "" : "s"} to CSV.`,
                  );
                }}
              >
                <Download size={15} />
                Export
              </Button>
              <Button variant="primary" onClick={openAddTenant}>
                <Plus size={17} />
                Add tenant
              </Button>
            </div>
          </div>
          <section
            className="summary-grid"
            aria-label="Tenant portfolio summary"
          >
            <div className="summary-card">
              <div className="summary-card-top">
                <span>Total tenants</span>
                <span className="summary-icon summary-icon-violet">
                  <Users size={17} strokeWidth={1.7} />
                </span>
              </div>
              <div className="summary-number">
                {summary.tenants}
                <span className="summary-unit">tenants</span>
              </div>
              <div className="summary-note">
                Across {db.properties.length} properties in your portfolio
              </div>
            </div>
            <div className="summary-card">
              <div className="summary-card-top">
                <span>Active leases</span>
                <span className="summary-icon summary-icon-blue">
                  <FileCheck2 size={17} strokeWidth={1.7} />
                </span>
              </div>
              <div className="summary-number">
                {summary.activeLeases}
                <span className="summary-unit">leases</span>
              </div>
              <button
                className="summary-note summary-note-link"
                onClick={() =>
                  changeFilters({
                    ...initialFilters,
                    warningDays: filters.warningDays,
                    expiring: true,
                  })
                }
              >
                <span className="summary-note-dot" />
                {expiringCount} expiring in the next {filters.warningDays} days
                <ChevronRight size={12} />
              </button>
            </div>
            <div className="summary-card">
              <div className="summary-card-top">
                <span>Outstanding balances</span>
                <span className="summary-icon summary-icon-amber">
                  <CircleDollarSign size={18} strokeWidth={1.7} />
                </span>
              </div>
              <div className="summary-number summary-money">
                {money(summary.outstanding)}
                <span className="currency-label">CAD</span>
              </div>
              <button
                className="summary-note summary-note-link"
                onClick={() =>
                  changeFilters({
                    ...initialFilters,
                    warningDays: filters.warningDays,
                    outstanding: true,
                    includeArchived: true,
                  })
                }
              >
                <span className="summary-note-dot amber-dot" />
                {summary.outstandingAccounts} accounts with an outstanding
                balance
                <ChevronRight size={12} />
              </button>
            </div>
          </section>
          <section className="directory-panel" aria-label="Tenant directory">
            <DirectoryControls
              db={db}
              filters={filters}
              onChange={changeFilters}
              searchRef={searchRef}
            />
            <TenantTable
              db={db}
              tenants={filtered}
              expandedId={expandedId}
              onExpand={(id) => setExpandedId(expandedId === id ? null : id)}
              actions={actions}
              onEdit={(tenantId) => setDialog({ type: "tenant", tenantId })}
              onArchive={handleArchive}
              filters={filters}
              onSort={sortBy}
              page={page}
              pageSize={pageSize}
              onPage={setPage}
              onPageSize={(size) => {
                setPageSize(size);
                setPage(1);
              }}
              onReset={clearFilters}
              onAdd={openAddTenant}
            />
          </section>
          <div className="directory-footnote">
            <span>
              <ShieldCheck size={13} />
              Your records stay connected. Your history stays intact.
            </span>
            <span>
              All amounts in CAD
              <span className="footnote-separator">&middot;</span>Posted
              transactions only
            </span>
          </div>
        </main>
      </div>
      {profile && profileTenant && (
        <TenantProfile
          key={profile.id}
          db={db}
          tenant={profileTenant}
          tab={profile.tab}
          onTab={(tab) => setProfile({ ...profile, tab })}
          onClose={() => setProfile(null)}
          onEdit={() => setDialog({ type: "tenant", tenantId: profile.id })}
          onArchive={() => handleArchive(profile.id)}
          onPayment={() => setDialog({ type: "payment", tenantId: profile.id })}
          actions={actions}
          warningDays={filters.warningDays}
        />
      )}
      {workspace && (
        <WorkspacePanel
          key={workspace}
          view={workspace}
          db={db}
          actions={actions}
          onClose={() => setWorkspace(null)}
          warningDays={filters.warningDays}
          dense={dense}
          onSettings={(warningDays, compact) => {
            setFilters({ ...filters, warningDays });
            setDense(compact);
            setWorkspace(null);
            notify("Workspace preferences saved.");
          }}
          onAddTenant={openAddTenant}
        />
      )}
      {entity?.type === "lease" && (
        <LeaseDetail
          key={entity.id}
          db={db}
          lease={db.leases.find((l) => l.id === entity.id)!}
          actions={actions}
          warningDays={filters.warningDays}
          onClose={() => setEntity(null)}
          notify={notify}
        />
      )}
      {entity?.type === "property" && (
        <PropertyDetail
          db={db}
          propertyId={entity.id}
          actions={actions}
          onClose={() => setEntity(null)}
        />
      )}
      {entity?.type === "unit" && (
        <UnitDetail
          db={db}
          unitId={entity.id}
          actions={actions}
          warningDays={filters.warningDays}
          onClose={() => setEntity(null)}
        />
      )}
      {dialog?.type === "tenant" && (
        <TenantForm
          db={db}
          tenant={dialogTenant}
          onClose={() => setDialog(null)}
          onSave={handleTenantSave}
        />
      )}
      {dialog?.type === "associate" && dialogTenant && (
        <AssociateLeaseForm
          db={db}
          tenant={dialogTenant}
          onClose={() => setDialog(null)}
          onSave={(association) =>
            handleAssociate(dialogTenant.id, association)
          }
        />
      )}
      {dialog?.type === "person" && dialogTenant && (
        <AddPersonForm
          db={db}
          tenant={dialogTenant}
          onClose={() => setDialog(null)}
          onSave={handleAddPerson}
        />
      )}
      {dialog?.type === "payment" && dialogTenant && (
        <PaymentForm
          db={db}
          tenant={dialogTenant}
          onClose={() => setDialog(null)}
          onSave={handlePayment}
        />
      )}
      {dialog?.type === "archive" && dialogTenant && (
        <Overlay title="Archive tenant?" onClose={() => setDialog(null)}>
          <div className="archive-dialog">
            <span className="archive-symbol">
              <Archive size={27} />
            </span>
            <h3>Archive {fullName(dialogTenant)}?</h3>
            <p>
              This person will be hidden from the default directory and marked
              as a former tenant. You can find them again using{" "}
              <strong>Include archived tenants</strong>.
            </p>
            <div className="archive-promise">
              <Check size={15} />
              <span>
                Leases, documents, transactions, and activity are preserved.
              </span>
            </div>
            <p className="archive-account-note">
              Archiving does not terminate a lease or clear an outstanding
              balance.
            </p>
          </div>
          <div className="form-footer">
            <Button onClick={() => setDialog(null)}>Keep tenant</Button>
            <Button
              variant="danger"
              onClick={() => confirmArchive(dialogTenant)}
            >
              <Archive size={15} />
              Archive tenant
            </Button>
          </div>
        </Overlay>
      )}
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={dismissToast}
        />
      )}
    </div>
  );
}
