import { test, expect, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";

async function fillPerson(page: Page, first = "Morgan", last = "Reed") {
  const dialog = page.getByRole("dialog").last();
  await dialog.getByLabel("First name", { exact: true }).fill(first);
  await dialog.getByLabel("Last name", { exact: true }).fill(last);
  await dialog
    .getByLabel("Email address", { exact: true })
    .fill(`${first.toLowerCase()}.${last.toLowerCase()}@example.com`);
  await dialog
    .getByLabel("Phone number", { exact: true })
    .fill("+1 (416) 555-9000");
}

test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "Tenants", exact: true }),
  ).toBeVisible();
});

test("master details show all units and unique household members; only one row expands", async ({
  page,
}) => {
  await expect(page.locator(".summary-number").nth(0)).toContainText("24");
  await expect(page.locator(".summary-number").nth(1)).toContainText("15");
  await expect(page.locator(".summary-number").nth(2)).toContainText(
    "$6,300.00",
  );
  const detail = page.locator(".expanded-detail");
  await expect(
    detail.getByRole("button", { name: "Unit 204", exact: true }),
  ).toBeVisible();
  await expect(
    detail.getByRole("button", { name: "Unit 205", exact: true }),
  ).toBeVisible();
  await expect(detail.locator(".person-item")).toHaveCount(3);
  await expect(
    detail.locator(".person-name").filter({ hasText: "Ethan Johnson" }),
  ).toHaveCount(1);
  await detail.getByRole("button", { name: "Unit 205", exact: true }).click();
  await expect(
    page
      .getByRole("dialog")
      .getByRole("heading", { name: "Unit 205", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Close dialog" }).click();
  await page
    .getByRole("button", { name: "Expand Michael Chen", exact: true })
    .click();
  await expect(page.locator(".expanded-detail")).toHaveCount(1);
  await expect(
    page.getByRole("button", { name: "Expand Sarah Johnson", exact: true }),
  ).toHaveAttribute("aria-expanded", "false");
  await expect(page.locator(".expanded-detail")).toContainText(
    "No outstanding balance",
  );
});

test("search, status, property matching, balance filtering and sorting work together", async ({
  page,
}) => {
  await page
    .getByRole("textbox", { name: "Search tenants" })
    .fill("4165551234");
  await expect(page.locator(".tenant-row")).toHaveCount(1);
  await expect(page.locator(".tenant-name")).toHaveText("Sarah Johnson");
  await page.getByRole("textbox", { name: "Search tenants" }).fill("Maplewood");
  await page
    .locator(".directory-tabs")
    .getByRole("button", { name: /^Active/ })
    .click();
  await page.getByRole("button", { name: "Filters", exact: true }).click();
  await page.getByLabel("Outstanding balance", { exact: false }).check();
  await page.getByRole("button", { name: "Show results" }).click();
  await expect(page.locator(".tenant-row")).toHaveCount(1);
  await expect(page.locator(".tenant-name")).toHaveText("Sarah Johnson");
  await page.getByRole("textbox", { name: "Search tenants" }).fill("");
  await page
    .getByRole("combobox", { name: "Sort tenants" })
    .selectOption("balance");
  await expect(page.locator(".tenant-row")).toHaveCount(5);
  await expect(page.locator(".tenant-name").first()).toHaveText("James Wilson");
});

test("pagination, page size and column sorting remain consistent", async ({
  page,
}) => {
  await page.getByRole("button", { name: "Next page", exact: true }).click();
  await expect(page.locator(".table-pagination")).toContainText(
    "Showing 9-16 of 24 tenants",
  );
  await page
    .getByRole("combobox", { name: "Rows per page" })
    .selectOption("16");
  await expect(page.locator(".tenant-row")).toHaveCount(16);
  await expect(page.locator(".table-pagination")).toContainText(
    "Showing 1-16 of 24 tenants",
  );
  await page
    .getByRole("combobox", { name: "Sort tenants" })
    .selectOption("name");
  await expect(page.locator(".tenant-name").first()).toHaveText(
    "Alexander Hall",
  );
  await page
    .getByRole("combobox", { name: "Sort tenants" })
    .selectOption("expiry");
  await expect(page.locator(".tenant-name").first()).toHaveText("Emily Davis");
  await page.getByRole("button", { name: "Balance", exact: true }).click();
  await expect(page.locator(".tenant-name").first()).toHaveText("James Wilson");
});

test("add tenant validates input and saves without requiring a lease", async ({
  page,
}) => {
  await page.getByRole("button", { name: "Add tenant", exact: true }).click();
  const dialog = page.getByRole("dialog");
  await dialog.getByRole("button", { name: "Add tenant", exact: true }).click();
  await expect(dialog).toContainText("First name is required.");
  await expect(dialog).toContainText("Enter a valid email address.");
  await fillPerson(page);
  await dialog.getByRole("button", { name: "Add tenant", exact: true }).click();
  await expect(page.getByRole("dialog")).toHaveCount(0);
  await expect(page.locator(".tenant-name").first()).toHaveText("Morgan Reed");
  await expect(page.locator(".summary-number").first()).toContainText("25");
  await expect(page.locator(".expanded-detail")).toContainText("No leases yet");
  await expect(page.getByRole("status")).toContainText(
    "added to your directory",
  );
});

test("new tenant can join an existing lease with selected occupied units", async ({
  page,
}) => {
  await page.getByRole("button", { name: "Add tenant", exact: true }).click();
  await fillPerson(page, "Jordan", "Lee");
  const dialog = page.getByRole("dialog");
  await dialog
    .getByLabel("Tenant status", { exact: true })
    .selectOption("Active");
  await dialog
    .getByRole("button", { name: "Existing lease", exact: true })
    .click();
  await dialog
    .getByLabel("Existing lease / household", { exact: true })
    .selectOption("l1");
  await dialog.getByRole("checkbox", { name: /Unit 205/ }).uncheck();
  await dialog.getByRole("button", { name: "Add tenant", exact: true }).click();
  await expect(page.locator(".summary-number").first()).toContainText("25");
  await expect(
    page.locator(".tenant-row").first().locator(".unit-count"),
  ).toHaveText("01");
  await expect(page.locator(".summary-number").nth(1)).toContainText("15");
  await expect(page.locator(".expanded-detail .person-item")).toHaveCount(4);
});

test("new tenant and multi-unit lease save as one connected workflow", async ({
  page,
}) => {
  await page.getByRole("button", { name: "Add tenant", exact: true }).click();
  await fillPerson(page, "Sam", "Parker");
  const dialog = page.getByRole("dialog");
  await dialog
    .getByRole("button", { name: "Create new lease", exact: true })
    .click();
  await dialog
    .getByLabel("Total monthly rent (CAD)", { exact: true })
    .fill("2400");
  await dialog
    .getByLabel("Security deposit (CAD)", { exact: false })
    .fill("2400");
  await dialog.getByRole("checkbox", { name: /Unit 108/ }).check();
  await dialog.getByRole("checkbox", { name: /Unit 402/ }).check();
  await dialog.getByRole("button", { name: "Add tenant", exact: true }).click();
  await expect(page.getByRole("dialog")).toHaveCount(0);
  await expect(page.locator(".tenant-name").first()).toHaveText("Sam Parker");
  await expect(
    page.locator(".tenant-row").first().locator(".unit-count"),
  ).toHaveText("02");
  await expect(page.locator(".expanded-detail .unit-item")).toHaveCount(2);
  await expect(page.locator(".summary-number").nth(1)).toContainText("16");
});

test("editing saves personal details without changing lease associations", async ({
  page,
}) => {
  await page
    .getByRole("button", { name: "Edit Sarah Johnson", exact: true })
    .click();
  const dialog = page.getByRole("dialog");
  await dialog
    .getByLabel("Phone number", { exact: true })
    .fill("+1 (416) 555-9999");
  await dialog
    .getByLabel("Internal notes", { exact: false })
    .fill("Updated notes for this household.");
  await dialog
    .getByRole("button", { name: "Save changes", exact: true })
    .click();
  await expect(
    page.locator(".tenant-row").first().locator(".phone-cell"),
  ).toContainText("555-9999");
  await expect(page.locator(".expanded-detail .unit-item")).toHaveCount(2);
  await expect(page.locator(".summary-number").first()).toContainText("24");
});

test("adding an existing occupant reuses the person and prevents duplicate membership", async ({
  page,
}) => {
  await page
    .locator(".expanded-detail")
    .getByRole("button", { name: "Add co-tenant / occupant", exact: true })
    .click();
  const dialog = page.getByRole("dialog");
  await dialog.getByLabel("Select person", { exact: true }).selectOption("t24");
  await dialog
    .getByLabel("Relationship", { exact: true })
    .selectOption("Occupant");
  await dialog.getByRole("checkbox", { name: /Unit 204/ }).uncheck();
  await expect(
    dialog.getByRole("checkbox", { name: /Lease signatory/ }),
  ).not.toBeChecked();
  await dialog.getByRole("button", { name: "Add person", exact: true }).click();
  await expect(page.locator(".expanded-detail .person-item")).toHaveCount(4);
  await expect(page.locator(".summary-number").first()).toContainText("24");
  await expect(
    page
      .locator(".expanded-detail .person-name")
      .filter({ hasText: "Jack Cooper" }),
  ).toHaveCount(1);
  await page
    .locator(".expanded-detail")
    .getByRole("button", { name: "Add co-tenant / occupant", exact: true })
    .click();
  await expect(
    page
      .getByLabel("Select person", { exact: true })
      .locator('option[value="t24"]'),
  ).toHaveCount(0);
});

test("profile tabs, historical leases, unit links and document download work", async ({
  page,
}) => {
  await page.locator(".tenant-name").filter({ hasText: "Emily Davis" }).click();
  const drawer = page.getByRole("dialog");
  await drawer
    .locator(".profile-tabs")
    .getByRole("button", { name: "Leases", exact: true })
    .click();
  await expect(drawer.locator(".lease-item")).toHaveCount(2);
  await expect(drawer.locator(".status-expired")).toHaveCount(1);
  for (const name of [
    "Personal info",
    "Units",
    "People",
    "Financial ledger",
    "Activity",
    "Documents",
  ]) {
    await drawer
      .locator(".profile-tabs")
      .getByRole("button", { name, exact: true })
      .click();
    await expect(drawer.locator(".profile-body")).toBeVisible();
  }
  await expect(drawer.locator(".document-row")).toHaveCount(2);
  await drawer.locator(".document-row").last().click();
  const lease = page.getByRole("dialog").last();
  await lease.getByRole("button", { name: "Preview", exact: true }).click();
  await expect(lease.locator(".document-preview")).toContainText(
    "SAMPLE RESIDENTIAL LEASE",
  );
  const download = page.waitForEvent("download");
  await lease
    .getByRole("button", { name: "Download agreement", exact: true })
    .click();
  expect((await download).suggestedFilename()).toContain(
    "sample-agreement.txt",
  );
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).toHaveCount(1);
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).toHaveCount(0);
});

test("recording a payment updates account, master row and portfolio totals", async ({
  page,
}) => {
  await page
    .locator(".expanded-detail")
    .getByRole("button", { name: "View financial ledger", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Record payment", exact: true })
    .click();
  const form = page.getByRole("dialog").last();
  await form.getByLabel("Amount (CAD)", { exact: true }).fill("500");
  await form.getByRole("button", { name: "Post payment", exact: true }).click();
  await expect(page.locator(".ledger-totals").first()).toContainText("$750.00");
  await page.getByRole("button", { name: "Close dialog", exact: true }).click();
  await expect(
    page.locator(".tenant-row").first().locator(".balance-value"),
  ).toHaveText("$750.00");
  await expect(page.locator(".summary-number").nth(2)).toContainText(
    "$5,800.00",
  );
});

test("independent ledger accounts show credit without hiding unpaid rent", async ({
  page,
}) => {
  await page.getByRole("textbox", { name: "Search tenants" }).fill("Sophia");
  await page
    .getByRole("button", { name: "Expand Sophia Anderson", exact: true })
    .click();
  await expect(page.locator(".tenant-row .balance-value")).toHaveText(
    "$750.00",
  );
  await expect(page.locator(".independent-accounts")).toContainText(
    "-$200.00 credit",
  );
  await page
    .getByRole("button", { name: "View financial ledger", exact: true })
    .click();
  await expect(page.locator(".ledger-totals")).toContainText("$750.00");
  await expect(page.locator(".ledger-totals")).toContainText("$200.00");
  await page
    .getByRole("combobox", { name: "Filter ledger by account" })
    .selectOption("a15");
  await expect(page.locator(".ledger-table tbody tr")).toHaveCount(3);
  await page
    .getByRole("combobox", { name: "Filter transaction type" })
    .selectOption("Credit");
  await expect(page.locator(".ledger-table tbody tr")).toHaveCount(1);
});

test("archive requires confirmation, preserves history and supports restore", async ({
  page,
}) => {
  await page
    .getByRole("button", {
      name: "More actions for Sarah Johnson",
      exact: true,
    })
    .click();
  await page
    .locator(".row-menu")
    .getByRole("button", { name: "Archive tenant", exact: true })
    .click();
  await expect(page.getByRole("dialog")).toContainText(
    "Leases, documents, transactions, and activity are preserved.",
  );
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Archive tenant", exact: true })
    .click();
  await expect(
    page.locator(".tenant-name").filter({ hasText: "Sarah Johnson" }),
  ).toHaveCount(0);
  await expect(page.locator(".summary-number").first()).toContainText("23");
  await expect(page.locator(".summary-number").nth(2)).toContainText(
    "$6,300.00",
  );
  await page.getByRole("button", { name: "Filters", exact: true }).click();
  await page
    .getByRole("checkbox", { name: /Include archived tenants/ })
    .check();
  await page.getByRole("button", { name: "Show results", exact: true }).click();
  await page
    .locator(".tenant-name")
    .filter({ hasText: "Sarah Johnson" })
    .click();
  await expect(page.locator(".archived-banner")).toBeVisible();
  await page
    .locator(".profile-tabs")
    .getByRole("button", { name: "Documents", exact: true })
    .click();
  await expect(page.locator(".document-row")).toHaveCount(1);
  await page
    .locator(".archived-banner")
    .getByRole("button", { name: "Restore", exact: true })
    .click();
  await expect(page.locator(".archived-banner")).toHaveCount(0);
  await expect(page.locator(".summary-number").first()).toContainText("24");
});

test("CSV export, empty search state and workspace settings are functional", async ({
  page,
}) => {
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export", exact: true }).click();
  expect((await download).suggestedFilename()).toMatch(
    /^rentora-tenants-.+\.csv$/,
  );
  await page
    .getByRole("textbox", { name: "Search tenants" })
    .fill("no-such-person");
  await expect(
    page.getByRole("heading", { name: "No tenants found", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Clear search & filters", exact: true })
    .click();
  await expect(page.locator(".tenant-row")).toHaveCount(8);
  await page
    .locator(".sidebar-bottom")
    .getByRole("button", { name: "Settings", exact: true })
    .click();
  await page.getByLabel("Lease expiry warning", { exact: false }).fill("10");
  await page.getByRole("checkbox", { name: /Compact table density/ }).check();
  await page
    .getByRole("button", { name: "Save preferences", exact: true })
    .click();
  await expect(page.locator(".summary-note-link").first()).toContainText(
    "0 expiring in the next 10 days",
  );
  await expect(page.locator(".app-shell")).toHaveClass(/density-compact/);
});

test("mobile layout stays within viewport and supports expansion, profiles and navigation", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page
    .getByRole("button", { name: "Collapse Sarah Johnson", exact: true })
    .click();
  await expect(page.locator(".expanded-detail")).toHaveCount(0);
  await page.locator(".tenant-name").first().click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.getByRole("button", { name: "Close dialog", exact: true }).click();
  await page
    .getByRole("button", { name: "Open navigation", exact: true })
    .click();
  await expect(page.locator(".sidebar")).toHaveClass(/sidebar-open/);
  await page
    .locator(".main-navigation")
    .getByRole("button", { name: "Properties", exact: true })
    .click();
  await expect(
    page
      .getByRole("dialog")
      .getByRole("heading", { name: "Properties", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Close dialog", exact: true }).click();
  await page.getByRole("button", { name: "Add tenant", exact: true }).click();
  await fillPerson(page, "Mobile", "Resident");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Add tenant", exact: true })
    .click();
  await expect(page.locator(".tenant-name").first()).toHaveText(
    "Mobile Resident",
  );
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
});

test("tablet layout has no horizontal overflow and navigation previews open", async ({
  page,
}) => {
  await page.setViewportSize({ width: 1024, height: 768 });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await expect(
    page.locator(".tenant-row").first().locator(".phone-cell"),
  ).toBeHidden();
  for (const view of [
    "Overview",
    "Properties",
    "Units",
    "Leases",
    "Financials",
    "Documents",
  ]) {
    await page
      .locator(".main-navigation")
      .getByRole("button", { name: view, exact: true })
      .click();
    await expect(
      page
        .getByRole("dialog")
        .getByRole("heading", { name: view, exact: true }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Close dialog", exact: true })
      .click();
  }
});

test("a new household member is created once and duplicate personal records are rejected", async ({
  page,
}) => {
  await page
    .locator(".expanded-detail")
    .getByRole("button", { name: "Add co-tenant / occupant", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Create a new person", exact: true })
    .click();
  await fillPerson(page, "Casey", "Jordan");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Add person", exact: true })
    .click();
  await expect(page.locator(".summary-number").first()).toContainText("25");
  await expect(page.locator(".expanded-detail .person-item")).toHaveCount(4);
  await expect(
    page
      .locator(".expanded-detail .person-name")
      .filter({ hasText: "Casey Jordan" }),
  ).toHaveCount(1);
  await page
    .locator(".expanded-detail")
    .getByRole("button", { name: "Add co-tenant / occupant", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Create a new person", exact: true })
    .click();
  await fillPerson(page, "Casey", "Jordan");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Add person", exact: true })
    .click();
  await expect(page.getByRole("alert")).toContainText(
    "A tenant with this email already exists",
  );
  await expect(page.locator(".summary-number").first()).toContainText("25");
});

test("a tenant without a lease can be associated from the expanded empty state", async ({
  page,
}) => {
  await page.getByRole("textbox", { name: "Search tenants" }).fill("Charlotte");
  await page
    .getByRole("button", { name: "Expand Charlotte Lee", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Create or associate a lease", exact: true })
    .click();
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Existing lease", exact: true })
    .click();
  await page
    .getByLabel("Existing lease / household", { exact: true })
    .selectOption("l2");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Associate lease", exact: true })
    .click();
  await expect(page.locator(".tenant-row .unit-count")).toHaveText("01");
  await expect(page.locator(".expanded-detail .lease-item")).toHaveCount(1);
  await expect(page.locator(".summary-number").first()).toContainText("24");
});

test("directory and tenant form pass automated WCAG checks and keep focus in the dialog", async ({
  page,
}) => {
  await page.waitForTimeout(500);
  const directory = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(directory.violations).toEqual([]);
  await page.getByRole("button", { name: "Add tenant", exact: true }).click();
  await page.waitForTimeout(300);
  await expect(page.getByLabel("First name", { exact: true })).toBeFocused();
  expect(
    await page.locator("#root").evaluate((root) => (root as HTMLElement).inert),
  ).toBe(true);
  for (let i = 0; i < 20; i++) await page.keyboard.press("Tab");
  expect(
    await page
      .getByRole("dialog")
      .evaluate((dialog) => dialog.contains(document.activeElement)),
  ).toBe(true);
  const form = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(form.violations).toEqual([]);
  await page.keyboard.press("Escape");
  expect(
    await page.locator("#root").evaluate((root) => (root as HTMLElement).inert),
  ).toBe(false);
});
