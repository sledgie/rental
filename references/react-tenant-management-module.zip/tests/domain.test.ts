import assert from "node:assert/strict";
import { test } from "node:test";
import { createMockDatabase } from "../src/data/mockData";
import {
  accountFinancials,
  associatePerson,
  createLease,
  currentTenantUnits,
  dashboardSummary,
  filterTenants,
  leaseStatus,
  leaseUnitLinks,
  relatedPeople,
  saveTenant,
  tenantFinancials,
  tenantLeases,
  today,
  type DirectoryFilters,
} from "../src/lib/domain";
import type { Database, TenantInput } from "../src/types";

const filters: DirectoryFilters = {
  search: "",
  status: "All Tenants",
  outstanding: false,
  expiring: false,
  includeArchived: false,
  propertyId: "",
  sort: "default",
  descending: false,
  warningDays: 60,
};
const person: TenantInput = {
  firstName: "Test",
  lastName: "Resident",
  phone: "+1 (416) 555-9000",
  email: "test.resident@example.com",
  classification: "Individual",
  tenantStatus: "Pending",
};
const none = {
  mode: "none" as const,
  role: "Main Tenant" as const,
  isSignatory: true,
  unitIds: [],
};

test("seed relationships have valid IDs and no duplicate person or lease-unit associations", () => {
  const db = createMockDatabase();
  assert.equal(new Set(db.tenants.map((t) => t.email)).size, db.tenants.length);
  assert.equal(
    new Set(db.leaseParties.map((p) => `${p.leaseId}:${p.tenantId}`)).size,
    db.leaseParties.length,
  );
  assert.equal(
    new Set(db.leaseUnits.map((l) => `${l.leaseId}:${l.unitId}`)).size,
    db.leaseUnits.length,
  );
  for (const party of db.leaseParties) {
    assert.ok(db.leases.some((l) => l.id === party.leaseId));
    assert.ok(db.tenants.some((t) => t.id === party.tenantId));
  }
  for (const occupied of db.partyUnits) {
    const party = db.leaseParties.find((p) => p.id === occupied.partyId)!;
    assert.ok(party);
    assert.ok(
      db.leaseUnits.some(
        (l) => l.leaseId === party.leaseId && l.unitId === occupied.unitId,
      ),
    );
  }
  for (const account of db.accounts) {
    assert.ok(db.tenants.some((t) => t.id === account.tenantId));
    assert.ok(db.leases.some((l) => l.id === account.leaseId));
  }
  for (const transaction of db.transactions)
    assert.ok(db.accounts.some((a) => a.id === transaction.accountId));
});

test("main tenant has every leased unit; household members retain individual unit assignments", () => {
  const db = createMockDatabase();
  assert.deepEqual(
    leaseUnitLinks(db, "l1").map((l) => l.unitId),
    ["u1", "u2"],
  );
  assert.deepEqual(
    currentTenantUnits(db, "t1").map((u) => u.id),
    ["u1", "u2"],
  );
  assert.deepEqual(
    currentTenantUnits(db, "t21").map((u) => u.id),
    ["u1"],
  );
  assert.deepEqual(
    currentTenantUnits(db, "t22").map((u) => u.id),
    ["u2"],
  );
  assert.equal(relatedPeople(db, "t1").length, 3);
  assert.deepEqual(
    relatedPeople(db, "t1").map((t) => t.id),
    ["t1", "t21", "t22"],
  );
});

test("historical relationships remain visible without double-counting current units", () => {
  const db = createMockDatabase();
  assert.equal(tenantLeases(db, "t3").length, 2);
  assert.equal(currentTenantUnits(db, "t3").length, 1);
  assert.equal(tenantLeases(db, "t19").length, 1);
  assert.equal(tenantLeases(db, "t19")[0].documentReferences.length, 1);
  assert.equal(currentTenantUnits(db, "t19").length, 0);
  assert.equal(tenantFinancials(db, "t19").outstanding, 250);
  assert.equal(tenantLeases(db, "t24").length, 0);
});

test("summary and tenant balances derive from posted transactions only", () => {
  const db = createMockDatabase();
  assert.deepEqual(dashboardSummary(db), {
    tenants: 24,
    activeLeases: 15,
    outstanding: 6300,
    outstandingAccounts: 6,
  });
  assert.equal(tenantFinancials(db, "t1").outstanding, 1250);
  assert.equal(tenantFinancials(db, "t4").outstanding, 3200);
  assert.equal(tenantFinancials(db, "t2").outstanding, 0);
  assert.equal(tenantFinancials(db, "t4").oldestOverdueDays, 45);
  const withCancelled: Database = {
    ...db,
    transactions: [
      ...db.transactions,
      {
        ...db.transactions[0],
        id: "cancelled",
        amount: 999999,
        paymentStatus: "Cancelled",
      },
    ],
  };
  assert.equal(dashboardSummary(withCancelled).outstanding, 6300);
});

test("independent account credits are visible but never offset another account", () => {
  const db = createMockDatabase();
  const financials = tenantFinancials(db, "t7");
  assert.equal(financials.accounts.length, 2);
  assert.equal(financials.outstanding, 750);
  assert.equal(financials.creditBalance, 200);
  assert.equal(
    accountFinancials(
      db,
      db.accounts.find((a) => a.id === "a15")!,
    ).netBalance,
    -200,
  );
});

test("payments settle oldest charges in their own account and update overdue totals", () => {
  const db = createMockDatabase();
  const next: Database = {
    ...db,
    transactions: [
      ...db.transactions,
      {
        id: "payment-test",
        accountId: "a1",
        accountType: "Lease",
        tenantId: "t1",
        transactionType: "Payment",
        description: "Test payment",
        amount: 1250,
        transactionDate: today(),
        paymentStatus: "Posted",
      },
    ],
  };
  assert.equal(tenantFinancials(next, "t1").outstanding, 0);
  assert.equal(tenantFinancials(next, "t1").overdue, 0);
  assert.equal(dashboardSummary(next).outstanding, 5050);
  assert.equal(tenantFinancials(next, "t4").outstanding, 3200);
});

test("expiring is derived from dates and configurable warning periods", () => {
  const db = createMockDatabase();
  const lease = db.leases.find((l) => l.id === "l3")!;
  assert.equal(lease.leaseStatus, "Active");
  assert.equal(leaseStatus(lease, 60), "Expiring");
  assert.equal(leaseStatus(lease, 10), "Active");
  assert.equal(
    leaseStatus(
      db.leases.find((l) => l.id === "l17")!,
      60,
    ),
    "Expired",
  );
});

test("name, ID, phone, email, property, units, filters and sorting combine correctly", () => {
  const db = createMockDatabase();
  for (const search of [
    "Sarah Johnson",
    "TNT-1001",
    "4165551234",
    "sarah.johnson@gmail.com",
    "Unit 204",
  ])
    assert.ok(
      filterTenants(db, { ...filters, search }).some((t) => t.id === "t1"),
    );
  assert.ok(
    filterTenants(db, { ...filters, search: "Maplewood" }).some(
      (t) => t.id === "t1",
    ),
  );
  const result = filterTenants(db, {
    ...filters,
    status: "Active",
    outstanding: true,
    sort: "balance",
    descending: true,
  });
  assert.equal(result.length, 5);
  assert.equal(result[0].id, "t4");
  assert.equal(filterTenants(db, { ...filters, expiring: true }).length, 3);
  assert.equal(filterTenants(db, { ...filters, status: "Pending" }).length, 3);
  assert.equal(
    filterTenants(db, { ...filters, search: "no such tenant" }).length,
    0,
  );
});

test("tenant creation does not require a lease and rejects duplicate personal records", () => {
  const db = createMockDatabase();
  const result = saveTenant(db, person, none);
  assert.equal(result.db.tenants.length, 25);
  assert.equal(result.tenant.tenantNumber, "TNT-1025");
  assert.equal(tenantLeases(result.db, result.tenant.id).length, 0);
  assert.throws(
    () =>
      saveTenant(
        result.db,
        { ...person, email: person.email.toUpperCase() },
        none,
      ),
    /already exists/,
  );
});

test("associating existing people preserves their record and rejects duplicate associations", () => {
  const db = createMockDatabase();
  const next = associatePerson(db, "t24", "l1", "Occupant", ["u2"], false);
  assert.equal(next.tenants.length, db.tenants.length);
  assert.equal(relatedPeople(next, "t1").length, 4);
  assert.deepEqual(
    currentTenantUnits(next, "t24").map((u) => u.id),
    ["u2"],
  );
  assert.throws(
    () => associatePerson(next, "t24", "l1", "Occupant", ["u2"], false),
    /already associated/,
  );
  assert.throws(
    () => associatePerson(db, "t24", "l1", "Occupant", ["u17"], false),
    /belonging/,
  );
  assert.throws(
    () => associatePerson(db, "t24", "l1", "Main Tenant", ["u1"], true),
    /already has a main/,
  );
});

test("a new multi-unit lease creates normalized links and precise rent allocations", () => {
  const db = createMockDatabase();
  const endDate = `${Number(today().slice(0, 4)) + 1}${today().slice(4)}`;
  const next = createLease(db, "t24", {
    startDate: today(),
    endDate,
    rent: 3000.01,
    deposit: 3000,
    unitIds: ["u17", "u18", "u19"],
  });
  const created = next.leases[next.leases.length - 1];
  assert.equal(next.tenants.length, db.tenants.length);
  assert.equal(leaseUnitLinks(next, created.id).length, 3);
  assert.equal(
    leaseUnitLinks(next, created.id).reduce(
      (sum, l) => sum + Math.round(l.rentAllocation * 100),
      0,
    ),
    300001,
  );
  assert.equal(currentTenantUnits(next, "t24").length, 3);
  assert.throws(
    () =>
      createLease(db, "t24", {
        startDate: today(),
        endDate,
        rent: 1000,
        deposit: 0,
        unitIds: ["u1"],
      }),
    /already has a lease/,
  );
});

test("archiving hides the person, not their financial, document, or lease history", () => {
  const db = createMockDatabase();
  const next: Database = {
    ...db,
    tenants: db.tenants.map((t) =>
      t.id === "t1" ? { ...t, archivedAt: today(), tenantStatus: "Former" } : t,
    ),
  };
  assert.equal(filterTenants(next, filters).length, 23);
  assert.equal(
    filterTenants(next, { ...filters, includeArchived: true }).length,
    24,
  );
  assert.deepEqual(tenantLeases(next, "t1"), tenantLeases(db, "t1"));
  assert.deepEqual(next.transactions, db.transactions);
  assert.equal(dashboardSummary(next).outstanding, 6300);
});
