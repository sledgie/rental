# Rentora Tenant Management

A working React + Vite + TypeScript prototype with a responsive dark tenant directory, expandable master-detail rows, full tenant profiles, and connected lease and financial workflows.

## Run

```sh
npm install
npm run dev
```

```sh
npm run build
npm run preview
```

## What Works

- Search names, tenant IDs, formatted or unformatted phone numbers, email, property names, and unit numbers.
- Combine tenant status, outstanding balance, lease expiry, property, and archive filters with sorting and pagination.
- Inspect all lease units, household members, historical leases, and account balances in the master-detail table.
- Create and edit tenants, upload a local profile image, and optionally create or associate a lease.
- Associate an existing person or create a new co-tenant or occupant with specific units and signatory status.
- Open tenant profiles, property details, unit details, lease details, documents, and financial ledgers.
- Record payments, export filtered tenant records or ledgers to CSV, and download sample agreements.
- Archive and restore records without deleting leases, financial history, documents, or activities.
- Configure the lease expiry warning period and compact table density.

## Data And Accounting

`src/types.ts` defines normalized entities. Tenant, lease, property, unit, account, and transaction records are linked by IDs. `LeaseParty` and `PartyUnit` preserve each person's role and individual unit assignments.

`src/data/mockData.ts` creates 24 tenant records across four properties. It demonstrates multiple units under one lease, multiple independent lease accounts, co-tenants and occupants, a renewed unit with historical agreements, former tenants, and tenants without leases. Mock dates are relative to the current date.

`src/lib/domain.ts` contains the pure relationship, filtering, and accounting functions, separate from the reusable components in `src/components/`.

- Only posted transactions dated on or before today affect balances. Draft, cancelled, and voided records remain visible in ledgers but do not affect totals.
- Payments and credits settle the oldest unpaid charges within the same account. Overdue amounts use charge due dates and the remaining unpaid amount.
- Each billing account has one designated billing tenant. A shared lease does not duplicate its charges across every household member.
- The portfolio outstanding figure sums positive account balances once, including archived billing accounts. Credit balances are shown separately and never offset independent accounts.
- Current charges cover the current calendar month. Payment and credit totals are all-time posted totals. The interface identifies these periods and account scopes.
- Security deposits are shown on leases and held separately, not silently applied to rent.
- Current-unit counts include effective current leases, party memberships, and occupancy dates, with unit IDs deduplicated. Historical relationships remain available separately.
- Expiring is derived from the end date and a configurable warning window, initially 60 days.

## Verification

```sh
npx tsc --noEmit
npx tsx --test tests/domain.test.ts
npx playwright install --with-deps chromium
npx playwright test --workers=2
```

Domain tests verify relationship integrity, multi-unit and household assignments, transaction-based balances, independent account credits, historical records, searching, sorting, lease creation, duplicate prevention, and archival preservation. Browser tests cover the primary workflows, exports, profile tabs, document downloads, payments, and desktop, tablet, and mobile layouts.

## Prototype Scope

Data and preferences are stored in memory for the current session. Reloading restores the sample dataset. No backend, authentication, real payment processing, or external database is required. Agreements are clearly marked sample text documents, not signed legal contracts.

The Inter font is served locally; its license is in `public/fonts/LICENSE.txt`. All imagery uploaded through the form stays in the browser session.
