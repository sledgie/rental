import { NavLink } from "react-router-dom";
import {
  BarChart3,
  Building2,
  ChevronsLeft,
  CreditCard,
  DoorOpen,
  FileSignature,
  Hammer,
  LayoutDashboard,
  Receipt,
  Settings,
  Users,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/utils/cn";

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  badge?: string;
}

export const navItems: NavItem[] = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/properties", label: "Properties", icon: Building2 },
  { to: "/units", label: "Units", icon: DoorOpen },
  { to: "/tenants", label: "Tenants", icon: Users },
  { to: "/leases", label: "Leases", icon: FileSignature },
  { to: "/invoices", label: "Invoices", icon: Receipt, badge: "26" },
  { to: "/payments", label: "Payments", icon: CreditCard },
  { to: "/maintenance", label: "Maintenance", icon: Wrench, badge: "3" },
  { to: "/renovations", label: "Renovation Projects", icon: Hammer },
  { to: "/reports", label: "Reports", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: Settings },
];

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapsed: () => void;
  onNavigate?: () => void;
  variant?: "desktop" | "mobile";
  /** Live badge counts keyed by route, e.g. { "/invoices": 26 }. */
  counts?: Record<string, number>;
}

export function Sidebar({
  collapsed,
  onToggleCollapsed,
  onNavigate,
  variant = "desktop",
  counts,
}: SidebarProps) {
  const isMobile = variant === "mobile";
  const showLabels = isMobile || !collapsed;
  const items = navItems.map((n) => ({
    ...n,
    badge: counts?.[n.to] !== undefined ? String(counts[n.to]) : n.badge,
  }));

  return (
    <div
      className={cn(
        "flex h-full flex-col border-r border-line bg-surface transition-[width] duration-200 ease-out",
        collapsed && !isMobile ? "w-[68px]" : "w-64"
      )}
    >
      {/* Brand */}
      <div
        className={cn(
          "flex h-14 shrink-0 items-center gap-2.5 border-b border-line px-3.5",
          collapsed && !isMobile && "justify-center px-0"
        )}
      >
        <div className="grid size-8 shrink-0 place-items-center rounded-lg bg-accent text-white shadow-[0_0_0_1px_rgba(255,255,255,0.08)_inset]">
          <Building2 className="size-[17px]" strokeWidth={2.2} />
        </div>
        {showLabels ? (
          <div className="min-w-0">
            <p className="truncate text-[13.5px] font-semibold leading-tight text-ink">
              Prop Ledger
            </p>
            <p className="truncate text-[11px] leading-tight text-ink-faint">
              Rental management
            </p>
          </div>
        ) : null}
      </div>

      {/* Nav */}
      <nav className="scrollbar-thin flex-1 overflow-y-auto px-2 py-3" aria-label="Main">
        {showLabels ? (
          <p className="px-2.5 pb-2 text-[10px] font-semibold uppercase tracking-wider text-ink-faint">
            Portfolio
          </p>
        ) : (
          <div className="pb-2" />
        )}
        <ul className="space-y-0.5">
          {items.map((item) => (
            <li key={item.to}>
              <NavLink
                to={item.to}
                onClick={onNavigate}
                title={collapsed && !isMobile ? item.label : undefined}
                className={({ isActive }) =>
                  cn(
                    "group relative flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13.5px] transition-colors duration-150",
                    isActive
                      ? "bg-accent-soft text-ink"
                      : "text-ink-muted hover:bg-surface-2 hover:text-ink",
                    collapsed && !isMobile && "justify-center px-0"
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    {isActive ? (
                      <span className="absolute left-0 h-5 w-[2px] rounded-r bg-accent" />
                    ) : null}
                    <item.icon
                      className={cn(
                        "size-[17px] shrink-0",
                        isActive ? "text-accent-hover" : "text-ink-faint group-hover:text-ink-muted"
                      )}
                      strokeWidth={2}
                    />
                    {showLabels ? (
                      <>
                        <span className="truncate">{item.label}</span>
                        {item.badge ? (
                          <span
                            className={cn(
                              "ml-auto rounded px-1.5 py-0.5 text-[10px] font-semibold tabular-nums",
                              isActive
                                ? "bg-accent/25 text-[#c3c6fb]"
                                : "bg-surface-3 text-ink-faint"
                            )}
                          >
                            {item.badge}
                          </span>
                        ) : null}
                      </>
                    ) : null}
                  </>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      {/* Demo banner */}
      {showLabels ? (
        <div className="mx-2 mb-2 rounded-lg border border-line bg-surface-2 px-3 py-2.5">
          <p className="text-[11px] font-semibold text-ink-muted">Demonstration data</p>
          <p className="mt-0.5 text-[11px] leading-snug text-ink-faint">
            Sample portfolio as of Oct 22, 2026. Changes stay in this browser only.
          </p>
        </div>
      ) : null}

      {/* Profile */}
      <div className="border-t border-line p-2">
        <div
          className={cn(
            "flex items-center gap-2.5 rounded-lg px-2 py-2",
            collapsed && !isMobile && "justify-center px-0"
          )}
        >
          <div className="grid size-8 shrink-0 place-items-center rounded-full bg-[#2a3050] text-[11px] font-semibold text-[#b9bcfa] ring-1 ring-accent/30">
            DW
          </div>
          {showLabels ? (
            <div className="min-w-0 flex-1">
              <p className="truncate text-[12.5px] font-medium text-ink">Dana Whitmore</p>
              <p className="truncate text-[11px] text-ink-faint">Property Manager</p>
            </div>
          ) : null}
        </div>
        {!isMobile ? (
          <button
            type="button"
            onClick={onToggleCollapsed}
            className={cn(
              "mt-1 flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] text-ink-faint transition-colors hover:bg-surface-2 hover:text-ink",
              collapsed && "justify-center px-0"
            )}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            <ChevronsLeft
              className={cn("size-4 transition-transform duration-200", collapsed && "rotate-180")}
            />
            {showLabels ? <span>Collapse</span> : null}
          </button>
        ) : null}
      </div>
    </div>
  );
}
