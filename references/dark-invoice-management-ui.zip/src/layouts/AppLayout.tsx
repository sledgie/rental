import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { Bell, CircleHelp, Menu as MenuIcon, Search, X } from "lucide-react";
import { Sidebar } from "@/components/Sidebar";
import { useInvoices } from "@/store/InvoiceStore";
import { cn } from "@/utils/cn";

const COLLAPSE_KEY = "prop-ledger.sidebar.collapsed";

export function AppLayout() {
  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem(COLLAPSE_KEY) === "1";
    } catch {
      return false;
    }
  });
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { invoices } = useInvoices();
  const openInvoices = invoices.filter(
    (i) => !["paid", "void", "draft"].includes(i.status)
  ).length;

  useEffect(() => {
    try {
      localStorage.setItem(COLLAPSE_KEY, collapsed ? "1" : "0");
    } catch {
      /* noop */
    }
  }, [collapsed]);

  // Close the mobile drawer whenever the route changes.
  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  return (
    <div className="flex min-h-screen bg-canvas text-ink">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen shrink-0 lg:block">
        <Sidebar
          collapsed={collapsed}
          onToggleCollapsed={() => setCollapsed((v) => !v)}
          counts={{ "/invoices": openInvoices }}
        />
      </aside>

      {/* Mobile drawer */}
      {mobileOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="animate-fade-in absolute inset-0 bg-black/65"
            onClick={() => setMobileOpen(false)}
          />
          <div className="animate-slide-up absolute inset-y-0 left-0 w-64">
            <Sidebar
              variant="mobile"
              collapsed={false}
              onToggleCollapsed={() => setMobileOpen(false)}
              onNavigate={() => setMobileOpen(false)}
              counts={{ "/invoices": openInvoices }}
            />
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              aria-label="Close navigation"
              className="absolute -right-11 top-3 grid size-9 place-items-center rounded-lg border border-line-strong bg-surface text-ink-muted"
            >
              <X className="size-4" />
            </button>
          </div>
        </div>
      ) : null}

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-canvas/85 px-4 backdrop-blur-md sm:px-6">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            aria-label="Open navigation"
            className="grid size-9 shrink-0 place-items-center rounded-lg border border-line-strong bg-surface-2 text-ink-muted transition-colors hover:text-ink lg:hidden"
          >
            <MenuIcon className="size-4" />
          </button>

          <div className="relative hidden max-w-sm flex-1 sm:block">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-ink-faint" />
            <input
              type="search"
              placeholder="Search the workspace…"
              aria-label="Global search"
              className="h-9 w-full rounded-lg border border-line bg-surface-2 pl-9 pr-3 text-[13px] text-ink placeholder:text-ink-faint transition-colors focus:border-accent/60 focus:outline-none focus:ring-2 focus:ring-accent/20"
            />
          </div>

          <div className="ml-auto flex items-center gap-1.5">
            <span className="mr-1 hidden items-center gap-1.5 rounded-full border border-line bg-surface-2 px-2.5 py-1 text-[11px] text-ink-faint xl:inline-flex">
              <span className="size-1.5 rounded-full bg-unpaid" />
              Prototype · demo data
            </span>
            <button
              type="button"
              aria-label="Help"
              className="grid size-9 place-items-center rounded-lg text-ink-faint transition-colors hover:bg-surface-2 hover:text-ink"
            >
              <CircleHelp className="size-4" />
            </button>
            <button
              type="button"
              aria-label="Notifications"
              className="relative grid size-9 place-items-center rounded-lg text-ink-faint transition-colors hover:bg-surface-2 hover:text-ink"
            >
              <Bell className="size-4" />
              <span className="absolute right-2 top-2 size-1.5 rounded-full bg-overdue ring-2 ring-canvas" />
            </button>
            <div
              className={cn(
                "ml-1 grid size-8 place-items-center rounded-full bg-[#2a3050] text-[11px] font-semibold text-[#b9bcfa] ring-1 ring-accent/30"
              )}
            >
              DW
            </div>
          </div>
        </header>

        <main className="min-w-0 flex-1 px-4 py-5 sm:px-6 sm:py-6">
          <Outlet />
        </main>

        <footer className="border-t border-line px-4 py-4 text-[11px] text-ink-faint sm:px-6">
          Prop Ledger · Invoice management prototype. All invoices, tenants and payments are
          fictional demonstration data — no live payments are processed.
        </footer>
      </div>
    </div>
  );
}
