import { Link, useLocation } from "react-router-dom";
import { ArrowRight, Construction, LayoutGrid } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/Button";
import { navItems } from "@/components/Sidebar";

const fallback = (path: string) =>
  path
    .replace(/^\//, "")
    .replace(/-/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());

export default function PlaceholderPage() {
  const { pathname } = useLocation();
  const item = navItems.find((n) => n.to === pathname);
  const title = item?.label ?? fallback(pathname);

  return (
    <>
      <PageHeader
        title={title}
        subtitle="This module is outside the scope of the invoice prototype."
        actions={
          <Link to="/invoices">
            <Button variant="primary">
              Go to Invoices
              <ArrowRight className="size-4" />
            </Button>
          </Link>
        }
      />
      <div className="rounded-xl border border-line bg-surface px-6 py-16 text-center">
        <div className="mx-auto grid size-11 place-items-center rounded-full border border-line bg-surface-2">
          <Construction className="size-5 text-unpaid" />
        </div>
        <p className="mt-4 text-[15px] font-medium text-ink">{title} is not wired up yet</p>
        <p className="mx-auto mt-1.5 max-w-md text-[13px] leading-relaxed text-ink-muted">
          This prototype focuses on the invoice management module. The{" "}
          <span className="text-ink">{title}</span> navigation entry is here to demonstrate the
          complete application shell — the underlying data and screens are illustrative only.
        </p>
        <div className="mt-5 flex flex-wrap justify-center gap-2">
          <Link to="/invoices">
            <Button variant="primary">
              <LayoutGrid className="size-4" />
              Open invoice register
            </Button>
          </Link>
          <Link to="/invoices">
            <Button variant="secondary">Browse demo invoices</Button>
          </Link>
        </div>
      </div>
    </>
  );
}
