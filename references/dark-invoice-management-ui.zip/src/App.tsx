import { HashRouter, Navigate, Route, Routes } from "react-router-dom";
import { AppLayout } from "@/layouts/AppLayout";
import InvoiceDetailPage from "@/pages/InvoiceDetailPage";
import InvoiceListPage from "@/pages/InvoiceListPage";
import PlaceholderPage from "@/pages/PlaceholderPage";
import { ToastProvider } from "@/components/ui/Toast";
import { InvoiceStoreProvider } from "@/store/InvoiceStore";
import { navItems } from "@/components/Sidebar";

const otherModules = navItems
  .filter((n) => n.to !== "/invoices")
  .map((n) => n.to.replace(/^\//, ""));

export default function App() {
  return (
    <InvoiceStoreProvider>
      <ToastProvider>
        <HashRouter>
          <Routes>
            <Route element={<AppLayout />}>
              <Route index element={<Navigate to="/invoices" replace />} />
              <Route path="invoices" element={<InvoiceListPage />} />
              <Route path="invoices/:id" element={<InvoiceDetailPage />} />
              {otherModules.map((path) => (
                <Route key={path} path={path} element={<PlaceholderPage />} />
              ))}
              <Route path="*" element={<Navigate to="/invoices" replace />} />
            </Route>
          </Routes>
        </HashRouter>
      </ToastProvider>
    </InvoiceStoreProvider>
  );
}
