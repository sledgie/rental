import { useState } from 'react';
import {
  Bell, Building2, CalendarClock, CheckCircle2, FileText, Hammer, Home, Info,
  LayoutDashboard, Menu as MenuIcon, Package, Receipt, Search, Settings, TriangleAlert,
  Users, Wrench, X,
} from 'lucide-react';
import { StoreProvider, useStore, type PageKey } from './store';
import { Avatar } from './ui';
import { MaintenanceRequestsPage } from './pages/Maintenance';
import { AssetsPage } from './pages/Assets';
import { PreventivePage, WorkOrdersPage } from './pages/Operations';
import {
  BillsPage, DashboardPage, LeasesPage, ProjectsPage, PropertiesPage, SettingsPage,
  TenantsPage, UnitsPage,
} from './pages/Other';
import { OPEN_STATUSES } from './types';
import { isOverdue } from './utils';
import { cn } from './utils/cn';

interface NavItem {
  key: PageKey;
  label: string;
  icon: React.ReactNode;
  badge?: number;
  alert?: boolean;
}

function Sidebar({ mobileOpen, setMobileOpen }: { mobileOpen: boolean; setMobileOpen: (v: boolean) => void }) {
  const s = useStore();
  const openCount = s.requests.filter((r) => OPEN_STATUSES.includes(r.status)).length;
  const alertCount = s.requests.filter((r) => (OPEN_STATUSES.includes(r.status) && r.priority === 'Emergency') || isOverdue(r)).length;
  const woOpen = s.workOrders.filter((w) => !['Completed', 'Cancelled'].includes(w.status)).length;
  const pmDue = s.schedules.filter((sc) => sc.active && sc.nextDue <= new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10)).length;

  const groups: { heading: string; items: NavItem[] }[] = [
    { heading: 'Overview', items: [{ key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={16} /> }] },
    {
      heading: 'Portfolio',
      items: [
        { key: 'properties', label: 'Properties', icon: <Building2 size={16} /> },
        { key: 'units', label: 'Units', icon: <Home size={16} /> },
        { key: 'tenants', label: 'Tenants', icon: <Users size={16} /> },
        { key: 'leases', label: 'Leases', icon: <FileText size={16} /> },
      ],
    },
    {
      heading: 'Maintenance',
      items: [
        { key: 'requests', label: 'Maintenance Requests', icon: <Wrench size={16} />, badge: openCount, alert: alertCount > 0 },
        { key: 'workorders', label: 'Work Orders', icon: <Hammer size={16} />, badge: woOpen },
        { key: 'assets', label: 'Assets & Appliances', icon: <Package size={16} /> },
        { key: 'preventive', label: 'Preventive Maintenance', icon: <CalendarClock size={16} />, badge: pmDue || undefined, alert: s.schedules.some((sc) => sc.active && sc.nextDue < new Date().toISOString().slice(0, 10)) },
      ],
    },
    {
      heading: 'Operations & Finance',
      items: [
        { key: 'projects', label: 'Projects', icon: <Hammer size={16} /> },
        { key: 'bills', label: 'Bills & Expenses', icon: <Receipt size={16} /> },
      ],
    },
  ];

  return (
    <>
      {mobileOpen && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setMobileOpen(false)} />}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 flex w-[248px] flex-col border-r border-line bg-[#0c1017] transition-transform lg:static lg:translate-x-0',
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex items-center gap-2.5 px-5 pb-5 pt-6">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-500 text-zinc-950">
            <Building2 size={19} strokeWidth={2.2} />
          </span>
          <span>
            <span className="block text-[15px] font-bold leading-tight tracking-tight text-zinc-50">Keystone</span>
            <span className="block text-[10.5px] font-medium uppercase tracking-widest text-zinc-500">Property Manager</span>
          </span>
          <button className="ml-auto rounded-md p-1 text-zinc-500 lg:hidden" onClick={() => setMobileOpen(false)}><X size={16} /></button>
        </div>

        <nav className="flex-1 space-y-5 overflow-y-auto px-3 pb-4">
          {groups.map((g) => (
            <div key={g.heading}>
              <p className="px-2.5 pb-1.5 text-[10.5px] font-semibold uppercase tracking-widest text-zinc-600">{g.heading}</p>
              <div className="space-y-0.5">
                {g.items.map((item) => {
                  const active = s.route.page === item.key;
                  return (
                    <button
                      key={item.key}
                      onClick={() => { s.navigate(item.key); setMobileOpen(false); }}
                      className={cn(
                        'flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] font-medium transition',
                        active ? 'bg-teal-500/12 text-teal-300 ring-1 ring-inset ring-teal-500/25' : 'text-zinc-400 hover:bg-panel2 hover:text-zinc-100'
                      )}
                    >
                      <span className={active ? 'text-teal-300' : 'text-zinc-500'}>{item.icon}</span>
                      <span className="flex-1 text-left">{item.label}</span>
                      {item.alert && <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse" title="Emergencies or overdue items" />}
                      {item.badge !== undefined && item.badge > 0 && (
                        <span className={cn('rounded-full px-1.5 py-px text-[10px] font-semibold tabular', active ? 'bg-teal-500/20 text-teal-200' : 'bg-panel3 text-zinc-400')}>
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="border-t border-line p-3">
          <button
            onClick={() => { s.navigate('settings'); setMobileOpen(false); }}
            className={cn(
              'mb-2 flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] font-medium transition',
              s.route.page === 'settings' ? 'bg-teal-500/12 text-teal-300 ring-1 ring-inset ring-teal-500/25' : 'text-zinc-400 hover:bg-panel2 hover:text-zinc-100'
            )}
          >
            <Settings size={16} className="text-zinc-500" /> Settings
          </button>
          <div className="flex items-center gap-2.5 rounded-lg bg-panel2 px-3 py-2.5">
            <Avatar name={s.currentUser.name} />
            <span className="min-w-0">
              <span className="block truncate text-[12.5px] font-medium text-zinc-100">{s.currentUser.name}</span>
              <span className="block text-[11px] text-zinc-500">{s.currentUser.role}</span>
            </span>
          </div>
        </div>
      </aside>
    </>
  );
}

const PAGE_TITLES: Record<PageKey, string> = {
  dashboard: 'Dashboard', properties: 'Properties', units: 'Units', tenants: 'Tenants',
  leases: 'Leases', requests: 'Maintenance Requests', workorders: 'Work Orders',
  assets: 'Assets & Appliances', preventive: 'Preventive Maintenance', projects: 'Projects',
  bills: 'Bills & Expenses', settings: 'Settings',
};

function Topbar({ setMobileOpen }: { setMobileOpen: (v: boolean) => void }) {
  const s = useStore();
  const [query, setQuery] = useState('');
  const alerts = s.requests.filter((r) => (OPEN_STATUSES.includes(r.status) && r.priority === 'Emergency') || isOverdue(r)).length;

  return (
    <header className="sticky top-0 z-20 flex h-[57px] items-center gap-3 border-b border-line bg-ink/90 px-4 backdrop-blur lg:px-6">
      <button className="rounded-md p-1.5 text-zinc-400 transition hover:bg-panel2 lg:hidden" onClick={() => setMobileOpen(true)}>
        <MenuIcon size={18} />
      </button>
      <div className="hidden items-center gap-1.5 text-[13px] text-zinc-500 sm:flex">
        <span>Keystone</span>
        <span className="text-zinc-700">/</span>
        <span className="font-medium text-zinc-200">{PAGE_TITLES[s.route.page]}</span>
      </div>
      <div className="relative mx-auto w-full max-w-md flex-1 px-2">
        <Search size={14} className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && query.trim()) {
              s.navigate('requests', { searchQuery: query.trim() });
              setQuery('');
            }
          }}
          placeholder="Search requests… (Enter)"
          className="w-full rounded-lg border border-line bg-panel2 py-1.5 pl-9 pr-3 text-[12.5px] text-zinc-100 outline-none placeholder:text-zinc-600 focus:border-teal-500/60"
        />
      </div>
      <span className="hidden items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-[10.5px] font-medium text-amber-300 md:inline-flex" title="In-memory prototype — data resets on refresh">
        <Info size={11} /> Demo data
      </span>
      <button
        onClick={() => s.navigate('requests')}
        className="relative rounded-lg border border-line bg-panel2 p-2 text-zinc-400 transition hover:border-zinc-600 hover:text-zinc-100"
        title={alerts ? `${alerts} emergency/overdue items need attention` : 'Notifications'}
      >
        <Bell size={16} />
        {alerts > 0 && (
          <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-0.5 text-[9.5px] font-bold text-white">{alerts}</span>
        )}
      </button>
      <Avatar name={s.currentUser.name} />
    </header>
  );
}

function Toasts() {
  const s = useStore();
  const icons = {
    success: <CheckCircle2 size={16} className="text-emerald-400" />,
    info: <Info size={16} className="text-sky-400" />,
    warning: <TriangleAlert size={16} className="text-amber-400" />,
    error: <TriangleAlert size={16} className="text-rose-400" />,
  };
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-[340px] max-w-[calc(100vw-2rem)] flex-col gap-2">
      {s.toasts.map((t) => (
        <div key={t.id} className="pointer-events-auto flex items-start gap-2.5 rounded-xl border border-line bg-panel2 px-3.5 py-3 shadow-xl shadow-black/50 animate-toast">
          <span className="mt-px shrink-0">{icons[t.kind]}</span>
          <p className="flex-1 text-[12.5px] leading-snug text-zinc-200">{t.message}</p>
          <button onClick={() => s.dismissToast(t.id)} className="shrink-0 text-zinc-500 transition hover:text-zinc-200"><X size={13} /></button>
        </div>
      ))}
    </div>
  );
}

function Shell() {
  const s = useStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const page = s.route.page;

  return (
    <div className="flex min-h-screen bg-ink font-sans">
      <Sidebar mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar setMobileOpen={setMobileOpen} />
        <main className="flex-1 animate-fade-in" key={page}>
          {page === 'dashboard' && <DashboardPage />}
          {page === 'properties' && <PropertiesPage />}
          {page === 'units' && <UnitsPage />}
          {page === 'tenants' && <TenantsPage />}
          {page === 'leases' && <LeasesPage />}
          {page === 'requests' && <MaintenanceRequestsPage />}
          {page === 'workorders' && <WorkOrdersPage />}
          {page === 'assets' && <AssetsPage />}
          {page === 'preventive' && <PreventivePage />}
          {page === 'projects' && <ProjectsPage />}
          {page === 'bills' && <BillsPage />}
          {page === 'settings' && <SettingsPage />}
        </main>
        <footer className="border-t border-line px-6 py-3 text-center text-[11px] text-zinc-600">
          Keystone Property Management · Maintenance module prototype · In-memory demo data — changes reset on refresh.
        </footer>
      </div>
      <Toasts />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
