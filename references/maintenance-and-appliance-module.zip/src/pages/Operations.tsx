import { Fragment, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle, CalendarClock, CalendarDays, CheckCircle2, ChevronDown, ClipboardList,
  ExternalLink, ListChecks, MoreHorizontal, Pencil, Plus, Power, Search, Wrench, X,
} from 'lucide-react';
import { useStore } from '../store';
import {
  Avatar, Chip, ConfirmDialog, DetailItem, EmptyState, Menu, PrimaryButton,
  PriorityBadge, SectionTitle, SelectInput, SmallButton,
} from '../ui';
import {
  CompleteWorkOrderModal, PreventiveFormModal, RequestFormModal, VisitModal,
  WorkLogModal, WorkOrderFormModal,
} from '../modals';
import { WORKORDER_STATUSES, type PreventiveSchedule, type WorkOrder } from '../types';
import { daysUntil, fmtDate, fmtMoney, todayISO } from '../utils';
import { cn } from '../utils/cn';

// ═════════════════════════════════════════════════════════════════════════════
// Work Orders
// ═════════════════════════════════════════════════════════════════════════════

function woTone(status: string): 'green' | 'amber' | 'red' | 'zinc' | 'sky' | 'teal' {
  switch (status) {
    case 'Completed': return 'green';
    case 'In Progress': return 'sky';
    case 'Scheduled': return 'teal';
    case 'On Hold': return 'amber';
    case 'Cancelled': return 'red';
    default: return 'zinc';
  }
}

export function WorkOrdersPage() {
  const s = useStore();
  const [search, setSearch] = useState('');
  const [fStatus, setFStatus] = useState('');
  const [fContractor, setFContractor] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [formWO, setFormWO] = useState<WorkOrder | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [completing, setCompleting] = useState<WorkOrder | null>(null);
  const [worklogFor, setWorklogFor] = useState<WorkOrder | null>(null);
  const [visitFor, setVisitFor] = useState<WorkOrder | null>(null);
  const [cancelConfirm, setCancelConfirm] = useState<WorkOrder | null>(null);

  useEffect(() => {
    if (s.route.focusRequestId) {
      setSearch(s.route.focusRequestId);
      const first = s.workOrders.find((w) => w.requestId === s.route.focusRequestId);
      if (first) setExpandedId(first.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.route.nonce]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return s.workOrders.filter((w) => {
      if (fStatus && w.status !== fStatus) return false;
      if (fContractor && w.contractorId !== fContractor) return false;
      if (q) {
        const req = s.requests.find((r) => r.id === w.requestId);
        const hay = [w.id, w.title, w.description, w.requestId, req?.title ?? '', s.getProperty(req?.propertyId)?.name ?? '', s.getUnit(req?.unitId)?.name ?? '', s.getContractor(w.contractorId)?.company ?? ''].join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.workOrders, s.requests, search, fStatus, fContractor]);

  const counts = useMemo(() => ({
    open: s.workOrders.filter((w) => !['Completed', 'Cancelled'].includes(w.status)).length,
    scheduled: s.workOrders.filter((w) => w.status === 'Scheduled').length,
    inProgress: s.workOrders.filter((w) => w.status === 'In Progress').length,
    unassigned: s.workOrders.filter((w) => w.status === 'Awaiting Assignment' && !w.contractorId).length,
    completed: s.workOrders.filter((w) => w.status === 'Completed').length,
  }), [s.workOrders]);

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-bold tracking-tight text-zinc-50">Work Orders</h1>
          <p className="mt-0.5 text-[13px] text-zinc-500">Contractor jobs, visits and follow-up tasks generated from maintenance requests.</p>
        </div>
        <PrimaryButton onClick={() => { setFormWO(null); setFormOpen(true); }}><Plus size={15} /> New Work Order</PrimaryButton>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-5">
        {[
          { label: 'Open Work Orders', value: counts.open },
          { label: 'Scheduled', value: counts.scheduled },
          { label: 'In Progress', value: counts.inProgress },
          { label: 'Awaiting Contractor', value: counts.unassigned, tone: counts.unassigned ? 'text-amber-400' : undefined },
          { label: 'Completed', value: counts.completed, tone: 'text-emerald-400' },
        ].map((c, i) => (
          <div key={i} className="rounded-xl border border-line bg-panel p-3.5">
            <div className={cn('text-[22px] font-bold leading-none tabular text-zinc-50', c.tone)}>{c.value}</div>
            <div className="mt-1.5 text-[12px] font-medium text-zinc-300">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-line bg-panel p-3">
        <div className="relative min-w-[220px] flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search work order, request ID, property, contractor…" className="w-full rounded-lg border border-line bg-panel2 py-2 pl-9 pr-3 text-[13px] text-zinc-100 outline-none placeholder:text-zinc-600 focus:border-teal-500/60 focus:ring-2 focus:ring-teal-500/15" />
        </div>
        <div className="w-44"><SelectInput value={fStatus} onChange={(e) => setFStatus(e.target.value)}>
          <option value="">All Statuses</option>{WORKORDER_STATUSES.map((st) => <option key={st} value={st}>{st}</option>)}
        </SelectInput></div>
        <div className="w-48"><SelectInput value={fContractor} onChange={(e) => setFContractor(e.target.value)}>
          <option value="">All Contractors</option>{s.contractors.map((c) => <option key={c.id} value={c.id}>{c.company}</option>)}
        </SelectInput></div>
        {(search || fStatus || fContractor) && (
          <button onClick={() => { setSearch(''); setFStatus(''); setFContractor(''); }} className="inline-flex items-center gap-1 text-[12px] font-medium text-teal-400 hover:text-teal-300"><X size={13} /> Clear</button>
        )}
      </div>

      <div className="mt-4 overflow-hidden rounded-xl border border-line bg-panel">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1100px] border-collapse">
            <thead>
              <tr className="border-b border-line bg-panel2/60 text-left text-[11px] uppercase tracking-wider text-zinc-500">
                <th className="w-10 px-2 py-2.5" />
                <th className="px-3 py-2.5 font-semibold">Work Order</th>
                <th className="px-3 py-2.5 font-semibold">Request</th>
                <th className="px-3 py-2.5 font-semibold">Property / Unit</th>
                <th className="px-3 py-2.5 font-semibold">Contractor</th>
                <th className="px-3 py-2.5 font-semibold">Priority</th>
                <th className="px-3 py-2.5 font-semibold">Scheduled</th>
                <th className="px-3 py-2.5 font-semibold">Target</th>
                <th className="px-3 py-2.5 font-semibold">Status</th>
                <th className="px-3 py-2.5 text-right font-semibold">Estimate</th>
                <th className="px-3 py-2.5 text-right font-semibold">Actual</th>
                <th className="w-12 px-2 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {filtered.map((w, idx) => {
                const req = s.requests.find((r) => r.id === w.requestId);
                const expanded = expandedId === w.id;
                const overdue = w.targetDate && !['Completed', 'Cancelled'].includes(w.status) && (daysUntil(w.targetDate) ?? 0) < 0;
                return (
                  <Fragment key={w.id}>
                    <tr onClick={() => setExpandedId(expanded ? null : w.id)} className={cn('cursor-pointer border-b border-line/60 transition hover:bg-white/[0.02]', expanded && 'bg-teal-500/[0.03]')}>
                      <td className="px-2 py-3">
                        <span className={cn('flex h-6 w-6 items-center justify-center rounded-md border', expanded ? 'border-teal-500/40 bg-teal-500/10 text-teal-300' : 'border-line text-zinc-500')}>
                          <ChevronDown size={13} className={cn('transition-transform', expanded && 'rotate-180')} />
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <div className="max-w-[260px] truncate text-[13px] font-medium text-zinc-100">{w.title}</div>
                        <div className="text-[11px] text-zinc-500">{w.id}</div>
                      </td>
                      <td className="px-3 py-3">
                        <button onClick={(e) => { e.stopPropagation(); s.navigate('requests', { focusRequestId: w.requestId }); }} className="text-left">
                          <span className="block text-[12.5px] font-medium text-teal-300 hover:text-teal-200">{w.requestId}</span>
                          <span className="block max-w-[180px] truncate text-[11px] text-zinc-500">{req?.title}</span>
                        </button>
                      </td>
                      <td className="px-3 py-3 text-[12.5px] text-zinc-300">
                        {s.getProperty(req?.propertyId)?.name}
                        <span className="block text-[11px] text-zinc-500">{s.getUnit(req?.unitId)?.name ?? 'Common Area'}</span>
                      </td>
                      <td className="px-3 py-3 text-[12.5px] text-zinc-300">{s.getContractor(w.contractorId)?.company ?? <span className="text-amber-400">Unassigned</span>}</td>
                      <td className="px-3 py-3"><PriorityBadge priority={w.priority} /></td>
                      <td className="px-3 py-3 text-[12.5px] tabular text-zinc-300">{fmtDate(w.scheduledDate)}</td>
                      <td className="px-3 py-3 text-[12.5px] tabular">
                        <span className={overdue ? 'font-medium text-rose-400' : 'text-zinc-300'}>{fmtDate(w.targetDate)}</span>
                        {overdue && <span className="block text-[11px] font-semibold text-rose-400">Overdue</span>}
                      </td>
                      <td className="px-3 py-3"><Chip tone={woTone(w.status)}>{w.status}</Chip></td>
                      <td className="px-3 py-3 text-right text-[12.5px] tabular text-zinc-300">{fmtMoney(w.estimate)}</td>
                      <td className="px-3 py-3 text-right text-[12.5px] font-medium tabular text-zinc-100">{w.actualCost ? fmtMoney(w.actualCost) : '—'}</td>
                      <td className="px-2 py-3" onClick={(e) => e.stopPropagation()}>
                        <Menu
                          dropUp={idx >= filtered.length - 2 && filtered.length > 2}
                          trigger={<button className="rounded-md p-1.5 text-zinc-500 transition hover:bg-panel3 hover:text-zinc-100"><MoreHorizontal size={16} /></button>}
                          items={[
                            { label: 'Edit Work Order', icon: <Pencil size={13} />, onClick: () => { setFormWO(w); setFormOpen(true); } },
                            { label: 'Schedule a Visit', icon: <CalendarDays size={13} />, onClick: () => setVisitFor(w) },
                            { label: 'Add Work Log', icon: <ClipboardList size={13} />, onClick: () => setWorklogFor(w) },
                            { label: '', onClick: () => {}, divider: true },
                            ...(w.status !== 'In Progress' && w.status !== 'Completed' ? [{ label: 'Start Work', icon: <Wrench size={13} />, onClick: () => { s.updateWorkOrder(w.id, { status: 'In Progress' as const }, `Work order ${w.id} started`); s.toast(`${w.id} in progress.`); } }] : []),
                            ...(w.status !== 'Completed' ? [{ label: 'Complete Work Order…', icon: <CheckCircle2 size={13} />, onClick: () => setCompleting(w) }] : []),
                            ...(w.status !== 'Cancelled' && w.status !== 'Completed' ? [{ label: 'Cancel Work Order', icon: <X size={13} />, danger: true, onClick: () => setCancelConfirm(w) }] : []),
                          ]}
                        />
                      </td>
                    </tr>
                    {expanded && (
                      <tr className="border-b border-line bg-[#0c1017]">
                        <td colSpan={12} className="px-5 py-4">
                          <WorkOrderDetail
                            wo={w}
                            onEdit={() => { setFormWO(w); setFormOpen(true); }}
                            onComplete={() => setCompleting(w)}
                            onVisit={() => setVisitFor(w)}
                            onWorklog={() => setWorklogFor(w)}
                          />
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <EmptyState icon={<Wrench size={20} />} title="No work orders found" body="Create a work order here, or generate one from a maintenance request." action={<PrimaryButton onClick={() => { setFormWO(null); setFormOpen(true); }} className="px-3 py-2 text-[12px]">New Work Order</PrimaryButton>} />
          )}
        </div>
      </div>

      <WorkOrderFormModal open={formOpen} onClose={() => setFormOpen(false)} workOrder={formWO} />
      <CompleteWorkOrderModal open={!!completing} onClose={() => setCompleting(null)} workOrder={completing} />
      <WorkLogModal
        open={!!worklogFor}
        onClose={() => setWorklogFor(null)}
        request={worklogFor ? s.requests.find((r) => r.id === worklogFor.requestId) ?? null : null}
        workOrderId={worklogFor?.id}
      />
      <VisitModal
        open={!!visitFor}
        onClose={() => setVisitFor(null)}
        request={visitFor ? s.requests.find((r) => r.id === visitFor.requestId) ?? null : null}
      />
      <ConfirmDialog
        open={!!cancelConfirm}
        onClose={() => setCancelConfirm(null)}
        title={`Cancel ${cancelConfirm?.id}?`}
        body={<>This work order will be marked as cancelled. The parent maintenance request stays open so the work can be re-scoped or reassigned.</>}
        confirmLabel="Cancel Work Order"
        danger
        onConfirm={() => {
          if (cancelConfirm) {
            s.updateWorkOrder(cancelConfirm.id, { status: 'Cancelled' }, `Work order ${cancelConfirm.id} cancelled`);
            s.toast(`${cancelConfirm.id} cancelled.`, 'warning');
          }
        }}
      />
    </div>
  );
}

function WorkOrderDetail({ wo, onEdit, onComplete, onVisit, onWorklog }: { wo: WorkOrder; onEdit: () => void; onComplete: () => void; onVisit: () => void; onWorklog: () => void }) {
  const s = useStore();
  const req = s.requests.find((r) => r.id === wo.requestId);
  const visits = s.visits.filter((v) => v.workOrderId === wo.id);
  const logs = s.workLogs.filter((l) => l.workOrderId === wo.id);
  const expense = wo.linkedExpenseId ? s.getExpense(wo.linkedExpenseId) : undefined;
  const contractor = s.getContractor(wo.contractorId);

  return (
    <div className="animate-expand">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <h3 className="text-[15px] font-semibold text-zinc-50">{wo.title}</h3>
        <Chip tone={woTone(wo.status)}>{wo.status}</Chip>
        <PriorityBadge priority={wo.priority} />
        <span className="ml-auto flex flex-wrap gap-1.5">
          <SmallButton onClick={onEdit}><Pencil size={12} /> Edit</SmallButton>
          <SmallButton onClick={onVisit}><CalendarDays size={12} /> Schedule Visit</SmallButton>
          <SmallButton onClick={onWorklog}><ClipboardList size={12} /> Add Work Log</SmallButton>
          {wo.status !== 'Completed' && wo.status !== 'Cancelled' && (
            <PrimaryButton onClick={onComplete} className="px-2.5 py-1.5 text-[12px]"><CheckCircle2 size={13} /> Complete</PrimaryButton>
          )}
        </span>
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div>
          <SectionTitle icon={<Wrench size={13} />}>Job Details</SectionTitle>
          <dl className="grid grid-cols-2 gap-x-3 gap-y-3.5 rounded-xl border border-line bg-panel px-4 py-3.5">
            <DetailItem label="Request">
              <button onClick={() => s.navigate('requests', { focusRequestId: wo.requestId })} className="text-teal-300 hover:text-teal-200">{wo.requestId} <ExternalLink size={10} className="inline" /></button>
            </DetailItem>
            <DetailItem label="Property / Unit">{s.getProperty(req?.propertyId)?.name} · {s.getUnit(req?.unitId)?.name ?? 'Common Area'}</DetailItem>
            <DetailItem label="Contractor">{contractor ? `${contractor.company} (${contractor.contact}, ${contractor.phone})` : 'Unassigned'}</DetailItem>
            <DetailItem label="Staff Owner">{s.getStaff(wo.staffId)?.name ?? '—'}</DetailItem>
            <DetailItem label="Scheduled">{fmtDate(wo.scheduledDate)}</DetailItem>
            <DetailItem label="Target">{fmtDate(wo.targetDate)}</DetailItem>
            <DetailItem label="Estimate">{fmtMoney(wo.estimate)}</DetailItem>
            <DetailItem label="Approved Budget">{fmtMoney(wo.approvedBudget)}</DetailItem>
            <DetailItem label="Actual Cost">{fmtMoney(wo.actualCost)}</DetailItem>
            <DetailItem label="Linked Expense">{expense ? <button onClick={() => s.navigate('bills')} className="text-teal-300 hover:text-teal-200">{expense.id} · {fmtMoney(expense.amount)}</button> : '—'}</DetailItem>
            <DetailItem label="Work Description" className="col-span-2">{wo.description}</DetailItem>
            {wo.scope && <DetailItem label="Scope of Work" className="col-span-2">{wo.scope}</DetailItem>}
            {wo.completionNotes && <DetailItem label="Completion Notes" className="col-span-2">{wo.completionNotes}</DetailItem>}
          </dl>
          {wo.status !== 'Completed' && wo.status !== 'Cancelled' && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {(['Draft', 'Awaiting Assignment', 'Scheduled', 'In Progress', 'On Hold'] as const).filter((st) => st !== wo.status).map((st) => (
                <SmallButton key={st} onClick={() => { s.updateWorkOrder(wo.id, { status: st }, `Work order ${wo.id} → ${st}`); s.toast(`${wo.id} → ${st}.`); }}>
                  → {st}
                </SmallButton>
              ))}
            </div>
          )}
        </div>
        <div>
          <SectionTitle icon={<CalendarDays size={13} />}>Visits ({visits.length})</SectionTitle>
          {visits.length === 0 ? (
            <p className="rounded-xl border border-line bg-panel px-4 py-3 text-[12.5px] text-zinc-500">No visits recorded for this work order.</p>
          ) : (
            <div className="space-y-2">
              {visits.map((v) => (
                <div key={v.id} className="rounded-xl border border-line bg-panel px-3.5 py-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[12.5px] font-medium text-zinc-100">{v.purpose}</span>
                    <Chip tone={v.status === 'Completed' ? 'green' : v.status === 'Cancelled' ? 'red' : 'sky'}>{v.status}</Chip>
                  </div>
                  <p className="mt-0.5 text-[11.5px] text-zinc-500">{fmtDate(v.date)} · {v.time} · ~{v.durationMins} min</p>
                </div>
              ))}
            </div>
          )}
        </div>
        <div>
          <SectionTitle icon={<ClipboardList size={13} />}>Work Log ({logs.length})</SectionTitle>
          {logs.length === 0 ? (
            <p className="rounded-xl border border-line bg-panel px-4 py-3 text-[12.5px] text-zinc-500">No work log entries yet.</p>
          ) : (
            <div className="space-y-2">
              {logs.map((l) => (
                <div key={l.id} className="rounded-xl border border-line bg-panel px-3.5 py-2.5">
                  <div className="flex items-center gap-2">
                    <Avatar name={l.person} size="sm" />
                    <span className="text-[12.5px] font-medium text-zinc-100">{l.person}</span>
                    <span className="ml-auto text-[11px] text-zinc-500">{fmtDate(l.date)} · {l.hours}h</span>
                  </div>
                  <p className="mt-1.5 text-[12.5px] leading-relaxed text-zinc-300">{l.workPerformed}</p>
                  <p className="mt-1 text-[11px] text-zinc-500">{l.outcome}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// Preventive Maintenance
// ═════════════════════════════════════════════════════════════════════════════

function dueState(sc: PreventiveSchedule): { label: string; tone: 'red' | 'amber' | 'green' | 'zinc' } {
  if (!sc.active) return { label: 'Inactive', tone: 'zinc' };
  const d = daysUntil(sc.nextDue) ?? 0;
  if (d < 0) return { label: `Overdue ${Math.abs(d)}d`, tone: 'red' };
  if (d === 0) return { label: 'Due today', tone: 'amber' };
  if (d <= 14) return { label: `Due in ${d}d`, tone: 'amber' };
  return { label: `Due in ${d}d`, tone: 'green' };
}

export function PreventivePage() {
  const s = useStore();
  const [fProperty, setFProperty] = useState('');
  const [showInactive, setShowInactive] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<PreventiveSchedule | null>(null);
  const [genRequest, setGenRequest] = useState<PreventiveSchedule | null>(null);
  const [completeConfirm, setCompleteConfirm] = useState<PreventiveSchedule | null>(null);
  const [doneChecklist, setDoneChecklist] = useState<Record<string, Set<number>>>({});

  const list = useMemo(() => {
    return s.schedules
      .filter((sc) => (!fProperty || sc.propertyId === fProperty) && (showInactive || sc.active))
      .sort((a, b) => a.nextDue.localeCompare(b.nextDue));
  }, [s.schedules, fProperty, showInactive]);

  const overdueCount = s.schedules.filter((sc) => sc.active && (daysUntil(sc.nextDue) ?? 0) < 0).length;
  const dueSoonCount = s.schedules.filter((sc) => { const d = daysUntil(sc.nextDue) ?? 99; return sc.active && d >= 0 && d <= 14; }).length;

  const toggleCheck = (id: string, idx: number) => {
    setDoneChecklist((prev) => {
      const next = { ...prev };
      const set = new Set(next[id] ?? []);
      if (set.has(idx)) set.delete(idx); else set.add(idx);
      next[id] = set;
      return next;
    });
  };

  const generateWorkOrder = (sc: PreventiveSchedule) => {
    // Create a maintenance request from the schedule, then a work order under it
    const reqId = s.nextRequestId();
    s.addRequest({
      id: reqId, title: sc.task, description: `Preventive maintenance task generated from schedule ${sc.id}. ${sc.instructions ?? ''}`.trim(),
      category: sc.category, priority: 'Normal', status: sc.contractorId ? 'Assigned' : 'New',
      propertyId: sc.propertyId, unitId: sc.unitId, assetId: sc.assetId,
      reportedByName: s.currentUser.name, reportedByRole: 'Property Manager', source: 'Preventive Maintenance',
      reportedAt: new Date().toISOString(), targetDate: sc.nextDue < todayISO() ? todayISO() : sc.nextDue,
      assignedStaffId: s.currentUser.id, assignedContractorId: sc.contractorId,
      approvalStatus: 'Not Required', linkedExpenseIds: [], previousCompletions: [], createdBy: s.currentUser.name,
    }, `Generated from preventive schedule ${sc.id}`);
    const woId = s.nextWorkOrderId();
    setTimeout(() => {
      s.addWorkOrder({
        id: woId, requestId: reqId, title: sc.task, description: sc.instructions ?? sc.task,
        scope: sc.checklist.length ? `Checklist:\n${sc.checklist.map((c) => `• ${c}`).join('\n')}` : undefined,
        contractorId: sc.contractorId, priority: 'Normal', targetDate: sc.nextDue,
        status: sc.contractorId ? 'Scheduled' : 'Awaiting Assignment', estimate: sc.estimatedCost,
        createdAt: new Date().toISOString(),
      });
    }, 0);
    s.toast(`Request ${reqId} and work order created from schedule ${sc.id}.`);
    s.navigate('requests', { focusRequestId: reqId });
  };

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-bold tracking-tight text-zinc-50">Preventive Maintenance</h1>
          <p className="mt-0.5 text-[13px] text-zinc-500">Recurring inspections and servicing that prevent breakdowns — and keep warranties valid.</p>
        </div>
        <PrimaryButton onClick={() => { setEditing(null); setFormOpen(true); }}><Plus size={15} /> New Schedule</PrimaryButton>
      </div>

      {(overdueCount > 0 || dueSoonCount > 0) && (
        <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-amber-500/25 bg-amber-500/5 px-4 py-2.5 text-[12.5px] text-amber-200">
          <AlertTriangle size={14} />
          <span>
            {overdueCount > 0 && <><b>{overdueCount} overdue</b> task{overdueCount === 1 ? '' : 's'}</>}
            {overdueCount > 0 && dueSoonCount > 0 && ' · '}
            {dueSoonCount > 0 && <><b>{dueSoonCount}</b> due within 14 days</>}
            . Generate a request or work order to get them scheduled. (Prototype: indicators only — no background jobs or external reminders are running.)
          </span>
        </div>
      )}

      <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-line bg-panel p-3">
        <div className="w-52"><SelectInput value={fProperty} onChange={(e) => setFProperty(e.target.value)}>
          <option value="">All Properties</option>{s.properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </SelectInput></div>
        <label className="flex items-center gap-2 text-[12.5px] text-zinc-300">
          <input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} className="h-4 w-4 accent-teal-500" />
          Show inactive schedules
        </label>
        <span className="ml-auto text-[12px] text-zinc-500">{list.length} schedule{list.length === 1 ? '' : 's'}</span>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 lg:grid-cols-2">
        {list.map((sc) => {
          const due = dueState(sc);
          const asset = s.getAsset(sc.assetId);
          const checked = doneChecklist[sc.id] ?? new Set<number>();
          return (
            <div key={sc.id} className={cn('rounded-xl border bg-panel p-4', sc.active ? 'border-line' : 'border-line/60 opacity-65', due.tone === 'red' && sc.active && 'border-rose-500/30')}>
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-[14px] font-semibold text-zinc-50">{sc.task}</h3>
                    <Chip tone={due.tone}>{due.label}</Chip>
                    {!sc.active && <Chip>Paused</Chip>}
                  </div>
                  <p className="mt-0.5 text-[12px] text-zinc-500">
                    {sc.id} · {sc.category} · {s.getProperty(sc.propertyId)?.name}
                    {sc.unitId ? ` · ${s.getUnit(sc.unitId)?.name}` : ' · Whole property'}
                    {asset ? ` · ${asset.id} ${asset.name}` : ''}
                  </p>
                </div>
                <Menu
                  trigger={<button className="rounded-md p-1.5 text-zinc-500 transition hover:bg-panel3 hover:text-zinc-100"><MoreHorizontal size={16} /></button>}
                  items={[
                    { label: 'Edit Schedule', icon: <Pencil size={13} />, onClick: () => { setEditing(sc); setFormOpen(true); } },
                    { label: sc.active ? 'Deactivate Schedule' : 'Activate Schedule', icon: <Power size={13} />, onClick: () => { s.updateSchedule(sc.id, { active: !sc.active }); s.toast(`${sc.id} ${sc.active ? 'deactivated' : 'activated'}.`, 'info'); } },
                  ]}
                />
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2 text-[12px] sm:grid-cols-4">
                <span className="rounded-lg bg-panel2 px-2.5 py-1.5"><span className="text-zinc-500">Frequency </span><b className="text-zinc-200">{sc.frequency}{sc.frequency === 'Custom' ? ` (${sc.customDays}d)` : ''}</b></span>
                <span className="rounded-lg bg-panel2 px-2.5 py-1.5"><span className="text-zinc-500">Last done </span><b className="tabular text-zinc-200">{fmtDate(sc.lastCompleted)}</b></span>
                <span className="rounded-lg bg-panel2 px-2.5 py-1.5"><span className="text-zinc-500">Next due </span><b className={cn('tabular', due.tone === 'red' ? 'text-rose-400' : 'text-zinc-200')}>{fmtDate(sc.nextDue)}</b></span>
                <span className="rounded-lg bg-panel2 px-2.5 py-1.5"><span className="text-zinc-500">Est. cost </span><b className="tabular text-zinc-200">{fmtMoney(sc.estimatedCost)}</b></span>
              </div>
              <p className="mt-2 text-[12px] text-zinc-500">
                {sc.contractorId ? `Contractor: ${s.getContractor(sc.contractorId)?.company}` : 'Handled in-house / unassigned'}
                {sc.instructions && <span className="mt-0.5 block text-zinc-400">{sc.instructions}</span>}
              </p>

              {sc.checklist.length > 0 && (
                <div className="mt-3 rounded-lg border border-line bg-panel2/50 px-3 py-2.5">
                  <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-500">
                    <ListChecks size={12} /> Checklist · {checked.size}/{sc.checklist.length}
                  </p>
                  <div className="space-y-1">
                    {sc.checklist.map((item, i) => (
                      <label key={i} className="flex cursor-pointer items-center gap-2 text-[12.5px] text-zinc-300">
                        <input type="checkbox" checked={checked.has(i)} onChange={() => toggleCheck(sc.id, i)} className="h-3.5 w-3.5 accent-teal-500" />
                        <span className={checked.has(i) ? 'text-zinc-500 line-through' : ''}>{item}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-3.5 flex flex-wrap gap-1.5">
                <PrimaryButton onClick={() => setCompleteConfirm(sc)} disabled={!sc.active} className="px-2.5 py-1.5 text-[12px]">
                  <CheckCircle2 size={13} /> Mark Complete
                </PrimaryButton>
                <SmallButton onClick={() => setGenRequest(sc)} disabled={!sc.active}><Wrench size={12} /> Generate Request</SmallButton>
                <SmallButton onClick={() => generateWorkOrder(sc)} disabled={!sc.active}><ClipboardList size={12} /> Generate Request + Work Order</SmallButton>
                <SmallButton onClick={() => { setEditing(sc); setFormOpen(true); }}><Pencil size={12} /> Edit</SmallButton>
              </div>
            </div>
          );
        })}
      </div>
      {list.length === 0 && (
        <div className="mt-4 rounded-xl border border-line bg-panel">
          <EmptyState icon={<CalendarClock size={20} />} title="No schedules found" body="Create recurring tasks like furnace servicing, alarm inspections and filter changes so nothing falls through the cracks." />
        </div>
      )}

      <PreventiveFormModal open={formOpen} onClose={() => setFormOpen(false)} schedule={editing} />
      <RequestFormModal
        open={!!genRequest}
        onClose={() => setGenRequest(null)}
        preset={genRequest ? {
          propertyId: genRequest.propertyId, unitId: genRequest.unitId, assetId: genRequest.assetId,
          title: genRequest.task, category: genRequest.category, source: 'Preventive Maintenance',
          description: `Scheduled preventive task (${genRequest.id}, ${genRequest.frequency}). ${genRequest.instructions ?? ''}${genRequest.checklist.length ? `\n\nChecklist:\n${genRequest.checklist.map((c) => `• ${c}`).join('\n')}` : ''}`,
        } : undefined}
        onSaved={(id) => s.navigate('requests', { focusRequestId: id })}
      />
      <ConfirmDialog
        open={!!completeConfirm}
        onClose={() => setCompleteConfirm(null)}
        title={`Complete “${completeConfirm?.task}”?`}
        body={<>This sets the last-completed date to today and recalculates the next due date from the <b className="text-zinc-200">{completeConfirm?.frequency.toLowerCase()}</b> schedule. Checklist progress on this card will reset.</>}
        confirmLabel="Mark Complete"
        onConfirm={() => {
          if (completeConfirm) {
            s.completeSchedule(completeConfirm.id);
            setDoneChecklist((p) => ({ ...p, [completeConfirm.id]: new Set() }));
          }
        }}
      />
    </div>
  );
}
