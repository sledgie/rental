import { useMemo, useState } from 'react';
import {
  AlertTriangle, ArrowRight, Building2, CalendarClock, CheckCircle2, CircleDollarSign,
  Hammer, Home, Inbox, KeyRound, Mail, Phone, Plus, Receipt, RotateCcw, Search,
  Settings2, Siren, TrendingUp, Users, Wrench, X,
} from 'lucide-react';
import { useStore } from '../store';
import {
  Avatar, Chip, EmptyState, Field, GhostButton, Modal, MoneyInput, PaymentBadge,
  PriorityBadge, PrimaryButton, ProgressBar, SectionTitle, SelectInput, SmallButton,
  StatusBadge, TextInput,
} from '../ui';
import { EXPENSE_CATEGORIES, OPEN_STATUSES, type Expense } from '../types';
import { daysUntil, fmtDate, fmtMoney, isOverdue, overdueDays, timeAgo, todayISO } from '../utils';
import { cn } from '../utils/cn';

function PageHeader({ title, sub, action }: { title: string; sub: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-[22px] font-bold tracking-tight text-zinc-50">{title}</h1>
        <p className="mt-0.5 text-[13px] text-zinc-500">{sub}</p>
      </div>
      {action}
    </div>
  );
}

// ── Dashboard ────────────────────────────────────────────────────────────────

export function DashboardPage() {
  const s = useStore();
  const occupied = s.units.filter((u) => u.status === 'Occupied').length;
  const rentRoll = s.leases.filter((l) => l.status !== 'Ended').reduce((sum, l) => sum + l.rent, 0);
  const open = s.requests.filter((r) => OPEN_STATUSES.includes(r.status));
  const emergencies = open.filter((r) => r.priority === 'Emergency');
  const overdue = s.requests.filter((r) => isOverdue(r));
  const unpaid = s.expenses.filter((e) => e.paymentStatus !== 'Paid');
  const unpaidTotal = unpaid.reduce((sum, e) => sum + (e.amount - (e.amountPaid ?? 0)), 0);
  const attention = [...emergencies, ...overdue.filter((r) => r.priority !== 'Emergency')].slice(0, 6);
  const upcomingPM = [...s.schedules].filter((sc) => sc.active).sort((a, b) => a.nextDue.localeCompare(b.nextDue)).slice(0, 5);
  const recentActivity = [...s.activity].sort((a, b) => b.timestamp.localeCompare(a.timestamp)).slice(0, 8);
  const byStatus = OPEN_STATUSES.map((st) => ({ status: st, count: open.filter((r) => r.status === st).length })).filter((x) => x.count > 0);
  const maxStatus = Math.max(1, ...byStatus.map((x) => x.count));
  const maintenanceSpend30 = s.expenses
    .filter((e) => ['Maintenance & Repairs', 'Appliance Purchase'].includes(e.category) && (daysUntil(e.date) ?? -999) >= -30)
    .reduce((sum, e) => sum + e.amount, 0);

  const kpis = [
    { label: 'Occupancy', value: `${occupied}/${s.units.length}`, sub: `${Math.round((occupied / s.units.length) * 100)}% occupied`, icon: <Home size={17} />, accent: 'text-teal-300 bg-teal-500/10', page: 'units' as const },
    { label: 'Monthly Rent Roll', value: fmtMoney(rentRoll), sub: `${s.leases.filter((l) => l.status !== 'Ended').length} active leases`, icon: <TrendingUp size={17} />, accent: 'text-emerald-400 bg-emerald-500/10', page: 'leases' as const },
    { label: 'Open Requests', value: open.length, sub: `${emergencies.length} emergency · ${overdue.length} overdue`, icon: <Wrench size={17} />, accent: 'text-sky-400 bg-sky-500/10', page: 'requests' as const },
    { label: 'Maintenance Spend (30d)', value: fmtMoney(maintenanceSpend30), sub: 'From Bills & Expenses', icon: <CircleDollarSign size={17} />, accent: 'text-violet-400 bg-violet-500/10', page: 'bills' as const },
    { label: 'Unpaid Bills', value: fmtMoney(unpaidTotal), sub: `${unpaid.length} open invoices`, icon: <Receipt size={17} />, accent: 'text-amber-400 bg-amber-500/10', page: 'bills' as const },
  ];

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <PageHeader title={`Good day, ${s.currentUser.name.split(' ')[0]}`} sub="Portfolio overview — maintenance, money and tenancies at a glance." />
      <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        {kpis.map((k) => (
          <button key={k.label} onClick={() => s.navigate(k.page)} className="rounded-xl border border-line bg-panel p-4 text-left transition hover:border-zinc-600">
            <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg', k.accent)}>{k.icon}</span>
            <div className="mt-2.5 text-[22px] font-bold leading-none tabular text-zinc-50">{k.value}</div>
            <div className="mt-1 text-[12px] font-medium text-zinc-300">{k.label}</div>
            <div className="text-[11px] text-zinc-600">{k.sub}</div>
          </button>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="rounded-xl border border-line bg-panel p-4 xl:col-span-2">
          <SectionTitle icon={<Siren size={13} />} action={<SmallButton onClick={() => s.navigate('requests')}>Open Maintenance <ArrowRight size={11} /></SmallButton>}>
            Needs Attention
          </SectionTitle>
          {attention.length === 0 ? (
            <p className="flex items-center gap-2 py-6 text-[13px] text-zinc-400"><CheckCircle2 size={16} className="text-emerald-400" /> No emergencies or overdue requests. The queue is healthy.</p>
          ) : (
            <div className="space-y-2">
              {attention.map((r) => (
                <button key={r.id} onClick={() => s.navigate('requests', { focusRequestId: r.id })} className="flex w-full flex-wrap items-center gap-3 rounded-lg border border-line bg-panel2/60 px-3.5 py-2.5 text-left transition hover:border-zinc-600">
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] font-medium text-zinc-100">{r.title}</span>
                    <span className="text-[11.5px] text-zinc-500">{r.id} · {s.getProperty(r.propertyId)?.name} · {s.getUnit(r.unitId)?.name ?? 'Common Area'} · reported {timeAgo(r.reportedAt)}</span>
                  </span>
                  <PriorityBadge priority={r.priority} />
                  <StatusBadge status={r.status} />
                  {isOverdue(r) && <Chip tone="red">Overdue {overdueDays(r)}d</Chip>}
                </button>
              ))}
            </div>
          )}
          <div className="mt-5">
            <SectionTitle icon={<Inbox size={13} />}>Open Requests by Status</SectionTitle>
            <div className="space-y-2">
              {byStatus.map((x) => (
                <button key={x.status} onClick={() => s.navigate('requests', { statusFilter: x.status })} className="flex w-full items-center gap-3 text-left">
                  <span className="w-36 shrink-0 text-[12px] text-zinc-400">{x.status}</span>
                  <span className="h-2 flex-1 overflow-hidden rounded-full bg-panel3">
                    <span className="block h-full rounded-full bg-teal-500/80 transition-all" style={{ width: `${(x.count / maxStatus) * 100}%` }} />
                  </span>
                  <span className="w-6 text-right text-[12px] font-medium tabular text-zinc-200">{x.count}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-xl border border-line bg-panel p-4">
            <SectionTitle icon={<CalendarClock size={13} />} action={<SmallButton onClick={() => s.navigate('preventive')}>All <ArrowRight size={11} /></SmallButton>}>
              Preventive Maintenance Due
            </SectionTitle>
            <div className="space-y-2">
              {upcomingPM.map((sc) => {
                const d = daysUntil(sc.nextDue) ?? 0;
                return (
                  <div key={sc.id} className="flex items-center justify-between gap-2 rounded-lg border border-line bg-panel2/60 px-3 py-2">
                    <span className="min-w-0">
                      <span className="block truncate text-[12.5px] font-medium text-zinc-100">{sc.task}</span>
                      <span className="text-[11px] text-zinc-500">{s.getProperty(sc.propertyId)?.name} · {fmtDate(sc.nextDue)}</span>
                    </span>
                    <Chip tone={d < 0 ? 'red' : d <= 14 ? 'amber' : 'green'}>{d < 0 ? `${Math.abs(d)}d overdue` : d === 0 ? 'Today' : `${d}d`}</Chip>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="rounded-xl border border-line bg-panel p-4">
            <SectionTitle icon={<Receipt size={13} />} action={<SmallButton onClick={() => s.navigate('bills')}>All <ArrowRight size={11} /></SmallButton>}>
              Unpaid & Due
            </SectionTitle>
            <div className="space-y-2">
              {unpaid.slice(0, 5).map((e) => (
                <div key={e.id} className="flex items-center justify-between gap-2 rounded-lg border border-line bg-panel2/60 px-3 py-2">
                  <span className="min-w-0">
                    <span className="block truncate text-[12.5px] font-medium text-zinc-100">{e.vendor}</span>
                    <span className="text-[11px] text-zinc-500">{e.id} · due {fmtDate(e.dueDate)}</span>
                  </span>
                  <span className="flex shrink-0 items-center gap-2">
                    <PaymentBadge status={e.paymentStatus} />
                    <b className="text-[12.5px] tabular text-zinc-100">{fmtMoney(e.amount - (e.amountPaid ?? 0))}</b>
                  </span>
                </div>
              ))}
              {unpaid.length === 0 && <p className="py-3 text-[12.5px] text-zinc-500">All bills are settled.</p>}
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-xl border border-line bg-panel p-4">
        <SectionTitle icon={<Wrench size={13} />}>Recent Maintenance Activity</SectionTitle>
        <div className="grid grid-cols-1 gap-x-8 md:grid-cols-2">
          {recentActivity.map((a) => (
            <button
              key={a.id}
              onClick={() => a.requestId && s.navigate('requests', { focusRequestId: a.requestId })}
              className="flex items-start gap-3 border-b border-line/50 py-2.5 text-left last:border-0"
            >
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-teal-500/80" />
              <span className="min-w-0">
                <span className="block truncate text-[12.5px] text-zinc-200">{a.description}</span>
                <span className="text-[11px] text-zinc-500">{a.requestId} · {a.user} · {timeAgo(a.timestamp)}</span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Properties ───────────────────────────────────────────────────────────────

export function PropertiesPage() {
  const s = useStore();
  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <PageHeader title="Properties" sub={`${s.properties.length} properties · ${s.units.length} units under management.`} />
      <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
        {s.properties.map((p) => {
          const units = s.unitsForProperty(p.id);
          const occupied = units.filter((u) => u.status === 'Occupied').length;
          const openReqs = s.requests.filter((r) => r.propertyId === p.id && OPEN_STATUSES.includes(r.status)).length;
          const assets = s.assets.filter((a) => a.propertyId === p.id && !['Replaced', 'Disposed', 'Retired'].includes(a.status)).length;
          const rent = s.leases.filter((l) => units.some((u) => u.id === l.unitId) && l.status !== 'Ended').reduce((sum, l) => sum + l.rent, 0);
          return (
            <div key={p.id} className="rounded-xl border border-line bg-panel p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="flex items-center gap-2 text-[16px] font-semibold text-zinc-50"><Building2 size={17} className="text-teal-400" /> {p.name}</h3>
                  <p className="mt-0.5 text-[12.5px] text-zinc-500">{p.address}, {p.city} · {p.type} · Built {p.yearBuilt}</p>
                </div>
                <Chip tone={occupied === units.length ? 'green' : 'amber'}>{occupied}/{units.length} occupied</Chip>
              </div>
              <div className="mt-3"><ProgressBar value={(occupied / Math.max(1, units.length)) * 100} /></div>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {units.map((u) => {
                  const lease = s.leaseForUnit(u.id);
                  return (
                    <span key={u.id} className={cn('rounded-lg border px-2.5 py-1.5 text-[11.5px]', u.status === 'Occupied' ? 'border-line bg-panel2 text-zinc-200' : 'border-dashed border-zinc-700 text-zinc-500')}>
                      <b>{u.name}</b> · {u.beds}bd{u.status !== 'Occupied' ? ` · ${u.status}` : lease ? ` · ${s.getTenant(lease.tenantId)?.name.split(' ')[0]}` : ''}
                    </span>
                  );
                })}
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-1 border-t border-line pt-3.5 text-[12.5px]">
                <span className="text-zinc-400">Rent roll <b className="tabular text-zinc-100">{fmtMoney(rent)}/mo</b></span>
                <button onClick={() => s.navigate('requests', { searchQuery: p.name })} className="text-zinc-400 transition hover:text-teal-300">Open requests <b className="tabular text-zinc-100">{openReqs}</b></button>
                <button onClick={() => s.navigate('assets')} className="text-zinc-400 transition hover:text-teal-300">Assets <b className="tabular text-zinc-100">{assets}</b></button>
                <button onClick={() => s.navigate('units')} className="ml-auto inline-flex items-center gap-1 font-medium text-teal-400 hover:text-teal-300">View units <ArrowRight size={12} /></button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Units ────────────────────────────────────────────────────────────────────

export function UnitsPage() {
  const s = useStore();
  const [fProperty, setFProperty] = useState('');
  const [fStatus, setFStatus] = useState('');
  const units = s.units.filter((u) => (!fProperty || u.propertyId === fProperty) && (!fStatus || u.status === fStatus));
  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <PageHeader title="Units" sub="Every rentable unit with its current tenancy and open maintenance." />
      <div className="mt-4 flex gap-2 rounded-xl border border-line bg-panel p-3">
        <div className="w-52"><SelectInput value={fProperty} onChange={(e) => setFProperty(e.target.value)}>
          <option value="">All Properties</option>{s.properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </SelectInput></div>
        <div className="w-44"><SelectInput value={fStatus} onChange={(e) => setFStatus(e.target.value)}>
          <option value="">Any Status</option><option>Occupied</option><option>Vacant</option><option>Notice Given</option>
        </SelectInput></div>
      </div>
      <div className="mt-4 overflow-hidden rounded-xl border border-line bg-panel">
        <table className="w-full min-w-[900px]">
          <thead><tr className="border-b border-line bg-panel2/60 text-left text-[11px] uppercase tracking-wider text-zinc-500">
            <th className="px-4 py-2.5 font-semibold">Unit</th><th className="px-4 py-2.5 font-semibold">Property</th><th className="px-4 py-2.5 font-semibold">Layout</th><th className="px-4 py-2.5 font-semibold">Status</th><th className="px-4 py-2.5 font-semibold">Tenant</th><th className="px-4 py-2.5 font-semibold">Rent</th><th className="px-4 py-2.5 font-semibold">Assets</th><th className="px-4 py-2.5 font-semibold">Open Requests</th>
          </tr></thead>
          <tbody>
            {units.map((u) => {
              const lease = s.leaseForUnit(u.id);
              const tenant = lease ? s.getTenant(lease.tenantId) : undefined;
              const openCount = s.requests.filter((r) => r.unitId === u.id && OPEN_STATUSES.includes(r.status)).length;
              const assetCount = s.assets.filter((a) => a.unitId === u.id && !['Replaced', 'Disposed', 'Retired'].includes(a.status)).length;
              return (
                <tr key={u.id} className="border-b border-line/50 last:border-0 hover:bg-white/[0.02]">
                  <td className="px-4 py-3 text-[13px] font-medium text-zinc-100">{u.name}</td>
                  <td className="px-4 py-3 text-[12.5px] text-zinc-300">{s.getProperty(u.propertyId)?.name}</td>
                  <td className="px-4 py-3 text-[12.5px] tabular text-zinc-300">{u.beds} bd · {u.baths} ba · {u.sqft} sqft</td>
                  <td className="px-4 py-3"><Chip tone={u.status === 'Occupied' ? 'green' : u.status === 'Vacant' ? 'amber' : 'sky'}>{u.status}</Chip></td>
                  <td className="px-4 py-3">{tenant ? <span className="flex items-center gap-2 text-[12.5px] text-zinc-200"><Avatar name={tenant.name} size="sm" />{tenant.name}</span> : <span className="text-zinc-600">—</span>}</td>
                  <td className="px-4 py-3 text-[12.5px] tabular text-zinc-200">{lease ? `${fmtMoney(lease.rent)}/mo` : '—'}</td>
                  <td className="px-4 py-3 text-[12.5px] tabular text-zinc-300">{assetCount}</td>
                  <td className="px-4 py-3">
                    {openCount > 0 ? (
                      <button onClick={() => s.navigate('requests', { searchQuery: `${s.getProperty(u.propertyId)?.name} ${u.name}` })} className="font-medium text-teal-300 hover:text-teal-200">{openCount} open →</button>
                    ) : <span className="text-zinc-600">0</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Tenants ──────────────────────────────────────────────────────────────────

export function TenantsPage() {
  const s = useStore();
  const [search, setSearch] = useState('');
  const q = search.toLowerCase();
  const tenants = s.tenants.filter((t) => !q || `${t.name} ${t.email} ${t.phone}`.toLowerCase().includes(q));
  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <PageHeader title="Tenants" sub="Current residents, contact details and their maintenance history." />
      <div className="relative mt-4 max-w-md">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tenants…" className="w-full rounded-lg border border-line bg-panel2 py-2 pl-9 pr-3 text-[13px] text-zinc-100 outline-none placeholder:text-zinc-600 focus:border-teal-500/60" />
      </div>
      <div className="mt-4 overflow-hidden rounded-xl border border-line bg-panel">
        <table className="w-full min-w-[900px]">
          <thead><tr className="border-b border-line bg-panel2/60 text-left text-[11px] uppercase tracking-wider text-zinc-500">
            <th className="px-4 py-2.5 font-semibold">Tenant</th><th className="px-4 py-2.5 font-semibold">Contact</th><th className="px-4 py-2.5 font-semibold">Unit</th><th className="px-4 py-2.5 font-semibold">Lease Ends</th><th className="px-4 py-2.5 font-semibold">Rent</th><th className="px-4 py-2.5 font-semibold">Requests</th>
          </tr></thead>
          <tbody>
            {tenants.map((t) => {
              const lease = s.leases.find((l) => l.tenantId === t.id && l.status !== 'Ended');
              const unit = lease ? s.getUnit(lease.unitId) : undefined;
              const reqs = s.requests.filter((r) => r.tenantId === t.id);
              const open = reqs.filter((r) => OPEN_STATUSES.includes(r.status)).length;
              return (
                <tr key={t.id} className="border-b border-line/50 last:border-0 hover:bg-white/[0.02]">
                  <td className="px-4 py-3"><span className="flex items-center gap-2.5"><Avatar name={t.name} /><span><span className="block text-[13px] font-medium text-zinc-100">{t.name}</span><span className="text-[11px] text-zinc-500">Since {fmtDate(t.movedIn)}</span></span></span></td>
                  <td className="px-4 py-3 text-[12.5px] text-zinc-300">
                    <span className="flex items-center gap-1.5"><Phone size={11} className="text-zinc-500" />{t.phone}</span>
                    <span className="flex items-center gap-1.5"><Mail size={11} className="text-zinc-500" />{t.email}</span>
                  </td>
                  <td className="px-4 py-3 text-[12.5px] text-zinc-300">{unit ? `${s.getProperty(unit.propertyId)?.name} · ${unit.name}` : '—'}</td>
                  <td className="px-4 py-3 text-[12.5px] tabular text-zinc-300">{lease ? fmtDate(lease.end) : '—'}{lease && (daysUntil(lease.end) ?? 999) <= 45 && <span className="block text-[11px] text-amber-400">Expiring in {daysUntil(lease.end)}d</span>}</td>
                  <td className="px-4 py-3 text-[12.5px] tabular text-zinc-200">{lease ? `${fmtMoney(lease.rent)}/mo` : '—'}</td>
                  <td className="px-4 py-3">
                    <button onClick={() => s.navigate('requests', { searchQuery: t.name })} className="text-[12.5px] font-medium text-teal-300 hover:text-teal-200">
                      {reqs.length} total{open ? ` · ${open} open` : ''} →
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Leases ───────────────────────────────────────────────────────────────────

export function LeasesPage() {
  const s = useStore();
  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <PageHeader title="Leases" sub="Active tenancies. A maintenance request keeps the lease that applied when it was reported." />
      <div className="mt-4 overflow-hidden rounded-xl border border-line bg-panel">
        <table className="w-full min-w-[900px]">
          <thead><tr className="border-b border-line bg-panel2/60 text-left text-[11px] uppercase tracking-wider text-zinc-500">
            <th className="px-4 py-2.5 font-semibold">Lease</th><th className="px-4 py-2.5 font-semibold">Tenant</th><th className="px-4 py-2.5 font-semibold">Unit</th><th className="px-4 py-2.5 font-semibold">Term</th><th className="px-4 py-2.5 font-semibold">Rent</th><th className="px-4 py-2.5 font-semibold">Remaining</th><th className="px-4 py-2.5 font-semibold">Status</th>
          </tr></thead>
          <tbody>
            {s.leases.map((l) => {
              const unit = s.getUnit(l.unitId);
              const tenant = s.getTenant(l.tenantId);
              const remaining = daysUntil(l.end) ?? 0;
              return (
                <tr key={l.id} className="border-b border-line/50 last:border-0 hover:bg-white/[0.02]">
                  <td className="px-4 py-3 text-[13px] font-medium text-zinc-100">{l.id}</td>
                  <td className="px-4 py-3"><span className="flex items-center gap-2 text-[12.5px] text-zinc-200"><Avatar name={tenant?.name ?? '?'} size="sm" />{tenant?.name}</span></td>
                  <td className="px-4 py-3 text-[12.5px] text-zinc-300">{s.getProperty(unit?.propertyId)?.name} · {unit?.name}</td>
                  <td className="px-4 py-3 text-[12.5px] tabular text-zinc-300">{fmtDate(l.start)} → {fmtDate(l.end)}</td>
                  <td className="px-4 py-3 text-[12.5px] tabular text-zinc-200">{fmtMoney(l.rent)}/mo</td>
                  <td className="px-4 py-3 text-[12.5px] tabular text-zinc-300">{remaining > 0 ? `${remaining} days` : 'Ended'}</td>
                  <td className="px-4 py-3"><Chip tone={l.status === 'Active' ? 'green' : l.status === 'Expiring Soon' ? 'amber' : 'zinc'}>{l.status}</Chip></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Projects ─────────────────────────────────────────────────────────────────

export function ProjectsPage() {
  const s = useStore();
  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <PageHeader title="Projects" sub="Capital improvements and renovations. Routine repairs stay in Maintenance — large jobs graduate here." />
      <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-3">
        {s.projects.map((p) => {
          const pct = Math.round((p.spent / p.budget) * 100);
          return (
            <div key={p.id} className="rounded-xl border border-line bg-panel p-5">
              <div className="flex items-start justify-between gap-2">
                <h3 className="flex items-center gap-2 text-[15px] font-semibold text-zinc-50"><Hammer size={15} className="text-teal-400" />{p.name}</h3>
                <Chip tone={p.status === 'Completed' ? 'green' : p.status === 'In Progress' ? 'sky' : 'zinc'}>{p.status}</Chip>
              </div>
              <p className="mt-1 text-[12px] text-zinc-500">{s.getProperty(p.propertyId)?.name}{p.unitId ? ` · ${s.getUnit(p.unitId)?.name}` : ''} · {fmtDate(p.start)} → {fmtDate(p.end)}</p>
              <div className="mt-4">
                <div className="mb-1 flex justify-between text-[11.5px] text-zinc-500"><span>Progress</span><span className="tabular text-zinc-300">{p.progress}%</span></div>
                <ProgressBar value={p.progress} />
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-panel2 px-2 py-2"><p className="text-[13px] font-semibold tabular text-zinc-100">{fmtMoney(p.budget)}</p><p className="text-[10.5px] text-zinc-500">Budget</p></div>
                <div className="rounded-lg bg-panel2 px-2 py-2"><p className="text-[13px] font-semibold tabular text-zinc-100">{fmtMoney(p.spent)}</p><p className="text-[10.5px] text-zinc-500">Spent ({pct}%)</p></div>
                <div className="rounded-lg bg-panel2 px-2 py-2"><p className={cn('text-[13px] font-semibold tabular', p.budget - p.spent < 0 ? 'text-rose-400' : 'text-zinc-100')}>{fmtMoney(p.budget - p.spent)}</p><p className="text-[10.5px] text-zinc-500">Remaining</p></div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Bills & Expenses ─────────────────────────────────────────────────────────

export function BillsPage() {
  const s = useStore();
  const [search, setSearch] = useState('');
  const [fStatus, setFStatus] = useState('');
  const [fCategory, setFCategory] = useState('');
  const [fProperty, setFProperty] = useState('');
  const [adding, setAdding] = useState(false);
  const [paying, setPaying] = useState<Expense | null>(null);
  const [payAmount, setPayAmount] = useState('');

  const now = new Date();
  const due = (e: Expense) => e.amount - (e.amountPaid ?? 0);
  const unpaid = s.expenses.filter((e) => e.paymentStatus !== 'Paid');
  const overdueAmt = s.expenses.filter((e) => e.paymentStatus === 'Overdue').reduce((sum, e) => sum + due(e), 0);
  const paidThisMonth = s.expenses.filter((e) => e.paymentStatus === 'Paid' && new Date(e.date + 'T12:00:00').getMonth() === now.getMonth()).reduce((sum, e) => sum + e.amount, 0);
  const maintSpendTotal = s.expenses.filter((e) => e.linkedRequestId).reduce((sum, e) => sum + e.amount, 0);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return s.expenses.filter((e) => {
      if (fStatus && e.paymentStatus !== fStatus) return false;
      if (fCategory && e.category !== fCategory) return false;
      if (fProperty && e.propertyId !== fProperty) return false;
      if (q && !`${e.id} ${e.description} ${e.vendor} ${e.invoiceRef ?? ''}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [s.expenses, search, fStatus, fCategory, fProperty]);

  const recordPayment = () => {
    if (!paying) return;
    const amt = parseFloat(payAmount) || 0;
    if (amt <= 0) return;
    const totalPaid = (paying.amountPaid ?? 0) + amt;
    if (totalPaid >= paying.amount) {
      s.updateExpense(paying.id, { paymentStatus: 'Paid', amountPaid: paying.amount });
      s.toast(`${paying.id} paid in full.`);
    } else {
      s.updateExpense(paying.id, { paymentStatus: 'Partially Paid', amountPaid: totalPaid });
      s.toast(`Partial payment recorded on ${paying.id} (${fmtMoney(totalPaid)} of ${fmtMoney(paying.amount)}).`, 'info');
    }
    setPaying(null);
  };

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <PageHeader
        title="Bills & Expenses"
        sub="The financial source of truth. Maintenance requests link to these records — they never duplicate them."
        action={<PrimaryButton onClick={() => setAdding(true)}><Plus size={15} /> New Expense</PrimaryButton>}
      />
      <div className="mt-5 grid grid-cols-2 gap-3 xl:grid-cols-4">
        {[
          { label: 'Outstanding Balance', value: fmtMoney(unpaid.reduce((sum, e) => sum + due(e), 0)), sub: `${unpaid.length} open invoices`, tone: 'text-amber-400' },
          { label: 'Overdue', value: fmtMoney(overdueAmt), sub: 'Past due date', tone: overdueAmt ? 'text-rose-400' : undefined },
          { label: 'Paid This Month', value: fmtMoney(paidThisMonth), sub: 'Settled invoices (by invoice date)', tone: 'text-emerald-400' },
          { label: 'Maintenance-Linked', value: fmtMoney(maintSpendTotal), sub: `${s.expenses.filter((e) => e.linkedRequestId).length} invoices tied to requests` },
        ].map((c, i) => (
          <div key={i} className="rounded-xl border border-line bg-panel p-4">
            <div className={cn('text-[22px] font-bold leading-none tabular text-zinc-50', c.tone)}>{c.value}</div>
            <div className="mt-1.5 text-[12px] font-medium text-zinc-300">{c.label}</div>
            <div className="text-[11px] text-zinc-600">{c.sub}</div>
          </div>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-line bg-panel p-3">
        <div className="relative min-w-[200px] flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search expense, vendor, invoice #…" className="w-full rounded-lg border border-line bg-panel2 py-2 pl-9 pr-3 text-[13px] text-zinc-100 outline-none placeholder:text-zinc-600 focus:border-teal-500/60" />
        </div>
        <div className="w-44"><SelectInput value={fProperty} onChange={(e) => setFProperty(e.target.value)}>
          <option value="">All Properties</option>{s.properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </SelectInput></div>
        <div className="w-44"><SelectInput value={fCategory} onChange={(e) => setFCategory(e.target.value)}>
          <option value="">All Categories</option>{EXPENSE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </SelectInput></div>
        <div className="w-40"><SelectInput value={fStatus} onChange={(e) => setFStatus(e.target.value)}>
          <option value="">Any Payment Status</option><option>Paid</option><option>Unpaid</option><option>Partially Paid</option><option>Overdue</option>
        </SelectInput></div>
        {(search || fStatus || fCategory || fProperty) && (
          <button onClick={() => { setSearch(''); setFStatus(''); setFCategory(''); setFProperty(''); }} className="inline-flex items-center gap-1 text-[12px] font-medium text-teal-400 hover:text-teal-300"><X size={13} /> Clear</button>
        )}
      </div>

      <div className="mt-4 overflow-hidden rounded-xl border border-line bg-panel">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1050px]">
            <thead><tr className="border-b border-line bg-panel2/60 text-left text-[11px] uppercase tracking-wider text-zinc-500">
              <th className="px-4 py-2.5 font-semibold">Expense</th><th className="px-4 py-2.5 font-semibold">Vendor</th><th className="px-4 py-2.5 font-semibold">Property</th><th className="px-4 py-2.5 font-semibold">Category</th><th className="px-4 py-2.5 font-semibold">Date / Due</th><th className="px-4 py-2.5 font-semibold">Linked To</th><th className="px-4 py-2.5 font-semibold">Payment</th><th className="px-4 py-2.5 text-right font-semibold">Amount</th><th className="w-28 px-3 py-2.5" />
            </tr></thead>
            <tbody>
              {filtered.map((e) => (
                <tr key={e.id} className="border-b border-line/50 last:border-0 hover:bg-white/[0.02]">
                  <td className="px-4 py-3">
                    <span className="block text-[12.5px] font-medium text-zinc-100">{e.id}</span>
                    <span className="block max-w-[300px] truncate text-[11.5px] text-zinc-500">{e.description}</span>
                    {e.invoiceRef && <span className="text-[11px] text-zinc-600">Inv {e.invoiceRef}</span>}
                  </td>
                  <td className="px-4 py-3 text-[12.5px] text-zinc-300">{e.vendor}</td>
                  <td className="px-4 py-3 text-[12.5px] text-zinc-300">{s.getProperty(e.propertyId)?.name ?? 'Portfolio'}<span className="block text-[11px] text-zinc-500">{s.getUnit(e.unitId)?.name ?? ''}</span></td>
                  <td className="px-4 py-3 text-[12.5px] text-zinc-400">{e.category}</td>
                  <td className="px-4 py-3 text-[12.5px] tabular text-zinc-300">{fmtDate(e.date)}<span className="block text-[11px] text-zinc-500">Due {fmtDate(e.dueDate)}</span></td>
                  <td className="px-4 py-3 text-[12.5px]">
                    {e.linkedRequestId ? <button onClick={() => s.navigate('requests', { focusRequestId: e.linkedRequestId })} className="font-medium text-teal-300 hover:text-teal-200">{e.linkedRequestId} →</button> : <span className="text-zinc-600">—</span>}
                    {e.linkedAssetId && <span className="block text-[11px] text-zinc-500">{e.linkedAssetId}</span>}
                  </td>
                  <td className="px-4 py-3">
                    <PaymentBadge status={e.paymentStatus} />
                    {e.paymentStatus === 'Partially Paid' && <span className="block text-[11px] tabular text-zinc-500">{fmtMoney(e.amountPaid)} paid · {fmtMoney(due(e))} left</span>}
                  </td>
                  <td className="px-4 py-3 text-right text-[13px] font-medium tabular text-zinc-100">{fmtMoney(e.amount)}</td>
                  <td className="px-3 py-3 text-right">
                    {e.paymentStatus !== 'Paid' && (
                      <SmallButton onClick={() => { setPaying(e); setPayAmount(String(due(e))); }}>Record Payment</SmallButton>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <EmptyState icon={<Receipt size={20} />} title="No expenses match these filters" />}
        </div>
      </div>

      <Modal
        open={!!paying}
        onClose={() => setPaying(null)}
        title={`Record Payment — ${paying?.id}`}
        subtitle={paying ? `${paying.vendor} · invoice total ${fmtMoney(paying.amount)} · balance due ${fmtMoney(due(paying))}` : ''}
        footer={<><GhostButton onClick={() => setPaying(null)}>Cancel</GhostButton><PrimaryButton onClick={recordPayment}>Record Payment</PrimaryButton></>}
      >
        <Field label="Payment Amount" hint="Partial payments are supported. The expense total never changes — only the paid balance.">
          <MoneyInput value={payAmount} onChange={setPayAmount} />
        </Field>
      </Modal>

      <NewExpenseModal open={adding} onClose={() => setAdding(false)} />
    </div>
  );
}

function NewExpenseModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const s = useStore();
  const [desc, setDesc] = useState('');
  const [vendor, setVendor] = useState('');
  const [propertyId, setPropertyId] = useState('');
  const [category, setCategory] = useState('Maintenance & Repairs');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(todayISO());
  const [status, setStatus] = useState('Unpaid');
  const [error, setError] = useState('');

  const save = () => {
    if (!desc.trim() || !vendor.trim()) { setError('Description and vendor are required.'); return; }
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { setError('Enter an amount above $0.'); return; }
    const id = s.nextExpenseId();
    s.addExpense({ id, description: desc.trim(), vendor: vendor.trim(), propertyId: propertyId || undefined, category, amount: amt, date, paymentStatus: status as Expense['paymentStatus'] });
    s.toast(`Expense ${id} created. Link it to a maintenance request from the request's Costs tab.`);
    setDesc(''); setVendor(''); setAmount(''); setError('');
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose} title="New Expense" footer={<><GhostButton onClick={onClose}>Cancel</GhostButton><PrimaryButton onClick={save}>Create Expense</PrimaryButton></>}>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Field label="Description" required error={error} className="sm:col-span-2"><TextInput value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
        <Field label="Vendor" required><TextInput value={vendor} onChange={(e) => setVendor(e.target.value)} /></Field>
        <Field label="Property">
          <SelectInput value={propertyId} onChange={(e) => setPropertyId(e.target.value)}>
            <option value="">Portfolio-wide</option>{s.properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </SelectInput>
        </Field>
        <Field label="Category">
          <SelectInput value={category} onChange={(e) => setCategory(e.target.value)}>{EXPENSE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}</SelectInput>
        </Field>
        <Field label="Amount" required><MoneyInput value={amount} onChange={setAmount} /></Field>
        <Field label="Date"><TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
        <Field label="Payment Status">
          <SelectInput value={status} onChange={(e) => setStatus(e.target.value)}><option>Unpaid</option><option>Paid</option><option>Partially Paid</option><option>Overdue</option></SelectInput>
        </Field>
      </div>
    </Modal>
  );
}

// ── Settings ─────────────────────────────────────────────────────────────────

export function SettingsPage() {
  const s = useStore();
  const [emergency, setEmergency] = useState(String(s.settings.emergencyResponseHours));
  const [high, setHigh] = useState(String(s.settings.highResponseHours));
  const [threshold, setThreshold] = useState(String(s.settings.approvalThreshold));

  const save = () => {
    s.updateSettings({
      emergencyResponseHours: Math.max(1, parseInt(emergency) || 4),
      highResponseHours: Math.max(1, parseInt(high) || 24),
      approvalThreshold: Math.max(0, parseFloat(threshold) || 0),
    });
    s.toast('Maintenance settings saved.');
  };

  return (
    <div className="mx-auto max-w-[900px] px-5 py-6 lg:px-8">
      <PageHeader title="Settings" sub="Module configuration for maintenance workflows and approvals." />
      <div className="mt-5 space-y-4">
        <div className="rounded-xl border border-line bg-panel p-5">
          <SectionTitle icon={<Settings2 size={13} />}>Response Targets & Approvals</SectionTitle>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <Field label="Emergency Response Target (hours)" hint="Shown when an Emergency request is created. Response needs vary — this is a target, not an SLA engine.">
              <TextInput type="number" min="1" value={emergency} onChange={(e) => setEmergency(e.target.value)} />
            </Field>
            <Field label="High Priority Target (hours)">
              <TextInput type="number" min="1" value={high} onChange={(e) => setHigh(e.target.value)} />
            </Field>
            <Field label="Estimate Approval Threshold" hint="Estimates above this amount must be submitted for approval.">
              <MoneyInput value={threshold} onChange={setThreshold} />
            </Field>
          </div>
          <div className="mt-4"><PrimaryButton onClick={save}>Save Settings</PrimaryButton></div>
        </div>

        <div className="rounded-xl border border-line bg-panel p-5">
          <SectionTitle icon={<Users size={13} />}>Signed-In User (Prototype)</SectionTitle>
          <div className="flex items-center gap-3">
            <Avatar name={s.currentUser.name} size="lg" />
            <div>
              <p className="text-[14px] font-semibold text-zinc-50">{s.currentUser.name}</p>
              <p className="text-[12px] text-zinc-500">{s.currentUser.role} — can approve estimates, see tenant contacts, access instructions and internal notes. In production these are governed by your existing roles & permissions.</p>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
            {s.staff.map((m) => (
              <div key={m.id} className="flex items-center gap-2 rounded-lg border border-line bg-panel2 px-3 py-2">
                <Avatar name={m.name} size="sm" />
                <span><span className="block text-[12.5px] font-medium text-zinc-100">{m.name}</span><span className="text-[11px] text-zinc-500">{m.role}</span></span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-amber-500/25 bg-amber-500/5 p-5">
          <SectionTitle icon={<AlertTriangle size={13} />}>Prototype Data Notice</SectionTitle>
          <p className="text-[13px] leading-relaxed text-zinc-300">
            This build runs on <b>in-memory sample data</b> — there is no backend connected yet. Everything you do (create requests, approve estimates, replace appliances, link expenses) works for real within this session, but a page refresh restores the original dataset. Attached files are previewed from your browser only and are <b>not uploaded or permanently stored</b>. The data model is normalized (requests, work orders, estimates, assets, expenses…) so it can be wired to your existing API without restructuring.
          </p>
          <div className="mt-3">
            <GhostButton onClick={() => window.location.reload()}><RotateCcw size={13} /> Reset to Sample Data</GhostButton>
          </div>
        </div>

        <div className="rounded-xl border border-line bg-panel p-5">
          <SectionTitle icon={<KeyRound size={13} />}>Contractor Directory</SectionTitle>
          <div className="space-y-2">
            {s.contractors.map((c) => (
              <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line bg-panel2/60 px-3.5 py-2.5">
                <span>
                  <span className="block text-[13px] font-medium text-zinc-100">{c.company}</span>
                  <span className="text-[11.5px] text-zinc-500">{c.contact} · {c.phone} · {c.email} · {c.categories.join(', ')}</span>
                </span>
                <Chip tone={c.active ? 'green' : 'zinc'}>{c.active ? 'Active' : 'Inactive'}</Chip>
              </div>
            ))}
          </div>
          <p className="mt-2 text-[11.5px] text-zinc-500">New contractors can be added from the Assign dialog on any maintenance request — records are shared across the module to avoid duplicates.</p>
        </div>
      </div>
    </div>
  );
}
