import { Fragment, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle, ArrowRight, CalendarClock, ChevronDown, ExternalLink, FileText,
  History, MoreHorizontal, Package, Pencil, Plus, Receipt, RefreshCw, Search,
  ShieldCheck, Wrench, X,
} from 'lucide-react';
import { useStore } from '../store';
import {
  Chip, DetailItem, EmptyState, GhostButton, Menu, PaymentBadge, PrimaryButton,
  PriorityBadge, SectionTitle, SelectInput, SmallButton, StatusBadge,
} from '../ui';
import { AssetFormModal, ReplaceApplianceModal, RequestFormModal } from '../modals';
import { ASSET_CONDITIONS, ASSET_STATUSES, ASSET_TYPES, type Asset } from '../types';
import { assetAgeYears, daysUntil, fmtDate, fmtMoney, warrantyState } from '../utils';
import { cn } from '../utils/cn';

function conditionTone(c: string): 'green' | 'amber' | 'red' | 'zinc' | 'teal' {
  if (c === 'Excellent') return 'teal';
  if (c === 'Good') return 'green';
  if (c === 'Fair') return 'amber';
  return 'red';
}
function statusTone(st: string): 'green' | 'amber' | 'red' | 'zinc' | 'sky' {
  if (st === 'Active') return 'green';
  if (st === 'Under Repair' || st === 'Under Inspection') return 'amber';
  return 'zinc';
}

export function AssetsPage() {
  const s = useStore();
  const [search, setSearch] = useState('');
  const [fProperty, setFProperty] = useState('');
  const [fUnit, setFUnit] = useState('');
  const [fType, setFType] = useState('');
  const [fCondition, setFCondition] = useState('');
  const [fStatus, setFStatus] = useState('');
  const [fWarranty, setFWarranty] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Asset | null>(null);
  const [replacing, setReplacing] = useState<Asset | null>(null);
  const [newRequestAsset, setNewRequestAsset] = useState<Asset | null>(null);

  useEffect(() => {
    if (s.route.focusAssetId) {
      setExpandedId(s.route.focusAssetId);
      setSearch(s.route.focusAssetId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.route.nonce]);

  const stats = useMemo(() => {
    const active = s.assets.filter((a) => ['Active', 'Under Inspection', 'Under Repair'].includes(a.status));
    return {
      total: s.assets.length,
      inService: active.length,
      underWarranty: active.filter((a) => warrantyState(a) === 'active').length,
      expiring: active.filter((a) => warrantyState(a) === 'expiring').length,
      needsAttention: active.filter((a) => a.condition === 'Poor' || a.condition === 'Failed' || a.status === 'Under Repair').length,
      lifetimeSpend: s.assets.reduce((sum, a) => sum + s.assetRepairSpend(a.id), 0),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.assets, s.requests, s.expenses]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return s.assets.filter((a) => {
      if (fProperty && a.propertyId !== fProperty) return false;
      if (fUnit && a.unitId !== fUnit) return false;
      if (fType && a.type !== fType) return false;
      if (fCondition && a.condition !== fCondition) return false;
      if (fStatus && a.status !== fStatus) return false;
      if (fWarranty && warrantyState(a) !== fWarranty) return false;
      if (q) {
        const hay = [a.id, a.name, a.type, a.brand ?? '', a.model ?? '', a.serial ?? '', s.getProperty(a.propertyId)?.name ?? '', s.getUnit(a.unitId)?.name ?? ''].join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.assets, search, fProperty, fUnit, fType, fCondition, fStatus, fWarranty]);

  const liveReplacing = replacing ? s.getAsset(replacing.id) ?? replacing : null;

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-bold tracking-tight text-zinc-50">Assets & Appliances</h1>
          <p className="mt-0.5 text-[13px] text-zinc-500">Inventory, warranties, condition and lifetime service history for every appliance and system.</p>
        </div>
        <PrimaryButton onClick={() => { setEditing(null); setFormOpen(true); }}><Plus size={15} /> New Asset</PrimaryButton>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {[
          { label: 'Total Assets', value: stats.total, sub: `${stats.inService} in service` },
          { label: 'Under Warranty', value: stats.underWarranty, sub: 'Active coverage', tone: 'text-emerald-400' },
          { label: 'Warranty Expiring ≤90d', value: stats.expiring, sub: 'Review before paying for repairs', tone: 'text-amber-400' },
          { label: 'Needs Attention', value: stats.needsAttention, sub: 'Poor condition or under repair', tone: stats.needsAttention ? 'text-rose-400' : undefined },
          { label: 'Lifetime Repair Spend', value: fmtMoney(stats.lifetimeSpend), sub: 'From linked invoices' },
          { label: 'Properties Covered', value: s.properties.length, sub: `${s.units.length} units` },
        ].map((c, i) => (
          <div key={i} className="rounded-xl border border-line bg-panel p-3.5">
            <div className={cn('text-[22px] font-bold leading-none tabular text-zinc-50', c.tone)}>{c.value}</div>
            <div className="mt-1.5 text-[12px] font-medium text-zinc-300">{c.label}</div>
            <div className="text-[11px] text-zinc-600">{c.sub}</div>
          </div>
        ))}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-line bg-panel p-3">
        <div className="relative min-w-[200px] flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search asset ID, name, brand, model, serial…" className="w-full rounded-lg border border-line bg-panel2 py-2 pl-9 pr-3 text-[13px] text-zinc-100 outline-none placeholder:text-zinc-600 focus:border-teal-500/60 focus:ring-2 focus:ring-teal-500/15" />
        </div>
        <div className="w-44"><SelectInput value={fProperty} onChange={(e) => { setFProperty(e.target.value); setFUnit(''); }}>
          <option value="">All Properties</option>{s.properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </SelectInput></div>
        <div className="w-36"><SelectInput value={fUnit} onChange={(e) => setFUnit(e.target.value)} disabled={!fProperty}>
          <option value="">All Units</option>{s.unitsForProperty(fProperty).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
        </SelectInput></div>
        <div className="w-40"><SelectInput value={fType} onChange={(e) => setFType(e.target.value)}>
          <option value="">All Types</option>{ASSET_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
        </SelectInput></div>
        <div className="w-36"><SelectInput value={fCondition} onChange={(e) => setFCondition(e.target.value)}>
          <option value="">Any Condition</option>{ASSET_CONDITIONS.map((c) => <option key={c} value={c}>{c}</option>)}
        </SelectInput></div>
        <div className="w-40"><SelectInput value={fStatus} onChange={(e) => setFStatus(e.target.value)}>
          <option value="">Any Status</option>{ASSET_STATUSES.map((st) => <option key={st} value={st}>{st}</option>)}
        </SelectInput></div>
        <div className="w-40"><SelectInput value={fWarranty} onChange={(e) => setFWarranty(e.target.value)}>
          <option value="">Any Warranty</option>
          <option value="active">Warranty Active</option>
          <option value="expiring">Expiring ≤90 Days</option>
          <option value="expired">Warranty Expired</option>
          <option value="none">No Warranty Recorded</option>
        </SelectInput></div>
        {(search || fProperty || fType || fCondition || fStatus || fWarranty) && (
          <button onClick={() => { setSearch(''); setFProperty(''); setFUnit(''); setFType(''); setFCondition(''); setFStatus(''); setFWarranty(''); }} className="inline-flex items-center gap-1 text-[12px] font-medium text-teal-400 hover:text-teal-300">
            <X size={13} /> Clear
          </button>
        )}
      </div>

      <div className="mt-4 overflow-hidden rounded-xl border border-line bg-panel">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1150px] border-collapse">
            <thead>
              <tr className="border-b border-line bg-panel2/60 text-left text-[11px] uppercase tracking-wider text-zinc-500">
                <th className="w-10 px-2 py-2.5" />
                <th className="px-3 py-2.5 font-semibold">Asset</th>
                <th className="px-3 py-2.5 font-semibold">Type</th>
                <th className="px-3 py-2.5 font-semibold">Property / Unit</th>
                <th className="px-3 py-2.5 font-semibold">Brand / Model</th>
                <th className="px-3 py-2.5 font-semibold">Purchased</th>
                <th className="px-3 py-2.5 font-semibold">Warranty</th>
                <th className="px-3 py-2.5 font-semibold">Condition</th>
                <th className="px-3 py-2.5 font-semibold">Status</th>
                <th className="px-3 py-2.5 font-semibold">Last Service</th>
                <th className="px-3 py-2.5 text-right font-semibold">Repair Costs</th>
                <th className="w-12 px-2 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {filtered.map((a, idx) => {
                const expanded = expandedId === a.id;
                const ws = warrantyState(a);
                const age = assetAgeYears(a);
                return (
                  <Fragment key={a.id}>
                    <tr onClick={() => setExpandedId(expanded ? null : a.id)} className={cn('cursor-pointer border-b border-line/60 transition hover:bg-white/[0.02]', expanded && 'bg-teal-500/[0.03]', (a.status === 'Replaced' || a.status === 'Retired' || a.status === 'Disposed') && 'opacity-60')}>
                      <td className="px-2 py-3">
                        <span className={cn('flex h-6 w-6 items-center justify-center rounded-md border', expanded ? 'border-teal-500/40 bg-teal-500/10 text-teal-300' : 'border-line text-zinc-500')}>
                          <ChevronDown size={13} className={cn('transition-transform', expanded && 'rotate-180')} />
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <div className="text-[13px] font-medium text-zinc-100">{a.name}</div>
                        <div className="text-[11px] text-zinc-500">{a.id}{age !== null ? ` · ${age.toFixed(1)} yrs old` : ''}</div>
                      </td>
                      <td className="px-3 py-3 text-[12.5px] text-zinc-300">{a.type}</td>
                      <td className="px-3 py-3">
                        <div className="text-[12.5px] text-zinc-200">{s.getProperty(a.propertyId)?.name}</div>
                        <div className="text-[11px] text-zinc-500">{s.getUnit(a.unitId)?.name ?? 'Property-level'}{a.room ? ` · ${a.room}` : ''}</div>
                      </td>
                      <td className="px-3 py-3 text-[12.5px] text-zinc-300">{a.brand ?? '—'}<span className="block text-[11px] text-zinc-500">{a.model ?? ''}</span></td>
                      <td className="px-3 py-3 text-[12.5px] tabular text-zinc-300">{fmtDate(a.purchaseDate)}<span className="block text-[11px] text-zinc-500">{fmtMoney(a.purchasePrice)}</span></td>
                      <td className="px-3 py-3">
                        {ws === 'active' && <span className="text-[12px] text-emerald-400">Active<span className="block text-[11px] tabular text-zinc-500">to {fmtDate(a.warrantyEnd)}</span></span>}
                        {ws === 'expiring' && <span className="text-[12px] text-amber-400">Expiring<span className="block text-[11px] tabular text-zinc-500">{fmtDate(a.warrantyEnd)} · {daysUntil(a.warrantyEnd)}d left</span></span>}
                        {ws === 'expired' && <span className="text-[12px] text-zinc-500">Expired<span className="block text-[11px] tabular text-zinc-600">{fmtDate(a.warrantyEnd)}</span></span>}
                        {ws === 'none' && <span className="text-[12px] text-zinc-600">—</span>}
                      </td>
                      <td className="px-3 py-3"><Chip tone={conditionTone(a.condition)}>{a.condition}</Chip></td>
                      <td className="px-3 py-3"><Chip tone={statusTone(a.status)}>{a.status}</Chip></td>
                      <td className="px-3 py-3 text-[12.5px] tabular text-zinc-300">{fmtDate(a.lastService)}</td>
                      <td className="px-3 py-3 text-right text-[12.5px] font-medium tabular text-zinc-100">{fmtMoney(s.assetRepairSpend(a.id))}</td>
                      <td className="px-2 py-3" onClick={(e) => e.stopPropagation()}>
                        <Menu
                          dropUp={idx >= filtered.length - 2 && filtered.length > 2}
                          trigger={<button className="rounded-md p-1.5 text-zinc-500 transition hover:bg-panel3 hover:text-zinc-100"><MoreHorizontal size={16} /></button>}
                          items={[
                            { label: 'Edit Asset', icon: <Pencil size={13} />, onClick: () => { setEditing(a); setFormOpen(true); } },
                            { label: 'New Maintenance Request', icon: <Wrench size={13} />, onClick: () => setNewRequestAsset(a) },
                            { label: 'Replace Appliance…', icon: <RefreshCw size={13} />, onClick: () => setReplacing(a), disabled: ['Replaced', 'Disposed'].includes(a.status) },
                          ]}
                        />
                      </td>
                    </tr>
                    {expanded && (
                      <tr className="border-b border-line bg-[#0c1017]">
                        <td colSpan={12} className="px-5 py-4">
                          <AssetDetail asset={a} onEdit={() => { setEditing(a); setFormOpen(true); }} onReplace={() => setReplacing(a)} onNewRequest={() => setNewRequestAsset(a)} />
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <EmptyState icon={<Package size={20} />} title="No assets match these filters" body="Adjust the filters or add a new asset to the inventory." action={<GhostButton onClick={() => { setSearch(''); setFProperty(''); setFUnit(''); setFType(''); setFCondition(''); setFStatus(''); setFWarranty(''); }}>Clear Filters</GhostButton>} />
          )}
        </div>
        <div className="border-t border-line px-4 py-2.5 text-[12px] text-zinc-500">
          {filtered.length} of {s.assets.length} assets · Replaced and retired assets remain visible so their history is never lost.
        </div>
      </div>

      <AssetFormModal open={formOpen} onClose={() => setFormOpen(false)} asset={editing} onSaved={(id) => setExpandedId(id)} />
      <ReplaceApplianceModal
        open={!!replacing}
        onClose={() => setReplacing(null)}
        asset={liveReplacing}
        request={liveReplacing ? s.assetRequests(liveReplacing.id).find((r) => !['Completed', 'Closed', 'Cancelled', 'Rejected'].includes(r.status)) ?? null : null}
        onDone={(newId) => { setExpandedId(newId); setSearch(''); }}
      />
      <RequestFormModal
        open={!!newRequestAsset}
        onClose={() => setNewRequestAsset(null)}
        preset={newRequestAsset ? { assetId: newRequestAsset.id, propertyId: newRequestAsset.propertyId, unitId: newRequestAsset.unitId, category: 'Appliance', title: `${newRequestAsset.name} — issue reported` } : undefined}
        onSaved={(id) => s.navigate('requests', { focusRequestId: id })}
      />
    </div>
  );
}

function AssetDetail({ asset, onEdit, onReplace, onNewRequest }: { asset: Asset; onEdit: () => void; onReplace: () => void; onNewRequest: () => void }) {
  const s = useStore();
  const requests = s.assetRequests(asset.id);
  const expenses = s.assetExpenses(asset.id);
  const docs = s.attachments.filter((d) => d.assetId === asset.id);
  const ws = warrantyState(asset);
  const replacedBy = asset.replacedById ? s.getAsset(asset.replacedById) : undefined;
  const replacedFrom = asset.replacedFromId ? s.getAsset(asset.replacedFromId) : undefined;
  const schedules = s.schedules.filter((sc) => sc.assetId === asset.id);

  return (
    <div className="animate-expand">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <h3 className="text-[15px] font-semibold text-zinc-50">{asset.name}</h3>
        <Chip>{asset.id}</Chip>
        <Chip tone={statusTone(asset.status)}>{asset.status}</Chip>
        <Chip tone={conditionTone(asset.condition)}>{asset.condition}</Chip>
        {ws === 'expiring' && <Chip tone="amber"><AlertTriangle size={11} /> Warranty expires in {daysUntil(asset.warrantyEnd)} days</Chip>}
        <span className="ml-auto flex gap-1.5">
          <SmallButton onClick={onNewRequest}><Wrench size={12} /> New Request</SmallButton>
          <SmallButton onClick={onEdit}><Pencil size={12} /> Edit</SmallButton>
          {!['Replaced', 'Disposed', 'Retired'].includes(asset.status) && (
            <SmallButton onClick={onReplace} className="border-amber-500/40 text-amber-300 hover:border-amber-500/70"><RefreshCw size={12} /> Replace Appliance</SmallButton>
          )}
        </span>
      </div>

      {(replacedBy || replacedFrom) && (
        <div className="mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-line bg-panel px-4 py-3 text-[12.5px] text-zinc-300">
          <History size={14} className="text-zinc-500" />
          {replacedFrom && (
            <span>
              This asset replaced <b className="text-zinc-100">{replacedFrom.id} · {replacedFrom.name}</b> ({replacedFrom.brand} {replacedFrom.model}) on {fmtDate(replacedFrom.replacementDate)}.
              {replacedFrom.replacementReason && <span className="text-zinc-400"> Reason: {replacedFrom.replacementReason}</span>}
            </span>
          )}
          {replacedBy && (
            <span className="inline-flex items-center gap-1.5">
              Replaced by <b className="text-zinc-100">{replacedBy.id} · {replacedBy.name}</b> on {fmtDate(asset.replacementDate)} <ArrowRight size={12} className="text-zinc-500" />
              <button onClick={() => s.navigate('assets', { focusAssetId: replacedBy.id })} className="font-medium text-teal-300 hover:text-teal-200">View current asset</button>
            </span>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div>
          <SectionTitle icon={<Package size={13} />}>Identification</SectionTitle>
          <dl className="grid grid-cols-2 gap-x-3 gap-y-3.5 rounded-xl border border-line bg-panel px-4 py-3.5">
            <DetailItem label="Asset ID">{asset.id}</DetailItem>
            <DetailItem label="Type">{asset.type}</DetailItem>
            <DetailItem label="Brand">{asset.brand ?? '—'}</DetailItem>
            <DetailItem label="Model">{asset.model ?? '—'}</DetailItem>
            <DetailItem label="Serial Number">{asset.serial ?? '—'}</DetailItem>
            <DetailItem label="Room">{asset.room ?? '—'}</DetailItem>
            <DetailItem label="Property">{s.getProperty(asset.propertyId)?.name}</DetailItem>
            <DetailItem label="Unit">{s.getUnit(asset.unitId)?.name ?? 'Property-level'}</DetailItem>
          </dl>
          <SectionTitle icon={<CalendarClock size={13} />}> <span className="ml-1">Condition & Lifecycle</span></SectionTitle>
          <dl className="grid grid-cols-2 gap-x-3 gap-y-3.5 rounded-xl border border-line bg-panel px-4 py-3.5">
            <DetailItem label="Condition">{asset.condition}</DetailItem>
            <DetailItem label="Age">{assetAgeYears(asset)?.toFixed(1) ?? '—'} yrs</DetailItem>
            <DetailItem label="Installed">{fmtDate(asset.installDate)}</DetailItem>
            <DetailItem label="Last Inspection">{fmtDate(asset.lastInspection)}</DetailItem>
            <DetailItem label="Last Service">{fmtDate(asset.lastService)}</DetailItem>
            <DetailItem label="Next Service">{fmtDate(asset.nextService)}</DetailItem>
            {asset.retiredDate && <DetailItem label="Retired">{fmtDate(asset.retiredDate)}</DetailItem>}
            {asset.disposalNotes && <DetailItem label="Disposal Notes" className="col-span-2">{asset.disposalNotes}</DetailItem>}
          </dl>
          {schedules.length > 0 && (
            <>
              <SectionTitle icon={<CalendarClock size={13} />}> <span className="ml-1">Preventive Schedules</span></SectionTitle>
              <div className="space-y-2">
                {schedules.map((sc) => (
                  <button key={sc.id} onClick={() => s.navigate('preventive')} className="flex w-full items-center justify-between rounded-xl border border-line bg-panel px-3.5 py-2.5 text-left transition hover:border-zinc-600">
                    <span>
                      <span className="block text-[12.5px] font-medium text-zinc-100">{sc.task}</span>
                      <span className="text-[11px] text-zinc-500">{sc.frequency} · next due {fmtDate(sc.nextDue)}</span>
                    </span>
                    <ExternalLink size={12} className="text-zinc-500" />
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        <div>
          <SectionTitle icon={<ShieldCheck size={13} />}>Purchase & Warranty</SectionTitle>
          <dl className="grid grid-cols-2 gap-x-3 gap-y-3.5 rounded-xl border border-line bg-panel px-4 py-3.5">
            <DetailItem label="Purchase Date">{fmtDate(asset.purchaseDate)}</DetailItem>
            <DetailItem label="Purchase Price">{fmtMoney(asset.purchasePrice)}</DetailItem>
            <DetailItem label="Supplier">{asset.supplier ?? '—'}</DetailItem>
            <DetailItem label="Warranty Provider">{asset.warrantyProvider ?? '—'}</DetailItem>
            <DetailItem label="Warranty Start">{fmtDate(asset.warrantyStart)}</DetailItem>
            <DetailItem label="Warranty Expiry">
              {fmtDate(asset.warrantyEnd)}
              {ws === 'active' && <span className="ml-1.5 text-[11px] font-medium text-emerald-400">ACTIVE</span>}
              {ws === 'expiring' && <span className="ml-1.5 text-[11px] font-medium text-amber-400">EXPIRING</span>}
              {ws === 'expired' && <span className="ml-1.5 text-[11px] font-medium text-rose-400">EXPIRED</span>}
            </DetailItem>
            <DetailItem label="Warranty Reference">{asset.warrantyRef ?? '—'}</DetailItem>
            <DetailItem label="Coverage Notes">{asset.warrantyNotes ?? '—'}</DetailItem>
            <DetailItem label="Lifetime Repair Costs"><span className="font-semibold tabular">{fmtMoney(s.assetRepairSpend(asset.id))}</span></DetailItem>
            <DetailItem label="Linked Requests">{requests.length}</DetailItem>
          </dl>

          <SectionTitle icon={<FileText size={13} />}> <span className="ml-1">Documents</span></SectionTitle>
          <div className="rounded-xl border border-line bg-panel px-4 py-3">
            {docs.length === 0 ? (
              <p className="text-[12.5px] text-zinc-500">No documents on file (purchase receipt, warranty card).</p>
            ) : docs.map((d) => (
              <div key={d.id} className="flex items-center justify-between py-1.5 text-[12.5px]">
                <span className="flex items-center gap-2 text-zinc-200"><FileText size={13} className="text-zinc-500" /> {d.name}</span>
                <span className="text-[11px] text-zinc-500">{d.category} · {fmtDate(d.uploadedAt)}</span>
              </div>
            ))}
          </div>

          <SectionTitle icon={<Receipt size={13} />}> <span className="ml-1">Related Expenses</span></SectionTitle>
          <div className="space-y-2">
            {expenses.length === 0 && <p className="rounded-xl border border-line bg-panel px-4 py-3 text-[12.5px] text-zinc-500">No expenses recorded against this asset.</p>}
            {expenses.map((e) => (
              <div key={e.id} className="flex items-center justify-between gap-2 rounded-xl border border-line bg-panel px-3.5 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-[12.5px] font-medium text-zinc-100">{e.description}</p>
                  <p className="text-[11px] text-zinc-500">{e.id} · {fmtDate(e.date)} · {e.category}</p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <PaymentBadge status={e.paymentStatus} />
                  <span className="text-[12.5px] font-semibold tabular text-zinc-100">{fmtMoney(e.amount)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <SectionTitle icon={<Wrench size={13} />}>Service & Repair History</SectionTitle>
          {requests.length === 0 ? (
            <p className="rounded-xl border border-line bg-panel px-4 py-3 text-[12.5px] text-zinc-500">No maintenance requests linked to this asset yet.</p>
          ) : (
            <div className="space-y-2">
              {requests.map((r) => (
                <button
                  key={r.id}
                  onClick={() => s.navigate('requests', { focusRequestId: r.id })}
                  className="w-full rounded-xl border border-line bg-panel px-3.5 py-3 text-left transition hover:border-zinc-600"
                >
                  <span className="flex items-center justify-between gap-2">
                    <span className="text-[12.5px] font-medium text-zinc-100">{r.title}</span>
                    <StatusBadge status={r.status} />
                  </span>
                  <span className="mt-1 flex flex-wrap items-center gap-2 text-[11px] text-zinc-500">
                    <span>{r.id}</span>
                    <PriorityBadge priority={r.priority} />
                    <span>Reported {fmtDate(r.reportedAt)}</span>
                    {s.actualCost(r) > 0 && <span className="tabular text-zinc-300">Cost {fmtMoney(s.actualCost(r))}</span>}
                    {r.resolutionOutcome && <span>Outcome: {r.resolutionOutcome}</span>}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
