import { Fragment, useEffect, useMemo, useState } from 'react';
import {
  Activity as ActivityIcon, AlertTriangle, ArrowUpDown, Banknote, Building2,
  CalendarClock, CalendarDays, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight,
  CircleDollarSign, ClipboardList, Download, ExternalLink, Eye, FileText,
  Filter, History, Hourglass, Inbox, Link2, Mail, MapPin, MoreHorizontal,
  Package, Paperclip, Pencil, Phone, Plus, Receipt, RotateCcw, Search, ShieldCheck,
  Siren, Trash2, Unlink, UserCheck, Wrench, X,
} from 'lucide-react';
import { useStore } from '../store';
import {
  Avatar, Chip, ConfirmDialog, DetailItem, EmptyState, GhostButton, Menu, PaymentBadge,
  PrimaryButton, PriorityBadge, SectionTitle, SelectInput, SmallButton, StatusBadge, Tabs,
} from '../ui';
import {
  ApprovalModal, AssignModal, CompleteModal, EstimateModal, LinkExpenseModal,
  ReasonModal, ReplaceApplianceModal, RequestFormModal, UploadModal, VisitModal,
  WorkLogModal, WorkOrderFormModal, type RequestPreset,
} from '../modals';
import { CATEGORIES, OPEN_STATUSES, PRIORITIES, REQUEST_STATUSES, STATUS_TRANSITIONS, type Estimate, type MaintenanceRequest, type Visit } from '../types';
import { assetAgeYears, daysUntil, fmtDate, fmtDateTime, fmtMoney, isOverdue, overdueDays, timeAgo, warrantyState } from '../utils';
import { cn } from '../utils/cn';

type SummaryFilter = 'open' | 'urgent' | 'awaiting' | 'inprogress' | 'overdue' | 'completed' | null;
type SortKey = 'id' | 'reportedAt' | 'targetDate' | 'estimated' | 'actual' | 'priority';
type ModalState =
  | { kind: 'none' }
  | { kind: 'newRequest'; preset?: RequestPreset }
  | { kind: 'editRequest'; req: MaintenanceRequest }
  | { kind: 'assign'; req: MaintenanceRequest }
  | { kind: 'visit'; req: MaintenanceRequest; visit?: Visit }
  | { kind: 'worklog'; req: MaintenanceRequest }
  | { kind: 'estimate'; req: MaintenanceRequest; estimate?: Estimate }
  | { kind: 'approval'; req: MaintenanceRequest; estimate: Estimate; mode: 'approve' | 'reject' | 'revision' }
  | { kind: 'complete'; req: MaintenanceRequest }
  | { kind: 'reason'; req: MaintenanceRequest; action: 'reject' | 'cancel' | 'reopen' }
  | { kind: 'replace'; req: MaintenanceRequest }
  | { kind: 'expenses'; req: MaintenanceRequest }
  | { kind: 'upload'; req: MaintenanceRequest }
  | { kind: 'workorder'; req: MaintenanceRequest }
  | { kind: 'confirmDeleteEstimate'; req: MaintenanceRequest; estimate: Estimate };

const PAGE_SIZE = 8;
const PRIORITY_RANK: Record<string, number> = { Emergency: 0, High: 1, Normal: 2, Low: 3 };

export function MaintenanceRequestsPage() {
  const s = useStore();
  const [search, setSearch] = useState('');
  const [summary, setSummary] = useState<SummaryFilter>(null);
  const [fProperty, setFProperty] = useState('');
  const [fUnit, setFUnit] = useState('');
  const [fCategory, setFCategory] = useState('');
  const [fPriority, setFPriority] = useState('');
  const [fStatus, setFStatus] = useState('');
  const [fContractor, setFContractor] = useState('');
  const [fAsset, setFAsset] = useState('');
  const [fFrom, setFFrom] = useState('');
  const [fTo, setFTo] = useState('');
  const [fTargetBefore, setFTargetBefore] = useState('');
  const [fCostMin, setFCostMin] = useState('');
  const [fCostMax, setFCostMax] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [sortKey, setSortKey] = useState<SortKey>('reportedAt');
  const [sortDir, setSortDir] = useState<1 | -1>(-1);
  const [page, setPage] = useState(1);
  const [modal, setModal] = useState<ModalState>({ kind: 'none' });
  const closeModal = () => setModal({ kind: 'none' });

  // Deep-link handling (from dashboard, assets history, global search…)
  useEffect(() => {
    const r = s.route;
    if (r.focusRequestId) {
      setSearch(r.focusRequestId);
      setSummary(null); setFStatus(''); setFProperty(''); setFPriority(''); setFCategory('');
      setExpandedId(r.focusRequestId);
      setPage(1);
    } else if (r.searchQuery) {
      setSearch(r.searchQuery);
      setPage(1);
    } else if (r.statusFilter) {
      setFStatus(r.statusFilter);
      setPage(1);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.route.nonce]);

  const counts = useMemo(() => {
    const now = new Date();
    const open = s.requests.filter((r) => OPEN_STATUSES.includes(r.status));
    return {
      open: open.length,
      urgent: open.filter((r) => r.priority === 'Emergency' || r.priority === 'High').length,
      awaiting: s.requests.filter((r) => r.status === 'Awaiting Approval').length,
      inprogress: s.requests.filter((r) => r.status === 'In Progress').length,
      overdue: s.requests.filter((r) => isOverdue(r)).length,
      completed: s.requests.filter((r) => {
        if (!r.completedAt || !['Completed', 'Closed'].includes(r.status)) return false;
        const d = new Date(r.completedAt + 'T12:00:00');
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      }).length,
    };
  }, [s.requests]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = s.requests.filter((r) => {
      if (summary === 'open' && !OPEN_STATUSES.includes(r.status)) return false;
      if (summary === 'urgent' && !(OPEN_STATUSES.includes(r.status) && (r.priority === 'Emergency' || r.priority === 'High'))) return false;
      if (summary === 'awaiting' && r.status !== 'Awaiting Approval') return false;
      if (summary === 'inprogress' && r.status !== 'In Progress') return false;
      if (summary === 'overdue' && !isOverdue(r)) return false;
      if (summary === 'completed') {
        const now = new Date();
        if (!r.completedAt || !['Completed', 'Closed'].includes(r.status)) return false;
        const d = new Date(r.completedAt + 'T12:00:00');
        if (d.getMonth() !== now.getMonth() || d.getFullYear() !== now.getFullYear()) return false;
      }
      if (fProperty && r.propertyId !== fProperty) return false;
      if (fUnit && r.unitId !== fUnit) return false;
      if (fCategory && r.category !== fCategory) return false;
      if (fPriority && r.priority !== fPriority) return false;
      if (fStatus && r.status !== fStatus) return false;
      if (fContractor && r.assignedContractorId !== fContractor) return false;
      if (fAsset && r.assetId !== fAsset) return false;
      if (fFrom && r.reportedAt.slice(0, 10) < fFrom) return false;
      if (fTo && r.reportedAt.slice(0, 10) > fTo) return false;
      if (fTargetBefore && (!r.targetDate || r.targetDate > fTargetBefore)) return false;
      if (fCostMin || fCostMax) {
        const cost = Math.max(s.estimatedCost(r) ?? 0, s.actualCost(r));
        if (fCostMin && cost < parseFloat(fCostMin)) return false;
        if (fCostMax && cost > parseFloat(fCostMax)) return false;
      }
      if (q) {
        const hay = [
          r.id, r.title, r.description, r.reportedByName, r.category, r.status, r.priority,
          s.getProperty(r.propertyId)?.name ?? '', s.getUnit(r.unitId)?.name ?? '',
          s.getTenant(r.tenantId)?.name ?? '', s.getContractor(r.assignedContractorId)?.company ?? '',
          s.getAsset(r.assetId)?.name ?? '', s.getStaff(r.assignedStaffId)?.name ?? '',
        ].join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    list = [...list].sort((a, b) => {
      // Emergencies always float to the top unless sorting explicitly
      let cmp = 0;
      switch (sortKey) {
        case 'id': cmp = a.id.localeCompare(b.id); break;
        case 'reportedAt': cmp = a.reportedAt.localeCompare(b.reportedAt); break;
        case 'targetDate': cmp = (a.targetDate ?? '9999').localeCompare(b.targetDate ?? '9999'); break;
        case 'estimated': cmp = (s.estimatedCost(a) ?? -1) - (s.estimatedCost(b) ?? -1); break;
        case 'actual': cmp = s.actualCost(a) - s.actualCost(b); break;
        case 'priority': cmp = PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority]; break;
      }
      return cmp * sortDir;
    });
    return list;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.requests, s.estimates, s.expenses, search, summary, fProperty, fUnit, fCategory, fPriority, fStatus, fContractor, fAsset, fFrom, fTo, fTargetBefore, fCostMin, fCostMax, sortKey, sortDir]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const activeFilterCount = [fProperty, fUnit, fCategory, fPriority, fStatus, fContractor, fAsset, fFrom, fTo, fTargetBefore, fCostMin, fCostMax, search].filter(Boolean).length + (summary ? 1 : 0);

  const clearFilters = () => {
    setSearch(''); setSummary(null); setFProperty(''); setFUnit(''); setFCategory('');
    setFPriority(''); setFStatus(''); setFContractor(''); setFAsset(''); setFFrom('');
    setFTo(''); setFTargetBefore(''); setFCostMin(''); setFCostMax(''); setPage(1);
  };

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === 1 ? -1 : 1));
    else { setSortKey(key); setSortDir(key === 'reportedAt' ? -1 : 1); }
  };

  const exportCSV = () => {
    const headers = ['Request ID', 'Title', 'Property', 'Unit', 'Category', 'Priority', 'Status', 'Reported By', 'Assigned To', 'Reported', 'Target', 'Estimated Cost', 'Actual Cost'];
    const rows = filtered.map((r) => [
      r.id, r.title, s.getProperty(r.propertyId)?.name ?? '', s.getUnit(r.unitId)?.name ?? 'Common Area',
      r.category, r.priority, r.status, r.reportedByName,
      s.getContractor(r.assignedContractorId)?.company ?? s.getStaff(r.assignedStaffId)?.name ?? '',
      r.reportedAt.slice(0, 10), r.targetDate ?? '', s.estimatedCost(r) ?? '', s.actualCost(r),
    ]);
    const esc = (v: unknown) => `"${String(v).replace(/"/g, '""')}"`;
    const csv = [headers.map(esc).join(','), ...rows.map((row) => row.map(esc).join(','))].join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url; a.download = 'maintenance-requests.csv'; a.click();
    URL.revokeObjectURL(url);
    s.toast(`Exported ${filtered.length} request${filtered.length === 1 ? '' : 's'} to CSV.`);
  };

  const summaryCards: { key: Exclude<SummaryFilter, null>; label: string; value: number; icon: React.ReactNode; accent: string; sub: string }[] = [
    { key: 'open', label: 'Open Requests', value: counts.open, icon: <Inbox size={17} />, accent: 'text-sky-400 bg-sky-500/10', sub: 'Across all properties' },
    { key: 'urgent', label: 'Emergency / High', value: counts.urgent, icon: <Siren size={17} />, accent: 'text-rose-400 bg-rose-500/10', sub: 'Need prompt attention' },
    { key: 'awaiting', label: 'Awaiting Approval', value: counts.awaiting, icon: <Hourglass size={17} />, accent: 'text-amber-400 bg-amber-500/10', sub: 'Estimates pending decision' },
    { key: 'inprogress', label: 'In Progress', value: counts.inprogress, icon: <Wrench size={17} />, accent: 'text-blue-400 bg-blue-500/10', sub: 'Work underway' },
    { key: 'overdue', label: 'Overdue', value: counts.overdue, icon: <AlertTriangle size={17} />, accent: 'text-orange-400 bg-orange-500/10', sub: 'Past target date' },
    { key: 'completed', label: 'Completed This Month', value: counts.completed, icon: <CheckCircle2 size={17} />, accent: 'text-emerald-400 bg-emerald-500/10', sub: 'Closed out recently' },
  ];

  const SortHeader = ({ label, sortKeyName, className }: { label: string; sortKeyName?: SortKey; className?: string }) => (
    <th className={cn('px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wider text-zinc-500', className)}>
      {sortKeyName ? (
        <button onClick={() => toggleSort(sortKeyName)} className="inline-flex items-center gap-1 transition hover:text-zinc-200">
          {label}
          <ArrowUpDown size={11} className={sortKey === sortKeyName ? 'text-teal-400' : 'opacity-40'} />
        </button>
      ) : label}
    </th>
  );

  const modalRequest = modal.kind !== 'none' && modal.kind !== 'newRequest' ? (modal as { req: MaintenanceRequest }).req : null;
  const liveModalRequest = modalRequest ? s.requests.find((r) => r.id === modalRequest.id) ?? modalRequest : null;

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-bold tracking-tight text-zinc-50">Maintenance Requests</h1>
          <p className="mt-0.5 text-[13px] text-zinc-500">Triage, assign, track and cost every repair across your portfolio.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <GhostButton onClick={exportCSV}><Download size={14} /> Export Requests</GhostButton>
          <GhostButton onClick={() => s.navigate('assets')}><Package size={14} /> View Assets</GhostButton>
          <GhostButton onClick={() => s.navigate('preventive')}><CalendarClock size={14} /> Preventive Maintenance</GhostButton>
          <PrimaryButton onClick={() => setModal({ kind: 'newRequest' })}><Plus size={15} /> New Maintenance Request</PrimaryButton>
        </div>
      </div>

      {/* Summary cards */}
      <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {summaryCards.map((c) => (
          <button
            key={c.key}
            onClick={() => { setSummary(summary === c.key ? null : c.key); setPage(1); }}
            className={cn(
              'group rounded-xl border bg-panel p-3.5 text-left transition',
              summary === c.key ? 'border-teal-500/50 ring-1 ring-teal-500/30' : 'border-line hover:border-zinc-600'
            )}
          >
            <div className="flex items-center justify-between">
              <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg', c.accent)}>{c.icon}</span>
              {summary === c.key && <Chip tone="teal">Filtering</Chip>}
            </div>
            <div className="mt-2.5 text-[24px] font-bold leading-none tabular text-zinc-50">{c.value}</div>
            <div className="mt-1 text-[12px] font-medium text-zinc-300">{c.label}</div>
            <div className="text-[11px] text-zinc-600">{c.sub}</div>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="mt-4 rounded-xl border border-line bg-panel p-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[220px] flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search ID, title, tenant, property, unit, contractor, appliance…"
              className="w-full rounded-lg border border-line bg-panel2 py-2 pl-9 pr-3 text-[13px] text-zinc-100 outline-none placeholder:text-zinc-600 focus:border-teal-500/60 focus:ring-2 focus:ring-teal-500/15"
            />
          </div>
          <div className="w-44"><SelectInput value={fProperty} onChange={(e) => { setFProperty(e.target.value); setFUnit(''); setPage(1); }}>
            <option value="">All Properties</option>
            {s.properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </SelectInput></div>
          <div className="w-40"><SelectInput value={fStatus} onChange={(e) => { setFStatus(e.target.value); setPage(1); }}>
            <option value="">All Statuses</option>
            {REQUEST_STATUSES.map((st) => <option key={st} value={st}>{st}</option>)}
          </SelectInput></div>
          <div className="w-36"><SelectInput value={fPriority} onChange={(e) => { setFPriority(e.target.value); setPage(1); }}>
            <option value="">All Priorities</option>
            {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
          </SelectInput></div>
          <div className="w-44"><SelectInput value={fCategory} onChange={(e) => { setFCategory(e.target.value); setPage(1); }}>
            <option value="">All Categories</option>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </SelectInput></div>
          <div className="w-44"><SelectInput value={fContractor} onChange={(e) => { setFContractor(e.target.value); setPage(1); }}>
            <option value="">All Contractors</option>
            {s.contractors.map((c) => <option key={c.id} value={c.id}>{c.company}{c.active ? '' : ' (inactive)'}</option>)}
          </SelectInput></div>
          <GhostButton onClick={() => setShowAdvanced((v) => !v)}>
            <Filter size={13} /> More Filters
            <ChevronDown size={13} className={cn('transition', showAdvanced && 'rotate-180')} />
          </GhostButton>
          {activeFilterCount > 0 && (
            <button onClick={clearFilters} className="inline-flex items-center gap-1 text-[12px] font-medium text-teal-400 transition hover:text-teal-300">
              <X size={13} /> Clear all ({activeFilterCount})
            </button>
          )}
        </div>
        {showAdvanced && (
          <div className="mt-3 grid grid-cols-2 gap-2 border-t border-line pt-3 md:grid-cols-3 xl:grid-cols-6">
            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-zinc-500">Unit</span>
              <SelectInput value={fUnit} onChange={(e) => { setFUnit(e.target.value); setPage(1); }} disabled={!fProperty}>
                <option value="">{fProperty ? 'All Units' : 'Pick a property first'}</option>
                {s.unitsForProperty(fProperty).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
              </SelectInput>
            </label>
            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-zinc-500">Asset / Appliance</span>
              <SelectInput value={fAsset} onChange={(e) => { setFAsset(e.target.value); setPage(1); }}>
                <option value="">All Assets</option>
                {s.assets.map((a) => <option key={a.id} value={a.id}>{a.id} · {a.name}</option>)}
              </SelectInput>
            </label>
            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-zinc-500">Reported From</span>
              <input type="date" value={fFrom} onChange={(e) => { setFFrom(e.target.value); setPage(1); }} className="w-full rounded-lg border border-line bg-panel2 px-3 py-2 text-[13px] text-zinc-100 outline-none focus:border-teal-500/60" />
            </label>
            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-zinc-500">Reported To</span>
              <input type="date" value={fTo} onChange={(e) => { setFTo(e.target.value); setPage(1); }} className="w-full rounded-lg border border-line bg-panel2 px-3 py-2 text-[13px] text-zinc-100 outline-none focus:border-teal-500/60" />
            </label>
            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-zinc-500">Target Due Before</span>
              <input type="date" value={fTargetBefore} onChange={(e) => { setFTargetBefore(e.target.value); setPage(1); }} className="w-full rounded-lg border border-line bg-panel2 px-3 py-2 text-[13px] text-zinc-100 outline-none focus:border-teal-500/60" />
            </label>
            <div className="grid grid-cols-2 gap-2">
              <label className="block">
                <span className="mb-1 block text-[11px] font-medium text-zinc-500">Cost Min $</span>
                <input type="number" min="0" value={fCostMin} onChange={(e) => { setFCostMin(e.target.value); setPage(1); }} className="w-full rounded-lg border border-line bg-panel2 px-3 py-2 text-[13px] text-zinc-100 outline-none focus:border-teal-500/60" />
              </label>
              <label className="block">
                <span className="mb-1 block text-[11px] font-medium text-zinc-500">Cost Max $</span>
                <input type="number" min="0" value={fCostMax} onChange={(e) => { setFCostMax(e.target.value); setPage(1); }} className="w-full rounded-lg border border-line bg-panel2 px-3 py-2 text-[13px] text-zinc-100 outline-none focus:border-teal-500/60" />
              </label>
            </div>
          </div>
        )}
      </div>

      {/* Table */}
      <div className="mt-4 overflow-hidden rounded-xl border border-line bg-panel">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1180px] border-collapse">
            <thead>
              <tr className="border-b border-line bg-panel2/60">
                <th className="w-10 px-2 py-2.5" />
                <SortHeader label="Request" sortKeyName="id" />
                <SortHeader label="Property / Unit" />
                <SortHeader label="Reported By" />
                <SortHeader label="Category" />
                <SortHeader label="Priority" sortKeyName="priority" />
                <SortHeader label="Assigned To" />
                <SortHeader label="Reported" sortKeyName="reportedAt" />
                <SortHeader label="Target" sortKeyName="targetDate" />
                <SortHeader label="Status" />
                <SortHeader label="Est. Cost" sortKeyName="estimated" className="text-right" />
                <SortHeader label="Actual" sortKeyName="actual" className="text-right" />
                <th className="w-12 px-2 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {pageItems.map((r, idx) => {
                const expanded = expandedId === r.id;
                const overdue = isOverdue(r);
                const est = s.estimatedCost(r);
                const actual = s.actualCost(r);
                const assignee = s.getContractor(r.assignedContractorId)?.company ?? s.getStaff(r.assignedStaffId)?.name;
                return (
                  <Fragment key={r.id}>
                    <tr
                      onClick={() => setExpandedId(expanded ? null : r.id)}
                      className={cn(
                        'cursor-pointer border-b border-line/60 transition hover:bg-white/[0.02]',
                        expanded && 'bg-teal-500/[0.03]',
                        r.priority === 'Emergency' && OPEN_STATUSES.includes(r.status) && 'bg-rose-500/[0.03]'
                      )}
                    >
                      <td className="px-2 py-3">
                        <span className={cn('flex h-6 w-6 items-center justify-center rounded-md border transition', expanded ? 'border-teal-500/40 bg-teal-500/10 text-teal-300' : 'border-line text-zinc-500')}>
                          <ChevronDown size={13} className={cn('transition-transform', expanded && 'rotate-180')} />
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-2">
                          {r.priority === 'Emergency' && OPEN_STATUSES.includes(r.status) && <span className="h-6 w-1 shrink-0 rounded-full bg-rose-500" />}
                          <div className="min-w-0">
                            <div className="truncate text-[13px] font-medium text-zinc-100">{r.title}</div>
                            <div className="flex items-center gap-1.5 text-[11px] text-zinc-500">
                              <span className="font-medium text-zinc-400">{r.id}</span>
                              {r.assetId && <span className="inline-flex items-center gap-0.5 text-zinc-500"><Package size={10} />{r.assetId}</span>}
                              {s.requestAttachments(r.id).length > 0 && <span className="inline-flex items-center gap-0.5"><Paperclip size={10} />{s.requestAttachments(r.id).length}</span>}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <div className="text-[12.5px] text-zinc-200">{s.getProperty(r.propertyId)?.name}</div>
                        <div className="text-[11px] text-zinc-500">{s.getUnit(r.unitId)?.name ?? 'Common Area'}{r.room ? ` · ${r.room}` : ''}</div>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-2">
                          <Avatar name={r.reportedByName} size="sm" />
                          <div>
                            <div className="text-[12.5px] text-zinc-200">{r.reportedByName}</div>
                            <div className="text-[11px] text-zinc-500">{r.reportedByRole}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3 text-[12.5px] text-zinc-300">
                        {r.category === 'Heating, Ventilation & Air Conditioning' ? 'HVAC' : r.category}
                        {r.subcategory && <span className="block text-[11px] text-zinc-500">{r.subcategory}</span>}
                      </td>
                      <td className="px-3 py-3"><PriorityBadge priority={r.priority} /></td>
                      <td className="px-3 py-3 text-[12.5px] text-zinc-300">
                        {assignee ?? <span className="text-amber-400">Unassigned</span>}
                        {r.assignedContractorId && r.assignedStaffId && <span className="block text-[11px] text-zinc-500">Coord: {s.getStaff(r.assignedStaffId)?.name}</span>}
                      </td>
                      <td className="px-3 py-3 text-[12.5px] tabular text-zinc-300">
                        {fmtDate(r.reportedAt)}
                        <span className="block text-[11px] text-zinc-500">{timeAgo(r.reportedAt)}</span>
                      </td>
                      <td className="px-3 py-3 text-[12.5px] tabular">
                        {r.targetDate ? (
                          <span className={overdue ? 'font-medium text-rose-400' : 'text-zinc-300'}>
                            {fmtDate(r.targetDate)}
                            {overdue && <span className="block text-[11px] font-semibold">Overdue {overdueDays(r)}d</span>}
                            {!overdue && OPEN_STATUSES.includes(r.status) && daysUntil(r.targetDate) === 0 && <span className="block text-[11px] text-amber-400">Due today</span>}
                          </span>
                        ) : <span className="text-zinc-600">—</span>}
                      </td>
                      <td className="px-3 py-3"><StatusBadge status={r.status} /></td>
                      <td className="px-3 py-3 text-right text-[12.5px] tabular text-zinc-300">{est !== null ? fmtMoney(est) : <span className="text-zinc-600">—</span>}</td>
                      <td className="px-3 py-3 text-right text-[12.5px] font-medium tabular text-zinc-100">
                        {actual > 0 ? fmtMoney(actual) : <span className="font-normal text-zinc-600">—</span>}
                        {r.approvedBudget !== undefined && actual > r.approvedBudget && <span className="block text-[10.5px] font-semibold text-rose-400">Over budget</span>}
                      </td>
                      <td className="px-2 py-3" onClick={(e) => e.stopPropagation()}>
                        <RowActions req={r} onExpand={() => setExpandedId(r.id)} setModal={setModal} dropUp={idx >= pageItems.length - 2 && pageItems.length > 2} />
                      </td>
                    </tr>
                    {expanded && (
                      <tr key={r.id + '-detail'} className="border-b border-line bg-[#0c1017]">
                        <td colSpan={13} className="px-0 py-0">
                          <RequestDetail req={r} setModal={setModal} onCollapse={() => setExpandedId(null)} />
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <EmptyState
              icon={<Search size={20} />}
              title="No maintenance requests match these filters"
              body="Try widening the date or cost range, or clear all filters to see the full queue."
              action={<GhostButton onClick={clearFilters}>Clear All Filters</GhostButton>}
            />
          )}
        </div>
        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-line px-4 py-2.5">
          <span className="text-[12px] text-zinc-500">
            Showing <span className="text-zinc-300">{filtered.length === 0 ? 0 : (page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)}</span> of <span className="text-zinc-300">{filtered.length}</span> requests
          </span>
          <div className="flex items-center gap-1">
            <SmallButton disabled={page <= 1} onClick={() => setPage(page - 1)}><ChevronLeft size={13} /> Prev</SmallButton>
            {Array.from({ length: pageCount }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className={cn('h-7 w-7 rounded-md text-[12px] tabular transition', p === page ? 'bg-teal-500 font-semibold text-zinc-950' : 'text-zinc-400 hover:bg-panel3 hover:text-zinc-100')}
              >
                {p}
              </button>
            ))}
            <SmallButton disabled={page >= pageCount} onClick={() => setPage(page + 1)}>Next <ChevronRight size={13} /></SmallButton>
          </div>
        </div>
      </div>

      {/* ── Modals ─────────────────────────────────────────────────────────── */}
      <RequestFormModal
        open={modal.kind === 'newRequest'}
        onClose={closeModal}
        preset={modal.kind === 'newRequest' ? modal.preset : undefined}
        onSaved={(id) => { setExpandedId(id); setSearch(id); setPage(1); }}
      />
      <RequestFormModal open={modal.kind === 'editRequest'} onClose={closeModal} editing={liveModalRequest} />
      <AssignModal open={modal.kind === 'assign'} onClose={closeModal} request={liveModalRequest} />
      <VisitModal open={modal.kind === 'visit'} onClose={closeModal} request={liveModalRequest} visit={modal.kind === 'visit' ? modal.visit : undefined} />
      <WorkLogModal open={modal.kind === 'worklog'} onClose={closeModal} request={liveModalRequest} />
      <EstimateModal open={modal.kind === 'estimate'} onClose={closeModal} request={liveModalRequest} estimate={modal.kind === 'estimate' ? modal.estimate : undefined} />
      <ApprovalModal
        open={modal.kind === 'approval'}
        onClose={closeModal}
        request={liveModalRequest}
        estimate={modal.kind === 'approval' ? modal.estimate : null}
        mode={modal.kind === 'approval' ? modal.mode : 'approve'}
      />
      <CompleteModal open={modal.kind === 'complete'} onClose={closeModal} request={liveModalRequest} />
      <ReasonModal
        open={modal.kind === 'reason'}
        onClose={closeModal}
        title={
          modal.kind === 'reason'
            ? modal.action === 'reject' ? `Reject Request ${modal.req.id}` : modal.action === 'cancel' ? `Cancel Request ${modal.req.id}` : `Reopen Request ${modal.req.id}`
            : ''
        }
        label={modal.kind === 'reason' && modal.action === 'reopen' ? 'Why is this request being reopened?' : 'Reason (recorded in activity history)'}
        confirmLabel={modal.kind === 'reason' ? (modal.action === 'reopen' ? 'Reopen Request' : modal.action === 'reject' ? 'Reject Request' : 'Cancel Request') : ''}
        danger={modal.kind === 'reason' && modal.action !== 'reopen'}
        onSubmit={(reason) => {
          if (modal.kind !== 'reason' || !liveModalRequest) return;
          if (modal.action === 'reopen') {
            // Preserve the previous completion (with its true final cost), then reopen
            s.updateRequest(liveModalRequest.id, {
              status: 'In Progress',
              previousCompletions: [
                ...liveModalRequest.previousCompletions,
                {
                  completedAt: liveModalRequest.completedAt ?? '',
                  outcome: liveModalRequest.resolutionOutcome ?? 'Repaired',
                  notes: liveModalRequest.resolutionNotes ?? '',
                  finalCost: s.actualCost(liveModalRequest),
                  reopenedAt: new Date().toISOString(),
                  reopenReason: reason,
                },
              ],
              completedAt: undefined,
              resolutionOutcome: undefined,
              resolutionNotes: undefined,
              verificationStatus: 'Not Verified',
              followUpRequired: false,
            });
            s.logActivity(liveModalRequest.id, 'reopen', `Request reopened — ${reason}`);
            s.toast(`${liveModalRequest.id} reopened. Prior completion preserved in history.`);
          } else {
            s.setRequestStatus(liveModalRequest.id, modal.action === 'reject' ? 'Rejected' : 'Cancelled', { reason });
            s.toast(`${liveModalRequest.id} ${modal.action === 'reject' ? 'rejected' : 'cancelled'}.`, 'warning');
          }
        }}
      />
      <ReplaceApplianceModal
        open={modal.kind === 'replace'}
        onClose={closeModal}
        asset={liveModalRequest?.assetId ? s.getAsset(liveModalRequest.assetId) ?? null : null}
        request={liveModalRequest}
      />
      <LinkExpenseModal open={modal.kind === 'expenses'} onClose={closeModal} request={liveModalRequest} />
      <UploadModal open={modal.kind === 'upload'} onClose={closeModal} requestId={liveModalRequest?.id} />
      <WorkOrderFormModal open={modal.kind === 'workorder'} onClose={closeModal} presetRequest={liveModalRequest} />
    </div>
  );
}

// ── Row action menu ──────────────────────────────────────────────────────────

function RowActions({ req, onExpand, setModal, dropUp }: { req: MaintenanceRequest; onExpand: () => void; setModal: (m: ModalState) => void; dropUp?: boolean }) {
  const s = useStore();
  const finished = req.status === 'Completed' || req.status === 'Closed';
  return (
    <Menu
      dropUp={dropUp}
      trigger={
        <button className="rounded-md p-1.5 text-zinc-500 transition hover:bg-panel3 hover:text-zinc-100" aria-label="Actions">
          <MoreHorizontal size={16} />
        </button>
      }
      items={[
        { label: 'View Details', icon: <Eye size={13} />, onClick: onExpand },
        { label: 'Edit Request', icon: <Pencil size={13} />, onClick: () => setModal({ kind: 'editRequest', req }) },
        { label: 'Assign Staff / Contractor', icon: <UserCheck size={13} />, onClick: () => setModal({ kind: 'assign', req }) },
        { label: 'Schedule Visit', icon: <CalendarDays size={13} />, onClick: () => setModal({ kind: 'visit', req }) },
        { label: 'Add Work Log Entry', icon: <ClipboardList size={13} />, onClick: () => setModal({ kind: 'worklog', req }) },
        { label: 'New Estimate', icon: <Receipt size={13} />, onClick: () => setModal({ kind: 'estimate', req }) },
        { label: 'Create Work Order', icon: <Wrench size={13} />, onClick: () => setModal({ kind: 'workorder', req }) },
        { label: '', onClick: () => {}, divider: true },
        finished
          ? { label: 'Reopen Request', icon: <RotateCcw size={13} />, onClick: () => setModal({ kind: 'reason', req, action: 'reopen' }) }
          : { label: 'Mark Completed…', icon: <CheckCircle2 size={13} />, onClick: () => setModal({ kind: 'complete', req }) },
        { label: 'Go to Work Orders', icon: <ExternalLink size={13} />, onClick: () => s.navigate('workorders', { focusRequestId: req.id }) },
      ]}
    />
  );
}

// ── Expanded detail ──────────────────────────────────────────────────────────

function RequestDetail({ req, setModal, onCollapse }: { req: MaintenanceRequest; setModal: (m: ModalState) => void; onCollapse: () => void }) {
  const s = useStore();
  const [tab, setTab] = useState('overview');
  const [confirmCancelVisit, setConfirmCancelVisit] = useState<Visit | null>(null);
  const estimates = s.requestEstimates(req.id);
  const visits = s.requestVisits(req.id);
  const logs = s.requestWorkLogs(req.id);
  const docs = s.requestAttachments(req.id);
  const activity = s.requestActivity(req.id);
  const workOrders = s.requestWorkOrders(req.id);
  const property = s.getProperty(req.propertyId);
  const unit = s.getUnit(req.unitId);
  const tenant = s.getTenant(req.tenantId);
  const lease = s.getLease(req.leaseId);
  const asset = s.getAsset(req.assetId);
  const contractor = s.getContractor(req.assignedContractorId);
  const coordinator = s.getStaff(req.assignedStaffId);
  const est = s.estimatedCost(req);
  const actual = s.actualCost(req);
  const finished = req.status === 'Completed' || req.status === 'Closed';
  const transitions = STATUS_TRANSITIONS[req.status];

  const changeStatus = (next: string) => {
    if (next === 'Completed') return setModal({ kind: 'complete', req });
    if (next === 'Rejected') return setModal({ kind: 'reason', req, action: 'reject' });
    if (next === 'Cancelled') return setModal({ kind: 'reason', req, action: 'cancel' });
    if (next === 'In Progress' && finished) return setModal({ kind: 'reason', req, action: 'reopen' });
    if (next === 'Closed') {
      s.setRequestStatus(req.id, 'Closed');
      s.toast(`${req.id} closed.`);
      return;
    }
    s.setRequestStatus(req.id, next as MaintenanceRequest['status']);
    s.toast(`${req.id} → ${next}.`);
  };

  return (
    <div className="animate-expand px-5 py-4">
      {/* Detail header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="text-[15px] font-semibold text-zinc-50">{req.title}</h3>
          <StatusBadge status={req.status} />
          <PriorityBadge priority={req.priority} />
          {isOverdue(req) && <Chip tone="red"><AlertTriangle size={11} /> Overdue by {overdueDays(req)}d</Chip>}
          {req.followUpRequired && finished && <Chip tone="amber">Follow-up required</Chip>}
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <Menu
            trigger={
              <button className="inline-flex items-center gap-1 rounded-lg border border-line bg-panel2 px-2.5 py-1.5 text-[12px] font-medium text-zinc-200 transition hover:border-zinc-600">
                Change Status <ChevronDown size={12} />
              </button>
            }
            items={transitions.map((t) => ({
              label: t === 'In Progress' && finished ? 'Reopen (In Progress)…' : `${t}${t === 'Completed' || t === 'Rejected' || t === 'Cancelled' ? '…' : ''}`,
              danger: t === 'Rejected' || t === 'Cancelled',
              onClick: () => changeStatus(t),
            }))}
          />
          <SmallButton onClick={() => setModal({ kind: 'editRequest', req })}><Pencil size={12} /> Edit</SmallButton>
          <SmallButton onClick={() => setModal({ kind: 'assign', req })}><UserCheck size={12} /> Assign</SmallButton>
          <SmallButton onClick={() => setModal({ kind: 'visit', req })}><CalendarDays size={12} /> Schedule Visit</SmallButton>
          <SmallButton onClick={() => setModal({ kind: 'worklog', req })}><ClipboardList size={12} /> Add Work Log</SmallButton>
          {asset && asset.status !== 'Replaced' && (
            <SmallButton onClick={() => setModal({ kind: 'replace', req })} className="border-amber-500/40 text-amber-300 hover:border-amber-500/70">
              <Package size={12} /> Replace Appliance
            </SmallButton>
          )}
          {!finished && (
            <PrimaryButton onClick={() => setModal({ kind: 'complete', req })} className="px-2.5 py-1.5 text-[12px]">
              <CheckCircle2 size={13} /> Complete
            </PrimaryButton>
          )}
          <button onClick={onCollapse} className="rounded-md p-1.5 text-zinc-500 transition hover:bg-panel3 hover:text-zinc-200" aria-label="Collapse">
            <X size={15} />
          </button>
        </div>
      </div>

      <div className="mt-3">
        <Tabs
          active={tab}
          onChange={setTab}
          tabs={[
            { key: 'overview', label: 'Overview' },
            { key: 'visits', label: 'Assignment & Visits', count: visits.filter((v) => v.status === 'Scheduled').length || undefined },
            { key: 'worklog', label: 'Work Log', count: logs.length || undefined },
            { key: 'estimates', label: 'Estimates & Approvals', count: estimates.length || undefined },
            { key: 'costs', label: 'Costs & Expenses', count: req.linkedExpenseIds.length || undefined },
            { key: 'documents', label: 'Documents', count: docs.length || undefined },
            { key: 'activity', label: 'Activity', count: activity.length || undefined },
          ]}
        />
      </div>

      <div className="pt-4">
        {tab === 'overview' && (
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {/* Left: description + details */}
            <div className="space-y-5 lg:col-span-2">
              <div>
                <SectionTitle icon={<FileText size={13} />}>Description</SectionTitle>
                <p className="rounded-xl border border-line bg-panel px-4 py-3 text-[13px] leading-relaxed text-zinc-300">{req.description}</p>
                {req.statusReason && (req.status === 'Rejected' || req.status === 'Cancelled') && (
                  <p className="mt-2 rounded-xl border border-rose-500/25 bg-rose-500/5 px-4 py-3 text-[12.5px] text-rose-200">
                    <b>{req.status} reason:</b> {req.statusReason}
                  </p>
                )}
              </div>
              <div>
                <SectionTitle icon={<ClipboardList size={13} />}>Request Details</SectionTitle>
                <dl className="grid grid-cols-2 gap-x-4 gap-y-3.5 rounded-xl border border-line bg-panel px-4 py-3.5 sm:grid-cols-3">
                  <DetailItem label="Request ID">{req.id}</DetailItem>
                  <DetailItem label="Category">{req.category}{req.subcategory ? ` · ${req.subcategory}` : ''}</DetailItem>
                  <DetailItem label="Source">{req.source}</DetailItem>
                  <DetailItem label="Reported">{fmtDateTime(req.reportedAt)}</DetailItem>
                  <DetailItem label="Preferred By">{fmtDate(req.preferredDate)}</DetailItem>
                  <DetailItem label="Target Date">{fmtDate(req.targetDate)}</DetailItem>
                  <DetailItem label="Completed">{req.completedAt ? fmtDate(req.completedAt) : '—'}</DetailItem>
                  <DetailItem label="Reported By">{req.reportedByName} <span className="text-zinc-500">({req.reportedByRole})</span></DetailItem>
                  <DetailItem label="Approval Status">{req.approvalStatus}{req.approvedBudget !== undefined ? ` · Budget ${fmtMoney(req.approvedBudget)}` : ''}</DetailItem>
                </dl>
              </div>
              {(req.internalNotes || req.tenantNotes) && (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {req.internalNotes && (
                    <div className="rounded-xl border border-line bg-panel px-4 py-3">
                      <p className="text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Internal Notes <span className="normal-case text-zinc-600">(staff only)</span></p>
                      <p className="mt-1.5 text-[12.5px] leading-relaxed text-zinc-300">{req.internalNotes}</p>
                    </div>
                  )}
                  {req.tenantNotes && (
                    <div className="rounded-xl border border-line bg-panel px-4 py-3">
                      <p className="text-[11px] font-semibold uppercase tracking-wide text-zinc-500">Tenant-Facing Notes</p>
                      <p className="mt-1.5 text-[12.5px] leading-relaxed text-zinc-300">{req.tenantNotes}</p>
                    </div>
                  )}
                </div>
              )}
              {finished && (
                <div>
                  <SectionTitle icon={<CheckCircle2 size={13} />}>Resolution</SectionTitle>
                  <dl className="grid grid-cols-2 gap-x-4 gap-y-3.5 rounded-xl border border-emerald-500/20 bg-emerald-500/[0.03] px-4 py-3.5 sm:grid-cols-3">
                    <DetailItem label="Outcome">{req.resolutionOutcome ?? '—'}</DetailItem>
                    <DetailItem label="Completed">{fmtDate(req.completedAt)}</DetailItem>
                    <DetailItem label="Final Cost">{fmtMoney(actual)}</DetailItem>
                    <DetailItem label="Final Contractor">{contractor?.company ?? '—'}</DetailItem>
                    <DetailItem label="Verification">{req.verificationStatus ?? '—'}{req.verifiedBy ? ` · ${req.verifiedBy}` : ''}</DetailItem>
                    <DetailItem label="Warranty">{req.warrantyInfo ?? '—'}</DetailItem>
                    <DetailItem label="Completion Notes" className="col-span-2 sm:col-span-3">{req.resolutionNotes ?? '—'}</DetailItem>
                  </dl>
                  <div className="mt-2.5">
                    <SmallButton onClick={() => setModal({ kind: 'reason', req, action: 'reopen' })}><RotateCcw size={12} /> Reopen Request</SmallButton>
                  </div>
                </div>
              )}
              {req.previousCompletions.length > 0 && (
                <div>
                  <SectionTitle icon={<History size={13} />}>Previous Completions (preserved)</SectionTitle>
                  <div className="space-y-2">
                    {req.previousCompletions.map((pc, i) => (
                      <div key={i} className="rounded-xl border border-line bg-panel px-4 py-3 text-[12.5px] text-zinc-300">
                        <span className="font-medium text-zinc-100">{pc.outcome}</span> · completed {fmtDate(pc.completedAt)} · final cost {fmtMoney(pc.finalCost)}
                        <p className="mt-1 text-zinc-400">{pc.notes}</p>
                        {pc.reopenedAt && <p className="mt-1 text-[11.5px] text-zinc-500">Reopened {fmtDate(pc.reopenedAt)}{pc.reopenReason ? ` — ${pc.reopenReason}` : ''}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right: location, people, asset */}
            <div className="space-y-5">
              <div>
                <SectionTitle icon={<Building2 size={13} />}>Property & Unit</SectionTitle>
                <div className="rounded-xl border border-line bg-panel px-4 py-3.5">
                  <button onClick={() => s.navigate('properties')} className="text-left text-[13.5px] font-semibold text-teal-300 transition hover:text-teal-200">
                    {property?.name} <ExternalLink size={11} className="inline" />
                  </button>
                  <p className="mt-0.5 flex items-center gap-1 text-[12px] text-zinc-500"><MapPin size={11} /> {property?.address}, {property?.city}</p>
                  <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-3">
                    <DetailItem label="Unit">{unit ? <button onClick={() => s.navigate('units')} className="text-teal-300 hover:text-teal-200">{unit.name} <ExternalLink size={10} className="inline" /></button> : 'Common area'}</DetailItem>
                    <DetailItem label="Room / Location">{req.room ?? '—'}</DetailItem>
                    {unit && <DetailItem label="Layout">{unit.beds} bd · {unit.baths} ba · {unit.sqft} sqft</DetailItem>}
                    {lease && <DetailItem label="Lease"><button onClick={() => s.navigate('leases')} className="text-teal-300 hover:text-teal-200">{lease.id} <ExternalLink size={10} className="inline" /></button><span className="block text-[11px] text-zinc-500">{fmtDate(lease.start)} → {fmtDate(lease.end)}</span></DetailItem>}
                  </dl>
                  {tenant && (
                    <div className="mt-3 border-t border-line pt-3">
                      <div className="flex items-center gap-2.5">
                        <Avatar name={tenant.name} />
                        <div>
                          <button onClick={() => s.navigate('tenants')} className="text-[13px] font-medium text-teal-300 hover:text-teal-200">{tenant.name} <ExternalLink size={10} className="inline" /></button>
                          <p className="text-[11.5px] text-zinc-500">Tenant since {fmtDate(tenant.movedIn)}</p>
                        </div>
                      </div>
                      <div className="mt-2 space-y-1 text-[12px] text-zinc-400">
                        <p className="flex items-center gap-1.5"><Phone size={11} /> {tenant.phone}</p>
                        <p className="flex items-center gap-1.5"><Mail size={11} /> {tenant.email}</p>
                      </div>
                    </div>
                  )}
                  {(req.accessInstructions || req.preferredAccessTimes || req.petsNote) && (
                    <div className="mt-3 space-y-2 border-t border-line pt-3 text-[12px]">
                      {req.accessInstructions && <p><span className="font-medium text-zinc-400">Access: </span><span className="text-zinc-300">{req.accessInstructions}</span></p>}
                      {req.preferredAccessTimes && <p><span className="font-medium text-zinc-400">Preferred times: </span><span className="text-zinc-300">{req.preferredAccessTimes}</span></p>}
                      {req.petsNote && <p><span className="font-medium text-zinc-400">Pets: </span><span className="text-zinc-300">{req.petsNote}</span></p>}
                    </div>
                  )}
                </div>
              </div>

              {asset && <AssetSnapshot assetId={asset.id} req={req} onReplace={() => setModal({ kind: 'replace', req })} />}

              <div>
                <SectionTitle icon={<CircleDollarSign size={13} />}>Cost Summary</SectionTitle>
                <div className="rounded-xl border border-line bg-panel px-4 py-3.5 text-[12.5px]">
                  <div className="space-y-1.5">
                    <div className="flex justify-between"><span className="text-zinc-500">Estimated</span><span className="tabular text-zinc-200">{est !== null ? fmtMoney(est) : '—'}</span></div>
                    <div className="flex justify-between"><span className="text-zinc-500">Approved budget</span><span className="tabular text-zinc-200">{fmtMoney(req.approvedBudget)}</span></div>
                    <div className="flex justify-between"><span className="text-zinc-500">Actual (linked invoices)</span><span className="font-medium tabular text-zinc-50">{fmtMoney(actual)}</span></div>
                    {req.approvedBudget !== undefined && (
                      <div className="flex justify-between border-t border-line pt-1.5">
                        <span className="text-zinc-500">Remaining budget</span>
                        <span className={cn('font-medium tabular', req.approvedBudget - actual < 0 ? 'text-rose-400' : 'text-emerald-400')}>{fmtMoney(req.approvedBudget - actual)}</span>
                      </div>
                    )}
                  </div>
                  <button onClick={() => setTab('costs')} className="mt-2.5 text-[12px] font-medium text-teal-400 hover:text-teal-300">Open costs & expenses →</button>
                </div>
              </div>

              {workOrders.length > 0 && (
                <div>
                  <SectionTitle icon={<Wrench size={13} />}>Work Orders</SectionTitle>
                  <div className="space-y-2">
                    {workOrders.map((w) => (
                      <button
                        key={w.id}
                        onClick={() => s.navigate('workorders', { focusRequestId: req.id })}
                        className="flex w-full items-center justify-between gap-2 rounded-xl border border-line bg-panel px-3.5 py-2.5 text-left transition hover:border-zinc-600"
                      >
                        <span>
                          <span className="block text-[12.5px] font-medium text-zinc-100">{w.id} · {w.title}</span>
                          <span className="text-[11px] text-zinc-500">{s.getContractor(w.contractorId)?.company ?? 'Unassigned'}</span>
                        </span>
                        <Chip tone={w.status === 'Completed' ? 'green' : w.status === 'On Hold' ? 'amber' : 'sky'}>{w.status}</Chip>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'visits' && (
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div>
              <SectionTitle icon={<UserCheck size={13} />} action={<SmallButton onClick={() => setModal({ kind: 'assign', req })}>Change Assignment</SmallButton>}>
                Current Assignment
              </SectionTitle>
              <div className="space-y-3 rounded-xl border border-line bg-panel px-4 py-3.5">
                <DetailItem label="Assigned Contractor">
                  {contractor ? (
                    <span>
                      <span className="font-medium">{contractor.company}</span>
                      <span className="block text-[12px] text-zinc-500">{contractor.contact} · {contractor.phone}</span>
                      <span className="block text-[12px] text-zinc-500">{contractor.email}</span>
                    </span>
                  ) : <span className="text-amber-400">Not assigned</span>}
                </DetailItem>
                <DetailItem label="Coordinating Staff">{coordinator ? `${coordinator.name} — ${coordinator.role}` : '—'}</DetailItem>
                <DetailItem label="Assigned On">{req.assignedAt ? fmtDateTime(req.assignedAt) : '—'}</DetailItem>
                <DetailItem label="Assignment Status">{req.status}</DetailItem>
                {req.contractorNotes && <DetailItem label="Notes for Contractor">{req.contractorNotes}</DetailItem>}
              </div>
            </div>
            <div className="lg:col-span-2">
              <SectionTitle icon={<CalendarDays size={13} />} action={<PrimaryButton onClick={() => setModal({ kind: 'visit', req })} className="px-2.5 py-1.5 text-[12px]"><Plus size={13} /> Schedule Visit</PrimaryButton>}>
                Visits ({visits.length})
              </SectionTitle>
              {visits.length === 0 ? (
                <EmptyState icon={<CalendarDays size={18} />} title="No visits scheduled yet" body="Schedule an inspection or repair visit. Multiple visits are supported — e.g. diagnose first, return with parts later." />
              ) : (
                <div className="space-y-2">
                  {visits.map((v) => (
                    <div key={v.id} className="flex flex-wrap items-start justify-between gap-3 rounded-xl border border-line bg-panel px-4 py-3">
                      <div>
                        <p className="text-[13px] font-medium text-zinc-100">{v.purpose}</p>
                        <p className="mt-0.5 text-[12px] text-zinc-500">
                          {fmtDate(v.date)} · {v.time} · ~{v.durationMins} min
                          {v.contractorId ? ` · ${s.getContractor(v.contractorId)?.company}` : ''}
                          {v.staffId ? ` · ${s.getStaff(v.staffId)?.name}` : ''}
                          {v.workOrderId ? ` · ${v.workOrderId}` : ''}
                        </p>
                        {v.accessArrangements && <p className="text-[12px] text-zinc-500">Access: {v.accessArrangements}</p>}
                        {v.notes && <p className="mt-1 text-[12.5px] text-zinc-400">{v.notes}</p>}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Chip tone={v.status === 'Completed' ? 'green' : v.status === 'Cancelled' ? 'red' : v.status === 'Rescheduled' ? 'amber' : 'sky'}>{v.status}</Chip>
                        {v.status === 'Scheduled' && (
                          <>
                            <SmallButton onClick={() => { s.updateVisit(v.id, { status: 'Completed' }, `Visit marked completed: ${v.purpose}`); s.toast('Visit marked completed. Consider adding a work log entry.'); }}>Complete</SmallButton>
                            <SmallButton onClick={() => setModal({ kind: 'visit', req, visit: v })}>Reschedule</SmallButton>
                            <SmallButton onClick={() => setConfirmCancelVisit(v)} className="hover:border-rose-500/50 hover:text-rose-300">Cancel</SmallButton>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'worklog' && (
          <div>
            <SectionTitle icon={<ClipboardList size={13} />} action={<PrimaryButton onClick={() => setModal({ kind: 'worklog', req })} className="px-2.5 py-1.5 text-[12px]"><Plus size={13} /> Add Work Log Entry</PrimaryButton>}>
              Work Log
            </SectionTitle>
            {logs.length === 0 ? (
              <EmptyState icon={<ClipboardList size={18} />} title="No work recorded yet" body="Work log entries build the permanent service history for this request and any linked appliance. Entries are append-only." />
            ) : (
              <div className="space-y-2">
                {logs.map((w) => (
                  <div key={w.id} className="rounded-xl border border-line bg-panel px-4 py-3.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <Avatar name={w.person} size="sm" />
                        <div>
                          <p className="text-[13px] font-medium text-zinc-100">{w.person}</p>
                          <p className="text-[11.5px] text-zinc-500">{fmtDateTime(w.date)} · {w.hours}h{w.workOrderId ? ` · ${w.workOrderId}` : ''}</p>
                        </div>
                      </div>
                      <div className="flex gap-1.5">
                        <Chip tone={w.outcome === 'Work Completed' ? 'green' : w.outcome.includes('Replacement') ? 'amber' : 'sky'}>{w.outcome}</Chip>
                        {w.followUpRequired && <Chip tone="amber">Follow-up needed</Chip>}
                      </div>
                    </div>
                    <p className="mt-2.5 text-[13px] leading-relaxed text-zinc-300">{w.workPerformed}</p>
                    <div className="mt-2 grid grid-cols-1 gap-2 text-[12.5px] sm:grid-cols-2">
                      {w.diagnosis && <p><span className="font-medium text-zinc-500">Diagnosis: </span><span className="text-zinc-300">{w.diagnosis}</span></p>}
                      {w.materials && <p><span className="font-medium text-zinc-500">Materials: </span><span className="text-zinc-300">{w.materials}</span></p>}
                    </div>
                    {w.notes && <p className="mt-1.5 text-[12.5px] italic text-zinc-500">{w.notes}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'estimates' && (
          <div>
            <SectionTitle icon={<Receipt size={13} />} action={<PrimaryButton onClick={() => setModal({ kind: 'estimate', req })} className="px-2.5 py-1.5 text-[12px]"><Plus size={13} /> New Estimate</PrimaryButton>}>
              Estimates & Approvals
            </SectionTitle>
            <div className="mb-3 flex flex-wrap items-center gap-3 rounded-xl border border-line bg-panel px-4 py-3 text-[12.5px]">
              <span className="text-zinc-500">Request approval status:</span>
              <Chip tone={req.approvalStatus === 'Approved' ? 'green' : req.approvalStatus === 'Pending Approval' ? 'amber' : req.approvalStatus === 'Rejected' ? 'red' : 'zinc'}>{req.approvalStatus}</Chip>
              {req.approvedBudget !== undefined && <span className="text-zinc-300">Approved budget: <b className="tabular">{fmtMoney(req.approvedBudget)}</b></span>}
              <span className="text-zinc-600">Approval threshold: {fmtMoney(s.settings.approvalThreshold)} (Settings)</span>
            </div>
            {estimates.length === 0 ? (
              <EmptyState icon={<Receipt size={18} />} title="No estimates yet" body="Record a contractor quotation or internal estimate. Estimates above the approval threshold must be approved before work proceeds — an approved estimate is not a payment." />
            ) : (
              <div className="space-y-2">
                {estimates.map((e) => (
                  <div key={e.id} className="rounded-xl border border-line bg-panel px-4 py-3.5">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <p className="text-[13px] font-medium text-zinc-100">{e.id} · {e.label}</p>
                        <p className="mt-0.5 text-[11.5px] text-zinc-500">
                          Submitted by {e.submittedBy} · {fmtDate(e.submittedAt)}
                          {e.approvedBy && ` · Approved by ${e.approvedBy} on ${fmtDate(e.approvedAt)}`}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-[16px] font-semibold tabular text-zinc-50">{fmtMoney(e.total)}</p>
                        <Chip tone={e.status === 'Approved' ? 'green' : e.status === 'Pending Approval' ? 'amber' : e.status === 'Rejected' ? 'red' : e.status === 'Revision Requested' ? 'sky' : 'zinc'}>{e.status}</Chip>
                      </div>
                    </div>
                    <div className="mt-2.5 grid grid-cols-2 gap-2 text-[12px] sm:grid-cols-4">
                      <span className="rounded-lg bg-panel2 px-2.5 py-1.5"><span className="text-zinc-500">Labor </span><b className="tabular text-zinc-200">{fmtMoney(e.labor)}</b></span>
                      <span className="rounded-lg bg-panel2 px-2.5 py-1.5"><span className="text-zinc-500">Materials </span><b className="tabular text-zinc-200">{fmtMoney(e.materials)}</b></span>
                      <span className="rounded-lg bg-panel2 px-2.5 py-1.5"><span className="text-zinc-500">Other </span><b className="tabular text-zinc-200">{fmtMoney(e.other)}</b></span>
                      <span className="rounded-lg bg-panel2 px-2.5 py-1.5"><span className="text-zinc-500">Tax </span><b className="tabular text-zinc-200">{fmtMoney(e.tax)}</b></span>
                    </div>
                    {e.notes && <p className="mt-2 text-[12.5px] text-zinc-400">{e.notes}</p>}
                    {req.approvedBudget !== undefined && e.total > req.approvedBudget && e.status !== 'Approved' && (
                      <p className="mt-2 flex items-center gap-1 text-[12px] text-amber-400"><AlertTriangle size={12} /> Exceeds the approved budget of {fmtMoney(req.approvedBudget)}.</p>
                    )}
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {e.status === 'Pending Approval' && (
                        <>
                          <PrimaryButton onClick={() => setModal({ kind: 'approval', req, estimate: e, mode: 'approve' })} className="px-2.5 py-1.5 text-[12px]">Approve Work</PrimaryButton>
                          <SmallButton onClick={() => setModal({ kind: 'approval', req, estimate: e, mode: 'revision' })}>Request Revision</SmallButton>
                          <SmallButton onClick={() => setModal({ kind: 'approval', req, estimate: e, mode: 'reject' })} className="hover:border-rose-500/50 hover:text-rose-300">Reject Estimate</SmallButton>
                        </>
                      )}
                      {(e.status === 'Revision Requested' || e.status === 'Rejected' || e.status === 'Not Required') && (
                        <SmallButton onClick={() => setModal({ kind: 'estimate', req, estimate: e })}><Pencil size={11} /> Revise & Resubmit</SmallButton>
                      )}
                      {e.status === 'Approved' && (
                        <span className="flex items-center gap-1.5 text-[12px] text-emerald-400"><CheckCircle2 size={13} /> Approved budget {fmtMoney(e.approvedBudget ?? e.total)}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'costs' && <CostsTab req={req} setModal={setModal} />}

        {tab === 'documents' && (
          <div>
            <SectionTitle icon={<Paperclip size={13} />} action={<PrimaryButton onClick={() => setModal({ kind: 'upload', req })} className="px-2.5 py-1.5 text-[12px]"><Plus size={13} /> Attach Documents</PrimaryButton>}>
              Photos & Documents
            </SectionTitle>
            {docs.length === 0 ? (
              <EmptyState icon={<Paperclip size={18} />} title="No documents attached" body="Attach issue photos, contractor estimates, invoices, receipts and before/after photos. Prototype uploads are session-only." />
            ) : (
              <div className="overflow-hidden rounded-xl border border-line">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-line bg-panel2/60 text-left text-[11px] uppercase tracking-wider text-zinc-500">
                      <th className="px-3.5 py-2 font-semibold">File</th>
                      <th className="px-3.5 py-2 font-semibold">Category</th>
                      <th className="px-3.5 py-2 font-semibold">Uploaded</th>
                      <th className="px-3.5 py-2 font-semibold">By</th>
                      <th className="px-3.5 py-2 text-right font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {docs.map((doc) => (
                      <tr key={doc.id} className="border-b border-line/50 bg-panel last:border-0">
                        <td className="px-3.5 py-2.5">
                          <span className="flex items-center gap-2 text-[12.5px] font-medium text-zinc-100">
                            <FileText size={14} className="shrink-0 text-zinc-500" />
                            <span className="truncate">{doc.name}</span>
                            <span className="text-[11px] font-normal text-zinc-500">{doc.size}</span>
                            {doc.mock && <Chip tone="amber">Session only</Chip>}
                          </span>
                        </td>
                        <td className="px-3.5 py-2.5 text-[12.5px] text-zinc-300">{doc.category}</td>
                        <td className="px-3.5 py-2.5 text-[12.5px] tabular text-zinc-400">{fmtDate(doc.uploadedAt)}</td>
                        <td className="px-3.5 py-2.5 text-[12.5px] text-zinc-400">{doc.uploadedBy}</td>
                        <td className="px-3.5 py-2.5">
                          <div className="flex justify-end gap-1">
                            <SmallButton
                              onClick={() => {
                                if (doc.url) window.open(doc.url, '_blank');
                                else s.toast('This is a sample file from the demo dataset — no preview is stored. Files you attach can be previewed during the session.', 'info');
                              }}
                            >
                              <Eye size={11} /> Preview
                            </SmallButton>
                            <SmallButton onClick={() => { s.removeAttachment(doc.id); s.toast(`Removed ${doc.name}.`); }} className="hover:border-rose-500/50 hover:text-rose-300">
                              <Trash2 size={11} />
                            </SmallButton>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {tab === 'activity' && (
          <div>
            <SectionTitle icon={<ActivityIcon size={13} />}>Activity History</SectionTitle>
            <div className="relative ml-2 space-y-0 border-l border-line pl-5">
              {activity.map((a) => (
                <div key={a.id} className="relative pb-4 last:pb-0">
                  <span className="absolute -left-[25.5px] top-1 h-2 w-2 rounded-full bg-teal-500/70 ring-4 ring-[#0c1017]" />
                  <p className="text-[13px] text-zinc-200">{a.description}</p>
                  <p className="mt-0.5 text-[11.5px] text-zinc-500">{a.user} · {fmtDateTime(a.timestamp)} · {timeAgo(a.timestamp)}</p>
                </div>
              ))}
              {activity.length === 0 && <p className="py-4 text-[12.5px] text-zinc-500">No activity recorded yet.</p>}
            </div>
          </div>
        )}
      </div>

      <ConfirmDialog
        open={!!confirmCancelVisit}
        onClose={() => setConfirmCancelVisit(null)}
        title="Cancel this visit?"
        body={<>The visit “{confirmCancelVisit?.purpose}” on {fmtDate(confirmCancelVisit?.date)} will be marked as cancelled. The cancellation is recorded in the activity history.</>}
        confirmLabel="Cancel Visit"
        danger
        onConfirm={() => {
          if (confirmCancelVisit) {
            s.updateVisit(confirmCancelVisit.id, { status: 'Cancelled' }, `Visit cancelled: ${confirmCancelVisit.purpose}`);
            s.toast('Visit cancelled.', 'warning');
          }
        }}
      />
    </div>
  );
}

// ── Costs tab ────────────────────────────────────────────────────────────────

function CostsTab({ req, setModal }: { req: MaintenanceRequest; setModal: (m: ModalState) => void }) {
  const s = useStore();
  const est = s.estimatedCost(req);
  const actual = s.actualCost(req);
  const linked = req.linkedExpenseIds.map((id) => s.getExpense(id)).filter(Boolean);
  const remaining = req.approvedBudget !== undefined ? req.approvedBudget - actual : null;
  const varianceBase = req.approvedBudget ?? est;
  const variance = varianceBase !== undefined && varianceBase !== null ? actual - varianceBase : null;

  const cells = [
    { label: 'Estimated Cost', value: est !== null ? fmtMoney(est) : '—' },
    { label: 'Approved Budget', value: fmtMoney(req.approvedBudget) },
    { label: 'Actual Cost (linked)', value: fmtMoney(actual) },
    { label: 'Remaining Budget', value: remaining !== null ? fmtMoney(remaining) : '—', tone: remaining !== null && remaining < 0 ? 'text-rose-400' : 'text-emerald-400' },
    { label: `Variance vs ${req.approvedBudget !== undefined ? 'budget' : 'estimate'}`, value: variance !== null ? `${variance > 0 ? '+' : ''}${fmtMoney(variance)}` : '—', tone: variance !== null && variance > 0 ? 'text-rose-400' : 'text-zinc-100' },
  ];

  return (
    <div>
      <SectionTitle
        icon={<Banknote size={13} />}
        action={
          <div className="flex gap-1.5">
            <SmallButton onClick={() => setModal({ kind: 'expenses', req })}><Link2 size={12} /> Link Existing Expense</SmallButton>
            <PrimaryButton onClick={() => setModal({ kind: 'expenses', req })} className="px-2.5 py-1.5 text-[12px]"><Plus size={13} /> Create Expense Record</PrimaryButton>
          </div>
        }
      >
        Costs & Expenses
      </SectionTitle>
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-5">
        {cells.map((c) => (
          <div key={c.label} className="rounded-xl border border-line bg-panel px-3.5 py-3">
            <p className="text-[11px] font-medium uppercase tracking-wide text-zinc-500">{c.label}</p>
            <p className={cn('mt-1 text-[17px] font-semibold tabular text-zinc-50', c.tone)}>{c.value}</p>
          </div>
        ))}
      </div>

      <h5 className="mb-2 mt-5 flex items-center gap-2 text-[12px] font-semibold uppercase tracking-wider text-zinc-400">
        <Receipt size={13} /> Linked Financial Records (Bills & Expenses)
      </h5>
      {linked.length === 0 ? (
        <EmptyState
          icon={<Receipt size={18} />}
          title="No expenses linked yet"
          body="Actual cost comes from linked invoices in Bills & Expenses — never entered twice. Link an existing invoice or create a new expense record."
          action={<PrimaryButton onClick={() => setModal({ kind: 'expenses', req })} className="px-3 py-2 text-[12px]">Link or Create Expense</PrimaryButton>}
        />
      ) : (
        <div className="overflow-hidden rounded-xl border border-line">
          <table className="w-full">
            <thead>
              <tr className="border-b border-line bg-panel2/60 text-left text-[11px] uppercase tracking-wider text-zinc-500">
                <th className="px-3.5 py-2 font-semibold">Expense</th>
                <th className="px-3.5 py-2 font-semibold">Vendor</th>
                <th className="px-3.5 py-2 font-semibold">Category</th>
                <th className="px-3.5 py-2 font-semibold">Date</th>
                <th className="px-3.5 py-2 font-semibold">Payment</th>
                <th className="px-3.5 py-2 text-right font-semibold">Amount</th>
                <th className="px-3.5 py-2" />
              </tr>
            </thead>
            <tbody>
              {linked.map((e) => e && (
                <tr key={e.id} className="border-b border-line/50 bg-panel last:border-0">
                  <td className="px-3.5 py-2.5">
                    <button onClick={() => s.navigate('bills')} className="text-left">
                      <span className="block text-[12.5px] font-medium text-teal-300 hover:text-teal-200">{e.id} <ExternalLink size={10} className="inline" /></span>
                      <span className="block max-w-[320px] truncate text-[11.5px] text-zinc-500">{e.description}</span>
                    </button>
                  </td>
                  <td className="px-3.5 py-2.5 text-[12.5px] text-zinc-300">{e.vendor}</td>
                  <td className="px-3.5 py-2.5 text-[12.5px] text-zinc-400">{e.category}</td>
                  <td className="px-3.5 py-2.5 text-[12.5px] tabular text-zinc-400">{fmtDate(e.date)}</td>
                  <td className="px-3.5 py-2.5">
                    <PaymentBadge status={e.paymentStatus} />
                    {e.paymentStatus === 'Partially Paid' && e.amountPaid !== undefined && <span className="block text-[11px] text-zinc-500">{fmtMoney(e.amountPaid)} paid</span>}
                  </td>
                  <td className="px-3.5 py-2.5 text-right text-[13px] font-medium tabular text-zinc-100">{fmtMoney(e.amount)}</td>
                  <td className="px-3.5 py-2.5">
                    <SmallButton onClick={() => { s.unlinkExpense(req.id, e.id); s.toast(`${e.id} unlinked (record kept in Bills & Expenses).`); }}>
                      <Unlink size={11} /> Unlink
                    </SmallButton>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="mt-3 text-[11.5px] leading-relaxed text-zinc-500">
        A quotation is an estimate, not an expense. Approving an estimate doesn't pay the bill, and recording an expense doesn't mean the contractor has been paid — payment status always comes from the linked record in Bills & Expenses. Each invoice is counted once.
      </p>
    </div>
  );
}

// ── Asset snapshot + repair-vs-replace ──────────────────────────────────────

function AssetSnapshot({ assetId, req, onReplace }: { assetId: string; req: MaintenanceRequest; onReplace: () => void }) {
  const s = useStore();
  const asset = s.getAsset(assetId);
  if (!asset) return null;
  const ws = warrantyState(asset);
  const age = assetAgeYears(asset);
  const history = s.assetRequests(asset.id);
  const spend = s.assetRepairSpend(asset.id);
  const repairEst = s.estimatedCost(req);
  const failures24mo = history.filter((h) => new Date(h.reportedAt).getTime() > Date.now() - 730 * 86400000).length;
  const repairVsValue = repairEst && asset.purchasePrice ? Math.round((repairEst / asset.purchasePrice) * 100) : null;
  const replacedBy = asset.replacedById ? s.getAsset(asset.replacedById) : undefined;

  return (
    <div>
      <SectionTitle icon={<Package size={13} />} action={<SmallButton onClick={() => s.navigate('assets', { focusAssetId: asset.id })}>Open Asset <ExternalLink size={11} /></SmallButton>}>
        Related Asset
      </SectionTitle>
      <div className="rounded-xl border border-line bg-panel px-4 py-3.5">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[13.5px] font-semibold text-zinc-50">{asset.name}</span>
          <Chip tone="zinc">{asset.id}</Chip>
          <Chip tone={asset.status === 'Active' ? 'green' : asset.status === 'Under Repair' || asset.status === 'Under Inspection' ? 'amber' : 'zinc'}>{asset.status}</Chip>
        </div>
        <p className="mt-1 text-[12px] text-zinc-500">{asset.brand} {asset.model} · {asset.type} · {asset.room ?? ''}</p>
        {replacedBy && (
          <p className="mt-2 rounded-lg border border-line bg-panel2 px-2.5 py-1.5 text-[12px] text-zinc-300">
            Replaced by <button onClick={() => s.navigate('assets', { focusAssetId: replacedBy.id })} className="font-medium text-teal-300 hover:text-teal-200">{replacedBy.id} · {replacedBy.name}</button> on {fmtDate(asset.replacementDate)}
          </p>
        )}
        <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-3">
          <DetailItem label="Age">{age !== null ? `${age.toFixed(1)} yrs` : '—'}<span className="block text-[11px] text-zinc-500">bought {fmtDate(asset.purchaseDate)} · {fmtMoney(asset.purchasePrice)}</span></DetailItem>
          <DetailItem label="Condition">{asset.condition}</DetailItem>
          <DetailItem label="Warranty">
            {ws === 'active' && <span className="text-emerald-400">Active → {fmtDate(asset.warrantyEnd)}</span>}
            {ws === 'expiring' && <span className="text-amber-400">Expires {fmtDate(asset.warrantyEnd)}</span>}
            {ws === 'expired' && <span className="text-rose-400">Expired {fmtDate(asset.warrantyEnd)}</span>}
            {ws === 'none' && 'None on record'}
          </DetailItem>
          <DetailItem label="Last Service">{fmtDate(asset.lastService)}</DetailItem>
        </dl>

        <div className="mt-3 border-t border-line pt-3">
          <p className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-zinc-400">
            <ShieldCheck size={12} /> Repair vs. Replace
          </p>
          <div className="space-y-1.5 text-[12.5px]">
            <div className="flex justify-between"><span className="text-zinc-500">This repair (estimated)</span><b className="tabular text-zinc-100">{repairEst !== null ? fmtMoney(repairEst) : '—'}</b></div>
            {repairVsValue !== null && <div className="flex justify-between"><span className="text-zinc-500">Repair as % of purchase price</span><b className={cn('tabular', repairVsValue >= 50 ? 'text-amber-400' : 'text-zinc-100')}>{repairVsValue}%</b></div>}
            <div className="flex justify-between"><span className="text-zinc-500">Historical repair costs</span><b className="tabular text-zinc-100">{fmtMoney(spend)}</b></div>
            <div className="flex justify-between"><span className="text-zinc-500">Requests in last 24 months</span><b className="tabular text-zinc-100">{failures24mo}</b></div>
            <div className="flex justify-between"><span className="text-zinc-500">Lifetime requests</span><b className="tabular text-zinc-100">{history.length}</b></div>
          </div>
          {ws === 'active' && (
            <p className="mt-2 rounded-lg border border-emerald-500/25 bg-emerald-500/5 px-2.5 py-1.5 text-[11.5px] text-emerald-300">
              Under warranty until {fmtDate(asset.warrantyEnd)}{asset.warrantyProvider ? ` (${asset.warrantyProvider})` : ''} — check coverage before paying for parts.
            </p>
          )}
          {asset.status !== 'Replaced' && asset.status !== 'Disposed' && (
            <div className="mt-3 flex gap-1.5">
              <SmallButton onClick={onReplace} className="border-amber-500/40 text-amber-300 hover:border-amber-500/70">Replace Appliance…</SmallButton>
              <SmallButton onClick={() => s.navigate('assets', { focusAssetId: asset.id })}>Full Service History</SmallButton>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
