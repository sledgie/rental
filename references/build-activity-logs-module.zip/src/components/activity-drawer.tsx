"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, Check, Clipboard, ExternalLink, FileClock, Fingerprint, LockKeyhole, RotateCcw, X } from "lucide-react";
import type { ActivityChange, ActivityEventDTO } from "@/lib/activity/types";
import { actionLabel, formatActorType } from "@/lib/activity/types";
import { formatDate, formatDateTime, money } from "@/lib/format";
import { ActorAvatar, CategoryBadge, RecordLink, ResultBadge, SeverityIndicator, recordHref } from "./activity-ui";

function displayValue(change: ActivityChange, value: string | null) {
  if (change.sensitivity === "restricted") return "Restricted by audit policy";
  if (value === null || value === "") return "Not set";
  if (change.valueType === "currency") return money(value, change.currency ?? "USD");
  if (change.valueType === "date") return formatDate(`${value.slice(0, 10)}T12:00:00Z`);
  if (change.valueType === "datetime") return formatDateTime(value);
  if (change.valueType === "boolean") return value === "true" ? "Yes" : "No";
  return value;
}

function ChangeRow({ change }: { change: ActivityChange }) {
  const isAdded = change.changeType === "added";
  const isRemoved = change.changeType === "removed";
  return <div className="rounded-xl border border-slate-200 bg-white p-3.5">
    <div className="mb-3 flex items-center justify-between gap-2"><p className="text-xs font-semibold text-slate-800">{change.label}</p><span className={`rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide ${isAdded ? "bg-emerald-50 text-emerald-700" : isRemoved ? "bg-red-50 text-red-700" : "bg-blue-50 text-blue-700"}`}>{isAdded ? "Added" : isRemoved ? "Removed" : "Modified"}</span></div>
    <div className="grid grid-cols-[1fr_20px_1fr] items-center gap-2">
      <div className={`min-w-0 rounded-lg px-2.5 py-2 ${isAdded ? "bg-slate-50" : "bg-red-50/70"}`}><p className="mb-1 text-[9px] font-bold uppercase tracking-wider text-slate-400">Previous</p><p className={`break-words text-xs ${isAdded ? "text-slate-400" : "text-red-700 line-through decoration-red-300"}`}>{displayValue(change, change.previousValue)}</p></div>
      <ArrowRight size={14} className="mx-auto text-slate-300" />
      <div className={`min-w-0 rounded-lg px-2.5 py-2 ${isRemoved ? "bg-slate-50" : "bg-emerald-50/80"}`}><p className="mb-1 text-[9px] font-bold uppercase tracking-wider text-slate-400">New</p><p className={`break-words text-xs font-medium ${isRemoved ? "text-slate-400" : "text-emerald-800"}`}>{displayValue(change, change.newValue)}</p></div>
    </div>
    {change.sensitivity === "restricted" && <p className="mt-2 flex items-center gap-1 text-[10px] text-slate-400"><LockKeyhole size={11} />Values are redacted at rest and excluded from exports.</p>}
  </div>;
}

function InfoItem({ label, value, mono = false }: { label: string; value: string | null | undefined; mono?: boolean }) {
  return <div className="min-w-0"><dt className="text-[10px] font-semibold uppercase tracking-[0.08em] text-slate-400">{label}</dt><dd className={`mt-1 break-words text-xs leading-5 text-slate-700 ${mono ? "font-mono text-[11px]" : ""}`}>{value || "—"}</dd></div>;
}

export function ActivityDrawer({ eventId, onClose, onNavigate, canViewRecords, canViewSensitive }: { eventId: string; onClose: () => void; onNavigate: (id: string) => void; canViewRecords: boolean; canViewSensitive: boolean }) {
  const [event, setEvent] = useState<ActivityEventDTO | null>(null);
  const [related, setRelated] = useState<ActivityEventDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [retryToken, setRetryToken] = useState(0);
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (keyboardEvent: KeyboardEvent) => { if (keyboardEvent.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = previousOverflow; window.removeEventListener("keydown", onKey); };
  }, [onClose]);
  useEffect(() => {
    const controller = new AbortController();
    setLoading(true); setError(""); setEvent(null); setRelated([]); setCopied(false);
    Promise.all([
      fetch(`/api/activity-logs/${encodeURIComponent(eventId)}`, { signal: controller.signal }).then(async (response) => { const body = await response.json(); if (!response.ok) throw new Error(body.error || "Unable to load event"); return body as ActivityEventDTO; }),
    ]).then(async ([detail]) => {
      setEvent(detail);
      const response = await fetch(`/api/activity-logs/related?entityType=${encodeURIComponent(detail.entityType)}&entityId=${encodeURIComponent(detail.entityId)}&exclude=${encodeURIComponent(detail.id)}`, { signal: controller.signal });
      if (response.ok) { const body = await response.json() as { items: ActivityEventDTO[] }; setRelated(body.items); }
    }).catch((reason: unknown) => { if (reason instanceof DOMException && reason.name === "AbortError") return; setError(reason instanceof Error ? reason.message : "Unable to load activity details."); }).finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [eventId, retryToken]);
  const copyId = async () => {
    if (!event) return;
    try { await navigator.clipboard.writeText(event.id); setCopied(true); window.setTimeout(() => setCopied(false), 1800); } catch { setCopied(false); }
  };
  return <div className="fixed inset-0 z-[70] flex justify-end" role="dialog" aria-modal="true" aria-labelledby="activity-detail-title">
    <button aria-label="Close activity details" onClick={onClose} className="absolute inset-0 animate-fade bg-slate-950/35 backdrop-blur-[2px]" />
    <aside className="animate-drawer relative flex h-full w-full flex-col bg-[#f8fafc] shadow-[-20px_0_60px_rgba(15,23,42,.16)] sm:w-[610px]">
      <div className="flex items-start justify-between border-b border-slate-200 bg-white px-5 py-5 sm:px-7"><div className="min-w-0 pr-3"><div className="mb-2 flex items-center gap-2"><span className="text-[10px] font-bold uppercase tracking-[0.14em] text-blue-600">Activity details</span>{event && <SeverityIndicator severity={event.severity} showLabel />}</div><h2 id="activity-detail-title" className="text-lg font-bold tracking-[-0.025em] text-slate-950">{loading ? "Loading event…" : event?.description ?? "Activity event"}</h2>{event && <div className="mt-2 flex items-center gap-2"><button onClick={copyId} className="inline-flex items-center gap-1.5 font-mono text-[10px] text-slate-400 hover:text-blue-600">{copied ? <Check size={12} className="text-emerald-500" /> : <Clipboard size={12} />}{event.id}</button></div>}</div><button ref={closeRef} onClick={onClose} aria-label="Close details" className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-800"><X size={19} /></button></div>
      <div className="scrollbar-thin flex-1 overflow-y-auto px-5 py-5 sm:px-7">
        {loading && <div className="space-y-4">{[1, 2, 3, 4].map((item) => <div key={item} className="h-28 animate-pulse rounded-xl bg-slate-200/60" />)}</div>}
        {!loading && error && <div className="rounded-xl border border-red-200 bg-red-50 p-5 text-center"><p className="text-sm font-semibold text-red-800">Couldn’t load this event</p><p className="mt-1 text-xs text-red-600">{error}</p><button onClick={() => setRetryToken((value) => value + 1)} className="mt-4 inline-flex items-center gap-2 rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white"><RotateCcw size={14} />Retry</button></div>}
        {!loading && event && <div className="space-y-5">
          <section className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5"><div className="mb-4 flex items-center justify-between"><h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.08em] text-slate-500"><Fingerprint size={14} className="text-blue-500" />Event information</h3><ResultBadge outcome={event.outcome} /></div><dl className="grid grid-cols-2 gap-x-5 gap-y-4"><InfoItem label="Event ID" value={event.id} mono /><InfoItem label="Occurred at" value={formatDateTime(event.occurredAt)} /><InfoItem label="Recorded at" value={formatDateTime(event.recordedAt)} /><InfoItem label="Actor" value={event.actorDisplayName} /><InfoItem label="Actor ID" value={event.actorId} mono /><InfoItem label="Actor type" value={formatActorType(event.actorType)} /><InfoItem label="Action" value={actionLabel(event.action)} /><InfoItem label="Category" value={event.category} /><InfoItem label="Source module" value={event.sourceModule} /><InfoItem label="Correlation ID" value={event.correlationId} mono /></dl><div className="mt-4 border-t border-slate-100 pt-4"><p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Description</p><p className="mt-1.5 text-sm leading-6 text-slate-700">{event.description}</p></div></section>
          <section className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5"><h3 className="mb-4 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.08em] text-slate-500"><ExternalLink size={14} className="text-blue-500" />Related records</h3><dl className="grid grid-cols-2 gap-x-5 gap-y-4"><InfoItem label="Property" value={event.propertyName} /><InfoItem label="Unit" value={event.unitNumber ? `Unit ${event.unitNumber}` : null} /><InfoItem label="Tenant" value={event.tenantName} /><InfoItem label="Entity type" value={event.entityType.replaceAll("_", " ")} /><InfoItem label="Entity ID" value={event.entityId} mono /><div><dt className="text-[10px] font-semibold uppercase tracking-[0.08em] text-slate-400">Related record</dt><dd className="mt-1 text-xs">{canViewRecords ? <RecordLink event={event} label={event.relatedRecordLabel} /> : <span className="text-slate-500">{event.relatedRecordLabel}</span>}</dd></div></dl>{event.propertyId && canViewRecords && <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-4"><Link href={`/records/property/${encodeURIComponent(event.propertyId)}`} className="inline-flex items-center gap-1 text-[11px] font-medium text-blue-600 hover:underline">Open property <ArrowUpRight size={12} /></Link>{event.tenantId && event.tenantName && <Link href={`/records/tenant/${encodeURIComponent(event.tenantId)}`} className="inline-flex items-center gap-1 text-[11px] font-medium text-blue-600 hover:underline">Open tenant <ArrowUpRight size={12} /></Link>}</div>}</section>
          <section><div className="mb-3 flex items-center justify-between"><h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.08em] text-slate-500"><ArrowDown size={14} className="text-blue-500" />Change details</h3><span className="text-[10px] text-slate-400">{event.changes.length} {event.changes.length === 1 ? "field" : "fields"}</span></div>{event.changes.length ? <div className="space-y-2.5">{event.changes.map((change) => <ChangeRow key={`${change.field}-${change.label}`} change={change} />)}</div> : <div className="rounded-xl border border-dashed border-slate-200 bg-white p-4 text-xs leading-5 text-slate-500">No field-level changes were recorded for this event. The event metadata and related record remain available above.</div>}</section>
          {(event.reason || Object.keys(event.metadata).length > 0 || event.error) && <section className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5"><h3 className="mb-4 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.08em] text-slate-500"><FileClock size={14} className="text-blue-500" />Additional information</h3>{event.reason && <div className="mb-4 rounded-lg bg-blue-50/70 px-3 py-2.5"><p className="text-[10px] font-bold uppercase tracking-wider text-blue-500">Reason / comment</p><p className="mt-1 text-xs leading-5 text-blue-950">{event.reason}</p></div>}{event.error && <div className="mb-4 rounded-lg border border-red-100 bg-red-50 p-3"><p className="text-xs font-bold text-red-800">{event.error.code}</p><p className="mt-1 text-xs leading-5 text-red-700">{event.error.message}</p>{event.error.retryable && <p className="mt-2 text-[10px] font-medium text-red-500">Retryable operation</p>}</div>}{Object.keys(event.metadata).length > 0 && <dl className="grid grid-cols-2 gap-x-4 gap-y-3">{Object.entries(event.metadata).map(([key, value]) => <InfoItem key={key} label={key.replace(/([A-Z])/g, " $1")} value={typeof value === "object" ? JSON.stringify(value) : String(value)} mono={key.toLowerCase().includes("id")} />)}</dl>}{!canViewSensitive && <p className="mt-4 flex items-center gap-1.5 text-[10px] text-slate-400"><LockKeyhole size={12} />Restricted metadata is hidden for your role.</p>}</section>}
          <section><h3 className="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.08em] text-slate-500"><ArrowLeft size={14} className="text-blue-500" />Related activity <span className="font-normal normal-case tracking-normal text-slate-400">({related.length})</span></h3>{related.length ? <div className="space-y-2">{related.slice(0, 6).map((item) => <button key={item.id} onClick={() => onNavigate(item.id)} className="group flex w-full items-center gap-3 rounded-xl border border-slate-200 bg-white p-3 text-left transition-all hover:border-blue-200 hover:shadow-sm"><ActorAvatar name={item.actorDisplayName} actorType={item.actorType} size="sm" /><div className="min-w-0 flex-1"><p className="truncate text-xs font-medium text-slate-700 group-hover:text-blue-700">{item.description}</p><p className="mt-1 text-[10px] text-slate-400">{formatDateTime(item.occurredAt)}</p></div><ArrowRight size={14} className="shrink-0 text-slate-300 group-hover:text-blue-500" /></button>)}</div> : <p className="rounded-xl border border-dashed border-slate-200 bg-white p-4 text-xs text-slate-500">No other activities are linked to this record.</p>}</section>
          <div className="flex items-center gap-2 pb-2 text-[10px] text-slate-400"><LockKeyhole size={12} /><span>SHA-256 chain hash</span><span className="truncate font-mono">{event.eventHash.slice(0, 20)}…</span>{canViewRecords ? <Link href={`/records/${encodeURIComponent(event.entityType)}/${encodeURIComponent(event.entityId)}`} className="ml-auto shrink-0 text-blue-600 hover:underline">Full timeline</Link> : <span className="ml-auto text-slate-400">Record access restricted</span>}</div>
        </div>}
      </div>
    </aside>
  </div>;
}
