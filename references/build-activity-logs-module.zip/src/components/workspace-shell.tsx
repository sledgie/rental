"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { Activity, BarChart3, Building2, ChevronRight, FileKey2, FolderLock, Hammer, LayoutDashboard, Menu, MessageSquare, PlugZap, ReceiptText, ScrollText, ShieldCheck, UserCog, UsersRound, Wrench, X } from "lucide-react";

const primaryNav = [
  { href: "/overview", label: "Overview", icon: LayoutDashboard },
  { href: "/properties", label: "Properties & Units", icon: Building2 },
  { href: "/tenants", label: "Tenants & Leases", icon: UsersRound },
  { href: "/accounting", label: "Accounting", icon: ReceiptText },
  { href: "/maintenance", label: "Maintenance", icon: Wrench },
  { href: "/projects", label: "Projects", icon: Hammer },
  { href: "/documents", label: "Documents", icon: FolderLock },
  { href: "/communications", label: "Communications", icon: MessageSquare },
];
const administrationNav = [
  { href: "/admin/users", label: "Users & Permissions", icon: UserCog },
  { href: "/activity-logs", label: "Activity Logs", icon: ScrollText },
  { href: "/admin/security", label: "Security & Audit", icon: ShieldCheck },
  { href: "/admin/integrations", label: "Integrations", icon: PlugZap },
];

function NavGroup({ title, items, pathname, onNavigate }: { title: string; items: typeof primaryNav; pathname: string; onNavigate: () => void }) {
  return (
    <div className="mb-7">
      <p className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">{title}</p>
      <nav aria-label={title} className="space-y-1">
        {items.map((item) => {
          const active = pathname === item.href || (item.href !== "/overview" && pathname.startsWith(`${item.href}/`));
          const Icon = item.icon;
          return <Link key={item.href} href={item.href} onClick={onNavigate} aria-current={active ? "page" : undefined} className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium transition-all duration-200 ${active ? "bg-blue-50 text-blue-700 shadow-[inset_3px_0_0_#2563eb]" : "text-slate-600 hover:bg-slate-50 hover:text-slate-950"}`}>
            <Icon size={17} strokeWidth={active ? 2.2 : 1.8} className={active ? "text-blue-600" : "text-slate-400 group-hover:text-slate-600"} />
            <span className="flex-1">{item.label}</span>
            {active && <ChevronRight size={14} className="text-blue-400" />}
          </Link>;
        })}
      </nav>
    </div>
  );
}

export function WorkspaceShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  useEffect(() => setMobileOpen(false), [pathname]);
  useEffect(() => {
    const close = (event: KeyboardEvent) => { if (event.key === "Escape") setMobileOpen(false); };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, []);
  const sidebar = <div className="flex h-full flex-col">
    <div className="flex h-[76px] items-center gap-3 border-b border-slate-100 px-6">
      <div className="grid h-9 w-9 place-items-center rounded-xl bg-blue-600 text-white shadow-[0_5px_14px_rgba(37,99,235,.25)]"><Activity size={20} strokeWidth={2.4} /></div>
      <div><div className="text-[17px] font-bold tracking-[-0.04em] text-slate-950">rentwise</div><div className="text-[9px] font-semibold uppercase tracking-[0.17em] text-slate-400">Property operations</div></div>
    </div>
    <div className="flex-1 overflow-y-auto px-3 py-6">
      <div className="mb-6 mx-2 rounded-xl border border-blue-100 bg-gradient-to-br from-blue-50 to-indigo-50/40 p-3.5">
        <div className="flex items-center gap-2 text-xs font-semibold text-blue-900"><span className="h-1.5 w-1.5 rounded-full bg-blue-500" />Northstar Rentals</div>
        <p className="mt-1 text-[11px] leading-4 text-blue-700/70">Sample workspace · 4 properties</p>
      </div>
      <NavGroup title="Workspace" items={primaryNav} pathname={pathname} onNavigate={() => setMobileOpen(false)} />
      <NavGroup title="Administration" items={administrationNav} pathname={pathname} onNavigate={() => setMobileOpen(false)} />
    </div>
    <div className="border-t border-slate-100 p-4">
      <Link href="/admin/security" className="flex items-center gap-2.5 rounded-lg px-2 py-2 text-xs text-slate-500 transition-colors hover:bg-slate-50 hover:text-slate-800"><ShieldCheck size={15} className="text-emerald-500" /><span>Audit controls</span><span className="ml-auto h-1.5 w-1.5 rounded-full bg-emerald-400" /></Link>
      <p className="mt-3 px-2 text-[10px] leading-4 text-slate-400">Demo identity · permissions enforced server-side</p>
    </div>
  </div>;
  return <div className="min-h-screen bg-[#f7f8fa] text-slate-900">
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[248px] border-r border-slate-200/80 bg-white lg:block">{sidebar}</aside>
    {mobileOpen && <button aria-label="Close navigation" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-40 bg-slate-950/30 backdrop-blur-[2px] lg:hidden" />}
    <aside className={`fixed inset-y-0 left-0 z-50 w-[280px] border-r border-slate-200 bg-white transition-transform duration-300 lg:hidden ${mobileOpen ? "translate-x-0" : "-translate-x-full"}`}>
      <button onClick={() => setMobileOpen(false)} aria-label="Close navigation" className="absolute right-3 top-5 rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-800"><X size={18} /></button>{sidebar}
    </aside>
    <div className="lg:pl-[248px]">
      <header className="sticky top-0 z-20 flex h-[68px] items-center justify-between border-b border-slate-200/70 bg-white/90 px-4 backdrop-blur-xl sm:px-7 lg:px-9">
        <div className="flex items-center gap-3"><button onClick={() => setMobileOpen(true)} aria-label="Open navigation" className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 lg:hidden"><Menu size={20} /></button><div className="hidden items-center gap-2 text-xs text-slate-400 sm:flex"><BarChart3 size={14} /><span>Operations</span><ChevronRight size={13} /><span className="font-medium text-slate-600">{pathname === "/activity-logs" ? "Activity Logs" : pathname.startsWith("/admin") ? "Administration" : "Workspace"}</span></div><span className="text-sm font-semibold text-slate-700 sm:hidden">rentwise</span></div>
        <div className="flex items-center gap-3 sm:gap-5"><span className="hidden items-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-2.5 py-1 text-[10px] font-semibold text-amber-700 sm:inline-flex"><FileKey2 size={12} />Sample data</span><div className="h-6 w-px bg-slate-200" /><div className="flex items-center gap-2.5"><div className="grid h-8 w-8 place-items-center rounded-full bg-slate-900 text-[11px] font-semibold text-white">OM</div><div className="hidden text-right sm:block"><p className="text-xs font-semibold text-slate-800">Olivia Martin</p><p className="text-[10px] text-slate-400">Administrator</p></div></div></div>
      </header>
      <main>{children}</main>
    </div>
  </div>;
}
