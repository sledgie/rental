import Link from "next/link";
import { ArrowUpRight, Check, CircleAlert, Clock3, Info, ShieldAlert, XCircle } from "lucide-react";
import type { ActivityEventDTO, Outcome, Severity } from "@/lib/activity/types";
import { formatActorType } from "@/lib/activity/types";
import { initials } from "@/lib/format";

export function ResultBadge({ outcome }: { outcome: Outcome }) {
  const config = {
    success: { label: "Success", className: "bg-emerald-50 text-emerald-700 ring-emerald-600/15", Icon: Check },
    failure: { label: "Failure", className: "bg-red-50 text-red-700 ring-red-600/15", Icon: XCircle },
    denied: { label: "Denied", className: "bg-orange-50 text-orange-700 ring-orange-600/15", Icon: ShieldAlert },
    pending: { label: "Pending", className: "bg-amber-50 text-amber-700 ring-amber-600/15", Icon: Clock3 },
  }[outcome];
  const Icon = config.Icon;
  return <span className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2 py-1 text-[11px] font-semibold ring-1 ring-inset ${config.className}`}><Icon size={12} strokeWidth={2.2} />{config.label}</span>;
}

export function SeverityIndicator({ severity, showLabel = false }: { severity: Severity; showLabel?: boolean }) {
  const config = {
    informational: { label: "Informational", className: "bg-slate-400", text: "text-slate-500", Icon: Info },
    warning: { label: "Warning", className: "bg-amber-500", text: "text-amber-700", Icon: CircleAlert },
    critical: { label: "Critical", className: "bg-red-500", text: "text-red-700", Icon: ShieldAlert },
  }[severity];
  return <span title={config.label} className={`inline-flex items-center gap-1.5 text-[11px] font-medium ${config.text}`}><span className={`h-1.5 w-1.5 rounded-full ${config.className}`} />{showLabel && config.label}</span>;
}

export function CategoryBadge({ category }: { category: string }) {
  const colors: Record<string, string> = {
    "Properties & Units": "bg-blue-50 text-blue-700",
    "Tenants & Leases": "bg-violet-50 text-violet-700",
    "Accounting & Finance": "bg-emerald-50 text-emerald-700",
    "Maintenance & Repairs": "bg-orange-50 text-orange-700",
    "Projects & Renovations": "bg-cyan-50 text-cyan-700",
    "Documents & eSignatures": "bg-indigo-50 text-indigo-700",
    Communications: "bg-pink-50 text-pink-700",
    "Users & Security": "bg-slate-100 text-slate-700",
  };
  return <span className={`inline-flex rounded-md px-2 py-1 text-[10px] font-semibold leading-4 ${colors[category] ?? "bg-slate-100 text-slate-600"}`}>{category}</span>;
}

export function ActorAvatar({ name, actorType, size = "md" }: { name: string; actorType: string; size?: "sm" | "md" }) {
  const system = actorType !== "user";
  return <div title={`${name} · ${formatActorType(actorType)}`} className={`grid shrink-0 place-items-center rounded-full font-semibold ${size === "sm" ? "h-7 w-7 text-[9px]" : "h-8 w-8 text-[10px]"} ${system ? "bg-slate-100 text-slate-600 ring-1 ring-slate-200" : "bg-blue-100 text-blue-700"}`}>{system ? <ActivityTypeIcon type={actorType} /> : initials(name)}</div>;
}

function ActivityTypeIcon({ type }: { type: string }) {
  if (type === "integration") return <ArrowUpRight size={13} />;
  if (type === "scheduled_job") return <Clock3 size={13} />;
  return <ActivityGlyph />;
}
function ActivityGlyph() { return <span className="text-[12px] font-bold">S</span>; }

export function recordHref(event: Pick<ActivityEventDTO, "entityType" | "entityId">) {
  return `/records/${encodeURIComponent(event.entityType)}/${encodeURIComponent(event.entityId)}`;
}

export function RecordLink({ event, label, className = "" }: { event: Pick<ActivityEventDTO, "entityType" | "entityId">; label: string; className?: string }) {
  return <Link href={recordHref(event)} className={`group inline-flex items-center gap-1 text-blue-600 hover:text-blue-800 hover:underline ${className}`}>{label}<ArrowUpRight size={12} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></Link>;
}
