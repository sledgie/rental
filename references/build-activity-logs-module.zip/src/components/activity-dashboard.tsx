"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, ArrowUpDown, CalendarDays, Check, ChevronDown, ChevronLeft, ChevronRight, CircleAlert, Download, FileClock, Filter, Landmark, Loader2, RefreshCw, Search, ShieldAlert, SlidersHorizontal, Sparkles, UsersRound, X, XCircle } from "lucide-react";
import type { ActivityEventDTO, ActivityFilters, ActivityListResponse } from "@/lib/activity/types";
import { ACTIONS, ACTOR_TYPES, CATEGORIES, DEFAULT_FILTERS, ENTITY_TYPES, OUTCOMES, SEVERITIES, actionLabel, formatActorType } from "@/lib/activity/types";
import { filtersToSearchParams } from "@/lib/activity/filters";
import { formatDateTime, formatRelativeTime } from "@/lib/format";
import { ActivityDrawer } from "./activity-drawer";
import { ActorAvatar, CategoryBadge, RecordLink, ResultBadge, SeverityIndicator, recordHref } from "./activity-ui";

type DashboardProps = {
  initialData: ActivityListResponse;
  initialFilters: ActivityFilters;
  initialEventId?: string;
  permissions: { records: boolean; sensitive: boolean };
};

function isoDate(date: Date) { return date.toISOString().slice(0, 10); }
function dateRange(days: number) {
  const to = new Date();
  const from = new Date(); from.setDate(from.getDate() - days);
  return { from: isoDate(from), to: isoDate(to) };
}

function FilterSelect({ label, value, onChange, children }: { label: string; value: string; onChange: (value: string) => void; children: React.ReactNode }) {
  return <label className="block"><span className="mb-1.5 block text-[11px] font-semibold text-slate-600">{label}</span><span className="relative block"><select aria-label={label} value={value} onChange={(event) => onChange(event.target.value)} className="w-full appearance-none rounded-lg border border-slate-200 bg-white px-3 py-2.5 pr-8 text-xs text-slate-700 shadow-sm transition-colors hover:border-slate-300 focus:border-blue-400">{children}</select><ChevronDown size={13} className="pointer-events-none absolute right-2.5 top-3 text-slate-400" /></span></label>;
}

function SortButton({ label, column, filters, onSort }: { label: string; column: string; filters: ActivityFilters; onSort: (column: string) => void }) {
  const active = filters.sort === column;
  return <button onClick={() => onSort(column)} className={`inline-flex items-center gap-1 whitespace-nowrap text-left text-[10px] font-bold uppercase tracking-[0.08em] transition-colors ${active ? "text-blue-600" : "text-slate-400 hover:text-slate-700"}`}>{label}{active ? filters.direction === "asc" ? <ArrowUp size={12} /> : <ArrowDown size={12} /> : <ArrowUpDown size={11} />}</button>;
}

export function ActivityDashboard({ initialData, initialFilters, initialEventId, permissions }: DashboardProps) {
  const [data, setData] = useState(initialData);
  const [filters, setFilters] = useState(initialFilters);
  const [searchDraft, setSearchDraft] = useState(initialFilters.q);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [selectedId, setSelectedId] = useState(initialEventId ?? "");
  const [exportOpen, setExportOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [toast, setToast] = useState<{ type: "success" | "error"; message: string } | null>(null);
  const mounted = useRef(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const notify = useCallback((type: "success" | "error", message: string) => {
    setToast({ type, message });
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 5000);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFilters((previous) => previous.q === searchDraft ? previous : { ...previous, q: searchDraft, page: 1 });
    }, 320);
    return () => clearTimeout(timer);
  }, [searchDraft]);

  useEffect(() => {
    const params = filtersToSearchParams(filters);
    if (selectedId) params.set("event", selectedId);
    const query = params.toString();
    window.history.replaceState(null, "", `/activity-logs${query ? `?${query}` : ""}`);
  }, [filters, selectedId]);

  useEffect(() => {
    if (!mounted.current) { mounted.current = true; return; }
    const controller = new AbortController();
    setLoading(true); setError("");
    fetch(`/api/activity-logs?${filtersToSearchParams(filters).toString()}`, { signal: controller.signal })
      .then(async (response) => { const body = await response.json(); if (!response.ok) throw new Error(body.error || "Unable to load activity logs"); return body as ActivityListResponse; })
      .then((body) => setData(body))
      .catch((reason: unknown) => { if (reason instanceof DOMException && reason.name === "AbortError") return; setError(reason instanceof Error ? reason.message : "Unable to load activity logs."); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [filters]);

  useEffect(() => () => { if (toastTimer.current) clearTimeout(toastTimer.current); }, []);

  const updateFilter = <K extends keyof ActivityFilters>(key: K, value: ActivityFilters[K]) => {
    setFilters((previous) => ({ ...previous, [key]: value, page: 1 }));
  };
  const clearFilters = () => { setSearchDraft(""); setFilters({ ...DEFAULT_FILTERS, pageSize: filters.pageSize }); };
  const sortBy = (column: string) => setFilters((previous) => ({ ...previous, sort: column, direction: previous.sort === column && previous.direction === "desc" ? "asc" : "desc", page: 1 }));
  const closeDrawer = useCallback(() => setSelectedId(""), []);
  const navigateDrawer = useCallback((id: string) => setSelectedId(id), []);
  const refresh = () => setFilters((previous) => ({ ...previous }));
  const activeFilterCount = [filters.q, filters.from, filters.to, filters.actorId, filters.actorType, filters.category, filters.action, filters.propertyId, filters.unitId, filters.entityType, filters.entityId, filters.outcome, filters.severity].filter(Boolean).length;
  const units = useMemo(() => filters.propertyId ? data.options.units.filter((unit) => unit.propertyId === filters.propertyId) : data.options.units, [data.options.units, filters.propertyId]);
  const firstRow = data.total ? (data.page - 1) * data.pageSize + 1 : 0;
  const lastRow = Math.min(data.page * data.pageSize, data.total);
  const pageNumbers = Array.from({ length: Math.min(5, data.totalPages) }, (_, index) => {
    const start = Math.max(1, Math.min(data.page - 2, data.totalPages - 4));
    return start + index;
  }).filter((page) => page <= data.totalPages);

  const applyRange = (days: number | null) => {
    if (days === null) { setFilters((previous) => ({ ...previous, from: "", to: "", page: 1 })); return; }
    const range = dateRange(days);
    setFilters((previous) => ({ ...previous, ...range, page: 1 }));
  };

  const downloadExport = async () => {
    setExporting(true);
    try {
      const response = await fetch(`/api/activity-logs/export?${filtersToSearchParams(filters, false).toString()}`);
      if (!response.ok) { const body = await response.json(); throw new Error(body.error || "Export failed"); }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = response.headers.get("Content-Disposition")?.match(/filename="([^"]+)"/)?.[1] ?? "activity-logs.csv";
      document.body.appendChild(anchor); anchor.click(); anchor.remove(); URL.revokeObjectURL(url);
      const count = response.headers.get("X-Export-Row-Count") ?? "0";
      setExportOpen(false);
      notify("success", `CSV downloaded · ${count} records. Export recorded in the audit trail.`);
      refresh();
    } catch (reason) {
      notify("error", reason instanceof Error ? reason.message : "Export failed. Please try again.");
    } finally { setExporting(false); }
  };

  const summaryCards = [
    { label: "Total Activities", value: data.summary.total, icon: FileClock, color: "text-blue-600", bg: "bg-blue-50", note: "Matching current query" },
    { label: "Financial Activities", value: data.summary.financial, icon: Landmark, color: "text-emerald-600", bg: "bg-emerald-50", note: "Accounting & finance" },
    { label: "Property & Tenant Changes", value: data.summary.propertyTenant, icon: UsersRound, color: "text-violet-600", bg: "bg-violet-50", note: "Portfolio and leasing" },
    { label: "Document & Lease Activities", value: data.summary.documentLease, icon: FileClock, color: "text-indigo-600", bg: "bg-indigo-50", note: "Documents and leases" },
    { label: "Security Events", value: data.summary.security, icon: ShieldAlert, color: "text-slate-600", bg: "bg-slate-100", note: "Users & security" },
    { label: "Failed or Denied Actions", value: data.summary.failedDenied, icon: XCircle, color: "text-red-600", bg: "bg-red-50", note: "Needs review" },
  ];

  return <div className="mx-auto max-w-[1680px] px-4 pb-12 pt-7 sm:px-7 lg:px-9 lg:pt-9">
    <div className="animate-rise mb-7 flex flex-col justify-between gap-5 xl:flex-row xl:items-end">
      <div><div className="mb-3 flex flex-wrap items-center gap-2"><span className="inline-flex items-center gap-1.5 rounded-full border border-blue-100 bg-blue-50 px-2.5 py-1 text-[10px] font-semibold text-blue-700"><Sparkles size={12} />Centralized audit trail</span><span className="inline-flex items-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-2.5 py-1 text-[10px] font-semibold text-amber-700">Sample workspace</span></div><h1 className="text-[30px] font-bold tracking-[-0.045em] text-slate-950 sm:text-[34px]">Activity Logs</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">Track important actions, changes, and system events across your rental property business.</p></div>
      <div className="flex items-center gap-2.5"><button onClick={() => setFiltersOpen((open) => !open)} className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-semibold text-slate-700 shadow-sm transition-colors hover:bg-slate-50 lg:hidden"><SlidersHorizontal size={15} />Filters{activeFilterCount > 0 && <span className="grid h-5 w-5 place-items-center rounded-full bg-blue-600 text-[10px] text-white">{activeFilterCount}</span>}</button><button onClick={() => setExportOpen(true)} disabled={loading} className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 disabled:cursor-not-allowed disabled:opacity-50 text-xs font-semibold text-white shadow-[0_4px_12px_rgba(37,99,235,.2)] transition-all hover:bg-blue-700 hover:shadow-[0_6px_16px_rgba(37,99,235,.28)]"><Download size={15} />Export CSV</button></div>
    </div>

    <div className="animate-rise stagger-1 mb-6 flex items-start gap-2.5 rounded-xl border border-amber-200/70 bg-amber-50/60 px-4 py-3 text-xs leading-5 text-amber-800"><CircleAlert size={15} className="mt-0.5 shrink-0 text-amber-500" /><p><strong>Sample data, persisted locally.</strong> These seeded records demonstrate the audit workflows and are stored in PostgreSQL. The demo identity and external provider connections are not production integrations.</p></div>

    <section aria-label="Activity summary" className="mb-7 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
      {summaryCards.map((card, index) => { const Icon = card.icon; return <div key={card.label} className={`animate-rise stagger-${Math.min(index + 1, 6)} rounded-xl border border-slate-200/80 bg-white p-4 shadow-[0_2px_5px_rgba(15,23,42,.02)] transition-shadow hover:shadow-[0_5px_16px_rgba(15,23,42,.05)]`}><div className="flex items-start justify-between gap-2"><p className="min-h-8 text-[11px] font-semibold leading-4 text-slate-500">{card.label}</p><span className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg ${card.bg} ${card.color}`}><Icon size={14} /></span></div><p className="mt-3 text-2xl font-bold tracking-[-0.04em] text-slate-950">{card.value.toLocaleString()}</p><p className="mt-1 truncate text-[10px] text-slate-400">{card.note}</p></div>; })}
    </section>

    <section className={`animate-rise stagger-2 mb-5 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5 ${filtersOpen ? "block" : "hidden lg:block"}`} aria-label="Activity filters">
      <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><Filter size={15} className="text-blue-600" /><h2 className="text-xs font-bold uppercase tracking-[0.08em] text-slate-700">Filter activity</h2>{activeFilterCount > 0 && <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-semibold text-blue-600">{activeFilterCount} active</span>}</div><button onClick={clearFilters} className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 transition-colors hover:text-blue-600"><RefreshCw size={13} />Clear filters</button></div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
        <div className="sm:col-span-2 lg:col-span-2 xl:col-span-2"><label htmlFor="activity-search" className="mb-1.5 block text-[11px] font-semibold text-slate-600">Search activity</label><div className="relative"><Search size={15} className="pointer-events-none absolute left-3 top-3 text-slate-400" /><input id="activity-search" value={searchDraft} onChange={(event) => setSearchDraft(event.target.value)} placeholder="Description, actor, property, unit, tenant, record or event ID" className="w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-9 text-xs text-slate-700 shadow-sm placeholder:text-slate-400 focus:border-blue-400" />{searchDraft && <button onClick={() => setSearchDraft("")} aria-label="Clear search" className="absolute right-2.5 top-2.5 rounded p-0.5 text-slate-400 hover:text-slate-700"><X size={14} /></button>}</div></div>
        <FilterSelect label="Actor" value={filters.actorId} onChange={(value) => updateFilter("actorId", value)}><option value="">All users & actors</option>{data.options.actors.map((actor) => <option key={actor.id} value={actor.id}>{actor.name} · {formatActorType(actor.type)}</option>)}</FilterSelect>
        <FilterSelect label="Actor type" value={filters.actorType} onChange={(value) => updateFilter("actorType", value)}><option value="">All actor types</option>{ACTOR_TYPES.map((type) => <option key={type} value={type}>{formatActorType(type)}</option>)}</FilterSelect>
        <FilterSelect label="Category" value={filters.category} onChange={(value) => updateFilter("category", value)}><option value="">All categories</option>{CATEGORIES.map((category) => <option key={category} value={category}>{category}</option>)}</FilterSelect>
        <FilterSelect label="Action type" value={filters.action} onChange={(value) => updateFilter("action", value)}><option value="">All action types</option>{ACTIONS.map((action) => <option key={action} value={action}>{actionLabel(action)}</option>)}</FilterSelect>
        <FilterSelect label="Property" value={filters.propertyId} onChange={(value) => { setFilters((previous) => ({ ...previous, propertyId: value, unitId: "", page: 1 })); }}><option value="">All properties</option>{data.options.properties.map((property) => <option key={property.id} value={property.id}>{property.name}</option>)}</FilterSelect>
        <FilterSelect label="Unit" value={filters.unitId} onChange={(value) => updateFilter("unitId", value)}><option value="">All units</option>{units.map((unit) => <option key={unit.id} value={unit.id}>{unit.propertyName} · {unit.number}</option>)}</FilterSelect>
        <FilterSelect label="Related entity type" value={filters.entityType} onChange={(value) => updateFilter("entityType", value)}><option value="">All entity types</option>{ENTITY_TYPES.map((type) => <option key={type} value={type}>{type.replaceAll("_", " ")}</option>)}</FilterSelect>
        <FilterSelect label="Result" value={filters.outcome} onChange={(value) => updateFilter("outcome", value)}><option value="">All results</option>{OUTCOMES.map((outcome) => <option key={outcome} value={outcome}>{outcome[0].toUpperCase() + outcome.slice(1)}</option>)}</FilterSelect>
        <FilterSelect label="Severity" value={filters.severity} onChange={(value) => updateFilter("severity", value)}><option value="">All severities</option>{SEVERITIES.map((severity) => <option key={severity} value={severity}>{severity[0].toUpperCase() + severity.slice(1)}</option>)}</FilterSelect>
      </div>
      <div className="mt-4 flex flex-col justify-between gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:items-end"><div><span className="mb-1.5 block text-[11px] font-semibold text-slate-600">Date range</span><div className="flex flex-wrap items-center gap-1.5"><button onClick={() => applyRange(null)} className={`rounded-md px-2.5 py-1.5 text-[11px] font-medium ${!filters.from && !filters.to ? "bg-blue-50 text-blue-700" : "bg-slate-50 text-slate-500 hover:bg-slate-100"}`}>All time</button>{[7, 30, 90].map((days) => <button key={days} onClick={() => applyRange(days)} className="rounded-md bg-slate-50 px-2.5 py-1.5 text-[11px] font-medium text-slate-500 hover:bg-slate-100">Last {days} days</button>)}</div></div><div className="flex items-end gap-2"><label><span className="mb-1.5 block text-[10px] text-slate-400">From</span><input aria-label="From date" type="date" value={filters.from} onChange={(event) => updateFilter("from", event.target.value)} className="rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-xs text-slate-600" /></label><span className="pb-2.5 text-slate-300">→</span><label><span className="mb-1.5 block text-[10px] text-slate-400">To</span><input aria-label="To date" type="date" value={filters.to} onChange={(event) => updateFilter("to", event.target.value)} className="rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-xs text-slate-600" /></label></div></div>
    </section>

    {error && <div role="alert" className="mb-4 flex items-center justify-between gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-700"><span className="flex items-center gap-2"><CircleAlert size={15} />{error} Showing the last successful result.</span><button onClick={refresh} className="inline-flex shrink-0 items-center gap-1.5 font-semibold text-red-800 hover:underline"><RefreshCw size={13} />Retry</button></div>}

    <section className="animate-rise stagger-3 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-[0_2px_6px_rgba(15,23,42,.025)]" aria-label="Activity records">
      <div className="flex flex-col justify-between gap-3 border-b border-slate-100 px-4 py-4 sm:flex-row sm:items-center sm:px-5"><div><h2 className="text-sm font-bold tracking-[-0.01em] text-slate-800">Activity stream</h2><p className="mt-1 text-[11px] text-slate-400">{data.total.toLocaleString()} matching events · Click any row for the full audit context</p></div><div className="flex items-center gap-2 text-[11px] text-slate-400">{loading && <Loader2 size={14} className="animate-spin text-blue-500" />}<span>Sorted by {filters.sort === "occurredAt" ? "most recent" : filters.sort}</span></div></div>
      <div className={`relative transition-opacity ${loading ? "opacity-60" : "opacity-100"}`}>
        {data.items.length > 0 && <div className="hidden overflow-x-auto lg:block"><table className="w-full min-w-[1060px] border-collapse text-left"><thead className="bg-slate-50/70"><tr className="border-b border-slate-100"><th className="w-[15%] px-5 py-3"><SortButton label="Date & Time" column="occurredAt" filters={filters} onSort={sortBy} /></th><th className="w-[16%] px-3 py-3"><SortButton label="User / Actor" column="actorDisplayName" filters={filters} onSort={sortBy} /></th><th className="w-[25%] px-3 py-3"><SortButton label="Activity" column="action" filters={filters} onSort={sortBy} /></th><th className="w-[14%] px-3 py-3"><SortButton label="Category" column="category" filters={filters} onSort={sortBy} /></th><th className="w-[12%] px-3 py-3 text-[10px] font-bold uppercase tracking-[0.08em] text-slate-400">Related Property</th><th className="w-[12%] px-3 py-3 text-[10px] font-bold uppercase tracking-[0.08em] text-slate-400">Related Record</th><th className="w-[9%] px-3 py-3"><SortButton label="Result" column="outcome" filters={filters} onSort={sortBy} /></th><th className="w-[60px] px-3 py-3 text-[10px] font-bold uppercase tracking-[0.08em] text-slate-400">Actions</th></tr></thead><tbody>{data.items.map((event) => <tr key={event.id} tabIndex={0} onClick={() => setSelectedId(event.id)} onKeyDown={(keyboardEvent) => { if (keyboardEvent.key === "Enter" || keyboardEvent.key === " ") { keyboardEvent.preventDefault(); setSelectedId(event.id); } }} className="group cursor-pointer border-b border-slate-100 transition-colors last:border-0 hover:bg-blue-50/30 focus:bg-blue-50/40"><td className="px-5 py-4 align-top"><p className="whitespace-nowrap text-xs font-medium text-slate-700">{formatDateTime(event.occurredAt)}</p><p className="mt-1 text-[10px] text-slate-400">{formatRelativeTime(event.occurredAt)}</p></td><td className="px-3 py-4 align-top"><div className="flex items-center gap-2.5"><ActorAvatar name={event.actorDisplayName} actorType={event.actorType} /><div className="min-w-0"><p className="truncate text-xs font-semibold text-slate-700">{event.actorDisplayName}</p><p className="mt-1 text-[10px] text-slate-400">{formatActorType(event.actorType)}</p></div></div></td><td className="max-w-[300px] px-3 py-4 align-top"><p className="line-clamp-2 text-xs font-medium leading-5 text-slate-700 group-hover:text-blue-800">{event.description}</p><p className="mt-1 truncate text-[10px] text-slate-400">{actionLabel(event.action)}</p></td><td className="px-3 py-4 align-top"><CategoryBadge category={event.category} /></td><td className="px-3 py-4 align-top">{event.propertyName ? <><p className="truncate text-xs font-medium text-slate-700">{event.propertyName}</p>{event.unitNumber && <p className="mt-1 text-[10px] text-slate-400">Unit {event.unitNumber}</p>}</> : <span className="text-xs text-slate-300">—</span>}</td><td className="px-3 py-4 align-top"><div onClick={(clickEvent) => clickEvent.stopPropagation()}>{permissions.records ? <RecordLink event={event} label={event.relatedRecordLabel} className="line-clamp-2 max-w-[150px] text-xs font-medium leading-5" /> : <span className="text-xs text-slate-500">{event.relatedRecordLabel}</span>}<p className="mt-1 truncate font-mono text-[9px] text-slate-400">{event.id}</p></div></td><td className="px-3 py-4 align-top"><ResultBadge outcome={event.outcome} /><div className="mt-2"><SeverityIndicator severity={event.severity} /></div></td><td className="px-3 py-4 align-top"><button onClick={(clickEvent) => { clickEvent.stopPropagation(); setSelectedId(event.id); }} aria-label={`View details for ${event.id}`} className="rounded-lg border border-slate-200 p-2 text-slate-400 opacity-60 transition-all hover:border-blue-200 hover:bg-blue-50 hover:text-blue-600 group-hover:opacity-100"><ArrowRight size={14} /></button></td></tr>)}</tbody></table></div>}
        <div className="divide-y divide-slate-100 lg:hidden">{data.items.map((event) => <article key={event.id} tabIndex={0} onClick={() => setSelectedId(event.id)} onKeyDown={(keyboardEvent) => { if (keyboardEvent.key === "Enter") setSelectedId(event.id); }} className="cursor-pointer p-4 transition-colors hover:bg-blue-50/30"><div className="flex items-start gap-3"><ActorAvatar name={event.actorDisplayName} actorType={event.actorType} /><div className="min-w-0 flex-1"><div className="flex items-start justify-between gap-2"><p className="text-xs font-semibold leading-5 text-slate-800">{event.description}</p><ArrowRight size={15} className="mt-0.5 shrink-0 text-slate-300" /></div><p className="mt-1.5 text-[10px] text-slate-400">{event.actorDisplayName} · {formatRelativeTime(event.occurredAt)}</p><div className="mt-3 flex flex-wrap items-center gap-2"><CategoryBadge category={event.category} /><ResultBadge outcome={event.outcome} /><SeverityIndicator severity={event.severity} /></div><div className="mt-3 flex items-center justify-between gap-3 text-[10px] text-slate-400"><span>{event.propertyName ?? "Workspace"}{event.unitNumber ? ` · Unit ${event.unitNumber}` : ""}</span><span className="truncate font-mono">{event.id}</span></div></div></div></article>)}</div>
        {!loading && data.items.length === 0 && <div className="flex flex-col items-center justify-center px-6 py-20 text-center"><div className="grid h-14 w-14 place-items-center rounded-2xl bg-slate-100 text-slate-400"><Search size={24} /></div><h3 className="mt-5 text-base font-bold text-slate-800">No activity matches these filters</h3><p className="mt-2 max-w-sm text-xs leading-5 text-slate-500">Try a broader date range, remove a filter, or search by a different record or event ID.</p><button onClick={clearFilters} className="mt-5 rounded-lg bg-blue-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-blue-700">Clear all filters</button></div>}
        {loading && data.items.length === 0 && <div className="space-y-3 p-5">{[1, 2, 3, 4, 5].map((item) => <div key={item} className="h-16 animate-pulse rounded-lg bg-slate-100" />)}</div>}
      </div>
      <div className="flex flex-col justify-between gap-4 border-t border-slate-100 bg-slate-50/40 px-4 py-3.5 sm:flex-row sm:items-center sm:px-5"><div className="flex items-center gap-3 text-[11px] text-slate-500"><span>{firstRow}–{lastRow} of {data.total}</span><label className="flex items-center gap-1.5"><span className="text-slate-400">Rows</span><select aria-label="Rows per page" value={filters.pageSize} onChange={(event) => updateFilter("pageSize", Number(event.target.value))} className="rounded-md border border-slate-200 bg-white px-1.5 py-1 text-[11px] text-slate-600"><option value={10}>10</option><option value={25}>25</option><option value={50}>50</option><option value={100}>100</option></select></label></div><div className="flex items-center gap-1"><button disabled={data.page <= 1} onClick={() => updateFilter("page", data.page - 1)} aria-label="Previous page" className="grid h-8 w-8 place-items-center rounded-md border border-slate-200 bg-white text-slate-500 transition-colors hover:border-blue-200 hover:text-blue-600 disabled:cursor-not-allowed disabled:opacity-40"><ChevronLeft size={15} /></button>{pageNumbers.map((page) => <button key={page} onClick={() => updateFilter("page", page)} aria-label={`Page ${page}`} aria-current={data.page === page ? "page" : undefined} className={`h-8 min-w-8 rounded-md px-2 text-[11px] font-semibold ${data.page === page ? "bg-blue-600 text-white" : "border border-slate-200 bg-white text-slate-500 hover:border-blue-200 hover:text-blue-600"}`}>{page}</button>)}<button disabled={data.page >= data.totalPages} onClick={() => updateFilter("page", data.page + 1)} aria-label="Next page" className="grid h-8 w-8 place-items-center rounded-md border border-slate-200 bg-white text-slate-500 transition-colors hover:border-blue-200 hover:text-blue-600 disabled:cursor-not-allowed disabled:opacity-40"><ChevronRight size={15} /></button></div></div>
    </section>
    <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[10px] leading-4 text-slate-400"><ShieldAlert size={12} />Audit events are append-only through the application API. Change values and secrets are never included in CSV exports.</p>

    {selectedId && <ActivityDrawer eventId={selectedId} onClose={closeDrawer} onNavigate={navigateDrawer} canViewRecords={permissions.records} canViewSensitive={permissions.sensitive} />}
    {exportOpen && <div className="fixed inset-0 z-[80] grid place-items-center p-4" role="dialog" aria-modal="true" aria-labelledby="export-title"><button aria-label="Cancel export" onClick={() => !exporting && setExportOpen(false)} className="absolute inset-0 animate-fade bg-slate-950/35 backdrop-blur-[2px]" /><div className="animate-rise relative w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl"><div className="grid h-11 w-11 place-items-center rounded-xl bg-blue-50 text-blue-600"><Download size={21} /></div><h2 id="export-title" className="mt-5 text-lg font-bold tracking-[-0.025em] text-slate-950">Export filtered activity?</h2><p className="mt-2 text-sm leading-6 text-slate-500">Your CSV will include <strong className="font-semibold text-slate-700">{data.total.toLocaleString()} matching events</strong> from the sample workspace, with the active filters applied.</p><div className="mt-4 rounded-xl bg-slate-50 p-3.5 text-xs leading-5 text-slate-600"><p className="flex items-center gap-2"><Check size={14} className="text-emerald-500" />Before/after values are excluded</p><p className="mt-1.5 flex items-center gap-2"><Check size={14} className="text-emerald-500" />Untrusted cells are formula-escaped</p><p className="mt-1.5 flex items-center gap-2"><Check size={14} className="text-emerald-500" />This sensitive export will be audit logged</p></div><div className="mt-6 flex justify-end gap-2"><button disabled={exporting} onClick={() => setExportOpen(false)} className="rounded-lg border border-slate-200 px-4 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-50">Cancel</button><button disabled={exporting} onClick={downloadExport} className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-60">{exporting ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}{exporting ? "Preparing CSV…" : "Download CSV"}</button></div></div></div>}
    {toast && <div role="status" className={`animate-rise fixed bottom-5 right-5 z-[90] flex max-w-[calc(100vw-40px)] items-start gap-3 rounded-xl border bg-white px-4 py-3.5 text-xs font-medium shadow-[0_12px_40px_rgba(15,23,42,.16)] ${toast.type === "success" ? "border-emerald-200 text-emerald-800" : "border-red-200 text-red-800"}`}>{toast.type === "success" ? <Check size={17} className="shrink-0 text-emerald-500" /> : <CircleAlert size={17} className="shrink-0 text-red-500" />}<span className="leading-5">{toast.message}</span><button onClick={() => setToast(null)} aria-label="Dismiss notification" className="ml-2 text-slate-400 hover:text-slate-700"><X size={14} /></button></div>}
  </div>;
}
