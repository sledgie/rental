"use client";

import { CircleAlert, RefreshCw } from "lucide-react";

export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <div className="grid min-h-[70vh] place-items-center px-6"><div className="max-w-md text-center"><CircleAlert size={32} className="mx-auto text-red-500" /><h1 className="mt-5 text-xl font-bold text-slate-900">We couldn’t load this workspace view</h1><p className="mt-2 text-sm leading-6 text-slate-500">The activity service did not respond. Your persisted audit records have not been changed.</p><button onClick={reset} className="mt-6 inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-xs font-semibold text-white hover:bg-blue-700"><RefreshCw size={14} />Try again</button></div></div>;
}
