import type { Metadata } from "next";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { appUsers } from "@/db/schema";
import { UserPermissions } from "@/components/user-permissions";
import { getRequestContext, requirePermission } from "@/lib/auth";
import { ensureActivityWorkspace } from "@/lib/activity/sample-data";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Users & Permissions" };

export default async function UsersPage() {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "users:manage");
  const users = await db.select().from(appUsers).orderBy(asc(appUsers.name));
  return <UserPermissions initialUsers={users.map((user) => ({ ...user, lastActiveAt: user.lastActiveAt?.toISOString() ?? null }))} />;
}
