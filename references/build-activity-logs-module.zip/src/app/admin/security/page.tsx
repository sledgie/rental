import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { auditPolicies } from "@/db/schema";
import { SecurityAudit } from "@/components/security-audit";
import { getRequestContext, requirePermission } from "@/lib/auth";
import { ensureActivityWorkspace } from "@/lib/activity/sample-data";
import { getAuditExportHistory, getSecurityEvents, verifyActivityIntegrity } from "@/lib/activity/service";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Security & Audit" };

export default async function SecurityPage() {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "audit:manage");
  const [policyRows, integrity, exportRows, securityEvents] = await Promise.all([
    db.select().from(auditPolicies).where(eq(auditPolicies.id, "default")).limit(1),
    verifyActivityIntegrity(), getAuditExportHistory(), getSecurityEvents(),
  ]);
  const policy = policyRows[0];
  return <SecurityAudit initialIntegrity={integrity} initialPolicy={{ ...policy, updatedAt: policy.updatedAt.toISOString() }} exports={exportRows.map((item) => ({ id: item.id, fileName: item.fileName, rowCount: item.rowCount, outcome: item.outcome, createdAt: item.createdAt.toISOString(), activityEventId: item.activityEventId }))} securityEvents={securityEvents} />;
}
