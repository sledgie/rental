export default function ActivityLoading() {
  return <div className="mx-auto max-w-[1680px] animate-pulse px-4 py-10 sm:px-7 lg:px-9"><div className="h-8 w-56 rounded-lg bg-slate-200" /><div className="mt-3 h-4 w-[420px] max-w-full rounded bg-slate-100" /><div className="mt-9 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">{[1, 2, 3, 4, 5, 6].map((item) => <div key={item} className="h-32 rounded-xl bg-white" />)}</div><div className="mt-7 h-40 rounded-xl bg-white" /><div className="mt-5 h-[540px] rounded-xl bg-white" /></div>;
}
