import type { Metadata } from "next";
import { ActivityDashboard } from "@/components/activity-dashboard";
import { can, getRequestContext } from "@/lib/auth";
import { parseActivityFilters } from "@/lib/activity/filters";
import { getActivityLogs } from "@/lib/activity/service";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Activity Logs" };

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function ActivityLogsPage({ searchParams }: { searchParams: SearchParams }) {
  const resolved = await searchParams;
  const params = new URLSearchParams();
  Object.entries(resolved).forEach(([key, value]) => {
    if (Array.isArray(value)) value.forEach((item) => params.append(key, item));
    else if (value !== undefined) params.set(key, value);
  });
  const filters = parseActivityFilters(params);
  const [initialData, context] = await Promise.all([getActivityLogs(filters), Promise.resolve(getRequestContext())]);
  return <ActivityDashboard initialData={initialData} initialFilters={filters} initialEventId={typeof resolved.event === "string" ? resolved.event : undefined} permissions={{ records: can(context, "records:view"), sensitive: can(context, "activity:view_sensitive") }} />;
}
