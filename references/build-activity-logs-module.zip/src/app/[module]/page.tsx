import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ModuleOverview, type ModuleConfig } from "@/components/module-overview";
import { getActivityLogs } from "@/lib/activity/service";
import { DEFAULT_FILTERS } from "@/lib/activity/types";

export const dynamic = "force-dynamic";
const modules: Record<string, ModuleConfig> = {
  overview: { title: "Portfolio overview", eyebrow: "Northstar Rentals", description: "A connected view of operational and financial activity across your rental business.", category: "", coverage: ["Cross-module event search and filtering", "Property, tenant, invoice, and project timelines", "Permission-aware exports and security review"] },
  properties: { title: "Properties & Units", eyebrow: "Portfolio", description: "Monitor property records, rental rates, occupancy, and management changes.", category: "Properties & Units", coverage: ["Property creation, updates, and archival", "Unit occupancy and rental rate differences", "Ownership and management detail history"] },
  tenants: { title: "Tenants & Leases", eyebrow: "Leasing", description: "Follow tenant onboarding, lease signatures, renewals, and tenancy changes.", category: "Tenants & Leases", coverage: ["Tenant creation, assignment, and unit moves", "Lease dates, statuses, signatures, and renewals", "Identification document metadata events"] },
  accounting: { title: "Accounting & Finance", eyebrow: "Financial operations", description: "Review invoices, payments, expenses, bills, journals, and reconciliation activity.", category: "Accounting & Finance", coverage: ["Amount, currency, allocation, and status history", "Approvals, rejections, reversals, and void reasons", "Sensitive report and financial export events"] },
  maintenance: { title: "Maintenance & Repairs", eyebrow: "Operations", description: "Track requests, contractor assignments, appointments, quotes, and completed work.", category: "Maintenance & Repairs", coverage: ["Request submission and priority changes", "Work order assignment and appointment history", "Quotes, repair approvals, and completion outcomes"] },
  projects: { title: "Projects & Renovations", eyebrow: "Capital projects", description: "Follow budgets, schedules, contractors, milestones, and project approvals.", category: "Projects & Renovations", coverage: ["Budget and schedule before/after differences", "Contractor assignments and project expenses", "Milestones, approvals, cancellation, and closure"] },
  documents: { title: "Documents & eSignatures", eyebrow: "Records", description: "Audit document metadata, sharing, permissions, and signature provider outcomes.", category: "Documents & eSignatures", coverage: ["Uploads, replacements, downloads, and sharing", "Permission changes and archival history", "Signature requests, completion, and declines"] },
  communications: { title: "Communications", eyebrow: "Engagement", description: "Separate queued, accepted, delivered, opened, and failed communication states.", category: "Communications", coverage: ["Template and automation rule changes", "Email, SMS, notification, and bulk initiation", "Provider-supported delivery and open outcomes"] },
};

export async function generateMetadata({ params }: { params: Promise<{ module: string }> }): Promise<Metadata> {
  const { module } = await params;
  return { title: modules[module]?.title ?? "Workspace" };
}

export default async function ModulePage({ params }: { params: Promise<{ module: string }> }) {
  const { module } = await params;
  const config = modules[module];
  if (!config) notFound();
  const data = await getActivityLogs({ ...DEFAULT_FILTERS, category: config.category, pageSize: 10 });
  return <ModuleOverview config={config} data={data} />;
}
