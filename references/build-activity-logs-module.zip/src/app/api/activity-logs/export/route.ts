import { NextRequest } from "next/server";
import { AuthorizationError, getRequestContext } from "@/lib/auth";
import { parseActivityFilters } from "@/lib/activity/filters";
import { exportActivityLogs } from "@/lib/activity/service";
import { recordActivity } from "@/lib/activity/repository";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const result = await exportActivityLogs(parseActivityFilters(request.nextUrl.searchParams));
    return new Response(result.csv, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${result.fileName}"`,
        "Cache-Control": "no-store",
        "X-Audit-Event-Id": result.auditEventId,
        "X-Export-Row-Count": String(result.rowCount),
      },
    });
  } catch (error) {
    if (!(error instanceof AuthorizationError)) {
      try {
        const context = getRequestContext();
        await recordActivity({
          actorId: context.user.id, actorType: "user", actorDisplayName: context.user.name,
          action: "audit.exported", category: "Users & Security", description: "Activity log export failed.",
          entityType: "audit_export", entityId: `failed_${Date.now()}`, sourceModule: "Activity Logs",
          outcome: "failure", severity: "warning", error: { code: "EXPORT_FAILED", message: "The filtered CSV could not be generated.", retryable: true },
        });
      } catch { /* Preserve the original export error. */ }
    }
    const status = error instanceof AuthorizationError ? 403 : 500;
    return Response.json({ error: error instanceof Error ? error.message : "Unable to export activity logs." }, { status });
  }
}
