import { AuthorizationError } from "@/lib/auth";
import { getActivityById } from "@/lib/activity/service";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const event = await getActivityById(id);
    if (!event) return Response.json({ error: "Activity event not found." }, { status: 404 });
    return Response.json(event);
  } catch (error) {
    const status = error instanceof AuthorizationError ? 403 : 500;
    return Response.json({ error: error instanceof Error ? error.message : "Unable to load activity event." }, { status });
  }
}
