import { NextRequest } from "next/server";
import { AuthorizationError } from "@/lib/auth";
import { getRelatedActivities } from "@/lib/activity/service";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const entityType = request.nextUrl.searchParams.get("entityType") ?? "";
    const entityId = request.nextUrl.searchParams.get("entityId") ?? "";
    if (!entityType || !entityId) return Response.json({ error: "Entity type and ID are required." }, { status: 400 });
    const items = await getRelatedActivities(entityType, entityId, request.nextUrl.searchParams.get("exclude") ?? undefined, 12);
    return Response.json({ items });
  } catch (error) {
    const status = error instanceof AuthorizationError ? 403 : 500;
    return Response.json({ error: error instanceof Error ? error.message : "Unable to load related activities." }, { status });
  }
}
