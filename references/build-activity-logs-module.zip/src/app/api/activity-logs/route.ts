import { NextRequest } from "next/server";
import { AuthorizationError } from "@/lib/auth";
import { parseActivityFilters } from "@/lib/activity/filters";
import { getActivityLogs } from "@/lib/activity/service";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const result = await getActivityLogs(parseActivityFilters(request.nextUrl.searchParams));
    return Response.json(result);
  } catch (error) {
    const status = error instanceof AuthorizationError ? 403 : 500;
    return Response.json({ error: error instanceof Error ? error.message : "Unable to load activity logs." }, { status });
  }
}
