import { eq } from "drizzle-orm";
import { db } from "@/db";
import { appUsers } from "@/db/schema";
import { AuthorizationError, getRequestContext, requirePermission } from "@/lib/auth";
import { ensureActivityWorkspace } from "@/lib/activity/sample-data";
import { appendActivity } from "@/lib/activity/repository";

export const dynamic = "force-dynamic";
const roles = new Set(["Administrator", "Property Manager", "Accountant", "Maintenance Coordinator", "Leasing Agent", "Staff"]);

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    await ensureActivityWorkspace();
    const context = getRequestContext();
    requirePermission(context, "users:manage");
    const { id } = await params;
    if (id === context.user.id) return Response.json({ error: "Use your identity provider to change the signed-in administrator’s role." }, { status: 400 });
    const body = await request.json() as { role?: string; reason?: string };
    if (!body.role || !roles.has(body.role)) return Response.json({ error: "Choose a valid workspace role." }, { status: 400 });
    if (!body.reason || body.reason.trim().length < 3 || body.reason.length > 500) return Response.json({ error: "A reason between 3 and 500 characters is required." }, { status: 400 });
    const reason = body.reason.trim();
    const result = await db.transaction(async (tx) => {
      const [previous] = await tx.select().from(appUsers).where(eq(appUsers.id, id)).limit(1);
      if (!previous) throw new Error("User not found.");
      if (previous.role === body.role) throw new Error("The selected role is already assigned.");
      const [updated] = await tx.update(appUsers).set({ role: body.role! }).where(eq(appUsers.id, id)).returning();
      const activity = await appendActivity(tx, {
        actorId: context.user.id, actorType: "user", actorDisplayName: context.user.name,
        action: "user.role_changed", category: "Users & Security",
        description: `User Role changed from ${previous.role} to ${body.role} for ${previous.name}.`,
        entityType: "user", entityId: id, relatedRecordLabel: previous.name, sourceModule: "Users & Permissions",
        changes: [{ field: "role", label: "User Role", previousValue: previous.role, newValue: body.role!, changeType: "modified" }],
        reason, severity: "warning", metadata: { requestId: `req_role_${Date.now()}`, permissionSetRecalculated: true },
      });
      return { updated, activity };
    });
    return Response.json({ user: result.updated, auditEventId: result.activity.id });
  } catch (error) {
    const status = error instanceof AuthorizationError ? 403 : error instanceof Error && error.message === "User not found." ? 404 : 400;
    return Response.json({ error: error instanceof Error ? error.message : "Unable to update user." }, { status });
  }
}
