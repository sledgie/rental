import { eq } from "drizzle-orm";
import { db } from "@/db";
import { auditPolicies } from "@/db/schema";
import { AuthorizationError, getRequestContext, requirePermission } from "@/lib/auth";
import { ensureActivityWorkspace } from "@/lib/activity/sample-data";
import { appendActivity } from "@/lib/activity/repository";

export const dynamic = "force-dynamic";
export async function PATCH(request: Request) {
  try {
    await ensureActivityWorkspace();
    const context = getRequestContext();
    requirePermission(context, "audit:manage");
    const body = await request.json() as { retentionDays?: number; archiveAfterDays?: number; restrictSensitiveChanges?: boolean; reason?: string };
    const retentionDays = Number(body.retentionDays);
    const archiveAfterDays = Number(body.archiveAfterDays);
    if (!Number.isInteger(retentionDays) || retentionDays < 365 || retentionDays > 3650 || !Number.isInteger(archiveAfterDays) || archiveAfterDays < 30 || archiveAfterDays >= retentionDays) return Response.json({ error: "Use a retention of 1–10 years and an archive window shorter than retention." }, { status: 400 });
    if (!body.reason || body.reason.trim().length < 3) return Response.json({ error: "A reason is required for audit policy changes." }, { status: 400 });
    const reason = body.reason.trim();
    const result = await db.transaction(async (tx) => {
      const [previous] = await tx.select().from(auditPolicies).where(eq(auditPolicies.id, "default")).limit(1);
      if (!previous) throw new Error("Audit policy not found.");
      const restrict = body.restrictSensitiveChanges ?? previous.restrictSensitiveChanges;
      const changes = [
        ...(previous.retentionDays !== retentionDays ? [{ field: "retentionDays", label: "Audit Retention", previousValue: `${previous.retentionDays} days`, newValue: `${retentionDays} days`, changeType: "modified" as const }] : []),
        ...(previous.archiveAfterDays !== archiveAfterDays ? [{ field: "archiveAfterDays", label: "Archive After", previousValue: `${previous.archiveAfterDays} days`, newValue: `${archiveAfterDays} days`, changeType: "modified" as const }] : []),
        ...(previous.restrictSensitiveChanges !== restrict ? [{ field: "restrictSensitiveChanges", label: "Restrict Sensitive Changes", previousValue: String(previous.restrictSensitiveChanges), newValue: String(restrict), valueType: "boolean" as const, changeType: "modified" as const }] : []),
      ];
      if (!changes.length) throw new Error("No policy values changed.");
      const [updated] = await tx.update(auditPolicies).set({ retentionDays, archiveAfterDays, restrictSensitiveChanges: restrict, updatedAt: new Date(), updatedBy: context.user.id }).where(eq(auditPolicies.id, "default")).returning();
      const activity = await appendActivity(tx, { actorId: context.user.id, actorType: "user", actorDisplayName: context.user.name, action: "audit.settings_changed", category: "Users & Security", description: "Audit retention and redaction settings changed.", entityType: "audit_policy", entityId: "audit_policy_default", relatedRecordLabel: "Audit policy", sourceModule: "Security & Audit", changes, reason, severity: "warning", metadata: { automatedWorkerConfigured: false } });
      return { updated, activity };
    });
    return Response.json({ policy: result.updated, auditEventId: result.activity.id });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Unable to update audit policy." }, { status: error instanceof AuthorizationError ? 403 : 400 });
  }
}
