import { AuthorizationError } from "@/lib/auth";
import { verifyActivityIntegrity } from "@/lib/activity/service";

export const dynamic = "force-dynamic";
export async function POST() {
  try { return Response.json(await verifyActivityIntegrity()); }
  catch (error) { return Response.json({ error: error instanceof Error ? error.message : "Integrity check failed." }, { status: error instanceof AuthorizationError ? 403 : 500 }); }
}
