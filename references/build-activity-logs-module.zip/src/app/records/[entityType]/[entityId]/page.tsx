import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { RecordTimeline } from "@/components/record-timeline";
import { ENTITY_TYPES } from "@/lib/activity/types";
import { getRecordTimeline } from "@/lib/activity/service";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Record timeline" };

export default async function RecordPage({ params }: { params: Promise<{ entityType: string; entityId: string }> }) {
  const { entityType, entityId } = await params;
  if (!ENTITY_TYPES.includes(entityType as (typeof ENTITY_TYPES)[number])) notFound();
  const timeline = await getRecordTimeline(entityType, entityId);
  return <RecordTimeline {...timeline} />;
}
