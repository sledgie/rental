import "server-only";
import { and, asc, desc, eq, gte, ilike, inArray, lte, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { activityEvents, auditExports, properties, tenants, units } from "@/db/schema";
import { can, getRequestContext, requirePermission, type RequestContext } from "@/lib/auth";
import { ensureActivityWorkspace } from "./sample-data";
import { appendActivity, calculateEventHash } from "./repository";
import { actionLabel, formatActorType, type ActivityEventDTO, type ActivityFilterOptions, type ActivityFilters, type ActivityListResponse, type ActivitySummary } from "./types";
import { randomUUID } from "node:crypto";

type EventRow = typeof activityEvents.$inferSelect;
type JoinedRow = { event: EventRow; propertyName: string | null; unitNumber: string | null; tenantName: string | null };

function dateBoundary(value: string, end = false) {
  if (!value) return null;
  const date = new Date(value.length === 10 ? `${value}T${end ? "23:59:59.999" : "00:00:00.000"}Z` : value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function conditionsFor(filters: ActivityFilters, context: RequestContext): SQL[] {
  const conditions: SQL[] = [];
  const from = dateBoundary(filters.from);
  const to = dateBoundary(filters.to, true);
  if (from) conditions.push(gte(activityEvents.occurredAt, from));
  if (to) conditions.push(lte(activityEvents.occurredAt, to));
  if (filters.actorId) conditions.push(eq(activityEvents.actorId, filters.actorId));
  if (filters.actorType) conditions.push(eq(activityEvents.actorType, filters.actorType));
  if (filters.category) conditions.push(eq(activityEvents.category, filters.category));
  if (filters.action) conditions.push(eq(activityEvents.action, filters.action));
  if (filters.propertyId) conditions.push(eq(activityEvents.propertyId, filters.propertyId));
  if (filters.unitId) conditions.push(eq(activityEvents.unitId, filters.unitId));
  if (filters.entityType) conditions.push(eq(activityEvents.entityType, filters.entityType));
  if (filters.entityId) conditions.push(eq(activityEvents.entityId, filters.entityId));
  if (filters.outcome) conditions.push(eq(activityEvents.outcome, filters.outcome));
  if (filters.severity) conditions.push(eq(activityEvents.severity, filters.severity));
  if (filters.q) {
    const query = `%${filters.q.replaceAll("%", "\\%").replaceAll("_", "\\_")}%`;
    const searchConditions = [
      ilike(activityEvents.description, query),
      ilike(activityEvents.actorDisplayName, query),
      ilike(activityEvents.id, query),
      ilike(activityEvents.entityId, query),
      ilike(activityEvents.relatedRecordLabel, query),
      ilike(activityEvents.correlationId, query),
      ilike(properties.name, query),
      ilike(units.unitNumber, query),
      sql`${activityEvents.metadata}->>'recordNumber' ilike ${query}`,
    ];
    if (can(context, "tenant:view")) searchConditions.push(ilike(tenants.name, query));
    const search = or(...searchConditions);
    if (search) conditions.push(search);
  }
  return conditions;
}

function whereClause(conditions: SQL[]) {
  return conditions.length ? and(...conditions) : undefined;
}

const eventSelection = {
  event: activityEvents,
  propertyName: properties.name,
  unitNumber: units.unitNumber,
  tenantName: tenants.name,
};

function eventsQuery(filters: ActivityFilters, context: RequestContext, paginate: boolean) {
  const sortColumns = {
    occurredAt: activityEvents.occurredAt,
    actorDisplayName: activityEvents.actorDisplayName,
    action: activityEvents.action,
    category: activityEvents.category,
    outcome: activityEvents.outcome,
    severity: activityEvents.severity,
  };
  const sortColumn = sortColumns[filters.sort as keyof typeof sortColumns] ?? activityEvents.occurredAt;
  const direction = filters.direction === "asc" ? asc : desc;
  const base = db.select(eventSelection).from(activityEvents)
    .leftJoin(properties, eq(activityEvents.propertyId, properties.id))
    .leftJoin(units, eq(activityEvents.unitId, units.id))
    .leftJoin(tenants, eq(activityEvents.tenantId, tenants.id))
    .where(whereClause(conditionsFor(filters, context)))
    .orderBy(direction(sortColumn), desc(activityEvents.occurredAt), desc(activityEvents.id));
  if (!paginate) return base;
  return base.limit(filters.pageSize).offset((filters.page - 1) * filters.pageSize);
}

function toDTO(row: JoinedRow, context: RequestContext): ActivityEventDTO {
  const event = row.event;
  const restrictedAllowed = can(context, "activity:view_sensitive");
  const metadata = { ...(event.metadata ?? {}) };
  if (!restrictedAllowed) {
    for (const key of ["ipAddress", "userAgent", "requestId", "providerReference"]) delete metadata[key];
  }
  return {
    id: event.id,
    occurredAt: event.occurredAt.toISOString(),
    recordedAt: event.recordedAt.toISOString(),
    actorId: event.actorId,
    actorType: event.actorType as ActivityEventDTO["actorType"],
    actorDisplayName: event.actorDisplayName,
    action: event.action as ActivityEventDTO["action"],
    category: event.category as ActivityEventDTO["category"],
    description: event.description,
    entityType: event.entityType as ActivityEventDTO["entityType"],
    entityId: event.entityId,
    relatedRecordLabel: event.relatedRecordLabel,
    propertyId: event.propertyId,
    propertyName: row.propertyName,
    unitId: event.unitId,
    unitNumber: row.unitNumber,
    tenantId: can(context, "tenant:view") ? event.tenantId : null,
    tenantName: can(context, "tenant:view") ? row.tenantName : null,
    changes: (event.changes ?? []).map((change) => change.sensitivity === "restricted" && !restrictedAllowed
      ? { ...change, previousValue: null, newValue: null }
      : change),
    outcome: event.outcome as ActivityEventDTO["outcome"],
    severity: event.severity as ActivityEventDTO["severity"],
    sourceModule: event.sourceModule,
    correlationId: event.correlationId,
    reason: event.reason,
    metadata,
    error: event.error ?? null,
    previousHash: event.previousHash,
    eventHash: event.eventHash,
  };
}

async function summaryFor(filters: ActivityFilters, context: RequestContext): Promise<ActivitySummary> {
  const [summary] = await db.select({
    total: sql<number>`count(*)::int`,
    financial: sql<number>`count(*) filter (where ${activityEvents.category} = 'Accounting & Finance')::int`,
    propertyTenant: sql<number>`count(*) filter (where ${activityEvents.category} in ('Properties & Units', 'Tenants & Leases'))::int`,
    documentLease: sql<number>`count(*) filter (where ${activityEvents.category} in ('Documents & eSignatures', 'Tenants & Leases'))::int`,
    security: sql<number>`count(*) filter (where ${activityEvents.category} = 'Users & Security')::int`,
    failedDenied: sql<number>`count(*) filter (where ${activityEvents.outcome} in ('failure', 'denied'))::int`,
  }).from(activityEvents)
    .leftJoin(properties, eq(activityEvents.propertyId, properties.id))
    .leftJoin(units, eq(activityEvents.unitId, units.id))
    .leftJoin(tenants, eq(activityEvents.tenantId, tenants.id))
    .where(whereClause(conditionsFor(filters, context)));
  return {
    total: Number(summary?.total ?? 0),
    financial: Number(summary?.financial ?? 0),
    propertyTenant: Number(summary?.propertyTenant ?? 0),
    documentLease: Number(summary?.documentLease ?? 0),
    security: Number(summary?.security ?? 0),
    failedDenied: Number(summary?.failedDenied ?? 0),
  };
}

async function filterOptions(): Promise<ActivityFilterOptions> {
  const [actors, propertyRows, unitRows] = await Promise.all([
    db.selectDistinct({ id: activityEvents.actorId, name: activityEvents.actorDisplayName, type: activityEvents.actorType }).from(activityEvents),
    db.select({ id: properties.id, name: properties.name }).from(properties).orderBy(asc(properties.name)),
    db.select({ id: units.id, number: units.unitNumber, propertyId: units.propertyId, propertyName: properties.name })
      .from(units).innerJoin(properties, eq(units.propertyId, properties.id)).orderBy(asc(properties.name), asc(units.unitNumber)),
  ]);
  return {
    actors: actors.map((actor) => ({ ...actor, type: actor.type as ActivityEventDTO["actorType"] })).sort((a, b) => a.name.localeCompare(b.name)),
    properties: propertyRows,
    units: unitRows.map((unit) => ({ ...unit, propertyName: unit.propertyName ?? "" })),
  };
}

export async function getActivityLogs(filters: ActivityFilters): Promise<ActivityListResponse> {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "activity:view");
  const conditions = conditionsFor(filters, context);
  const [rows, countRows, summary, options] = await Promise.all([
    eventsQuery(filters, context, true),
    db.select({ count: sql<number>`count(*)::int` }).from(activityEvents)
      .leftJoin(properties, eq(activityEvents.propertyId, properties.id))
      .leftJoin(units, eq(activityEvents.unitId, units.id))
      .leftJoin(tenants, eq(activityEvents.tenantId, tenants.id))
      .where(whereClause(conditions)),
    summaryFor(filters, context),
    filterOptions(),
  ]);
  const total = Number(countRows[0]?.count ?? 0);
  return {
    items: rows.map((row) => toDTO(row, context)),
    total,
    page: filters.page,
    pageSize: filters.pageSize,
    totalPages: Math.max(1, Math.ceil(total / filters.pageSize)),
    summary,
    options,
    sampleData: true,
  };
}

export async function getActivitySummary(filters: ActivityFilters) {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "activity:view");
  return summaryFor(filters, context);
}

export async function getActivityById(id: string) {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "activity:view");
  const [row] = await db.select(eventSelection).from(activityEvents)
    .leftJoin(properties, eq(activityEvents.propertyId, properties.id))
    .leftJoin(units, eq(activityEvents.unitId, units.id))
    .leftJoin(tenants, eq(activityEvents.tenantId, tenants.id))
    .where(eq(activityEvents.id, id)).limit(1);
  return row ? toDTO(row, context) : null;
}

export async function getRelatedActivities(entityType: string, entityId: string, excludeId?: string, limit = 100) {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "activity:view");
  if (entityType === "tenant") requirePermission(context, "tenant:view");
  const direct = and(eq(activityEvents.entityType, entityType), eq(activityEvents.entityId, entityId));
  let relation = direct;
  if (entityType === "property") relation = eq(activityEvents.propertyId, entityId);
  if (entityType === "unit") relation = or(eq(activityEvents.unitId, entityId), direct);
  if (entityType === "tenant") relation = or(eq(activityEvents.tenantId, entityId), direct);
  if (["invoice", "lease", "project", "message", "signature_request"].includes(entityType)) {
    relation = or(direct, eq(activityEvents.correlationId, `cor_${entityId}`));
  }
  const predicates: SQL[] = [];
  if (relation) predicates.push(relation);
  if (excludeId) predicates.push(sql`${activityEvents.id} <> ${excludeId}`);
  const rows = await db.select(eventSelection).from(activityEvents)
    .leftJoin(properties, eq(activityEvents.propertyId, properties.id))
    .leftJoin(units, eq(activityEvents.unitId, units.id))
    .leftJoin(tenants, eq(activityEvents.tenantId, tenants.id))
    .where(whereClause(predicates)).orderBy(desc(activityEvents.occurredAt)).limit(limit);
  return rows.map((row) => toDTO(row, context));
}

function csvCell(value: unknown) {
  let text = value === null || value === undefined ? "" : String(value);
  if (/^[\s\u0000-\u001f]*[=+\-@]/.test(text) || /^[\t\r]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}

export async function exportActivityLogs(filters: ActivityFilters) {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "activity:export");
  const rows = await eventsQuery({ ...filters, page: 1 }, context, false);
  const events = rows.map((row) => toDTO(row, context));
  const headers = ["Event ID", "Timestamp", "Actor", "Actor Type", "Action", "Category", "Description", "Property", "Unit", "Related Record", "Result", "Severity"];
  const lines = events.map((event) => [
    event.id, event.occurredAt, event.actorDisplayName, formatActorType(event.actorType), actionLabel(event.action),
    event.category, event.description, event.propertyName ?? "", event.unitNumber ?? "", event.relatedRecordLabel,
    event.outcome, event.severity,
  ].map(csvCell).join(","));
  const csv = `\uFEFF${headers.map(csvCell).join(",")}\r\n${lines.join("\r\n")}${lines.length ? "\r\n" : ""}`;
  const fileName = `activity-logs-${new Date().toISOString().slice(0, 10)}.csv`;
  const exportId = `exp_${randomUUID()}`;
  const auditEvent = await db.transaction(async (tx) => {
    const activity = await appendActivity(tx, {
      actorId: context.user.id,
      actorType: "user",
      actorDisplayName: context.user.name,
      action: "audit.exported",
      category: "Users & Security",
      description: `Activity log export created: ${events.length} records (CSV).`,
      entityType: "audit_export",
      entityId: exportId,
      relatedRecordLabel: fileName,
      sourceModule: "Activity Logs",
      severity: "warning",
      reason: "User-initiated filtered audit export",
      metadata: {
        rowCount: events.length,
        format: "CSV",
        filterFields: Object.entries(filters).filter(([, value]) => Boolean(value)).map(([key]) => key),
        changeValuesIncluded: false,
        sampleWorkspace: true,
      },
    });
    await tx.insert(auditExports).values({
      id: exportId,
      activityEventId: activity.id,
      actorId: context.user.id,
      fileName,
      filters: filters as unknown as Record<string, unknown>,
      rowCount: events.length,
      outcome: "success",
    });
    return activity;
  });
  return { csv, rowCount: events.length, fileName, auditEventId: auditEvent.id };
}

export async function verifyActivityIntegrity() {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "audit:manage");
  const rows = await db.select().from(activityEvents).orderBy(asc(activityEvents.recordedAt), asc(activityEvents.id));
  let previousHash = "0".repeat(64);
  let firstInvalidEventId: string | null = null;
  for (const event of rows) {
    const { eventHash: _storedHash, ...hashableEvent } = event;
    const expectedHash = calculateEventHash({ ...hashableEvent, previousHash });
    if (event.previousHash !== previousHash || event.eventHash !== expectedHash) {
      firstInvalidEventId = event.id;
      break;
    }
    previousHash = event.eventHash;
  }
  return {
    valid: firstInvalidEventId === null,
    checked: rows.length,
    firstInvalidEventId,
    checkedAt: new Date().toISOString(),
    headHash: rows.at(-1)?.eventHash ?? null,
    algorithm: "SHA-256 canonical event chain",
  };
}

export async function getRecordTimeline(entityType: string, entityId: string) {
  const events = await getRelatedActivities(entityType, entityId);
  const context = getRequestContext();
  requirePermission(context, "records:view");
  if (entityType === "tenant") requirePermission(context, "tenant:view");
  let title = events[0]?.relatedRecordLabel ?? entityId;
  let subtitle = `${entityType.replaceAll("_", " ")} · ${entityId}`;
  if (entityType === "property") {
    const [record] = await db.select().from(properties).where(eq(properties.id, entityId)).limit(1);
    if (record) { title = record.name; subtitle = `${record.address} · ${record.city}`; }
  } else if (entityType === "unit") {
    const [record] = await db.select({ unit: units, propertyName: properties.name }).from(units)
      .leftJoin(properties, eq(units.propertyId, properties.id)).where(eq(units.id, entityId)).limit(1);
    if (record) { title = `${record.propertyName ?? "Property"} · Unit ${record.unit.unitNumber}`; subtitle = `Monthly rent $${Number(record.unit.monthlyRent).toLocaleString("en-US")} · ${record.unit.occupancy}`; }
  } else if (entityType === "tenant" && can(context, "tenant:view")) {
    const [record] = await db.select().from(tenants).where(eq(tenants.id, entityId)).limit(1);
    if (record) { title = record.name; subtitle = `${record.status} tenant · ${record.email}`; }
  }
  return { title, subtitle, entityType, entityId, events };
}

export async function getAuditExportHistory() {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "audit:manage");
  return db.select().from(auditExports).orderBy(desc(auditExports.createdAt)).limit(12);
}

export async function getCategoryActivity(category: string, limit = 8) {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "activity:view");
  const rows = await db.select(eventSelection).from(activityEvents)
    .leftJoin(properties, eq(activityEvents.propertyId, properties.id))
    .leftJoin(units, eq(activityEvents.unitId, units.id))
    .leftJoin(tenants, eq(activityEvents.tenantId, tenants.id))
    .where(eq(activityEvents.category, category)).orderBy(desc(activityEvents.occurredAt)).limit(limit);
  return rows.map((row) => toDTO(row, context));
}

export async function getSecurityEvents(limit = 6) {
  await ensureActivityWorkspace();
  const context = getRequestContext();
  requirePermission(context, "activity:view");
  const rows = await db.select(eventSelection).from(activityEvents)
    .leftJoin(properties, eq(activityEvents.propertyId, properties.id))
    .leftJoin(units, eq(activityEvents.unitId, units.id))
    .leftJoin(tenants, eq(activityEvents.tenantId, tenants.id))
    .where(inArray(activityEvents.outcome, ["failure", "denied"]))
    .orderBy(desc(activityEvents.occurredAt)).limit(limit);
  return rows.map((row) => toDTO(row, context));
}
