import "server-only";
import { createHash, randomUUID } from "node:crypto";
import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { activityEvents } from "@/db/schema";
import type { ActivityAction, ActivityChange, ActivityError, ActorType, Category, EntityType, Outcome, Severity } from "./types";

export type ActivityInput = {
  id?: string;
  occurredAt?: Date;
  recordedAt?: Date;
  actorId: string;
  actorType: ActorType;
  actorDisplayName: string;
  action: ActivityAction;
  category: Category;
  description: string;
  entityType: EntityType;
  entityId: string;
  relatedRecordLabel?: string;
  propertyId?: string | null;
  unitId?: string | null;
  tenantId?: string | null;
  changes?: ActivityChange[];
  outcome?: Outcome;
  severity?: Severity;
  sourceModule: string;
  correlationId?: string;
  reason?: string | null;
  metadata?: Record<string, unknown>;
  error?: ActivityError | null;
};

export type DbExecutor = typeof db | Parameters<Parameters<typeof db.transaction>[0]>[0];
const GENESIS_HASH = "0".repeat(64);

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  const record = value as Record<string, unknown>;
  return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableStringify(record[key])}`).join(",")}}`;
}

type HashableEvent = {
  id: string;
  occurredAt: Date;
  recordedAt: Date;
  actorId: string;
  actorType: string;
  actorDisplayName: string;
  action: string;
  category: string;
  description: string;
  entityType: string;
  entityId: string;
  relatedRecordLabel: string;
  propertyId: string | null;
  unitId: string | null;
  tenantId: string | null;
  changes: ActivityChange[];
  outcome: string;
  severity: string;
  sourceModule: string;
  correlationId: string;
  reason: string | null;
  metadata: Record<string, unknown>;
  error: ActivityError | null;
  previousHash: string;
};

export function calculateEventHash(event: HashableEvent) {
  const canonical = {
    ...event,
    occurredAt: event.occurredAt.toISOString(),
    recordedAt: event.recordedAt.toISOString(),
  };
  return createHash("sha256").update(stableStringify(canonical)).digest("hex");
}

/** Append inside the caller's transaction. The advisory lock serializes chain heads. */
export async function appendActivity(executor: DbExecutor, input: ActivityInput) {
  await executor.execute(sql`select pg_advisory_xact_lock(724198)`);
  const id = input.id ?? `evt_${randomUUID()}`;
  const occurredAt = input.occurredAt ?? new Date();
  const recordedAt = input.recordedAt ?? new Date();
  const [head] = await executor.select({ eventHash: activityEvents.eventHash }).from(activityEvents)
    .orderBy(desc(activityEvents.recordedAt), desc(activityEvents.id)).limit(1);
  const previousHash = head?.eventHash ?? GENESIS_HASH;
  const values: HashableEvent = {
    id,
    occurredAt,
    recordedAt,
    actorId: input.actorId,
    actorType: input.actorType,
    actorDisplayName: input.actorDisplayName,
    action: input.action,
    category: input.category,
    description: input.description,
    entityType: input.entityType,
    entityId: input.entityId,
    relatedRecordLabel: input.relatedRecordLabel ?? input.entityId,
    propertyId: input.propertyId ?? null,
    unitId: input.unitId ?? null,
    tenantId: input.tenantId ?? null,
    changes: input.changes ?? [],
    outcome: input.outcome ?? "success",
    severity: input.severity ?? "informational",
    sourceModule: input.sourceModule,
    correlationId: input.correlationId ?? `cor_${randomUUID()}`,
    reason: input.reason ?? null,
    metadata: input.metadata ?? {},
    error: input.error ?? null,
    previousHash,
  };
  const eventHash = calculateEventHash(values);
  await executor.insert(activityEvents).values({ ...values, eventHash });
  return { id, eventHash, occurredAt, recordedAt };
}

/** Server-only publishing API for business modules. Never pass client actor data. */
export async function recordActivity(input: ActivityInput) {
  return db.transaction(async (tx) => appendActivity(tx, input));
}
