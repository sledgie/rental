import "server-only";

export type Permission =
  | "activity:view"
  | "activity:export"
  | "activity:view_sensitive"
  | "tenant:view"
  | "records:view"
  | "users:manage"
  | "audit:manage";

export type RequestContext = {
  user: { id: string; name: string; email: string; role: string };
  permissions: Set<Permission>;
  isDemoIdentity: boolean;
};

const administratorPermissions: Permission[] = [
  "activity:view", "activity:export", "activity:view_sensitive", "tenant:view",
  "records:view", "users:manage", "audit:manage",
];

/**
 * Demo identity adapter. The starter has no IdP or session middleware. Replace
 * this single function with the production session resolver; all activity APIs
 * already derive actor identity and permissions here rather than from payloads.
 */
export function getRequestContext(): RequestContext {
  return {
    user: {
      id: "usr_olivia",
      name: "Olivia Martin",
      email: "olivia@northstar-rentals.example",
      role: "Administrator",
    },
    permissions: new Set(administratorPermissions),
    isDemoIdentity: true,
  };
}

export class AuthorizationError extends Error {
  status = 403;
  constructor(permission: Permission) {
    super(`Missing required permission: ${permission}`);
    this.name = "AuthorizationError";
  }
}

export function requirePermission(context: RequestContext, permission: Permission) {
  if (!context.permissions.has(permission)) throw new AuthorizationError(permission);
}

export function can(context: RequestContext, permission: Permission) {
  return context.permissions.has(permission);
}
