import { relations } from "drizzle-orm";
import { boolean, index, jsonb, pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";
import type { ActivityChange, ActivityError } from "@/lib/activity/types";

export const properties = pgTable("properties", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const units = pgTable("units", {
  id: text("id").primaryKey(),
  propertyId: text("property_id").notNull().references(() => properties.id),
  unitNumber: text("unit_number").notNull(),
  monthlyRent: text("monthly_rent").notNull(),
  occupancy: text("occupancy").notNull().default("vacant"),
});

export const tenants = pgTable("tenants", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  unitId: text("unit_id").references(() => units.id),
  status: text("status").notNull().default("active"),
});

export const appUsers = pgTable("app_users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull(),
  status: text("status").notNull().default("active"),
  lastActiveAt: timestamp("last_active_at", { withTimezone: true }),
});

export const activityEvents = pgTable("activity_events", {
  id: text("id").primaryKey(),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull(),
  recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull().defaultNow(),
  actorId: text("actor_id").notNull(),
  actorType: text("actor_type").notNull(),
  actorDisplayName: text("actor_display_name").notNull(),
  action: text("action").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  relatedRecordLabel: text("related_record_label").notNull(),
  propertyId: text("property_id").references(() => properties.id),
  unitId: text("unit_id").references(() => units.id),
  tenantId: text("tenant_id").references(() => tenants.id),
  changes: jsonb("changes").$type<ActivityChange[]>().notNull().default([]),
  outcome: text("outcome").notNull(),
  severity: text("severity").notNull().default("informational"),
  sourceModule: text("source_module").notNull(),
  correlationId: text("correlation_id").notNull(),
  reason: text("reason"),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
  error: jsonb("error").$type<ActivityError | null>(),
  previousHash: text("previous_hash"),
  eventHash: text("event_hash").notNull(),
}, (table) => [
  index("activity_occurred_at_idx").on(table.occurredAt),
  index("activity_recorded_at_idx").on(table.recordedAt),
  index("activity_actor_id_idx").on(table.actorId),
  index("activity_category_idx").on(table.category),
  index("activity_action_idx").on(table.action),
  index("activity_property_id_idx").on(table.propertyId),
  index("activity_unit_id_idx").on(table.unitId),
  index("activity_tenant_id_idx").on(table.tenantId),
  index("activity_entity_idx").on(table.entityType, table.entityId),
  index("activity_correlation_id_idx").on(table.correlationId),
  index("activity_outcome_idx").on(table.outcome),
]);

export const auditExports = pgTable("audit_exports", {
  id: text("id").primaryKey(),
  activityEventId: text("activity_event_id").references(() => activityEvents.id),
  actorId: text("actor_id").notNull(),
  fileName: text("file_name").notNull(),
  filters: jsonb("filters").$type<Record<string, unknown>>().notNull(),
  rowCount: integer("row_count").notNull(),
  outcome: text("outcome").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const auditPolicies = pgTable("audit_policies", {
  id: text("id").primaryKey(),
  retentionDays: integer("retention_days").notNull().default(2555),
  archiveAfterDays: integer("archive_after_days").notNull().default(365),
  restrictSensitiveChanges: boolean("restrict_sensitive_changes").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  updatedBy: text("updated_by").notNull(),
});

export const propertiesRelations = relations(properties, ({ many }) => ({ units: many(units) }));
export const unitsRelations = relations(units, ({ one }) => ({
  property: one(properties, { fields: [units.propertyId], references: [properties.id] }),
}));
