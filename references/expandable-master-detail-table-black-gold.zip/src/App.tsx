import { useMemo, useState } from "react";
import {
  currency,
  properties,
  propertyBalance,
  propertyOccupied,
  propertyRentRoll,
  type Property,
} from "./data/properties";
import { Avatar, Bar, Donut, Sparkline, useCountUp } from "./components/charts";
import PropertyTable, { type SortKey } from "./components/PropertyTable";
import ThemeToggle from "./components/ThemeToggle";
import { useTheme } from "./theme";
import {
  Alert,
  Bell,
  Check,
  ChevronsDown,
  ChevronsUp,
  Download,
  Layers,
  Search,
  Send,
  Sparkle,
  Users,
  Wallet,
} from "./components/icons";
import { cn } from "./utils/cn";

type FilterKey = "all" | "delinquent" | "current" | "vacant";

const FILTERS: { key: FilterKey; label: string; dot: string }[] = [
  { key: "all", label: "All properties", dot: "bg-slate-400" },
  { key: "delinquent", label: "With arrears", dot: "bg-rose-500" },
  { key: "current", label: "Fully current", dot: "bg-emerald-500" },
  { key: "vacant", label: "Has vacancy", dot: "bg-amber-500" },
];

function KpiCard({
  icon,
  label,
  value,
  sub,
  tone,
  spark,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub: string;
  tone: "indigo" | "rose" | "emerald" | "amber";
  spark?: number[];
  accent: React.ReactNode;
}) {
  const tones = {
    indigo: "from-indigo-500 to-violet-600 shadow-none",
    rose: "from-rose-500 to-red-600 shadow-none",
    emerald: "from-emerald-500 to-teal-600 shadow-none",
    amber: "from-amber-500 to-orange-600 shadow-none",
  };
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-hairline bg-surface p-4 shadow-[0_1px_2px_rgba(15,23,42,.04)] transition hover:-translate-y-0.5 hover:shadow-lg dark:border-white/10 dark:shadow-[0_1px_2px_rgba(0,0,0,.45)] dark:hover:border-indigo-400/30 dark:hover:shadow-[0_16px_36px_-14px_rgba(0,0,0,.85)]">
      <div className={cn("absolute inset-x-0 top-0 h-[3px] bg-gradient-to-r", tones[tone])} />
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.09em] text-ink-3">{label}</p>
          <p className="mt-1.5 text-2xl font-extrabold tabular-nums tracking-tight text-ink">{value}</p>
        </div>
        <span className={cn("flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br text-white shadow-md", tones[tone])}>
          {icon}
        </span>
      </div>
      <div className="mt-3 flex items-end justify-between gap-2">
        {accent}
        {spark && (
          <Sparkline
            data={spark}
            width={90}
            height={30}
            tone={tone}
            className="opacity-70 transition group-hover:opacity-100"
          />
        )}
      </div>
      <p className="mt-1 text-[11px] font-medium text-ink-3">{sub}</p>
    </div>
  );
}

export default function App() {
  const { dark } = useTheme();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterKey>("all");
  const [sort, setSort] = useState<SortKey>("balance");
  const [dir, setDir] = useState<"asc" | "desc">("desc");
  const [expanded, setExpanded] = useState<Set<string>>(new Set(["PR-1042"]));
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    let out = properties.filter((p) => {
      if (q) {
        const hay = [
          p.code,
          p.name,
          p.address1,
          p.city,
          p.state,
          p.manager,
          ...p.units.flatMap((u) => [u.unit, ...u.tenants.map((t) => t.name)]),
        ]
          .join(" ")
          .toLowerCase();
        if (!hay.includes(q)) return false;
      }
      const bal = propertyBalance(p);
      if (filter === "delinquent" && bal === 0) return false;
      if (filter === "current" && bal !== 0) return false;
      if (filter === "vacant" && !p.units.some((u) => u.status === "vacant" || u.status === "notice")) return false;
      return true;
    });

    const cmp: Record<SortKey, (a: Property, b: Property) => number> = {
      code: (a, b) => a.code.localeCompare(b.code),
      name: (a, b) => a.name.localeCompare(b.name),
      units: (a, b) => a.units.length - b.units.length,
      balance: (a, b) => propertyBalance(a) - propertyBalance(b),
    };
    out = [...out].sort(cmp[sort]);
    if (dir === "desc") out.reverse();
    return out;
  }, [query, filter, sort, dir]);

  const totals = useMemo(() => {
    const balance = rows.reduce((s, p) => s + propertyBalance(p), 0);
    const rent = rows.reduce((s, p) => s + propertyRentRoll(p), 0);
    const units = rows.reduce((s, p) => s + p.units.length, 0);
    const occ = rows.reduce((s, p) => s + propertyOccupied(p), 0);
    const residents = rows.reduce((s, p) => s + p.units.reduce((a, u) => a + u.tenants.length, 0), 0);
    const withArrears = rows.filter((p) => propertyBalance(p) > 0).length;
    return { balance, rent, units, occ, residents, withArrears };
  }, [rows]);

  const portfolioBalance = properties.reduce((s, p) => s + propertyBalance(p), 0);
  const portfolioRent = properties.reduce((s, p) => s + propertyRentRoll(p), 0);
  const allUnits = properties.reduce((s, p) => s + p.units.length, 0);
  const allOcc = properties.reduce((s, p) => s + propertyOccupied(p), 0);
  const delinquentUnits = properties
    .flatMap((p) => p.units)
    .filter((u) => u.status === "delinquent").length;

  const animatedBalance = useCountUp(portfolioBalance);
  const collectionRate = 1 - portfolioBalance / (portfolioRent + portfolioBalance);

  const toggle = (id: string) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const toggleSelect = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const allOpen = rows.length > 0 && rows.every((p) => expanded.has(p.code));

  const onSort = (k: SortKey) => {
    if (k === sort) setDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSort(k);
      setDir(k === "name" || k === "code" ? "asc" : "desc");
    }
  };

  // contribution of each property to total arrears (stacked bar)
  const contributions = [...properties]
    .map((p) => ({ name: p.name, bal: propertyBalance(p) }))
    .sort((a, b) => b.bal - a.bal);
  const maxContribution = Math.max(...contributions.map((c) => c.bal), 1);
  const contributionColors = [
    "bg-indigo-500",
    "bg-indigo-500",
    "bg-indigo-500",
    "bg-indigo-500",
    "bg-indigo-500",
    "bg-indigo-500",
    "bg-indigo-500",
    "bg-indigo-500",
  ];

  return (
    <div className="page-glow min-h-screen bg-canvas text-ink transition-colors duration-500">
      {/* ---------------- top nav ---------------- */}
      <header className="sticky top-0 z-30 border-b border-hairline/80 bg-surface/80 shadow-[0_1px_2px_rgba(15,23,42,.04)] backdrop-blur-xl dark:border-white/10 dark:bg-black/85 dark:shadow-[0_14px_34px_-18px_rgba(0,0,0,.9)]">
        <div className="mx-auto flex max-w-[1500px] items-center gap-4 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-neutral-950 shadow-none">
              <Layers className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-extrabold leading-tight tracking-tight text-ink">
                RentLedger <span className="text-indigo-600 dark:text-indigo-300">Pro</span>
              </p>
              <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-3">
                Portfolio receivables
              </p>
            </div>
          </div>

          <nav className="ml-6 hidden items-center gap-1 lg:flex">
            {["Ledger", "Collections", "Leases", "Reports"].map((n, i) => (
              <span
                key={n}
                className={cn(
                  "cursor-pointer rounded-lg px-3 py-1.5 text-[13px] font-semibold transition",
                  i === 0
                    ? "bg-indigo-50 dark:bg-indigo-400/10 text-indigo-700 dark:text-indigo-300"
                    : "text-ink-2 hover:bg-surface-2 hover:text-ink",
                )}
              >
                {n}
              </span>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <span className="hidden items-center gap-1.5 rounded-full bg-emerald-50 dark:bg-emerald-400/10 px-2.5 py-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-300 ring-1 ring-emerald-200 dark:ring-emerald-400/30 sm:inline-flex">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" /> Synced live
            </span>
            <ThemeToggle />
            <button className="relative flex h-9 w-9 items-center justify-center rounded-xl text-ink-2 ring-1 ring-hairline transition hover:bg-surface-2/70 hover:text-indigo-600 dark:hover:text-indigo-300">
              <Bell className="h-4 w-4" />
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-bold text-white">
                {delinquentUnits}
              </span>
            </button>
            <button className="hidden items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-3.5 py-2 text-xs font-bold text-neutral-950 shadow-md shadow-none transition hover:brightness-110 sm:inline-flex">
              <Download className="h-4 w-4" /> Export
            </button>
            <Avatar name="Jordan Reyes" size={34} />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1500px] px-4 pb-24 pt-6 sm:px-6">
        {/* ---------------- page heading ---------------- */}
        <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">
                Property receivables
              </h1>
              <span className="rounded-full bg-surface px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-300 ring-1 ring-indigo-200 dark:ring-indigo-400/30">
                Master / detail
              </span>
              <span
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full px-2 py-1 text-[10px] font-bold uppercase tracking-wider ring-1",
                  dark
                    ? "bg-indigo-500/15 text-indigo-300 ring-indigo-400/30"
                    : "bg-amber-50 text-amber-700 ring-amber-200",
                )}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full", dark ? "bg-indigo-400" : "bg-amber-500")} />
                Option B · {dark ? "dark" : "light"}
              </span>
            </div>
            <p className="mt-1 max-w-2xl text-sm text-ink-2">
              Each property is a master row — click the{" "}
              <span className="inline-flex h-4 w-4 translate-y-0.5 items-center justify-center rounded border border-hairline-strong text-ink-2">
                <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round">
                  <path d="M12 5v14M5 12h14" />
                </svg>
              </span>{" "}
              to drop down its unit-level detail: who lives there and exactly what they owe.
            </p>
          </div>
          <div className="flex items-center gap-2 rounded-2xl border border-hairline bg-surface/80 p-2 shadow-sm backdrop-blur">
            <Donut
              value={collectionRate}
              size={58}
              thickness={7}
              tone="indigo"
              label={`${Math.round(collectionRate * 100)}%`}
            />
            <div className="pr-1">
              <p className="text-[10px] font-bold uppercase tracking-wider text-ink-3">Collected</p>
              <p className="text-sm font-bold text-ink">
                {currency(portfolioRent)}{" "}
                <span className="font-medium text-ink-3">/ {currency(portfolioRent + portfolioBalance)}</span>
              </p>
              <p className="text-[11px] font-semibold text-rose-500">
                {currency(portfolioBalance)} outstanding
              </p>
            </div>
          </div>
        </div>

        {/* ---------------- KPI cards ---------------- */}
        <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <KpiCard
            icon={<Wallet className="h-4.5 w-4.5" />}
            label="Outstanding balance"
            value={currency(Math.round(animatedBalance))}
            sub={`across ${totals.withArrears} of ${rows.length} properties`}
            tone="rose"
            spark={properties.map((p) => propertyBalance(p)).slice(0, 8)}
            accent={
              <span className="inline-flex items-center gap-1 rounded-lg bg-rose-50 dark:bg-rose-400/10 px-2 py-1 text-[10px] font-bold text-rose-600 dark:text-rose-400">
                <Alert className="h-3 w-3" /> {delinquentUnits} delinquent units
              </span>
            }
          />
          <KpiCard
            icon={<Sparkle className="h-4.5 w-4.5" />}
            label="Monthly rent roll"
            value={currency(portfolioRent)}
            sub="gross potential rent"
            tone="emerald"
            spark={[188, 196, 204, 199, 212, 220, 216, 228]}
            accent={
              <span className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 dark:bg-emerald-400/10 px-2 py-1 text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                <Check className="h-3 w-3" /> 100% billed
              </span>
            }
          />
          <KpiCard
            icon={<Users className="h-4.5 w-4.5" />}
            label="Occupancy"
            value={`${allOcc}/${allUnits}`}
            sub={`${Math.round((allOcc / allUnits) * 100)}% of units leased`}
            tone="indigo"
            accent={
              <div className="w-28">
                <Bar value={allOcc / allUnits} tone="indigo" height={6} />
              </div>
            }
          />
          <KpiCard
            icon={<Layers className="h-4.5 w-4.5" />}
            label="Units & residents"
            value={`${allUnits}`}
            sub={`${properties.reduce((s, p) => s + p.units.reduce((a, u) => a + u.tenants.length, 0), 0)} residents on active leases`}
            tone="amber"
            spark={[12, 14, 14, 17, 19, 21, 24, 26]}
            accent={
              <div className="flex -space-x-2">
                {["Dana W", "Owen C", "Renee S", "Alice K"].map((n) => (
                  <Avatar key={n} name={n} size={24} />
                ))}
              </div>
            }
          />
        </div>

        {/* ---------------- arrears distribution ---------------- */}
        <div className="mb-5 rounded-2xl border border-hairline bg-surface p-4 shadow-sm">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-ink-2">
                Arrears concentration by property
              </p>
              <p className="text-[11px] text-ink-3">
                Top contributors to the {currency(portfolioBalance)} portfolio balance
              </p>
            </div>
            <div className="flex items-center gap-3 text-[10px] font-semibold text-ink-2">
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-indigo-500" /> Highest
              </span>
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-indigo-500/40" /> Lowest
              </span>
            </div>
          </div>
          <div className="space-y-2">
            {contributions.map((c, i) => (
              <div key={c.name} className="flex items-center gap-3">
                <span className="w-40 shrink-0 truncate text-[11px] font-semibold text-ink-2">{c.name}</span>
                <div className="h-4 flex-1 overflow-hidden rounded-full bg-surface-2">
                  <div
                    className={cn("h-full rounded-full transition-all duration-1000 ease-out", contributionColors[i])}
                    style={{ width: `${Math.max(1.5, (c.bal / maxContribution) * 100)}%`, opacity: 1 - i * 0.07 }}
                  />
                </div>
                <span className="w-20 shrink-0 text-right text-[11px] font-bold tabular-nums text-ink">
                  {currency(c.bal)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* ---------------- toolbar ---------------- */}
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <div className="relative min-w-[240px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-3" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search property, address, unit # or resident…"
              className="w-full rounded-xl border border-hairline bg-surface py-2.5 pl-9 pr-3 text-sm text-ink shadow-sm outline-none transition placeholder:text-ink-3 focus:border-indigo-400 focus:ring-4 focus:ring-indigo-100 dark:ring-indigo-400/20"
            />
          </div>

          <div className="flex items-center gap-1 rounded-xl border border-hairline bg-surface p-1 shadow-sm">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition",
                  filter === f.key
                    ? "bg-gradient-to-r from-indigo-600 to-violet-600 text-neutral-950 shadow-sm"
                    : "text-ink-2 hover:bg-surface-2",
                )}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full", f.dot)} />
                {f.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() =>
                setExpanded(allOpen ? new Set() : new Set(rows.map((p) => p.code)))
              }
              className="inline-flex items-center gap-1.5 rounded-xl border border-hairline bg-surface px-3 py-2.5 text-xs font-bold text-ink-2 shadow-sm transition hover:border-indigo-300 dark:hover:border-indigo-400/40 hover:text-indigo-600 dark:hover:text-indigo-300 dark:text-indigo-300"
            >
              {allOpen ? <ChevronsUp className="h-4 w-4" /> : <ChevronsDown className="h-4 w-4" />}
              {allOpen ? "Collapse all" : "Expand all"}
            </button>
            <div className="hidden items-center gap-3 rounded-xl border border-hairline bg-surface px-3 py-2.5 text-xs font-semibold text-ink-2 shadow-sm sm:flex">
              <span>
                <span className="font-extrabold text-ink">{rows.length}</span> properties
              </span>
              <span className="h-4 w-px bg-surface-3" />
              <span>
                <span className="font-extrabold text-ink">{totals.units}</span> units
              </span>
              <span className="h-4 w-px bg-surface-3" />
              <span>
                <span className="font-extrabold text-rose-600 dark:text-rose-400">{currency(totals.balance)}</span> shown
              </span>
            </div>
          </div>
        </div>

        {/* ---------------- table ---------------- */}
        <PropertyTable
          rows={rows}
          expanded={expanded}
          toggle={toggle}
          selected={selected}
          toggleSelect={toggleSelect}
          sort={sort}
          dir={dir}
          onSort={onSort}
        />

        <p className="mt-4 text-center text-[11px] text-ink-3">
          Showing {rows.length} of {properties.length} properties · {totals.units} units ·{" "}
          {totals.residents} residents · demo data
        </p>
      </main>

      {/* ---------------- selection action bar ---------------- */}
      <div
        className={cn(
          "fixed inset-x-0 bottom-0 z-40 flex justify-center px-4 pb-5 transition-all duration-300",
          selected.size > 0 ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0",
        )}
      >
        <div className="flex items-center gap-3 rounded-2xl border border-slate-700/40 bg-slate-900/95 px-4 py-3 text-white shadow-2xl ring-1 ring-white/10 backdrop-blur dark:bg-slate-800/95 dark:shadow-black/60">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-300">
            <Check className="h-4 w-4" />
          </span>
          <p className="text-sm font-semibold">
            {selected.size} {selected.size === 1 ? "property" : "properties"} selected
          </p>
          <span className="h-6 w-px bg-surface/15" />
          <button className="inline-flex items-center gap-1.5 rounded-xl bg-surface/10 px-3 py-1.5 text-xs font-bold transition hover:bg-surface/20">
            <Send className="h-3.5 w-3.5" /> Send reminders
          </button>
          <button className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-3 py-1.5 text-xs font-bold shadow-lg transition hover:brightness-110">
            <Download className="h-3.5 w-3.5" /> Export statement
          </button>
          <button
            onClick={() => setSelected(new Set())}
            className="rounded-lg px-2 py-1 text-xs font-semibold text-ink-3 transition hover:text-white"
          >
            Clear
          </button>
        </div>
      </div>
    </div>
  );
}
