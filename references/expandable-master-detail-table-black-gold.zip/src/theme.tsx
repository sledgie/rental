import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export type Theme = "light" | "dark";

type Ctx = {
  theme: Theme;
  dark: boolean;
  setTheme: (t: Theme) => void;
  toggle: () => void;
};

const ThemeCtx = createContext<Ctx>({
  theme: "dark",
  dark: true,
  setTheme: () => {},
  toggle: () => {},
});

const STORAGE_KEY = "rentledger.theme";

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(() => {
    if (typeof window === "undefined") return "dark";
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved === "light" || saved === "dark") return saved;
    return "dark"; // dark is the default
  });

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.style.colorScheme = theme;
    try {
      window.localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      /* ignore */
    }
  }, [theme]);

  const setTheme = useCallback((t: Theme) => setThemeState(t), []);
  const toggle = useCallback(
    () => setThemeState((t) => (t === "dark" ? "light" : "dark")),
    [],
  );

  const value = useMemo(
    () => ({ theme, dark: theme === "dark", setTheme, toggle }),
    [theme, setTheme, toggle],
  );

  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>;
}

export const useTheme = () => useContext(ThemeCtx);

/* ------------------------------------------------------------------ */
/* Chart palette — hex values that stay legible in both themes         */
/* ------------------------------------------------------------------ */

export type Tone = "indigo" | "emerald" | "amber" | "rose" | "slate";

export type ChartPalette = {
  track: string;
  tone: Record<Tone, { stroke: string; fill: string; from: string; to: string }>;
};

const LIGHT: ChartPalette = {
  track: "#e7e7e5",
  tone: {
    indigo: { stroke: "#b88a1f", fill: "rgba(184,138,31,0.22)", from: "#b88a1f", to: "#d4a437" },
    emerald: { stroke: "#587a63", fill: "rgba(88,122,99,0.20)", from: "#587a63", to: "#6f927b" },
    amber: { stroke: "#b88a1f", fill: "rgba(184,138,31,0.22)", from: "#b88a1f", to: "#d4a437" },
    rose: { stroke: "#a9544a", fill: "rgba(169,84,74,0.20)", from: "#a9544a", to: "#c4695d" },
    slate: { stroke: "#71717a", fill: "rgba(113,113,122,0.18)", from: "#71717a", to: "#a1a1aa" },
  },
};

const DARK: ChartPalette = {
  track: "rgba(255,255,255,0.09)",
  tone: {
    indigo: { stroke: "#e4c76f", fill: "rgba(228,199,111,0.22)", from: "#d4a437", to: "#e4c76f" },
    emerald: { stroke: "#84a690", fill: "rgba(132,166,144,0.20)", from: "#6f927b", to: "#84a690" },
    amber: { stroke: "#e4c76f", fill: "rgba(228,199,111,0.22)", from: "#d4a437", to: "#e4c76f" },
    rose: { stroke: "#d4857a", fill: "rgba(212,133,122,0.22)", from: "#c4695d", to: "#d4857a" },
    slate: { stroke: "#a1a1aa", fill: "rgba(161,161,170,0.18)", from: "#71717a", to: "#a1a1aa" },
  },
};

export function useChartPalette(): ChartPalette {
  const { dark } = useTheme();
  return dark ? DARK : LIGHT;
}
