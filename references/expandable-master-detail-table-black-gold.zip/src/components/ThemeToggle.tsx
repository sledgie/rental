import { useTheme } from "../theme";
import { cn } from "../utils/cn";

function SunIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.2}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth={2.2}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
      <path d="M17 4.5h.01M20.5 8h.01" />
    </svg>
  );
}

export default function ThemeToggle() {
  const { dark, toggle, theme } = useTheme();

  return (
    <button
      onClick={toggle}
      role="switch"
      aria-checked={dark}
      aria-label={`Switch to ${dark ? "light" : "dark"} theme`}
      title={`Switch to ${dark ? "light" : "dark"} theme`}
      className={cn(
        "group relative inline-flex h-9 w-[74px] items-center rounded-full p-1 ring-1 transition-colors duration-500",
        dark
          ? "bg-surface-3 ring-white/10"
          : "bg-surface-2 ring-hairline-strong",
      )}
    >
      {/* track labels */}
      <span
        className={cn(
          "pointer-events-none absolute inset-y-0 left-2 flex items-center text-[10px] font-bold uppercase tracking-wider transition-opacity duration-300",
          dark ? "text-ink-3 opacity-100" : "text-amber-600 opacity-40",
        )}
      >
        Dark
      </span>
      <span
        className={cn(
          "pointer-events-none absolute inset-y-0 right-2 flex items-center text-[10px] font-bold uppercase tracking-wider transition-opacity duration-300",
          dark ? "text-amber-300 opacity-40" : "text-amber-700 opacity-100",
        )}
      >
        Light
      </span>

      {/* knob */}
      <span
        className={cn(
          "relative z-10 flex h-7 w-7 items-center justify-center rounded-full shadow-lg transition-all duration-500 ease-[cubic-bezier(.22,1,.36,1)]",
          dark
            ? "translate-x-[38px] bg-gradient-to-br from-indigo-400 to-violet-600 text-neutral-950"
            : "translate-x-0 bg-gradient-to-br from-amber-300 to-orange-500 text-neutral-950 shadow-amber-500/40",
        )}
      >
        <span key={theme} style={{ animation: "knobIn .5s ease-out both" }}>
          {dark ? <MoonIcon /> : <SunIcon />}
        </span>
      </span>
    </button>
  );
}
