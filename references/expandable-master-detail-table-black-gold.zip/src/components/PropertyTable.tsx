import { Fragment } from "react";
import {
  currency,
  propertyAtRisk,
  propertyBalance,
  propertyOccupied,
  propertyRentRoll,
  severityOf,
  type Property,
} from "../data/properties";
import { Bar, Collapse, Sparkline } from "./charts";
import PropertyDetail from "./PropertyDetail";
import { Building, ChevronsDown, ChevronsUp, Pin, Users } from "./icons";
import { cn } from "../utils/cn";

export type SortKey = "code" | "name" | "units" | "balance";

const thumbGrads = [
  "from-zinc-700 to-zinc-800",
  "from-zinc-600 to-zinc-700",
  "from-stone-700 to-stone-800",
  "from-neutral-600 to-neutral-700",
];

const gradFor = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 17 + s.charCodeAt(i)) % 9973;
  return thumbGrads[h % thumbGrads.length];
};

function SortHeader({
  label,
  k,
  sort,
  dir,
  onSort,
  className,
}: {
  label: string;
  k: SortKey;
  sort: SortKey;
  dir: "asc" | "desc";
  onSort: (k: SortKey) => void;
  className?: string;
}) {
  const active = sort === k;
  return (
    <th className={cn("px-3 py-3", className)}>
      <button
        onClick={() => onSort(k)}
        className={cn(
          "group inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.08em] transition",
          active ? "text-indigo-600 dark:text-indigo-300" : "text-ink-2 hover:text-ink",
          className,
        )}
      >
        {label}
        <span className={cn("transition", active ? "opacity-100" : "opacity-0 group-hover:opacity-40")}>
          {dir === "asc" ? (
            <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
              <path d="m6 15 6-6 6 6" />
            </svg>
          ) : (
            <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
              <path d="m6 9 6 6 6-6" />
            </svg>
          )}
        </span>
      </button>
    </th>
  );
}

export default function PropertyTable({
  rows,
  expanded,
  toggle,
  selected,
  toggleSelect,
  sort,
  dir,
  onSort,
}: {
  rows: Property[];
  expanded: Set<string>;
  toggle: (id: string) => void;
  selected: Set<string>;
  toggleSelect: (id: string) => void;
  sort: SortKey;
  dir: "asc" | "desc";
  onSort: (k: SortKey) => void;
}) {
  return (
    <div className="overflow-hidden rounded-2xl border border-hairline bg-surface shadow-[0_1px_2px_rgba(15,23,42,.04),0_12px_32px_-12px_rgba(15,23,42,.12)] dark:border-white/10 dark:shadow-[0_1px_2px_rgba(0,0,0,.5),0_18px_44px_-16px_rgba(0,0,0,.9)]">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1000px] border-collapse text-left">
          <thead>
            <tr className="relative bg-zinc-900 dark:bg-surface-2">
              <th className="w-10 px-3 py-3.5" />
              <th className="w-10 px-2 py-3.5" />
              <SortHeader label="Property ID" k="code" sort={sort} dir={dir} onSort={onSort} />
              <SortHeader label="Property name" k="name" sort={sort} dir={dir} onSort={onSort} />
              <th className="px-3 py-3.5 text-[10px] font-bold uppercase tracking-[0.08em] text-slate-300">
                Address
              </th>
              <SortHeader
                label="Units"
                k="units"
                sort={sort}
                dir={dir}
                onSort={onSort}
                className="text-center [&]:text-center"
              />
              <SortHeader
                label="Current balance"
                k="balance"
                sort={sort}
                dir={dir}
                onSort={onSort}
                className="text-right [&]:justify-end [&]:text-right"
              />
              <th className="w-12 px-3 py-3.5" />
            </tr>
          </thead>

          <tbody className="divide-y divide-hairline-2">
            {rows.map((p, idx) => {
              const isOpen = expanded.has(p.code);
              const isSel = selected.has(p.code);
              const bal = propertyBalance(p);
              const rent = propertyRentRoll(p);
              const occ = propertyOccupied(p);
              const risk = propertyAtRisk(p);
              const sev = severityOf(bal, rent);
              const prev = p.trend[p.trend.length - 2] ?? bal;
              const delta = bal - prev;
              const rising = delta > 0;

              return (
                <Fragment key={p.code}>
                  {/* ---------- MASTER ROW ---------- */}
                  <tr
                    key={p.code}
                    onClick={() => toggle(p.code)}
                    className={cn(
                      "group cursor-pointer align-middle transition-colors",
                      isOpen ? "bg-indigo-50 dark:bg-indigo-400/10/60 dark:bg-indigo-400/10" : "hover:bg-surface-2/70",
                      isSel && "bg-sky-50 dark:bg-sky-400/10/70 dark:bg-sky-400/10",
                      sev === "bad" && !isOpen && "bg-rose-50 dark:bg-rose-400/10/25 dark:bg-rose-400/[0.07]",
                    )}
                  >
                    {/* expander */}
                    <td className="relative px-3 py-3">
                      {isOpen && (
                        <span className="absolute left-0 top-2 bottom-2 w-[3px] rounded-r bg-gradient-to-b from-indigo-500 to-violet-500" />
                      )}
                      <span
                        className={cn(
                          "flex h-8 w-8 items-center justify-center rounded-lg border transition-all duration-300",
                          isOpen
                            ? "rotate-45 border-indigo-500 dark:border-indigo-400 bg-gradient-to-br from-indigo-500 to-violet-600 text-neutral-950 shadow-none"
                            : "border-hairline bg-surface text-ink-3 group-hover:border-indigo-300 dark:hover:border-indigo-400/40 group-hover:text-indigo-600 dark:hover:text-indigo-300 dark:text-indigo-300",
                        )}
                      >
                        <svg
                          viewBox="0 0 24 24"
                          className="h-4 w-4"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth={2.6}
                          strokeLinecap="round"
                        >
                          <path d="M12 5v14M5 12h14" />
                        </svg>
                      </span>
                    </td>

                    {/* checkbox */}
                    <td className="px-2 py-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleSelect(p.code);
                        }}
                        className={cn(
                          "flex h-4.5 w-4.5 items-center justify-center rounded border transition",
                          isSel
                            ? "border-indigo-600 dark:border-indigo-400 bg-indigo-600 text-neutral-950"
                            : "border-hairline-strong bg-surface hover:border-indigo-400",
                        )}
                        aria-label={`Select ${p.name}`}
                      >
                        {isSel && (
                          <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={4} strokeLinecap="round" strokeLinejoin="round">
                            <path d="m20 6-11 11-5-5" />
                          </svg>
                        )}
                      </button>
                    </td>

                    {/* id */}
                    <td className="whitespace-nowrap px-3 py-3">
                      <span className="rounded-md bg-surface-2 px-2 py-1 font-mono text-[11px] font-bold text-ink-2 group-hover:bg-indigo-100 dark:hover:bg-indigo-400/15 dark:hover:bg-indigo-400/15 group-hover:text-indigo-700 dark:hover:text-indigo-300 dark:text-indigo-300">
                        {p.code}
                      </span>
                    </td>

                    {/* name */}
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-3">
                        <span
                          className={cn(
                            "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br text-white shadow-md ring-2 ring-surface",
                            gradFor(p.name),
                          )}
                        >
                          <Building className="h-5 w-5" />
                        </span>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-bold text-ink group-hover:text-indigo-700 dark:hover:text-indigo-300 dark:text-indigo-300">
                            {p.name}
                          </p>
                          <div className="mt-0.5 flex items-center gap-1.5">
                            <span className="rounded bg-surface-2 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-ink-2">
                              {p.type}
                            </span>
                            {risk > 0 && (
                              <span className="inline-flex items-center gap-1 rounded bg-rose-100 dark:bg-rose-400/15 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-rose-600 dark:text-rose-400">
                                <span className="h-1 w-1 animate-pulse rounded-full bg-rose-500" />
                                {risk} at risk
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* address */}
                    <td className="px-3 py-3">
                      <div className="flex items-start gap-2">
                        <Pin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ink-3" />
                        <div>
                          <p className="text-[13px] font-medium leading-tight text-ink">{p.address1}</p>
                          <p className="text-[11px] text-ink-3">
                            {p.city}, {p.state} {p.zip}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* units */}
                    <td className="px-3 py-3">
                      <div className="flex flex-col items-center gap-1">
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-ink">
                          <Users className="h-3.5 w-3.5 text-ink-3" />
                          {occ}/{p.units.length}
                        </span>
                        <div className="w-16">
                          <Bar
                            value={occ / p.units.length}
                            tone={occ === p.units.length ? "emerald" : "amber"}
                            delay={idx * 40}
                            height={4}
                          />
                        </div>
                      </div>
                    </td>

                    {/* balance */}
                    <td className="px-3 py-3">
                      <div className="flex items-center justify-end gap-3">
                        <div className="flex flex-col items-end">
                          <span
                            className={cn(
                              "text-base font-extrabold tabular-nums leading-none",
                              sev === "good" && "text-emerald-600 dark:text-emerald-400",
                              sev === "warn" && "text-amber-600 dark:text-amber-400",
                              sev === "bad" && "text-rose-600 dark:text-rose-400",
                            )}
                          >
                            {bal === 0 ? "Paid" : currency(bal)}
                          </span>
                          <span
                            className={cn(
                              "mt-1 inline-flex items-center gap-0.5 rounded px-1.5 py-0.5 text-[9px] font-bold",
                              bal === 0
                                ? "bg-emerald-50 dark:bg-emerald-400/10 text-emerald-600 dark:text-emerald-400"
                                : rising
                                  ? "bg-rose-50 dark:bg-rose-400/10 text-rose-600 dark:text-rose-400"
                                  : "bg-emerald-50 dark:bg-emerald-400/10 text-emerald-600 dark:text-emerald-400",
                            )}
                          >
                            {bal === 0 ? (
                              "no arrears"
                            ) : (
                              <>
                                {rising ? "▲" : "▼"} {currency(Math.abs(delta))} vs last mo
                              </>
                            )}
                          </span>
                        </div>
                        <Sparkline
                          data={p.trend}
                          width={78}
                          height={30}
                          strokeWidth={1.8}
                          tone={sev === "bad" ? "rose" : sev === "warn" ? "amber" : "indigo"}
                          className="hidden sm:block"
                        />
                      </div>
                    </td>

                    {/* trailing chevron */}
                    <td className="px-3 py-3 text-right">
                      <span
                        className={cn(
                          "inline-flex text-slate-300 transition-all duration-300",
                          isOpen ? "rotate-180 text-indigo-500 dark:text-indigo-300" : "group-hover:text-indigo-400",
                        )}
                      >
                        {isOpen ? <ChevronsUp className="h-4 w-4" /> : <ChevronsDown className="h-4 w-4" />}
                      </span>
                    </td>
                  </tr>

                  {/* ---------- DETAIL ROW ---------- */}
                  <tr
                    key={`${p.code}-detail`}
                    className={cn(
                      "transition-colors",
                      isOpen ? "bg-canvas/40" : "bg-transparent",
                    )}
                  >
                    <td colSpan={8} className={cn("px-3 pt-0", isOpen ? "pb-3" : "pb-0")}>
                      <Collapse open={isOpen}>
                        <div style={{ animation: isOpen ? "riseIn .45s ease-out both" : undefined }}>
                          <PropertyDetail property={p} />
                        </div>
                      </Collapse>
                    </td>
                  </tr>
                </Fragment>
              );
            })}

            {rows.length === 0 && (
              <tr>
                <td colSpan={8} className="px-6 py-16 text-center">
                  <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-surface-2 text-ink-3">
                    <Pin className="h-6 w-6" />
                  </div>
                  <p className="mt-3 text-sm font-semibold text-ink-2">No properties match your filters</p>
                  <p className="text-xs text-ink-3">Try clearing the search or switching the status filter.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
