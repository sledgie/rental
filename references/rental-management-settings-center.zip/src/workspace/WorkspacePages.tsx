import {
  ArrowRight,
  ArrowUpRight,
  Bell,
  Building2,
  CalendarClock,
  CheckCircle2,
  ClipboardList,
  FileSignature,
  FileText,
  Hammer,
  Landmark,
  LayoutDashboard,
  PieChart,
  Plus,
  Settings2,
  TrendingUp,
  Users,
  Wallet,
  Wrench,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { CATEGORY_MAP } from "@/settings/catalog";
import { Badge, Button, Card, CardBody, CardHeader } from "@/settings/components/ui";
import { useSettings } from "@/settings/store";
import type { CategoryId } from "@/settings/types";
import { relativeTime } from "@/settings/utils";

export type ModuleId =
  | "properties"
  | "leases"
  | "tenants"
  | "maintenance"
  | "projects"
  | "accounting"
  | "reports"
  | "documents"
  | "automation";

export const MODULES: Record<
  ModuleId,
  {
    label: string;
    description: string;
    icon: LucideIcon;
    related: CategoryId;
    stats: Array<{ label: string; value: string; detail: string }>;
    rows: Array<{ name: string; detail: string; meta: string; status: string; tone: "green" | "amber" | "blue" | "gray" }>;
    note: string;
  }
> = {
  properties: {
    label: "Properties & units",
    description: "Manage your rental portfolio, unit details and property-level settings.",
    icon: Building2,
    related: "property",
    stats: [
      { label: "Properties", value: "24", detail: "8 single-family · 16 multi-unit" },
      { label: "Total units", value: "186", detail: "179 currently occupied" },
      { label: "Occupancy", value: "96.4%", detail: "+1.8% since last quarter" },
    ],
    rows: [
      { name: "Maple Court Apartments", detail: "Portland, OR · 24 units", meta: "$42,000 monthly rent", status: "Fully occupied", tone: "green" },
      { name: "Harborline Lofts", detail: "Portland, OR · 18 units", meta: "$35,100 monthly rent", status: "95% occupied", tone: "green" },
      { name: "Cedar Heights", detail: "Beaverton, OR · 12 units", meta: "$19,800 monthly rent", status: "1 unit turnover", tone: "amber" },
      { name: "The Grove Townhomes", detail: "Lake Oswego, OR · 16 units", meta: "$38,400 monthly rent", status: "Fully occupied", tone: "green" },
    ],
    note: "Property, unit and leasing defaults are configured in Settings. Adding and editing properties stays in this module.",
  },
  leases: {
    label: "Leases",
    description: "Track active leases, renewals, move-ins and signed documents.",
    icon: FileSignature,
    related: "property",
    stats: [
      { label: "Active leases", value: "179", detail: "Across 24 properties" },
      { label: "Renewals due", value: "8", detail: "Within the next 60 days" },
      { label: "Expiring notices", value: "3", detail: "Require action this month" },
    ],
    rows: [
      { name: "Jordan Rivera · Unit 4B", detail: "Maple Court Apartments", meta: "Ends Mar 31, 2027", status: "Active", tone: "green" },
      { name: "Sasha Patel · Unit 12", detail: "Cedar Heights", meta: "Ends Dec 31, 2026", status: "Renewal due", tone: "amber" },
      { name: "Noah Williams · 88 Cedar St", detail: "Single-family home", meta: "Ends Jun 30, 2026", status: "Notice given", tone: "blue" },
    ],
    note: "Lease templates, renewal notice periods and checklists live in Property & leasing settings.",
  },
  tenants: {
    label: "Tenants",
    description: "Manage tenant profiles, applications and communication history.",
    icon: Users,
    related: "property",
    stats: [
      { label: "Active tenants", value: "179", detail: "Plus 4 approved applicants" },
      { label: "Applications", value: "6", detail: "2 awaiting review" },
      { label: "Documents outstanding", value: "3", detail: "Renter's insurance or ID" },
    ],
    rows: [
      { name: "Jordan Rivera", detail: "Maple Court · Unit 4B", meta: "Since Aug 2023", status: "Current", tone: "green" },
      { name: "Sasha Patel", detail: "Cedar Heights · Unit 12", meta: "Since May 2024", status: "Renewal due", tone: "amber" },
      { name: "Amara Cole", detail: "Harborline · Unit 6", meta: "Application under review", status: "Applicant", tone: "blue" },
    ],
    note: "Tenant document requirements and onboarding checklists are managed in Settings.",
  },
  maintenance: {
    label: "Maintenance",
    description: "Coordinate requests, work orders, vendors and inspections.",
    icon: Wrench,
    related: "maintenance",
    stats: [
      { label: "Open work orders", value: "12", detail: "3 high priority" },
      { label: "Average response", value: "6.4 hr", detail: "Within target" },
      { label: "Emergency requests", value: "1", detail: "Assigned to on-call" },
    ],
    rows: [
      { name: "WO-2026-0238 · Kitchen faucet", detail: "Maple Court · Unit 4B", meta: "Assigned to Rivers Plumbing", status: "In progress", tone: "blue" },
      { name: "WO-2026-0237 · No heat", detail: "Cedar Heights · Unit 7", meta: "Priority 1 · on-call notified", status: "Emergency", tone: "amber" },
      { name: "WO-2026-0236 · Gutter repair", detail: "The Grove · Building B", meta: "Vendor estimate requested", status: "Triage", tone: "gray" },
    ],
    note: "Work order numbering, priorities, category lists and vendor rules are configured in Maintenance & vendors.",
  },
  projects: {
    label: "Capital projects",
    description: "Plan and track renovations, improvements and project budgets.",
    icon: Hammer,
    related: "projects",
    stats: [
      { label: "Active projects", value: "4", detail: "2 in progress · 2 planning" },
      { label: "Approved budget", value: "$186,500", detail: "Spent to date $92,400" },
      { label: "Over-warning budget", value: "1", detail: "Interior refresh at 87%" },
    ],
    rows: [
      { name: "PRJ-2026-0118 · Lobby refresh", detail: "Harborline Lofts", meta: "$74,000 budget · 42% spent", status: "In progress", tone: "green" },
      { name: "PRJ-2026-0117 · Roof replacement", detail: "Cedar Heights", meta: "$62,500 budget · planning", status: "Approved", tone: "blue" },
      { name: "PRJ-2026-0116 · Unit turns", detail: "Maple Court · 3 units", meta: "$28,000 budget · 87% spent", status: "Budget warning", tone: "amber" },
    ],
    note: "Project categories, thresholds and documentation requirements live in Projects & capital settings.",
  },
  accounting: {
    label: "Accounting",
    description: "Invoices, rent collection, expenses and deposit accounting.",
    icon: Landmark,
    related: "financial",
    stats: [
      { label: "Collected this month", value: "$184,250", detail: "92.4% of scheduled rent" },
      { label: "Outstanding", value: "$15,120", detail: "7 invoices past due" },
      { label: "Deposits held", value: "$342,800", detail: "Across 179 active leases" },
    ],
    rows: [
      { name: "INV-2026-1041", detail: "Maple Court · February rent", meta: "$1,850.00 · due Mar 1", status: "Paid", tone: "green" },
      { name: "INV-2026-1040", detail: "Cedar Heights · February rent", meta: "$1,640.00 · 4 days late", status: "Overdue", tone: "amber" },
      { name: "INV-2026-1039", detail: "Harborline Lofts · parking", meta: "$175.00 · due Mar 10", status: "Sent", tone: "blue" },
    ],
    note: "Chart of accounts, invoicing rules, late-fee settings and approval thresholds are configured in Accounting & financials.",
  },
  reports: {
    label: "Reports",
    description: "Portfolio performance, rent roll, owner statements and exports.",
    icon: PieChart,
    related: "financial",
    stats: [
      { label: "Net operating income", value: "$121,840", detail: "Year to date" },
      { label: "Expense ratio", value: "31.8%", detail: "2.4 pts below last year" },
      { label: "Reports scheduled", value: "5", detail: "Monthly owner statements" },
    ],
    rows: [
      { name: "Rent roll summary", detail: "All active leases · February", meta: "Generated Feb 1", status: "Ready", tone: "green" },
      { name: "Owner statement · Chen", detail: "4 properties · February", meta: "Draft · needs review", status: "Draft", tone: "amber" },
      { name: "Property P&L", detail: "Portfolio · year to date", meta: "Generated Feb 24", status: "Ready", tone: "green" },
    ],
    note: "Default reporting periods and financial display formats are configured in Settings.",
  },
  documents: {
    label: "Documents",
    description: "Lease packets, property records, compliance files and signatures.",
    icon: FileText,
    related: "documents",
    stats: [
      { label: "Documents", value: "1,284", detail: "Across 24 properties" },
      { label: "Outstanding signatures", value: "3", detail: "E-sign provider disconnected" },
      { label: "Expiring documents", value: "2", detail: "Vendor insurance certificates" },
    ],
    rows: [
      { name: "Maple-Court_Unit-4B_Lease_2026-02-01.pdf", detail: "Leases & addenda", meta: "Uploaded Feb 1 · 1.2 MB", status: "Signed", tone: "green" },
      { name: "Cedar-Heights_Insurance_2026.pdf", detail: "Property records", meta: "Expires in 18 days", status: "Expiring", tone: "amber" },
      { name: "Harborline_Lobby-Refresh_Scope.pdf", detail: "Project documents", meta: "Uploaded Feb 18 · 860 KB", status: "Current", tone: "green" },
    ],
    note: "Upload rules, document naming, retention and e-signature defaults are configured in Documents & e-signatures.",
  },
  automation: {
    label: "Workflow automation",
    description: "Build and monitor event-driven workflows for your team.",
    icon: Zap,
    related: "workflow",
    stats: [
      { label: "Active workflows", value: "6", detail: "Execution enabled" },
      { label: "Runs this month", value: "142", detail: "98.6% successful" },
      { label: "Failed runs", value: "2", detail: "Retried automatically" },
    ],
    rows: [
      { name: "New lease → welcome packet", detail: "Trigger: lease activated", meta: "Executed 18 times this month", status: "Active", tone: "green" },
      { name: "Emergency request → on-call", detail: "Trigger: priority 1 work order", meta: "Requires external message approval", status: "Needs approval", tone: "amber" },
      { name: "Invoice overdue → reminder", detail: "Trigger: 5 days overdue", meta: "Excluded from financial changes", status: "Paused", tone: "gray" },
    ],
    note: "Global automation guardrails, retries and execution limits live in Workflow automation settings.",
  },
};

export function OverviewPage({
  onOpenSettings,
  onOpenModule,
}: {
  onOpenSettings: (category: CategoryId) => void;
  onOpenModule: (module: ModuleId) => void;
}) {
  const { currentUser, activeOrg, activity, notify, orgSettings, prefs } = useSettings();
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  const allKpis = [
    { key: "rentCollection" as const, label: "Rent collected", value: "$184,250", detail: "92.4% of scheduled rent", delta: "+6.2%", icon: Wallet, tone: "bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400" },
    { key: "occupancy" as const, label: "Occupancy", value: "96.4%", detail: "179 of 186 units", delta: "+1.8%", icon: Building2, tone: "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400" },
    { key: "maintenance" as const, label: "Open work orders", value: "12", detail: "3 are high priority", delta: "−4", icon: Wrench, tone: "bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400" },
    { key: "renewals" as const, label: "Renewals due", value: "8", detail: "Next 60 days", delta: "2 urgent", icon: FileSignature, tone: "bg-violet-50 text-violet-600 dark:bg-violet-500/10 dark:text-violet-400" },
  ];
  const kpis = allKpis.filter((kpi) => prefs.widgets?.[kpi.key] !== false);

  return (
    <div className="mx-auto w-full max-w-[1380px] px-4 pb-16 pt-6 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-[11px] font-medium text-slate-400">{new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}</p>
          <h1 className="mt-1 text-[26px] font-semibold tracking-[-0.03em] text-slate-900 dark:text-white">{greeting}, {currentUser.firstName}</h1>
          <p className="mt-1 text-[13px] text-slate-500 dark:text-slate-400">Here's what's happening across {orgSettings.organization?.displayName?.trim() || activeOrg.name} today.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button type="button" variant="secondary" icon={Plus} onClick={() => notify("Creating records is outside this prototype", "info", "This demo focuses on the Settings Center and its integrations.")}>
            New lease
          </Button>
          <Button type="button" variant="primary" icon={Settings2} onClick={() => onOpenSettings("organization")}>
            Settings
          </Button>
        </div>
      </div>

      {kpis.length === 0 ? (
        <Card className="mt-6">
          <CardBody className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-[12.5px] font-medium text-slate-800 dark:text-slate-100">All dashboard widgets are hidden</p>
              <p className="mt-0.5 text-[11.5px] text-slate-500 dark:text-slate-400">Enable summary widgets in your personal preferences to see portfolio metrics here.</p>
            </div>
            <Button type="button" size="sm" variant="secondary" icon={Settings2} onClick={() => onOpenSettings("personal")}>Manage widgets</Button>
          </CardBody>
        </Card>
      ) : null}
      <div className={`mt-6 grid gap-3.5 sm:grid-cols-2 ${kpis.length === 3 ? "xl:grid-cols-3" : kpis.length <= 2 ? "xl:grid-cols-2" : "xl:grid-cols-4"}`}>
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="p-4">
            <div className="flex items-start justify-between gap-2">
              <p className="text-[11.5px] font-medium text-slate-500 dark:text-slate-400">{kpi.label}</p>
              <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${kpi.tone}`}>
                <kpi.icon className="h-4 w-4" />
              </span>
            </div>
            <p className="mt-2 text-[23px] font-semibold tracking-[-0.03em] text-slate-900 dark:text-white">{kpi.value}</p>
            <div className="mt-1 flex flex-wrap items-center gap-2">
              <span className={`inline-flex items-center gap-0.5 rounded px-1 py-0.5 text-[10px] font-medium ${kpi.delta.startsWith("+") ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400" : "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400"}`}>
                {kpi.delta.startsWith("+") ? <TrendingUp className="h-2.5 w-2.5" /> : null} {kpi.delta}
              </span>
              <span className="text-[10.5px] text-slate-400">{kpi.detail}</span>
            </div>
          </Card>
        ))}
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.55fr_1fr]">
        <div className="space-y-5">
          <Card>
            <CardHeader
              title="Portfolio performance"
              description="Occupancy and scheduled rent across your top properties."
              icon={Building2}
              aside={<button type="button" onClick={() => onOpenModule("properties")} className="inline-flex items-center gap-1 text-[11.5px] font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400">All properties <ArrowRight className="h-3 w-3" /></button>}
            />
            <CardBody className="space-y-3.5">
              {[
                { name: "Maple Court Apartments", city: "Portland, OR", units: 24, occupancy: 100, rent: "$42,000" },
                { name: "Harborline Lofts", city: "Portland, OR", units: 18, occupancy: 95, rent: "$35,100" },
                { name: "Cedar Heights", city: "Beaverton, OR", units: 12, occupancy: 92, rent: "$19,800" },
                { name: "The Grove Townhomes", city: "Lake Oswego, OR", units: 16, occupancy: 100, rent: "$38,400" },
              ].map((property) => (
                <div key={property.name} className="flex flex-wrap items-center gap-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-400 ring-1 ring-slate-200/70 dark:bg-slate-800 dark:text-slate-400 dark:ring-slate-700">
                    <Building2 className="h-3.5 w-3.5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12.5px] font-medium text-slate-800 dark:text-slate-100">{property.name}</p>
                    <p className="text-[10.5px] text-slate-400">{property.city} · {property.units} units</p>
                  </div>
                  <div className="hidden w-28 sm:block">
                    <div className="h-1.5 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                      <div className="h-full rounded-full bg-emerald-500" style={{ width: `${property.occupancy}%` }} />
                    </div>
                    <p className="mt-1 text-right text-[9.5px] text-slate-400">{property.occupancy}% occupied</p>
                  </div>
                  <p className="w-16 text-right text-[12px] font-semibold text-slate-700 dark:text-slate-200">{property.rent}</p>
                </div>
              ))}
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Settings shortcuts" description="Jump into the workspace configuration most teams adjust." icon={Settings2} />
            <CardBody className="grid gap-2.5 sm:grid-cols-2">
              {(["organization", "financial", "maintenance", "notifications", "property", "personal"] as CategoryId[]).map((categoryId) => {
                const item = CATEGORY_MAP[categoryId];
                return (
                  <button
                    key={categoryId}
                    type="button"
                    onClick={() => onOpenSettings(categoryId)}
                    className="group flex items-start gap-2.5 rounded-lg border border-slate-200 p-3 text-left transition hover:border-blue-300 hover:bg-blue-50/30 dark:border-slate-700 dark:hover:border-blue-500/40 dark:hover:bg-blue-500/5"
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500 ring-1 ring-slate-200/70 group-hover:text-blue-600 dark:bg-slate-800 dark:text-slate-400 dark:ring-slate-700">
                      <item.icon className="h-4 w-4" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-1 text-[12px] font-medium text-slate-800 dark:text-slate-100">{item.shortLabel} <ArrowUpRight className="h-3 w-3 text-slate-300" /></span>
                      <span className="mt-0.5 line-clamp-2 block text-[10.5px] leading-relaxed text-slate-400">{item.description}</span>
                    </span>
                  </button>
                );
              })}
            </CardBody>
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader title="Rent collection" icon={Wallet} aside={<Badge tone="green">On track</Badge>} />
            <CardBody>
              <div className="flex items-center gap-5">
                <div className="relative flex h-24 w-24 shrink-0 items-center justify-center rounded-full" style={{ background: "conic-gradient(#2563eb 0 82%, #22c55e 82% 92.4%, #e2e8f0 92.4% 100%)" }}>
                  <div className="flex h-[74px] w-[74px] flex-col items-center justify-center rounded-full bg-white dark:bg-slate-900">
                    <span className="text-[17px] font-semibold tracking-tight text-slate-900 dark:text-white">92.4%</span>
                    <span className="text-[8.5px] uppercase tracking-wide text-slate-400">collected</span>
                  </div>
                </div>
                <div className="space-y-2 text-[11px]">
                  <p className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400"><span className="h-2 w-2 rounded-full bg-blue-600" /> Collected <strong className="ml-auto text-slate-700 dark:text-slate-200">$184,250</strong></p>
                  <p className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400"><span className="h-2 w-2 rounded-full bg-emerald-500" /> Late fees <strong className="ml-auto text-slate-700 dark:text-slate-200">$2,420</strong></p>
                  <p className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400"><span className="h-2 w-2 rounded-full bg-slate-200" /> Outstanding <strong className="ml-auto text-slate-700 dark:text-slate-200">$15,120</strong></p>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-2 text-[10.5px] text-slate-500 dark:bg-slate-800/50 dark:text-slate-400">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" /> 173 of 186 scheduled charges settled.
              </div>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Recent activity" icon={LayoutDashboard} aside={<button type="button" onClick={() => onOpenSettings("organization")} className="text-[11px] font-semibold text-blue-600 dark:text-blue-400">View all</button>} />
            <CardBody className="space-y-3.5">
              {activity.slice(0, 5).map((event) => (
                <div key={event.id} className="flex items-start gap-2.5">
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-slate-100 text-[8.5px] font-semibold text-slate-500 dark:bg-slate-800 dark:text-slate-300">{event.actorInitials}</span>
                  <div className="min-w-0">
                    <p className="text-[11.5px] font-medium leading-5 text-slate-700 dark:text-slate-200">{event.action}</p>
                    <p className="truncate text-[10.5px] text-slate-400">{event.actor} · {relativeTime(event.at)}</p>
                  </div>
                </div>
              ))}
            </CardBody>
          </Card>

          <Card>
            <CardBody className="flex items-start gap-3">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400"><Bell className="h-4 w-4" /></span>
              <div>
                <p className="text-[12px] font-medium text-slate-800 dark:text-slate-100">Rent reminders are configured</p>
                <p className="mt-0.5 text-[10.5px] leading-relaxed text-slate-400">Delivery is simulated in this prototype. Review channels and communication hours in settings.</p>
                <button type="button" onClick={() => onOpenSettings("notifications")} className="mt-1.5 text-[11px] font-semibold text-blue-600 dark:text-blue-400">Review notifications</button>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}

export function ModulePreview({
  moduleId,
  onOpenSettings,
}: {
  moduleId: ModuleId;
  onOpenSettings: (category: CategoryId) => void;
}) {
  const module = MODULES[moduleId];
  const Icon = module.icon;
  const related = CATEGORY_MAP[module.related];

  return (
    <div className="mx-auto w-full max-w-[1280px] px-4 pb-16 pt-6 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-[24px] font-semibold tracking-[-0.03em] text-slate-900 dark:text-white">{module.label}</h1>
            <Badge tone="gray">Module preview</Badge>
          </div>
          <p className="mt-1 max-w-2xl text-[13px] text-slate-500 dark:text-slate-400">{module.description}</p>
        </div>
        <Button type="button" variant="secondary" icon={Settings2} onClick={() => onOpenSettings(module.related)}>
          Configure defaults
        </Button>
      </div>

      <div className="mt-5 grid gap-3.5 sm:grid-cols-3">
        {module.stats.map((stat) => (
          <Card key={stat.label} className="p-4">
            <p className="text-[11.5px] font-medium text-slate-500 dark:text-slate-400">{stat.label}</p>
            <p className="mt-1.5 text-[22px] font-semibold tracking-[-0.03em] text-slate-900 dark:text-white">{stat.value}</p>
            <p className="mt-0.5 text-[10.5px] text-slate-400">{stat.detail}</p>
          </Card>
        ))}
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.7fr_1fr]">
        <Card>
          <CardHeader title="Sample records" description="Read-only mock data that illustrates where these settings apply." icon={module.icon} />
          <CardBody className="space-y-2.5">
            {module.rows.map((row) => (
              <div key={row.name} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 px-3 py-2.5 dark:border-slate-700">
                <div className="flex min-w-0 items-center gap-2.5">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-slate-50 text-slate-400 ring-1 ring-slate-200/70 dark:bg-slate-800 dark:ring-slate-700">
                    <Icon className="h-3.5 w-3.5" />
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[12px] font-medium text-slate-800 dark:text-slate-100">{row.name}</p>
                    <p className="truncate text-[10.5px] text-slate-400">{row.detail} · {row.meta}</p>
                  </div>
                </div>
                <Badge tone={row.tone}>{row.status}</Badge>
              </div>
            ))}
          </CardBody>
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader title="Related settings" description="Defaults that shape records created in this module." icon={related.icon} />
            <CardBody className="space-y-3">
              <div>
                <p className="text-[12.5px] font-medium text-slate-800 dark:text-slate-100">{related.label}</p>
                <p className="mt-0.5 text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">{related.description}</p>
              </div>
              <Button type="button" variant="primary" size="sm" iconRight={ArrowRight} onClick={() => onOpenSettings(related.id)} className="w-full">
                Open settings
              </Button>
            </CardBody>
          </Card>
          <Card>
            <CardBody className="flex items-start gap-2.5">
              <ClipboardList className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
              <p className="text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                {module.note} Record creation and editing are intentionally outside this Settings Center prototype.
              </p>
            </CardBody>
          </Card>
          <Card>
            <CardBody className="flex items-start gap-2.5">
              <CalendarClock className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
              <div>
                <p className="text-[12px] font-medium text-slate-800 dark:text-slate-100">Need more from this module?</p>
                <p className="mt-0.5 text-[11px] leading-relaxed text-slate-400">This demo prioritizes complete settings workflows. Mock records demonstrate the operational context.</p>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}
