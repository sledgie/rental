import type {
  ActivityEvent,
  Invitation,
  ListItem,
  Member,
  Organization,
  OrgSettings,
  Role,
  UserPreferences,
} from "./types";

const now = Date.now();
const minutesAgo = (m: number) => new Date(now - m * 60_000).toISOString();
const daysAgo = (d: number) => new Date(now - d * 86_400_000).toISOString();

export const CURRENT_USER = {
  id: "usr_avery",
  name: "Avery Bennett",
  firstName: "Avery",
  email: "avery@northstarproperties.com",
  initials: "AB",
  title: "Director of Operations",
};

export const ORGANIZATIONS: Organization[] = [
  {
    id: "northstar",
    name: "Northstar Property Group",
    shortName: "Northstar",
    monogram: "NP",
    color: "bg-blue-600",
    ring: "ring-blue-100",
    role: "Owner",
    plan: "Scale",
    propertyCount: 24,
    unitCount: 186,
    memberCount: 9,
    city: "Portland, OR",
  },
  {
    id: "cedar",
    name: "Cedar & Stone Residential",
    shortName: "Cedar & Stone",
    monogram: "CS",
    color: "bg-emerald-600",
    ring: "ring-emerald-100",
    role: "Administrator",
    plan: "Growth",
    propertyCount: 11,
    unitCount: 74,
    memberCount: 6,
    city: "Austin, TX",
  },
  {
    id: "harborview",
    name: "Harborview Estates",
    shortName: "Harborview",
    monogram: "HE",
    color: "bg-violet-600",
    ring: "ring-violet-100",
    role: "Read-Only / Auditor",
    plan: "Essential",
    propertyCount: 8,
    unitCount: 42,
    memberCount: 4,
    city: "Seattle, WA",
  },
  {
    id: "bracken",
    name: "Bracken & Co. Property",
    shortName: "Bracken & Co.",
    monogram: "BC",
    color: "bg-amber-600",
    ring: "ring-amber-100",
    role: "Accountant",
    plan: "Growth",
    propertyCount: 16,
    unitCount: 98,
    memberCount: 7,
    city: "Denver, CO",
  },
  {
    id: "ridgeline",
    name: "Ridgeline Asset Management",
    shortName: "Ridgeline",
    monogram: "RA",
    color: "bg-teal-600",
    ring: "ring-teal-100",
    role: "Property Manager",
    plan: "Growth",
    propertyCount: 19,
    unitCount: 122,
    memberCount: 8,
    city: "Sacramento, CA",
  },
  {
    id: "ironwood",
    name: "Ironwood Tenant Services",
    shortName: "Ironwood",
    monogram: "IT",
    color: "bg-rose-600",
    ring: "ring-rose-100",
    role: "Maintenance Staff",
    plan: "Essential",
    propertyCount: 6,
    unitCount: 31,
    memberCount: 4,
    city: "Phoenix, AZ",
  },
];

const member = (
  id: string,
  name: string,
  email: string,
  role: Role,
  status: Member["status"],
  tone: string,
  lastActive: string,
): Member => ({
  id,
  name,
  email,
  role,
  status,
  initials: name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join(""),
  avatarTone: tone,
  lastActive,
});

export const MEMBERS: Record<string, Member[]> = {
  northstar: [
    member("usr_avery", "Avery Bennett", "avery@northstarproperties.com", "Owner", "Active", "bg-blue-600", "Active now"),
    member("usr_marcus", "Marcus Chen", "marcus@northstarproperties.com", "Administrator", "Active", "bg-slate-700", "18 min ago"),
    member("usr_priya", "Priya Raman", "priya@northstarproperties.com", "Property Manager", "Active", "bg-emerald-600", "1 hr ago"),
    member("usr_daniel", "Daniel Okafor", "daniel@northstarproperties.com", "Accountant", "Active", "bg-amber-600", "3 hrs ago"),
    member("usr_lena", "Lena Kowalski", "lena@northstarproperties.com", "Maintenance Staff", "Active", "bg-violet-600", "Yesterday"),
    member("usr_theo", "Theo Marsh", "theo@northstarproperties.com", "Read-Only / Auditor", "Active", "bg-slate-500", "2 days ago"),
    member("usr_sofia", "Sofia Alvarez", "sofia@northstarproperties.com", "Property Manager", "Active", "bg-rose-600", "4 hrs ago"),
    member("usr_jonah", "Jonah Reed", "jonah@northstarproperties.com", "Maintenance Staff", "Suspended", "bg-slate-500", "3 weeks ago"),
    member("usr_ada", "Ada Whitfield", "ada@northstarproperties.com", "Administrator", "Active", "bg-teal-600", "Yesterday"),
  ],
  cedar: [
    member("usr_avery", "Avery Bennett", "avery@northstarproperties.com", "Administrator", "Active", "bg-blue-600", "Active now"),
    member("usr_cara", "Cara Stone", "cara@cedarstone.com", "Owner", "Active", "bg-emerald-600", "32 min ago"),
    member("usr_eli", "Eli Navarro", "eli@cedarstone.com", "Property Manager", "Active", "bg-slate-700", "2 hrs ago"),
    member("usr_nina", "Nina Patel", "nina@cedarstone.com", "Accountant", "Active", "bg-amber-600", "Yesterday"),
    member("usr_omar", "Omar Haddad", "omar@cedarstone.com", "Maintenance Staff", "Active", "bg-violet-600", "2 days ago"),
    member("usr_rae", "Rae Kim", "rae@cedarstone.com", "Read-Only / Auditor", "Invited", "bg-rose-600", "Invitation pending"),
  ],
  harborview: [
    member("usr_avery", "Avery Bennett", "avery@northstarproperties.com", "Read-Only / Auditor", "Active", "bg-blue-600", "Active now"),
    member("usr_wes", "Wes Holloway", "wes@harborview.com", "Owner", "Active", "bg-violet-600", "1 hr ago"),
    member("usr_ines", "Ines Duarte", "ines@harborview.com", "Property Manager", "Active", "bg-emerald-600", "3 hrs ago"),
    member("usr_gal", "Gal Rosen", "gal@harborview.com", "Accountant", "Active", "bg-amber-600", "Yesterday"),
  ],
  bracken: [
    member("usr_avery", "Avery Bennett", "avery@northstarproperties.com", "Accountant", "Active", "bg-blue-600", "Active now"),
    member("usr_marco", "Marco Bracken", "marco@brackenco.com", "Owner", "Active", "bg-amber-600", "12 min ago"),
    member("usr_yuki", "Yuki Tan", "yuki@brackenco.com", "Administrator", "Active", "bg-slate-700", "4 hrs ago"),
    member("usr_esme", "Esme Laurent", "esme@brackenco.com", "Property Manager", "Active", "bg-emerald-600", "Yesterday"),
    member("usr_ravi", "Ravi Shah", "ravi@brackenco.com", "Accountant", "Active", "bg-teal-600", "2 hrs ago"),
    member("usr_tom", "Tom Baird", "tom@brackenco.com", "Maintenance Staff", "Active", "bg-rose-600", "3 days ago"),
    member("usr_ivy", "Ivy Chen", "ivy@brackenco.com", "Read-Only / Auditor", "Active", "bg-violet-600", "Last week"),
  ],
  ridgeline: [
    member("usr_avery", "Avery Bennett", "avery@northstarproperties.com", "Property Manager", "Active", "bg-blue-600", "Active now"),
    member("usr_cole", "Cole Bennett", "cole@ridgeline.com", "Owner", "Active", "bg-teal-600", "38 min ago"),
    member("usr_maya", "Maya Singh", "maya@ridgeline.com", "Administrator", "Active", "bg-slate-700", "2 hrs ago"),
    member("usr_finn", "Finn Walsh", "finn@ridgeline.com", "Maintenance Staff", "Active", "bg-violet-600", "Yesterday"),
    member("usr_luz", "Luz Herrera", "luz@ridgeline.com", "Accountant", "Active", "bg-amber-600", "2 days ago"),
  ],
  ironwood: [
    member("usr_avery", "Avery Bennett", "avery@northstarproperties.com", "Maintenance Staff", "Active", "bg-blue-600", "Active now"),
    member("usr_rhea", "Rhea Osei", "rhea@ironwood.com", "Owner", "Active", "bg-rose-600", "1 hr ago"),
    member("usr_ben", "Ben Castillo", "ben@ironwood.com", "Property Manager", "Active", "bg-emerald-600", "4 hrs ago"),
    member("usr_kat", "Kat Moreau", "kat@ironwood.com", "Administrator", "Active", "bg-slate-700", "2 days ago"),
  ],
};

export const INVITATIONS: Record<string, Invitation[]> = {
  northstar: [
    { id: "inv_1", email: "camille.ro@contractor.co", role: "Maintenance Staff", sentAt: daysAgo(2), expiresInDays: 5 },
    { id: "inv_2", email: "noah@finbridgecpa.com", role: "Accountant", sentAt: daysAgo(5), expiresInDays: 2 },
  ],
  cedar: [
    { id: "inv_3", email: "rae.kim@cedarstone.com", role: "Read-Only / Auditor", sentAt: daysAgo(1), expiresInDays: 6 },
  ],
  harborview: [],
  bracken: [],
  ridgeline: [{ id: "inv_4", email: "oliver@ridgeline.com", role: "Accountant", sentAt: daysAgo(3), expiresInDays: 4 }],
  ironwood: [],
};

export const INITIAL_ACTIVITY: Record<string, ActivityEvent[]> = {
  northstar: [
    {
      id: "act_1",
      actor: "Marcus Chen",
      actorInitials: "MC",
      action: "Updated financial defaults",
      detail: "Late-fee policy and invoice payment terms",
      at: minutesAgo(42),
      category: "financial",
    },
    {
      id: "act_2",
      actor: "Priya Raman",
      actorInitials: "PR",
      action: "Connected email delivery",
      detail: "Postmark sandbox · simulated",
      at: minutesAgo(190),
      category: "integrations",
    },
    {
      id: "act_3",
      actor: "Avery Bennett",
      actorInitials: "AB",
      action: "Invited a team member",
      detail: "northstarproperties.com · Maintenance Staff",
      at: minutesAgo(430),
    },
    {
      id: "act_4",
      actor: "Daniel Okafor",
      actorInitials: "DO",
      action: "Exported activity log",
      detail: "CSV · last 90 days",
      at: daysAgo(1),
      category: "data",
    },
    {
      id: "act_5",
      actor: "Avery Bennett",
      actorInitials: "AB",
      action: "Updated organization profile",
      detail: "Business address and fiscal year",
      at: daysAgo(2),
      category: "organization",
    },
  ],
  cedar: [
    {
      id: "act_c1",
      actor: "Cara Stone",
      actorInitials: "CS",
      action: "Updated leasing defaults",
      detail: "Renewal notice period changed",
      at: minutesAgo(75),
      category: "property",
    },
    {
      id: "act_c2",
      actor: "Eli Navarro",
      actorInitials: "EN",
      action: "Added a maintenance category",
      detail: "Appliance repair",
      at: daysAgo(1),
      category: "maintenance",
    },
  ],
  harborview: [
    {
      id: "act_h1",
      actor: "Wes Holloway",
      actorInitials: "WH",
      action: "Updated security policy",
      detail: "Session timeout set to 30 minutes",
      at: daysAgo(1),
      category: "security",
    },
  ],
  bracken: [
    {
      id: "act_b1",
      actor: "Yuki Tan",
      actorInitials: "YT",
      action: "Updated accounting defaults",
      detail: "Default rental income account",
      at: minutesAgo(120),
      category: "financial",
    },
  ],
  ridgeline: [
    {
      id: "act_r1",
      actor: "Maya Singh",
      actorInitials: "MS",
      action: "Updated leasing defaults",
      detail: "Renewal notice period and tenant documents",
      at: minutesAgo(65),
      category: "property",
    },
  ],
  ironwood: [
    {
      id: "act_i1",
      actor: "Rhea Osei",
      actorInitials: "RO",
      action: "Updated vendor approval rules",
      detail: "Insurance reminder timing",
      at: minutesAgo(210),
      category: "maintenance",
    },
  ],
};

export const ACCOUNT_OPTIONS = [
  { group: "Assets", options: ["1010 · Operating checking", "1020 · Security deposit trust", "1030 · Reserve savings"] },
  { group: "Liabilities", options: ["2100 · Accounts payable", "2200 · Tenant security deposits", "2300 · Owner distributions payable"] },
  { group: "Income", options: ["4100 · Rental income", "4150 · Late fee income", "4200 · Parking & ancillary income"] },
  { group: "Expenses", options: ["6100 · Property taxes", "6200 · Operating expenses", "6300 · Repairs & maintenance", "6400 · Utilities", "6500 · Management fees"] },
];

export const COUNTRIES = ["United States", "Canada", "United Kingdom", "Australia", "New Zealand"];
export const US_STATES = [
  "Arizona", "California", "Colorado", "Florida", "Georgia", "Illinois", "Nevada", "New York", "Oregon", "Texas", "Washington",
];
export const CURRENCIES = [
  "USD — US Dollar", "CAD — Canadian Dollar", "GBP — British Pound", "AUD — Australian Dollar", "EUR — Euro",
];
export const TIMEZONES = [
  "America/Los_Angeles — Pacific", "America/Denver — Mountain", "America/Chicago — Central", "America/New_York — Eastern",
  "America/Phoenix — Arizona", "Europe/London — London", "Australia/Sydney — Sydney",
];
export const FISCAL_MONTHS = [
  "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December",
];
export const LEASE_TEMPLATES = [
  "Standard residential lease (v4)",
  "Month-to-month rental agreement (v2)",
  "Single-family home lease (v3)",
  "Condominium lease addendum (v1)",
];

export const SECURITY_PERMISSIONS = [
  { id: "view_settings", label: "View organization settings", hint: "Read all workspace configuration" },
  { id: "edit_settings", label: "Edit organization settings", hint: "Change workspace-wide defaults" },
  { id: "financial_defaults", label: "Manage financial defaults", hint: "Chart of accounts, rent rules, taxes" },
  { id: "financial_reports", label: "View financial reports", hint: "Income, expenses and owner statements" },
  { id: "properties", label: "Manage properties & leases", hint: "Create and edit portfolio records" },
  { id: "maintenance", label: "Manage maintenance", hint: "Work orders, vendors and approvals" },
  { id: "members", label: "Manage members & roles", hint: "Invite and update team access" },
  { id: "integrations", label: "Manage integrations", hint: "Connect providers and API access" },
  { id: "export_data", label: "Export organization data", hint: "Configuration, activity and reference data" },
  { id: "audit_log", label: "View audit log", hint: "Security and administrative events" },
];

const matrix = (values: Partial<Record<Role, string[]>>): Record<Role, Record<string, boolean>> => {
  const roles: Role[] = [
    "Owner",
    "Administrator",
    "Property Manager",
    "Accountant",
    "Maintenance Staff",
    "Read-Only / Auditor",
  ];
  return roles.reduce(
    (acc, role) => {
      acc[role] = SECURITY_PERMISSIONS.reduce(
        (row, permission) => {
          row[permission.id] = (values[role] ?? []).includes(permission.id);
          return row;
        },
        {} as Record<string, boolean>,
      );
      return acc;
    },
    {} as Record<Role, Record<string, boolean>>,
  );
};

const DEFAULT_MATRIX = matrix({
  Owner: SECURITY_PERMISSIONS.map((p) => p.id),
  Administrator: [
    "view_settings", "edit_settings", "financial_defaults", "financial_reports", "properties", "maintenance",
    "members", "integrations", "export_data", "audit_log",
  ],
  "Property Manager": ["view_settings", "properties", "maintenance", "export_data"],
  Accountant: ["view_settings", "financial_defaults", "financial_reports", "export_data", "audit_log"],
  "Maintenance Staff": ["view_settings", "maintenance"],
  "Read-Only / Auditor": ["view_settings", "financial_reports", "audit_log"],
});

const list = (labels: string[], disableable = false): ListItem[] =>
  labels.map((label, i) => ({
    id: `li_${label.toLowerCase().replace(/[^a-z0-9]+/g, "-")}_${i}`,
    label,
    ...(disableable ? { enabled: true } : {}),
  }));

const notificationEvent = (
  inApp: boolean,
  email: boolean,
  sms: boolean,
  recipients: string,
) => ({ inApp, email, sms, recipients });

const ORG_LOCATIONS: Record<string, { address: string; city: string; state: string; postal: string; zone: string }> = {
  northstar: { address: "1420 NW Everett Street", city: "Portland", state: "Oregon", postal: "97209", zone: "America/Los_Angeles — Pacific" },
  cedar: { address: "88 Congress Avenue", city: "Austin", state: "Texas", postal: "78701", zone: "America/Chicago — Central" },
  harborview: { address: "701 Western Avenue", city: "Seattle", state: "Washington", postal: "98104", zone: "America/Los_Angeles — Pacific" },
  bracken: { address: "1550 Wynkoop Street", city: "Denver", state: "Colorado", postal: "80202", zone: "America/Denver — Mountain" },
  ridgeline: { address: "980 9th Street", city: "Sacramento", state: "California", postal: "95814", zone: "America/Los_Angeles — Pacific" },
  ironwood: { address: "240 N Central Avenue", city: "Phoenix", state: "Arizona", postal: "85004", zone: "America/Phoenix — Arizona" },
};

export function defaultOrganizationSettings(org: Organization): OrgSettings {
  const domain = `${org.shortName.toLowerCase().replace(/[^a-z]/g, "")}.com`;
  const location = ORG_LOCATIONS[org.id] ?? ORG_LOCATIONS.northstar;
  return {
    organization: {
      displayName: org.name,
      legalName: org.name,
      businessType: "Property management company",
      registrationNumber: "OR-2041887",
      logo: "",
      email: `hello@${domain}`,
      phone: org.id === "northstar" ? "(503) 555-0184" : "(512) 555-0142",
      website: `https://www.${domain}`,
      addressLine1: location.address,
      addressLine2: "Suite 410",
      city: location.city,
      state: location.state,
      postalCode: location.postal,
      country: "United States",
      currency: "USD — US Dollar",
      timeZone: location.zone,
      dateFormat: "MMM d, yyyy",
      numberFormat: "1,234.56",
      fiscalYearStart: "January",
      status: org.id === "northstar" ? "Active" : "Active",
      createdAt: org.id === "northstar" ? "March 12, 2019" : "September 4, 2022",
      orgCode: org.id.toUpperCase().slice(0, 3) + "-2041",
      plan: org.plan,
      propertyLevelPermissions: true,
      requireVendorApproval: true,
      autoArchiveSignedLeases: false,
      defaultRentReminders: true,
    },
    general: {
      reportingPeriod: "Month to date",
      portfolioView: "Grid",
      tablePageSize: "25",
      dateFormat: "MMM d, yyyy",
      timeFormat: "12-hour",
      currencyDisplay: "Symbol · $1,250.00",
      confirmDestructive: true,
      defaultSort: "Recently updated",
      defaultFilter: "Active records",
      documentPreview: "Side panel",
    },
    financial: {
      chartOfAccounts: "Standard property chart",
      incomeAccount: "4100 · Rental income",
      operatingExpenseAccount: "6200 · Operating expenses",
      repairExpenseAccount: "6300 · Repairs & maintenance",
      depositLiabilityAccount: "2200 · Tenant security deposits",
      bankAccount: "1010 · Operating checking",
      invoicePrefix: "INV-",
      nextInvoiceNumber: 1042,
      paymentTerms: "Net 15",
      dueDateCalculation: "Issue date + payment terms",
      rentDueDay: 1,
      gracePeriod: 5,
      lateFeeMethod: "Fixed amount",
      lateFeeAmount: 75,
      lateFeePercent: 5,
      lateFeeCap: 250,
      taxName: "State rental tax",
      taxRate: 8.25,
      taxInclusive: false,
      paymentInstructions: `Pay online from the tenant portal. Checks are payable to ${org.name} and must include the unit number. Please allow 3 business days for processing.`,
      depositRefund: "Original payment method within 21 days",
      financialReportingPeriod: "Calendar month",
      approvalThreshold: 5000,
    },
    property: {
      propertyType: "Multi-unit building",
      unitType: "1 bedroom / 1 bathroom",
      leaseDuration: 12,
      rentDueDay: 1,
      renewalNoticeDays: 60,
      renewalReminderDays: 45,
      inspectionFrequency: "Semi-annual",
      leaseTemplate: "Standard residential lease (v4)",
      utilityResponsibility: "Tenant pays electricity; owner pays water & sewer",
      recurringCharges: true,
      prorateFirstMonth: true,
      recurringDueDay: 1,
      moveInChecklist: list([
        "Signed lease and addenda on file",
        "Security deposit and first month received",
        "Keys and access devices issued",
        "Unit photos and meter readings recorded",
        "Utility transfer confirmed",
      ]),
      moveOutChecklist: list([
        "Forwarding address collected",
        "Final walkthrough completed",
        "Keys returned and locks verified",
        "Meter readings and final photos recorded",
        "Deposit disposition scheduled",
      ]),
      tenantDocs: ["Government-issued ID", "Proof of income", "Renter's insurance", "Pet vaccination records"],
    },
    maintenance: {
      workOrderPrefix: "WO-",
      nextWorkOrderNumber: 238,
      categories: [
        { id: "cat_plumbing", label: "Plumbing", enabled: true },
        { id: "cat_electrical", label: "Electrical", enabled: true },
        { id: "cat_hvac", label: "Heating & cooling", enabled: true },
        { id: "cat_appliance", label: "Appliance repair", enabled: true },
        { id: "cat_structural", label: "Structural & roofing", enabled: true },
        { id: "cat_landscaping", label: "Landscaping & grounds", enabled: false },
      ],
      defaultStatus: "Open · Unassigned",
      assignmentMethod: "Property manager triage",
      lowResponse: 48,
      normalResponse: 24,
      highResponse: 8,
      emergencyResponse: 1,
      vendorApproval: true,
      insuranceReminder: true,
      insuranceReminderDays: 30,
      approvalThreshold: 2500,
      checklist: list([
        "Confirm tenant availability for access",
        "Capture request photos and unit details",
        "Assign vendor and confirm ETA",
        "Document completed work and cost",
        "Notify tenant and close work order",
      ]),
      emergencyInstructions:
        "For active leaks, loss of heat, electrical hazards or lockouts, call the on-call line at (503) 555-0199 immediately. Escalate to the duty property manager if there is no response within 15 minutes. Never enter an occupied unit without tenant consent except in an emergency.",
    },
    projects: {
      projectPrefix: "PRJ-",
      nextProjectNumber: 118,
      defaultPriority: "Normal",
      categories: [
        { id: "pc_interior", label: "Interior renovation", enabled: true },
        { id: "pc_exterior", label: "Exterior & curb appeal", enabled: true },
        { id: "pc_systems", label: "Systems & infrastructure", enabled: true },
        { id: "pc_amenity", label: "Amenity improvement", enabled: true },
        { id: "pc_compliance", label: "Code & compliance", enabled: true },
      ],
      statuses: [
        { id: "ps_planning", label: "Planning", enabled: true },
        { id: "ps_approved", label: "Approved", enabled: true },
        { id: "ps_active", label: "In progress", enabled: true },
        { id: "ps_onhold", label: "On hold", enabled: true },
        { id: "ps_complete", label: "Completed", enabled: true },
      ],
      budgetWarningThreshold: 85,
      approvalThreshold: 10000,
      managerAssignment: "Assign property manager by portfolio",
      budgetOverrunNotify: true,
      overrunRecipients: "Owners & Administrators",
      requiredDocs: list([
        "Approved scope of work",
        "Contractor estimate or bid",
        "Signed contract and insurance certificate",
        "Permits where required",
      ]),
      completionChecklist: list([
        "Punch-list walkthrough completed",
        "Final invoices and lien waivers collected",
        "Photos uploaded to the property file",
        "Budget reconciliation approved",
      ]),
    },
    notifications: {
      events: {
        rentDue: notificationEvent(true, true, true, "Tenants"),
        overdueRent: notificationEvent(true, true, false, "Owners & Property Managers"),
        leaseRenewal: notificationEvent(true, true, false, "Property Managers"),
        maintenance: notificationEvent(true, true, false, "Maintenance Staff"),
        emergency: notificationEvent(true, true, true, "Owners & on-call staff"),
        projectBudget: notificationEvent(true, true, false, "Owners & Administrators"),
        invoicePayment: notificationEvent(true, true, false, "Accountants"),
        taskFailure: notificationEvent(true, true, false, "Administrators"),
        automationFailure: notificationEvent(true, false, false, "Administrators"),
      },
      senderName: org.name,
      replyTo: `billing@${domain}`,
      communicationStart: "08:00",
      communicationEnd: "19:00",
      timezone: "America/Los_Angeles — Pacific",
      dailyDigest: true,
    },
    tasks: {
      timezone: "America/Los_Angeles — Pacific",
      windowStart: "01:00",
      windowEnd: "05:00",
      failureNotifications: true,
      failureRecipients: "Owners & Administrators",
      retryCount: 3,
      retryIntervalMinutes: 15,
      retentionMonths: 24,
      reminderTiming: "24 hours before",
      missedTaskAlerts: true,
      missedTaskRecipients: "Administrators",
    },
    workflow: {
      enabled: true,
      requireApproval: true,
      failureNotifications: true,
      failureRecipients: "Administrators",
      retryPolicy: "Exponential backoff",
      retryCount: 3,
      retentionMonths: 12,
      financialAutomations: "Require approval",
      externalCommunications: "Require approval",
      maxRunsPerDay: 500,
      maxConcurrent: 10,
    },
    documents: {
      categories: [
        { id: "dc_lease", label: "Leases & addenda", enabled: true },
        { id: "dc_tenant", label: "Tenant records", enabled: true },
        { id: "dc_property", label: "Property records", enabled: true },
        { id: "dc_financial", label: "Financial documents", enabled: true },
        { id: "dc_maintenance", label: "Maintenance & inspections", enabled: true },
        { id: "dc_legal", label: "Legal & compliance", enabled: false },
      ],
      defaultLeaseTemplate: "Standard residential lease (v4)",
      leaseTemplate: "Standard residential lease (v4)",
      namingConvention: "{property}_{tenant}_{documentType}_{date}",
      allowedTypes: ["PDF", "DOCX", "JPG", "PNG"],
      maxUploadMb: 25,
      retentionPolicy: "7 years after lease end",
      reminderDays: 14,
      signatureExpiryDays: 30,
      signerReminderDays: 3,
      accessDefault: "Organization members",
      archiveSigned: true,
      archiveLocation: "Organization file storage",
      esignProvider: "Not connected",
    },
    security: {
      matrix: JSON.parse(JSON.stringify(DEFAULT_MATRIX)),
      sessionTimeout: "30 minutes",
      invitationExpiryDays: 7,
      suspensionPolicy: "Suspend after 10 failed sign-in attempts",
      sensitiveFinancialAction: "Require Owner or Administrator approval",
      documentAccess: "Role-based access",
      auditTracking: true,
      auditEvents: {
        signIn: true,
        permissionChanges: true,
        financialEdits: true,
        exports: true,
        integrationChanges: true,
      },
      securityAlerts: {
        failedSignIn: true,
        newDevice: true,
        roleChange: true,
        exportFailure: false,
      },
    },
    integrations: {
      email: {
        id: "email",
        provider: "Postmark",
        description: "Transactional email for rent notices, invoices and signed documents.",
        status: "connected",
        lastChecked: minutesAgo(4),
        account: `notifications@${domain}`,
        detail: "Sandbox server · 312 messages this month",
      },
      sms: {
        id: "sms",
        provider: "Textline",
        description: "Simulated SMS reminders for urgent maintenance and overdue rent.",
        status: "disconnected",
        lastChecked: minutesAgo(58),
        account: "",
        detail: "No sender number connected",
      },
      bank: {
        id: "bank",
        provider: "Plaid",
        description: "Read-only bank feed for reconciliation and cash position.",
        status: "connected",
        lastChecked: minutesAgo(11),
        account: "Operating checking · ••4821",
        detail: "Sandbox institution · last sync 11 minutes ago",
      },
      esign: {
        id: "esign",
        provider: "DocuSign",
        description: "Send lease packets and collect simulated signatures.",
        status: "disconnected",
        lastChecked: minutesAgo(92),
        account: "",
        detail: "E-signature sending is unavailable in this prototype",
      },
      storage: {
        id: "storage",
        provider: "Amazon S3",
        description: "Document and inspection photo storage for the organization.",
        status: "connected",
        lastChecked: minutesAgo(6),
        account: `${org.id}-docs · us-west-2`,
        detail: "Storage quota 4.2 GB of 50 GB",
      },
      automation: {
        id: "automation",
        provider: "Zapier",
        description: "Connect event workflows to external tools and services.",
        status: "disconnected",
        lastChecked: minutesAgo(130),
        account: "",
        detail: "No external automations configured",
      },
      api: {
        id: "api",
        provider: "Rentora API",
        description: "Programmatic access and outbound webhooks for developers.",
        status: "connected",
        lastChecked: minutesAgo(2),
        account: "2 mock webhook endpoints",
        detail: "Credentials are not stored in this prototype",
      },
    },
    data: {
      retentionYears: 7,
      activityRetentionMonths: 24,
      archiveInactiveProperties: true,
      archiveAfterMonths: 12,
      exportFormat: "JSON",
      keepExportedAuditCopy: true,
      importMode: "Preview before applying",
    },
  };
}

export function defaultUserPreferences(_userId: string): UserPreferences {
  return {
    theme: "light",
    landingPage: "Dashboard overview",
    language: "English (United States)",
    tableDensity: "Comfortable",
    notifications: { email: true, desktop: true, weeklyDigest: true, productUpdates: false },
    widgets: { occupancy: true, rentCollection: true, maintenance: true, renewals: true },
    reduceMotion: false,
  };
}

export const ROLE_TONES: Record<Role, string> = {
  Owner: "bg-blue-50 text-blue-700 ring-blue-600/15 dark:bg-blue-500/10 dark:text-blue-300 dark:ring-blue-400/20",
  Administrator: "bg-indigo-50 text-indigo-700 ring-indigo-600/15 dark:bg-indigo-500/10 dark:text-indigo-300 dark:ring-indigo-400/20",
  "Property Manager": "bg-emerald-50 text-emerald-700 ring-emerald-600/15 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-400/20",
  Accountant: "bg-amber-50 text-amber-700 ring-amber-600/15 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-400/20",
  "Maintenance Staff": "bg-violet-50 text-violet-700 ring-violet-600/15 dark:bg-violet-500/10 dark:text-violet-300 dark:ring-violet-400/20",
  "Read-Only / Auditor": "bg-slate-100 text-slate-600 ring-slate-500/15 dark:bg-slate-500/10 dark:text-slate-300 dark:ring-slate-400/20",
};
