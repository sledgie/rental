import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { CATEGORY_MAP } from "./catalog";
import {
  CURRENT_USER,
  INITIAL_ACTIVITY,
  INVITATIONS,
  MEMBERS,
  ORGANIZATIONS,
  defaultOrganizationSettings,
  defaultUserPreferences,
} from "./mockSettings";
import {
  appendActivityLog,
  exportMockSettings,
  getActivityLog,
  getOrganizationSettings,
  getUserPreferences,
  importOrganizationSettings,
  persistActiveOrganizationId,
  readActiveOrganizationId,
  resetOrganizationCategory,
  resetUserPreferences,
  updateOrganizationSettings,
  updateUserPreferences,
} from "./mockSettingsService";
import type {
  ActivityEvent,
  CategoryId,
  Invitation,
  Member,
  Organization,
  OrgSettings,
  Role,
  ToastMessage,
  ToastTone,
  UserPreferences,
} from "./types";
import { uid } from "./utils";

interface SettingsContextValue {
  orgs: Organization[];
  activeOrg: Organization;
  activeOrgId: string;
  role: Role;
  currentUser: typeof CURRENT_USER;
  members: Member[];
  invitations: Invitation[];
  activity: ActivityEvent[];
  orgSettings: OrgSettings;
  prefs: UserPreferences;
  toasts: ToastMessage[];
  theme: "light" | "dark";
  setActiveOrg: (id: string) => void;
  saveCategory: (category: CategoryId, value: unknown) => void;
  resetCategory: (category: CategoryId) => void;
  savePreferences: (value: UserPreferences) => void;
  resetPreferences: () => void;
  updateIntegration: (key: string, patch: Record<string, unknown>) => void;
  importSettings: (categories: CategoryId[], data: Partial<OrgSettings>) => void;
  addActivity: (action: string, detail?: string, category?: CategoryId) => void;
  notify: (message: string, tone?: ToastTone, description?: string) => void;
  dismissToast: (id: number) => void;
  canEdit: (category: CategoryId) => boolean;
  defaults: OrgSettings;
  revision: number;
  exportSettings: () => Record<string, unknown>;
}

const SettingsContext = createContext<SettingsContextValue | null>(null);

function findOrg(id: string): Organization {
  return ORGANIZATIONS.find((org) => org.id === id) ?? ORGANIZATIONS[0];
}

function defaultsFor(orgId: string): OrgSettings {
  return defaultOrganizationSettings(findOrg(orgId));
}

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [activeOrgId, setActiveOrgIdState] = useState<string>(() => {
    const stored = readActiveOrganizationId(ORGANIZATIONS[0].id);
    return ORGANIZATIONS.some((org) => org.id === stored) ? stored : ORGANIZATIONS[0].id;
  });
  const activeOrg = useMemo(() => findOrg(activeOrgId), [activeOrgId]);
  const defaults = useMemo(() => defaultsFor(activeOrgId), [activeOrgId]);
  const [orgSettings, setOrgSettings] = useState<OrgSettings>(() =>
    getOrganizationSettings(activeOrgId, defaultsFor(activeOrgId)),
  );
  const prefsDefaults = useMemo(() => defaultUserPreferences(CURRENT_USER.id), []);
  const [prefs, setPrefs] = useState<UserPreferences>(() =>
    getUserPreferences(CURRENT_USER.id, defaultUserPreferences(CURRENT_USER.id)),
  );
  const [activity, setActivity] = useState<ActivityEvent[]>(() =>
    getActivityLog(activeOrgId, INITIAL_ACTIVITY[activeOrgId] ?? []),
  );
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [revision, setRevision] = useState(0);
  const bumpRevision = useCallback(() => setRevision((current) => current + 1), []);
  const [systemDark, setSystemDark] = useState<boolean>(() =>
    typeof window !== "undefined" ? window.matchMedia("(prefers-color-scheme: dark)").matches : false,
  );
  const timers = useRef<Record<number, ReturnType<typeof setTimeout>>>({});

  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = (event: MediaQueryListEvent) => setSystemDark(event.matches);
    media.addEventListener("change", handler);
    return () => media.removeEventListener("change", handler);
  }, []);

  const effectiveDark = prefs.theme === "dark" || (prefs.theme === "system" && systemDark);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", effectiveDark);
    root.style.colorScheme = effectiveDark ? "dark" : "light";
  }, [effectiveDark]);

  useEffect(() => {
    document.documentElement.classList.toggle("reduce-motion", !!prefs.reduceMotion);
  }, [prefs.reduceMotion]);

  useEffect(
    () => () => {
      Object.values(timers.current).forEach(clearTimeout);
    },
    [],
  );

  const dismissToast = useCallback((id: number) => {
    setToasts((current) => current.filter((toast) => toast.id !== id));
    if (timers.current[id]) {
      clearTimeout(timers.current[id]);
      delete timers.current[id];
    }
  }, []);

  const notify = useCallback(
    (message: string, tone: ToastTone = "success", description?: string) => {
      const id = Date.now() + Math.floor(Math.random() * 1000);
      setToasts((current) => [...current.slice(-2), { id, message, tone, description }]);
      timers.current[id] = setTimeout(() => {
        setToasts((current) => current.filter((toast) => toast.id !== id));
        delete timers.current[id];
      }, 4800);
    },
    [],
  );

  const pushActivity = useCallback(
    (action: string, detail?: string, category?: CategoryId) => {
      const event: ActivityEvent = {
        id: uid("act"),
        actor: CURRENT_USER.name,
        actorInitials: CURRENT_USER.initials,
        action,
        detail,
        at: new Date().toISOString(),
        category,
      };
      setActivity((current) => [event, ...current].slice(0, 250));
      appendActivityLog(activeOrgId, event, INITIAL_ACTIVITY[activeOrgId] ?? []);
    },
    [activeOrgId],
  );

  const addActivity = pushActivity;

  const setActiveOrg = useCallback((id: string) => {
    if (!ORGANIZATIONS.some((org) => org.id === id)) return;
    setActiveOrgIdState(id);
    persistActiveOrganizationId(id);
    setOrgSettings(getOrganizationSettings(id, defaultsFor(id)));
    setActivity(getActivityLog(id, INITIAL_ACTIVITY[id] ?? []));
    bumpRevision();
  }, [bumpRevision]);

  const saveCategory = useCallback(
    (category: CategoryId, value: unknown) => {
      const updated = updateOrganizationSettings(
        activeOrgId,
        { [category]: value } as Partial<OrgSettings>,
        defaultsFor(activeOrgId),
      );
      setOrgSettings(updated);
      bumpRevision();
      pushActivity(
        `Updated ${CATEGORY_MAP[category]?.shortLabel.toLowerCase() ?? category} settings`,
        `${CATEGORY_MAP[category]?.label ?? category} · saved configuration`,
        category,
      );
    },
    [activeOrgId, pushActivity, bumpRevision],
  );

  const resetCategory = useCallback(
    (category: CategoryId) => {
      const updated = resetOrganizationCategory(activeOrgId, category, defaultsFor(activeOrgId));
      setOrgSettings(updated);
      bumpRevision();
      pushActivity(
        `Reset ${CATEGORY_MAP[category]?.shortLabel.toLowerCase() ?? category} settings`,
        "Restored prototype defaults for this category",
        category,
      );
    },
    [activeOrgId, pushActivity, bumpRevision],
  );

  const savePreferences = useCallback(
    (value: UserPreferences) => {
      const updated = updateUserPreferences(CURRENT_USER.id, value, prefsDefaults);
      setPrefs(updated);
      bumpRevision();
      pushActivity("Updated personal preferences", "Personal settings are scoped to the current mock user");
    },
    [prefsDefaults, pushActivity, bumpRevision],
  );

  const resetPreferences = useCallback(() => {
    const updated = resetUserPreferences(CURRENT_USER.id, prefsDefaults);
    setPrefs(updated);
    bumpRevision();
    pushActivity("Reset personal preferences", "Restored personal prototype defaults");
  }, [prefsDefaults, pushActivity, bumpRevision]);

  const updateIntegration = useCallback(
    (key: string, patch: Record<string, unknown>) => {
      const current = orgSettings.integrations ?? {};
      const nextIntegrations = {
        ...current,
        [key]: { ...(current[key] ?? {}), ...patch },
      };
      const updated = updateOrganizationSettings(
        activeOrgId,
        { integrations: nextIntegrations },
        defaultsFor(activeOrgId),
      );
      setOrgSettings(updated);
      bumpRevision();
    },
    [activeOrgId, orgSettings.integrations, bumpRevision],
  );

  const importSettings = useCallback(
    (categories: CategoryId[], data: Partial<OrgSettings>) => {
      const allowed = categories.filter((category) => category !== "personal");
      const imported: Partial<OrgSettings> = {};
      allowed.forEach((category) => {
        if (data[category] !== undefined) imported[category] = data[category];
      });
      const updated = importOrganizationSettings(activeOrgId, imported, defaultsFor(activeOrgId));
      setOrgSettings(updated);
      bumpRevision();
      pushActivity(
        "Imported organization configuration",
        `${allowed.length} categor${allowed.length === 1 ? "y" : "ies"} updated · simulated import`,
        "data",
      );
    },
    [activeOrgId, pushActivity, bumpRevision],
  );

  const canEdit = useCallback(
    (category: CategoryId) => {
      if (category === "personal") return true;
      if (activeOrg.role === "Owner") return true;
      const map: Record<Role, CategoryId[] | "all"> = {
        Owner: "all",
        Administrator: [
          "organization", "general", "financial", "property", "maintenance", "projects", "notifications",
          "tasks", "workflow", "documents", "security", "integrations", "data",
        ],
        "Property Manager": ["property", "maintenance", "projects", "notifications"],
        Accountant: ["financial", "documents", "data"],
        "Maintenance Staff": ["maintenance"],
        "Read-Only / Auditor": [],
      };
      const allowed = map[activeOrg.role];
      return allowed === "all" || allowed.includes(category);
    },
    [activeOrg.role],
  );

  const exportSettings = useCallback(
    () => exportMockSettings(activeOrgId, activeOrg.name, defaultsFor(activeOrgId)),
    [activeOrgId, activeOrg.name],
  );

  const value: SettingsContextValue = {
    orgs: ORGANIZATIONS,
    activeOrg,
    activeOrgId,
    role: activeOrg.role,
    currentUser: CURRENT_USER,
    members: MEMBERS[activeOrgId] ?? [],
    invitations: INVITATIONS[activeOrgId] ?? [],
    activity,
    orgSettings,
    prefs,
    toasts,
    theme: effectiveDark ? "dark" : "light",
    setActiveOrg,
    saveCategory,
    resetCategory,
    savePreferences,
    resetPreferences,
    updateIntegration,
    importSettings,
    addActivity,
    notify,
    dismissToast,
    canEdit,
    defaults,
    revision,
    exportSettings,
  };

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useSettings(): SettingsContextValue {
  const context = useContext(SettingsContext);
  if (!context) throw new Error("useSettings must be used within SettingsProvider");
  return context;
}
