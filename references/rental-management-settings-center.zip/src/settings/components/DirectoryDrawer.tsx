import { Activity, ArrowUpRight, Mail, ShieldCheck, UserPlus, Users } from "lucide-react";
import { useEffect, useState } from "react";
import { ROLE_TONES } from "../mockSettings";
import { useSettings } from "../store";
import type { DirectoryTab } from "../types";
import { dateTime, relativeTime } from "../utils";
import { Badge, Button, Drawer, EmptyState } from "./ui";

const TABS: Array<{ id: DirectoryTab; label: string; icon: typeof Users }> = [
  { id: "members", label: "Members", icon: Users },
  { id: "invitations", label: "Invitations", icon: UserPlus },
  { id: "activity", label: "Activity log", icon: Activity },
];

export default function DirectoryDrawer({
  open,
  initialTab,
  onClose,
}: {
  open: boolean;
  initialTab: DirectoryTab;
  onClose: () => void;
}) {
  const { members, invitations, activity, activeOrg, notify, orgSettings } = useSettings();
  const [tab, setTab] = useState<DirectoryTab>(initialTab);

  useEffect(() => {
    if (open) setTab(initialTab);
  }, [open, initialTab]);

  return (
    <Drawer
      open={open}
      onClose={onClose}
      title="Organization records"
      description={`${orgSettings.organization?.displayName?.trim() || activeOrg.name} · read-only view of existing modules`}
      footer={
        <Button type="button" variant="secondary" onClick={() => notify("Member management lives in the Organization module", "info", "This prototype reuses the existing records without duplicating management screens.")}>
          Member management <ArrowUpRight className="h-3.5 w-3.5" />
        </Button>
      }
    >
      <div className="space-y-4">
        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-0.5 dark:bg-slate-800">
          {TABS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={`inline-flex h-7.5 flex-1 items-center justify-center gap-1.5 rounded-md text-[11.5px] font-medium transition ${
                tab === item.id
                  ? "bg-white text-slate-900 shadow-sm dark:bg-slate-950 dark:text-white"
                  : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200"
              }`}
            >
              <item.icon className="h-3.5 w-3.5" /> {item.label}
            </button>
          ))}
        </div>

        {tab === "members" ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-[11px] text-slate-400">{members.length} people with workspace access</p>
              <Badge tone="gray"><ShieldCheck className="h-3 w-3" /> Reused membership</Badge>
            </div>
            <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 dark:divide-slate-800 dark:border-slate-700">
              {members.map((member) => (
                <div key={member.id} className="flex items-center gap-3 px-3.5 py-3">
                  <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[10.5px] font-semibold text-white ${member.avatarTone}`}>
                    {member.initials}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <p className="truncate text-[12.5px] font-medium text-slate-800 dark:text-slate-100">{member.name}</p>
                      {member.name.startsWith("Avery") ? <span className="rounded bg-slate-100 px-1 py-0.5 text-[9px] text-slate-500 dark:bg-slate-800 dark:text-slate-400">You</span> : null}
                    </div>
                    <p className="truncate text-[10.5px] text-slate-400">{member.email}</p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <span className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-medium ring-1 ring-inset ${ROLE_TONES[member.role]}`}>{member.role}</span>
                    <span className="text-[9.5px] text-slate-400">{member.lastActive}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {tab === "invitations" ? (
          <div className="space-y-3">
            <p className="text-[11px] text-slate-400">{invitations.length} pending invitation{invitations.length === 1 ? "" : "s"}</p>
            {invitations.length === 0 ? (
              <EmptyState icon={Mail} title="No pending invitations" description="New team invitations created in the Organization module would appear here." />
            ) : (
              <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 dark:divide-slate-800 dark:border-slate-700">
                {invitations.map((invite) => (
                  <div key={invite.id} className="flex items-center gap-3 px-3.5 py-3">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-400 dark:bg-slate-800">
                      <Mail className="h-3.5 w-3.5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12.5px] font-medium text-slate-800 dark:text-slate-100">{invite.email}</p>
                      <p className="text-[10.5px] text-slate-400">Sent {dateTime(invite.sentAt)}</p>
                    </div>
                    <div className="shrink-0 text-right">
                      <span className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-medium ring-1 ring-inset ${ROLE_TONES[invite.role]}`}>{invite.role}</span>
                      <p className="mt-1 text-[9.5px] text-amber-600 dark:text-amber-400">Expires in {invite.expiresInDays} days</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <p className="text-[10.5px] leading-relaxed text-slate-400">Invitation emails are simulated. No real email is sent by this prototype.</p>
          </div>
        ) : null}

        {tab === "activity" ? (
          <div className="space-y-3">
            <p className="text-[11px] text-slate-400">Recent mock administrative events</p>
            <div className="relative space-y-4 pl-1">
              <div className="absolute bottom-2 left-[15px] top-2 w-px bg-slate-200 dark:bg-slate-700" />
              {activity.map((event) => (
                <div key={event.id} className="relative flex items-start gap-3">
                  <span className="relative z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white text-slate-500 ring-1 ring-slate-200 dark:bg-slate-900 dark:text-slate-400 dark:ring-slate-700">
                    <Activity className="h-3 w-3" />
                  </span>
                  <div className="min-w-0 flex-1 pb-1">
                    <p className="text-[12px] font-medium text-slate-800 dark:text-slate-100">{event.action}</p>
                    {event.detail ? <p className="mt-0.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">{event.detail}</p> : null}
                    <p className="mt-1 text-[10px] text-slate-400">{event.actor} · {relativeTime(event.at)}</p>
                  </div>
                </div>
              ))}
            </div>
            <p className="rounded-lg bg-slate-50 px-3 py-2 text-[10.5px] leading-relaxed text-slate-400 dark:bg-slate-800/50">
              Passwords, credentials and sensitive form values are never written to this mock activity log.
            </p>
          </div>
        ) : null}
      </div>
    </Drawer>
  );
}
