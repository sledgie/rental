import {
  AlertCircle,
  AlertTriangle,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Eye,
  EyeOff,
  GripVertical,
  Info,
  Loader2,
  Lock,
  Plus,
  Trash2,
  X,
  XCircle,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useId, useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/utils/cn";
import type { ListItem, ToastMessage, ToastTone } from "../types";

/* ------------------------------------------------------------------ */
/* Buttons                                                             */
/* ------------------------------------------------------------------ */

type ButtonVariant = "primary" | "secondary" | "ghost" | "danger" | "soft";
type ButtonSize = "sm" | "md" | "lg";

const buttonVariants: Record<ButtonVariant, string> = {
  primary:
    "bg-blue-600 text-white shadow-sm shadow-blue-600/20 hover:bg-blue-700 focus-visible:ring-blue-500 disabled:bg-blue-300 dark:disabled:bg-blue-900/50",
  secondary:
    "border border-slate-200 bg-white text-slate-700 shadow-sm hover:border-slate-300 hover:bg-slate-50 focus-visible:ring-slate-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800",
  ghost:
    "text-slate-600 hover:bg-slate-100 hover:text-slate-900 focus-visible:ring-slate-400 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white",
  danger:
    "border border-rose-200 bg-white text-rose-600 shadow-sm hover:bg-rose-50 focus-visible:ring-rose-400 dark:border-rose-500/30 dark:bg-transparent dark:text-rose-400 dark:hover:bg-rose-500/10",
  soft:
    "bg-blue-50 text-blue-700 hover:bg-blue-100 focus-visible:ring-blue-400 dark:bg-blue-500/10 dark:text-blue-300 dark:hover:bg-blue-500/20",
};

const buttonSizes: Record<ButtonSize, string> = {
  sm: "h-8 gap-1.5 rounded-lg px-2.5 text-[12.5px]",
  md: "h-9.5 gap-2 rounded-lg px-3.5 text-[13px]",
  lg: "h-10.5 gap-2 rounded-xl px-4 text-sm",
};

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: LucideIcon;
  iconRight?: LucideIcon;
  loading?: boolean;
  children?: ReactNode;
}

export function Button({
  variant = "secondary",
  size = "md",
  icon: Icon,
  iconRight: IconRight,
  loading,
  children,
  className,
  disabled,
  ...props
}: ButtonProps) {
  return (
    <button
      {...props}
      disabled={disabled || loading}
      className={cn(
        "inline-flex select-none items-center justify-center font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-white disabled:opacity-60 dark:focus-visible:ring-offset-slate-950",
        buttonVariants[variant],
        buttonSizes[size],
        className,
      )}
    >
      {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : Icon ? <Icon className="h-3.5 w-3.5" /> : null}
      {children}
      {IconRight && !loading ? <IconRight className="h-3.5 w-3.5" /> : null}
    </button>
  );
}

export function IconButton({
  icon: Icon,
  label,
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { icon: LucideIcon; label: string }) {
  return (
    <button
      {...props}
      aria-label={label}
      title={label}
      className={cn(
        "inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 transition hover:bg-slate-100 hover:text-slate-800 disabled:opacity-40 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100",
        className,
      )}
    >
      <Icon className="h-4 w-4" />
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* Badges & status                                                     */
/* ------------------------------------------------------------------ */

type BadgeTone = "gray" | "blue" | "green" | "amber" | "red" | "violet" | "indigo";

const badgeTones: Record<BadgeTone, string> = {
  gray: "bg-slate-100 text-slate-600 ring-slate-500/10 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-400/10",
  blue: "bg-blue-50 text-blue-700 ring-blue-600/15 dark:bg-blue-500/10 dark:text-blue-300 dark:ring-blue-400/20",
  green: "bg-emerald-50 text-emerald-700 ring-emerald-600/15 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-400/20",
  amber: "bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-400/20",
  red: "bg-rose-50 text-rose-700 ring-rose-600/15 dark:bg-rose-500/10 dark:text-rose-300 dark:ring-rose-400/20",
  violet: "bg-violet-50 text-violet-700 ring-violet-600/15 dark:bg-violet-500/10 dark:text-violet-300 dark:ring-violet-400/20",
  indigo: "bg-indigo-50 text-indigo-700 ring-indigo-600/15 dark:bg-indigo-500/10 dark:text-indigo-300 dark:ring-indigo-400/20",
};

export function Badge({
  tone = "gray",
  dot,
  icon: Icon,
  children,
  className,
}: {
  tone?: BadgeTone;
  dot?: boolean;
  icon?: LucideIcon;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset",
        badgeTones[tone],
        className,
      )}
    >
      {dot ? <span className="h-1.5 w-1.5 rounded-full bg-current opacity-80" /> : null}
      {Icon ? <Icon className="h-3 w-3" /> : null}
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Cards                                                               */
/* ------------------------------------------------------------------ */

export function Card({ children, className, id }: { children: ReactNode; className?: string; id?: string }) {
  return (
    <div
      id={id}
      className={cn(
        "scroll-mt-24 overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:border-slate-800 dark:bg-slate-900/80",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function CardHeader({
  title,
  description,
  icon: Icon,
  aside,
  className,
}: {
  title: string;
  description?: string;
  icon?: LucideIcon;
  aside?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 px-5 py-4 sm:px-6 dark:border-slate-800", className)}>
      <div className="flex min-w-0 items-start gap-3">
        {Icon ? (
          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500 ring-1 ring-slate-200/70 dark:bg-slate-800/80 dark:text-slate-300 dark:ring-slate-700">
            <Icon className="h-4 w-4" />
          </span>
        ) : null}
        <div className="min-w-0">
          <h3 className="text-[14px] font-semibold tracking-[-0.01em] text-slate-900 dark:text-white">{title}</h3>
          {description ? (
            <p className="mt-0.5 max-w-2xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">{description}</p>
          ) : null}
        </div>
      </div>
      {aside ? <div className="flex shrink-0 items-center gap-2">{aside}</div> : null}
    </div>
  );
}

export function CardBody({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("px-5 py-5 sm:px-6", className)}>{children}</div>;
}

export function CardFooter({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 bg-slate-50/60 px-5 py-3 sm:px-6 dark:border-slate-800 dark:bg-slate-900", className)}>
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Form controls                                                       */
/* ------------------------------------------------------------------ */

export function Field({
  label,
  hint,
  error,
  required,
  badge,
  children,
  className,
}: {
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
  badge?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("min-w-0", className)}>
      {label ? (
        <div className="mb-1.5 flex flex-wrap items-center gap-2">
          <label className="text-[12.5px] font-medium text-slate-700 dark:text-slate-200">
            {label}
            {required ? <span className="ml-0.5 text-rose-500">*</span> : null}
          </label>
          {badge}
        </div>
      ) : null}
      {children}
      {error ? (
        <p className="mt-1.5 flex items-start gap-1 text-[11.5px] font-medium text-rose-600 dark:text-rose-400">
          <AlertCircle className="mt-0.5 h-3 w-3 shrink-0" />
          {error}
        </p>
      ) : hint ? (
        <p className="mt-1.5 text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">{hint}</p>
      ) : null}
    </div>
  );
}

const controlBase =
  "w-full rounded-lg border bg-white text-[13px] text-slate-900 shadow-[0_1px_2px_rgba(15,23,42,0.03)] outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/15 disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-500 dark:border-slate-700 dark:bg-slate-950/50 dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:border-blue-500 dark:disabled:bg-slate-800/50 dark:disabled:text-slate-400";

export function Input({
  invalid,
  icon: Icon,
  prefix,
  className,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean; icon?: LucideIcon; prefix?: string }) {
  return (
    <div className="relative">
      {prefix ? (
        <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-[12.5px] font-medium text-slate-400 dark:text-slate-500">
          {prefix}
        </span>
      ) : Icon ? (
        <Icon className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
      ) : null}
      <input
        {...props}
        className={cn(
          controlBase,
          "h-9.5 px-3",
          prefix ? "pl-12" : Icon ? "pl-9" : "",
          invalid
            ? "border-rose-300 focus:border-rose-500 focus:ring-rose-500/15 dark:border-rose-500/50"
            : "border-slate-200 dark:border-slate-700",
          className,
        )}
      />
    </div>
  );
}

export function Select({
  invalid,
  children,
  className,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & { invalid?: boolean }) {
  return (
    <div className="relative">
      <select
        {...props}
        className={cn(
          controlBase,
          "h-9.5 appearance-none px-3 pr-9",
          invalid ? "border-rose-300 dark:border-rose-500/50" : "border-slate-200 dark:border-slate-700",
          className,
        )}
      >
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400 dark:text-slate-500" />
    </div>
  );
}

export function Textarea({
  invalid,
  className,
  rows = 4,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { invalid?: boolean }) {
  return (
    <textarea
      {...props}
      rows={rows}
      className={cn(
        controlBase,
        "resize-y px-3 py-2.5 text-[13px] leading-relaxed",
        invalid ? "border-rose-300 dark:border-rose-500/50" : "border-slate-200 dark:border-slate-700",
        className,
      )}
    />
  );
}

export function Toggle({
  checked,
  onChange,
  disabled,
  label,
  size = "md",
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
  label: string;
  size?: "sm" | "md";
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative inline-flex shrink-0 items-center rounded-full transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:opacity-45 dark:focus-visible:ring-offset-slate-900",
        size === "sm" ? "h-4.5 w-8" : "h-5.5 w-10",
        checked ? "bg-blue-600" : "bg-slate-200 dark:bg-slate-700",
      )}
    >
      <span
        className={cn(
          "inline-block rounded-full bg-white shadow-sm transition-transform duration-200",
          size === "sm" ? "h-3.5 w-3.5 translate-x-0.5" : "h-4.5 w-4.5 translate-x-0.5",
          checked ? (size === "sm" ? "translate-x-4" : "translate-x-[20px]") : "",
        )}
      />
    </button>
  );
}

export function SettingRow({
  title,
  description,
  badge,
  children,
  className,
  icon: Icon,
}: {
  title: string;
  description?: string;
  badge?: ReactNode;
  children: ReactNode;
  className?: string;
  icon?: LucideIcon;
}) {
  return (
    <div className={cn("flex flex-wrap items-start justify-between gap-x-8 gap-y-3 py-3.5", className)}>
      <div className="flex min-w-0 flex-1 items-start gap-3">
        {Icon ? (
          <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-slate-50 text-slate-500 ring-1 ring-slate-200/70 dark:bg-slate-800 dark:text-slate-400 dark:ring-slate-700">
            <Icon className="h-3.5 w-3.5" />
          </span>
        ) : null}
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-[13px] font-medium text-slate-800 dark:text-slate-100">{title}</p>
            {badge}
          </div>
          {description ? (
            <p className="mt-0.5 max-w-xl text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">{description}</p>
          ) : null}
        </div>
      </div>
      <div className="shrink-0 pt-0.5">{children}</div>
    </div>
  );
}

export function Checkbox({
  checked,
  onChange,
  label,
  description,
  disabled,
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label: string;
  description?: string;
  disabled?: boolean;
}) {
  const id = useId();
  return (
    <label
      htmlFor={id}
      className={cn(
        "flex cursor-pointer items-start gap-2.5 rounded-lg py-1.5",
        disabled && "cursor-not-allowed opacity-60",
      )}
    >
      <span className="relative mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center">
        <input
          id={id}
          type="checkbox"
          checked={checked}
          disabled={disabled}
          onChange={(event) => onChange(event.target.checked)}
          className="peer h-4 w-4 cursor-pointer appearance-none rounded border border-slate-300 bg-white transition checked:border-blue-600 checked:bg-blue-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/30 disabled:cursor-not-allowed dark:border-slate-600 dark:bg-slate-950 dark:checked:border-blue-500 dark:checked:bg-blue-500"
        />
        <Check className="pointer-events-none absolute h-3 w-3 text-white opacity-0 peer-checked:opacity-100" strokeWidth={3} />
      </span>
      <span className="min-w-0">
        <span className="block text-[12.5px] font-medium leading-5 text-slate-700 dark:text-slate-200">{label}</span>
        {description ? (
          <span className="mt-0.5 block text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">{description}</span>
        ) : null}
      </span>
    </label>
  );
}

export function Segmented({
  options,
  value,
  onChange,
  disabled,
  size = "md",
}: {
  options: Array<{ value: string; label: string; icon?: LucideIcon }>;
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  size?: "sm" | "md";
}) {
  return (
    <div className="inline-flex flex-wrap items-center gap-0.5 rounded-lg bg-slate-100 p-0.5 dark:bg-slate-800">
      {options.map((option) => {
        const Icon = option.icon;
        const active = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            disabled={disabled}
            aria-pressed={active}
            onClick={() => onChange(option.value)}
            className={cn(
              "inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40 disabled:opacity-50",
              size === "sm" ? "h-6.5 px-2 text-[11.5px]" : "h-7.5 px-2.5 text-[12px]",
              active
                ? "bg-white text-slate-900 shadow-sm ring-1 ring-slate-900/5 dark:bg-slate-950 dark:text-white dark:ring-white/10"
                : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200",
            )}
          >
            {Icon ? <Icon className="h-3 w-3" /> : null}
            {option.label}
          </button>
        );
      })}
    </div>
  );
}

export function RadioCards({
  options,
  value,
  onChange,
  disabled,
  columns = 2,
}: {
  options: Array<{ value: string; label: string; description?: string; badge?: ReactNode }>;
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
  columns?: 1 | 2 | 3;
}) {
  return (
    <div
      role="radiogroup"
      className={cn(
        "grid gap-2",
        columns === 2 ? "sm:grid-cols-2" : columns === 3 ? "sm:grid-cols-3" : "grid-cols-1",
      )}
    >
      {options.map((option) => {
        const active = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            role="radio"
            aria-checked={active}
            disabled={disabled}
            onClick={() => onChange(option.value)}
            className={cn(
              "group flex items-start gap-2.5 rounded-lg border p-3 text-left transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/30 disabled:opacity-60",
              active
                ? "border-blue-500 bg-blue-50/40 ring-1 ring-blue-500/20 dark:border-blue-500/60 dark:bg-blue-500/5"
                : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/60 dark:border-slate-700 dark:bg-slate-900 dark:hover:border-slate-600 dark:hover:bg-slate-800/50",
            )}
          >
            <span
              className={cn(
                "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border transition",
                active ? "border-blue-600 bg-blue-600" : "border-slate-300 bg-white dark:border-slate-600 dark:bg-slate-950",
              )}
            >
              {active ? <span className="h-1.5 w-1.5 rounded-full bg-white" /> : null}
            </span>
            <span className="min-w-0">
              <span className="flex flex-wrap items-center gap-1.5 text-[12.5px] font-medium text-slate-800 dark:text-slate-100">
                {option.label}
                {option.badge}
              </span>
              {option.description ? (
                <span className="mt-0.5 block text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                  {option.description}
                </span>
              ) : null}
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* List editor                                                         */
/* ------------------------------------------------------------------ */

export function ListEditor({
  items,
  onChange,
  readOnly,
  allowDisable = false,
  placeholder = "Add a new item",
  addLabel = "Add item",
  emptyLabel = "No items configured yet.",
}: {
  items: ListItem[];
  onChange: (items: ListItem[]) => void;
  readOnly?: boolean;
  allowDisable?: boolean;
  placeholder?: string;
  addLabel?: string;
  emptyLabel?: string;
}) {
  const [newLabel, setNewLabel] = useState("");

  const addItem = () => {
    const label = newLabel.trim();
    if (!label || readOnly) return;
    onChange([...items, { id: `item_${Math.random().toString(36).slice(2, 8)}`, label, ...(allowDisable ? { enabled: true } : {}) }]);
    setNewLabel("");
  };

  return (
    <div className="space-y-2">
      {items.length === 0 ? (
        <div className="rounded-lg border border-dashed border-slate-200 px-4 py-5 text-center text-[12px] text-slate-500 dark:border-slate-700 dark:text-slate-400">
          {emptyLabel}
        </div>
      ) : (
        <div className="space-y-1.5">
          {items.map((item, index) => (
            <div
              key={item.id}
              className={cn(
                "group flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-2 py-1.5 dark:border-slate-700 dark:bg-slate-950/40",
                item.enabled === false && "bg-slate-50/60 opacity-70 dark:bg-slate-900/40",
              )}
            >
              <GripVertical className="h-3.5 w-3.5 shrink-0 text-slate-300 dark:text-slate-600" />
              <input
                value={item.label}
                disabled={readOnly}
                aria-label={`Item ${index + 1}`}
                onChange={(event) => {
                  const next = items.map((entry) => (entry.id === item.id ? { ...entry, label: event.target.value } : entry));
                  onChange(next);
                }}
                className="h-7 min-w-0 flex-1 bg-transparent text-[12.5px] text-slate-700 outline-none placeholder:text-slate-400 disabled:cursor-not-allowed dark:text-slate-200"
              />
              {allowDisable ? (
                <span
                  className={cn(
                    "hidden rounded px-1.5 py-0.5 text-[10px] font-medium sm:inline",
                    item.enabled === false
                      ? "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400"
                      : "bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400",
                  )}
                >
                  {item.enabled === false ? "Disabled" : "Enabled"}
                </span>
              ) : null}
              {allowDisable ? (
                <IconButton
                  icon={item.enabled === false ? EyeOff : Eye}
                  label={item.enabled === false ? `Enable ${item.label}` : `Disable ${item.label}`}
                  disabled={readOnly}
                  onClick={() =>
                    onChange(items.map((entry) => (entry.id === item.id ? { ...entry, enabled: entry.enabled === false } : entry)))
                  }
                  className="h-7 w-7"
                />
              ) : null}
              <IconButton
                icon={Trash2}
                label={`Remove ${item.label}`}
                disabled={readOnly}
                onClick={() => onChange(items.filter((entry) => entry.id !== item.id))}
                className="h-7 w-7 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/10"
              />
            </div>
          ))}
        </div>
      )}
      {!readOnly ? (
        <div className="flex items-center gap-2 pt-0.5">
          <Input
            value={newLabel}
            onChange={(event) => setNewLabel(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                event.preventDefault();
                addItem();
              }
            }}
            placeholder={placeholder}
            className="h-8.5 text-[12.5px]"
          />
          <Button type="button" variant="secondary" size="sm" icon={Plus} onClick={addItem} disabled={!newLabel.trim()} className="h-8.5 shrink-0">
            {addLabel}
          </Button>
        </div>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Feedback & disclosure                                               */
/* ------------------------------------------------------------------ */

const calloutTones = {
  info: {
    wrap: "border-blue-200/80 bg-blue-50/60 dark:border-blue-500/25 dark:bg-blue-500/5",
    icon: "text-blue-600 dark:text-blue-400",
    title: "text-blue-900 dark:text-blue-200",
    body: "text-blue-800/80 dark:text-blue-300/80",
    Icon: Info,
  },
  warning: {
    wrap: "border-amber-200/80 bg-amber-50/60 dark:border-amber-500/25 dark:bg-amber-500/5",
    icon: "text-amber-600 dark:text-amber-400",
    title: "text-amber-900 dark:text-amber-200",
    body: "text-amber-800/80 dark:text-amber-300/80",
    Icon: AlertTriangle,
  },
  danger: {
    wrap: "border-rose-200/80 bg-rose-50/50 dark:border-rose-500/25 dark:bg-rose-500/5",
    icon: "text-rose-600 dark:text-rose-400",
    title: "text-rose-900 dark:text-rose-200",
    body: "text-rose-800/80 dark:text-rose-300/80",
    Icon: AlertTriangle,
  },
  neutral: {
    wrap: "border-slate-200 bg-slate-50/70 dark:border-slate-700 dark:bg-slate-800/40",
    icon: "text-slate-500 dark:text-slate-400",
    title: "text-slate-800 dark:text-slate-200",
    body: "text-slate-600 dark:text-slate-400",
    Icon: Info,
  },
  success: {
    wrap: "border-emerald-200/80 bg-emerald-50/50 dark:border-emerald-500/25 dark:bg-emerald-500/5",
    icon: "text-emerald-600 dark:text-emerald-400",
    title: "text-emerald-900 dark:text-emerald-200",
    body: "text-emerald-800/80 dark:text-emerald-300/80",
    Icon: CheckCircle2,
  },
};

export function Callout({
  tone = "info",
  title,
  children,
  action,
  className,
  icon: CustomIcon,
}: {
  tone?: keyof typeof calloutTones;
  title?: string;
  children: ReactNode;
  action?: ReactNode;
  className?: string;
  icon?: LucideIcon;
}) {
  const style = calloutTones[tone];
  const Icon = CustomIcon ?? style.Icon;
  return (
    <div className={cn("flex items-start gap-3 rounded-xl border px-4 py-3.5", style.wrap, className)}>
      <Icon className={cn("mt-0.5 h-4 w-4 shrink-0", style.icon)} />
      <div className="min-w-0 flex-1">
        {title ? <p className={cn("text-[12.5px] font-semibold", style.title)}>{title}</p> : null}
        <div className={cn("text-[12px] leading-relaxed", style.body, title && "mt-0.5")}>{children}</div>
        {action ? <div className="mt-2">{action}</div> : null}
      </div>
    </div>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-200 px-6 py-9 text-center dark:border-slate-700">
      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-50 text-slate-400 ring-1 ring-slate-200/70 dark:bg-slate-800 dark:text-slate-400 dark:ring-slate-700">
        <Icon className="h-5 w-5" />
      </span>
      <p className="mt-3 text-[13px] font-medium text-slate-800 dark:text-slate-100">{title}</p>
      <p className="mt-1 max-w-sm text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">{description}</p>
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  );
}

export function MetaRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-2">
      <span className="text-[12px] text-slate-500 dark:text-slate-400">{label}</span>
      <span className="text-right text-[12px] font-medium text-slate-700 dark:text-slate-200">{children}</span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Modal & drawer                                                      */
/* ------------------------------------------------------------------ */

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  size = "md",
  icon: Icon,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children?: ReactNode;
  footer?: ReactNode;
  size?: "sm" | "md" | "lg";
  icon?: LucideIcon;
}) {
  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handler);
      document.body.style.overflow = previous;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 animate-fade bg-slate-950/40 backdrop-blur-[2px]" onClick={onClose} />
      <div
        className={cn(
          "animate-rise relative flex max-h-[90vh] w-full flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl shadow-slate-950/20 dark:border-slate-700 dark:bg-slate-900",
          size === "sm" ? "max-w-md" : size === "lg" ? "max-w-2xl" : "max-w-lg",
        )}
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-5 py-4 dark:border-slate-800">
          <div className="flex items-start gap-3">
            {Icon ? (
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-600 ring-1 ring-blue-600/10 dark:bg-blue-500/10 dark:text-blue-400 dark:ring-blue-500/20">
                <Icon className="h-4 w-4" />
              </span>
            ) : null}
            <div>
              <h2 className="text-[14.5px] font-semibold text-slate-900 dark:text-white">{title}</h2>
              {description ? <p className="mt-0.5 text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">{description}</p> : null}
            </div>
          </div>
          <IconButton icon={X} label="Close dialog" onClick={onClose} />
        </div>
        {children ? <div className="overflow-y-auto px-5 py-4">{children}</div> : null}
        {footer ? (
          <div className="flex flex-wrap items-center justify-end gap-2 border-t border-slate-100 bg-slate-50/60 px-5 py-3 dark:border-slate-800 dark:bg-slate-900">
            {footer}
          </div>
        ) : null}
      </div>
    </div>
  );
}

export function Drawer({
  open,
  onClose,
  title,
  description,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 animate-fade bg-slate-950/35 backdrop-blur-[2px]" onClick={onClose} />
      <div className="animate-rise absolute inset-y-0 right-0 flex w-full max-w-lg flex-col border-l border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-5 py-4 dark:border-slate-800">
          <div>
            <h2 className="text-[15px] font-semibold text-slate-900 dark:text-white">{title}</h2>
            {description ? <p className="mt-0.5 text-[12px] text-slate-500 dark:text-slate-400">{description}</p> : null}
          </div>
          <IconButton icon={X} label="Close panel" onClick={onClose} />
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer ? (
          <div className="flex items-center justify-end gap-2 border-t border-slate-100 bg-slate-50/60 px-5 py-3 dark:border-slate-800 dark:bg-slate-900">
            {footer}
          </div>
        ) : null}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Toasts                                                              */
/* ------------------------------------------------------------------ */

const toastStyles: Record<ToastTone, { icon: LucideIcon; iconClass: string; bar: string }> = {
  success: { icon: CheckCircle2, iconClass: "text-emerald-600 dark:text-emerald-400", bar: "bg-emerald-500" },
  error: { icon: XCircle, iconClass: "text-rose-600 dark:text-rose-400", bar: "bg-rose-500" },
  info: { icon: Info, iconClass: "text-blue-600 dark:text-blue-400", bar: "bg-blue-500" },
};

export function Toasts({ toasts, onDismiss }: { toasts: ToastMessage[]; onDismiss: (id: number) => void }) {
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[90] flex w-[calc(100vw-2rem)] max-w-sm flex-col gap-2" aria-live="polite">
      {toasts.map((toast) => {
        const style = toastStyles[toast.tone];
        const Icon = style.icon;
        return (
          <div
            key={toast.id}
            className="animate-toast pointer-events-auto relative flex items-start gap-3 overflow-hidden rounded-xl border border-slate-200 bg-white px-3.5 py-3 shadow-lg shadow-slate-950/10 dark:border-slate-700 dark:bg-slate-900"
          >
            <span className={cn("absolute inset-y-0 left-0 w-0.5", style.bar)} />
            <Icon className={cn("mt-0.5 h-4 w-4 shrink-0", style.iconClass)} />
            <div className="min-w-0 flex-1">
              <p className="text-[12.5px] font-medium text-slate-900 dark:text-white">{toast.message}</p>
              {toast.description ? (
                <p className="mt-0.5 text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">{toast.description}</p>
              ) : null}
            </div>
            <IconButton icon={X} label="Dismiss notification" onClick={() => onDismiss(toast.id)} className="h-6 w-6" />
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Misc                                                                */
/* ------------------------------------------------------------------ */

export function SectionHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description: string }) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-[0.12em] text-slate-400 dark:text-slate-500">
        {eyebrow}
        <ChevronRight className="h-3 w-3" />
        <span className="text-slate-500 dark:text-slate-400">{title}</span>
      </div>
      <p className="mt-1.5 max-w-2xl text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">{description}</p>
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={cn("h-4 w-4 animate-spin", className)} />;
}

export function ProtectedBadge() {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10.5px] font-medium text-slate-500 ring-1 ring-inset ring-slate-500/10 dark:bg-slate-800 dark:text-slate-400 dark:ring-slate-600">
      <Lock className="h-2.5 w-2.5" />
      Protected
    </span>
  );
}

export { buttonSizes, buttonVariants, badgeTones };
