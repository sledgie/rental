import {
  CheckCircle2,
  ChevronRight,
  Cloud,
  Copy,
  ExternalLink,
  FileSignature,
  Info,
  Landmark,
  Link2,
  Mail,
  MessageSquare,
  Plug,
  Plus,
  ShieldCheck,
  Unplug,
  Webhook,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { useSettings } from "../store";
import type { PageProps } from "../types";
import { dateTime, relativeTime } from "../utils";
import { Badge, Button, Callout, Card, EmptyState, Modal, Segmented } from "../components/ui";

type IntegrationKey = "email" | "sms" | "bank" | "esign" | "storage" | "automation" | "api";
type Integration = {
  id?: string;
  provider: string;
  description: string;
  status: string;
  lastChecked: string;
  account: string;
  detail: string;
};

const integrationMeta: Record<IntegrationKey, { icon: typeof Mail; label: string; tone: string; scopes: string[] }> = {
  email: { icon: Mail, label: "Email delivery", tone: "bg-blue-50 text-blue-600 ring-blue-600/10 dark:bg-blue-500/10 dark:text-blue-400", scopes: ["Send transactional email", "Read delivery events", "Manage sender identity"] },
  sms: { icon: MessageSquare, label: "SMS messaging", tone: "bg-violet-50 text-violet-600 ring-violet-600/10 dark:bg-violet-500/10 dark:text-violet-400", scopes: ["Send SMS reminders", "Read delivery receipts"] },
  bank: { icon: Landmark, label: "Banking", tone: "bg-emerald-50 text-emerald-600 ring-emerald-600/10 dark:bg-emerald-500/10 dark:text-emerald-400", scopes: ["Read balances", "Read transactions", "No movement of funds"] },
  esign: { icon: FileSignature, label: "E-signatures", tone: "bg-amber-50 text-amber-600 ring-amber-600/10 dark:bg-amber-500/10 dark:text-amber-400", scopes: ["Create signature requests", "Read envelope status"] },
  storage: { icon: Cloud, label: "File storage", tone: "bg-sky-50 text-sky-600 ring-sky-600/10 dark:bg-sky-500/10 dark:text-sky-400", scopes: ["Read and write documents", "Read storage usage"] },
  automation: { icon: Zap, label: "Automation", tone: "bg-orange-50 text-orange-600 ring-orange-600/10 dark:bg-orange-500/10 dark:text-orange-400", scopes: ["Receive workflow events", "Send workflow results"] },
  api: { icon: Webhook, label: "Developer access", tone: "bg-slate-100 text-slate-600 ring-slate-500/10 dark:bg-slate-800 dark:text-slate-300", scopes: ["Read mock records", "Receive webhook events"] },
};

const defaultAccount: Record<IntegrationKey, string> = {
  email: "notifications@organization.com",
  sms: "Sender number · ••0199",
  bank: "Operating checking · ••4821",
  esign: "Sandbox workspace · simulated",
  storage: "organization-docs · us-west-2",
  automation: "Sandbox workspace · simulated",
  api: "2 mock webhook endpoints",
};

const PROVIDER_NAMES: Record<IntegrationKey, string> = {
  email: "Postmark",
  sms: "Textline",
  bank: "Plaid",
  esign: "DocuSign",
  storage: "Amazon S3",
  automation: "Zapier",
  api: "Rentora API",
};

export default function IntegrationsPage({ org, notify, readOnly }: PageProps) {
  const { orgSettings, updateIntegration, addActivity } = useSettings();
  const integrations = (orgSettings.integrations ?? {}) as Record<IntegrationKey, Integration>;
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState<IntegrationKey | null>(null);
  const [busy, setBusy] = useState<IntegrationKey | null>(null);

  const entries = (Object.keys(integrationMeta) as IntegrationKey[]).map((key) => ({
    key,
    meta: integrationMeta[key],
    data: integrations[key] ?? {
      provider: PROVIDER_NAMES[key],
      description: "",
      status: "disconnected",
      lastChecked: new Date().toISOString(),
      account: "",
      detail: "",
    },
  }));

  const connectedCount = entries.filter((entry) => entry.data.status === "connected").length;
  const filtered = entries.filter((entry) =>
    filter === "all" ? true : filter === "connected" ? entry.data.status === "connected" : entry.data.status !== "connected",
  );

  const changeConnection = async (key: IntegrationKey, connect: boolean) => {
    setBusy(key);
    await new Promise((resolve) => setTimeout(resolve, 900));
    const account = connect
      ? key === "email"
        ? `notifications@${org.shortName.toLowerCase().replace(/[^a-z]/g, "")}.com`
        : defaultAccount[key]
      : "";
    updateIntegration(key, {
      status: connect ? "connected" : "disconnected",
      lastChecked: new Date().toISOString(),
      account,
      detail: connect ? "Simulated connection · no credentials stored" : "No active connection",
    });
    addActivity(
      connect ? `Simulated ${PROVIDER_NAMES[key]} connection` : `Disconnected ${PROVIDER_NAMES[key]}`,
      connect ? "Integration is simulated. No credentials were requested or stored." : "Mock integration status updated",
      "integrations",
    );
    setBusy(null);
    notify(
      connect ? `${PROVIDER_NAMES[key]} connected (simulated)` : `${PROVIDER_NAMES[key]} disconnected`,
      connect ? "success" : "info",
      connect ? "No real credentials are stored and no external service is contacted." : "Related settings are unaffected.",
    );
  };

  const selectedEntry = entries.find((entry) => entry.key === selected);
  const selectedConnected = selectedEntry?.data.status === "connected";

  return (
    <div className="space-y-5">
      <Callout tone="info" icon={Info} title="All integrations are simulated">
        Connections are mock configuration for this frontend prototype. Never enter real API keys or credentials. No outbound requests, payments or messages are made.
      </Callout>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white text-slate-500 ring-1 ring-slate-200 dark:bg-slate-900 dark:ring-slate-700">
            <Plug className="h-4 w-4" />
          </span>
          <div>
            <p className="text-[13px] font-semibold text-slate-800 dark:text-slate-100">{org.name}</p>
            <p className="text-[11px] text-slate-400">{connectedCount} of {entries.length} providers connected · all simulated</p>
          </div>
        </div>
        <Segmented
          value={filter}
          onChange={setFilter}
          options={[
            { value: "all", label: `All ${entries.length}` },
            { value: "connected", label: `Connected ${connectedCount}` },
            { value: "available", label: `Available ${entries.length - connectedCount}` },
          ]}
        />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={ShieldCheck}
            title={filter === "connected" ? "No connected providers" : "Everything is connected"}
            description={filter === "connected" ? "Connect a simulated provider to see it here." : "All mock integrations are currently connected."}
            action={<Button type="button" variant="primary" onClick={() => setFilter("all")}>View all integrations</Button>}
          />
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2" id="integration-grid">
          {filtered.map(({ key, meta, data }) => {
            const connected = data.status === "connected";
            const Icon = meta.icon;
            return (
              <Card key={key} className="flex flex-col">
                <div className="flex flex-1 flex-col p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ring-1 ${meta.tone}`}>
                        <Icon className="h-5 w-5" />
                      </span>
                      <div className="min-w-0">
                        <p className="text-[13.5px] font-semibold text-slate-900 dark:text-white">{data.provider || PROVIDER_NAMES[key]}</p>
                        <p className="mt-0.5 text-[11px] text-slate-400">{meta.label}</p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Badge tone={connected ? "green" : "gray"} dot>{connected ? "Connected" : "Not connected"}</Badge>
                      <span className="text-[9.5px] font-medium uppercase tracking-wide text-slate-400">Simulated</span>
                    </div>
                  </div>
                  <p className="mt-3 text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">{data.description}</p>
                  <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10.5px] text-slate-400">
                    <span>Last checked {relativeTime(data.lastChecked)}</span>
                    {connected && data.account ? <span className="truncate">· {data.account}</span> : null}
                  </div>
                  {connected ? (
                    <div className="mt-3 flex items-center gap-1.5 rounded-lg bg-emerald-50/70 px-2.5 py-1.5 text-[11px] text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">
                      <CheckCircle2 className="h-3 w-3 shrink-0" /> {data.detail}
                    </div>
                  ) : (
                    <div className="mt-3 flex items-center gap-1.5 rounded-lg bg-slate-50 px-2.5 py-1.5 text-[11px] text-slate-500 dark:bg-slate-800/60 dark:text-slate-400">
                      <Unplug className="h-3 w-3 shrink-0" /> {data.detail || "No active connection"}
                    </div>
                  )}
                  <div className="mt-4 flex items-center gap-2 border-t border-slate-100 pt-3.5 dark:border-slate-800">
                    <Button type="button" size="sm" variant="secondary" icon={key === "api" ? ExternalLink : ChevronRight} onClick={() => setSelected(key)}>
                      {connected ? "View details" : "Configure"}
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant={connected ? "ghost" : "primary"}
                      loading={busy === key}
                      disabled={busy !== null || readOnly}
                      icon={connected ? Unplug : Link2}
                      onClick={() => changeConnection(key, !connected)}
                      className={connected ? "text-slate-500" : ""}
                    >
                      {connected ? "Disconnect" : "Connect"}
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Callout tone="neutral" icon={Webhook} title="Developer access">
        API access and webhook endpoints are shown as simulated configuration. No API keys are generated, displayed or stored in this prototype.
      </Callout>

      <Modal
        open={selected !== null}
        onClose={() => setSelected(null)}
        title={selectedEntry ? `${selectedEntry.data.provider} · ${selectedEntry.meta.label}` : "Integration details"}
        description={selectedConnected ? "Simulated connection details. No credentials are stored." : "This provider is not connected in the current organization."}
        icon={selectedEntry?.meta.icon ?? Plug}
        size="lg"
        footer={
          selectedEntry ? (
            <>
              <Button type="button" variant="secondary" onClick={() => setSelected(null)}>Close</Button>
              <Button
                type="button"
                variant={selectedConnected ? "danger" : "primary"}
                icon={selectedConnected ? Unplug : Link2}
                loading={busy === selectedEntry.key}
                disabled={busy !== null || readOnly}
                onClick={() => changeConnection(selectedEntry.key, !selectedConnected)}
              >
                {selectedConnected ? "Disconnect simulated provider" : "Simulate connection"}
              </Button>
            </>
          ) : null
        }
      >
        {selectedEntry ? (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-700">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Status</p>
                <div className="mt-1.5"><Badge tone={selectedConnected ? "green" : "gray"} dot>{selectedConnected ? "Connected" : "Not connected"}</Badge></div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-700">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Last checked</p>
                <p className="mt-1.5 text-[12px] font-medium text-slate-700 dark:text-slate-200">{selectedConnected ? dateTime(selectedEntry.data.lastChecked) : "—"}</p>
              </div>
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-700">
                <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Environment</p>
                <p className="mt-1.5 text-[12px] font-medium text-slate-700 dark:text-slate-200">Sandbox / simulated</p>
              </div>
            </div>
            {selectedConnected ? (
              <>
                <div className="rounded-lg border border-slate-200 px-3.5 py-3 dark:border-slate-700">
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Account</p>
                  <p className="mt-1 font-mono text-[11.5px] text-slate-700 dark:text-slate-200">{selectedEntry.data.account || "Sandbox workspace"}</p>
                  <p className="mt-1.5 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">{selectedEntry.data.detail}</p>
                </div>
                <div>
                  <p className="text-[12px] font-medium text-slate-800 dark:text-slate-100">Mock permissions</p>
                  <ul className="mt-2 space-y-1.5">
                    {selectedEntry.meta.scopes.map((scope) => (
                      <li key={scope} className="flex items-center gap-2 text-[11.5px] text-slate-500 dark:text-slate-400">
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" /> {scope}
                      </li>
                    ))}
                  </ul>
                </div>
                {selectedEntry.key === "api" ? (
                  <div className="space-y-2 rounded-lg border border-slate-200 p-3 dark:border-slate-700">
                    <p className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">Mock webhook endpoints</p>
                    {["https://hooks.example.com/rentora/rent-events", "https://hooks.example.com/rentora/workflow-events"].map((url) => (
                      <div key={url} className="flex items-center justify-between gap-2 rounded-md bg-slate-50 px-2 py-1.5 dark:bg-slate-800">
                        <code className="truncate text-[10.5px] text-slate-600 dark:text-slate-300">{url}</code>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard?.writeText(url).catch(() => undefined);
                            notify("Webhook URL copied", "info", "This is a sample URL, not a real endpoint.");
                          }}
                          className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                          aria-label="Copy webhook URL"
                        >
                          <Copy className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                    <p className="text-[10.5px] leading-relaxed text-slate-400">No signing secrets or API keys are displayed or persisted.</p>
                  </div>
                ) : null}
                <div className="flex items-start gap-2 rounded-lg bg-amber-50 px-3 py-2.5 text-[11px] leading-relaxed text-amber-800 dark:bg-amber-500/10 dark:text-amber-300">
                  <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  Connected status is mock state only. Disconnecting has no effect outside this prototype.
                </div>
              </>
            ) : (
              <EmptyState
                icon={selectedEntry.key === "esign" ? FileSignature : selectedEntry.key === "api" ? Webhook : Plus}
                title="No connection configured"
                description="No provider account, key or credential exists for this integration. Connect to create simulated settings for the organization."
                action={
                  <Button type="button" variant="primary" icon={Link2} disabled={readOnly} loading={busy === selectedEntry.key} onClick={() => changeConnection(selectedEntry.key, true)}>
                    Simulate connection
                  </Button>
                }
              />
            )}
          </div>
        ) : null}
      </Modal>
    </div>
  );
}
