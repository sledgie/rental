import {
  ArrowRight,
  CalendarRange,
  Eye,
  LayoutGrid,
  ListFilter,
  MonitorPlay,
  SlidersHorizontal,
  Table2,
  UserRound,
} from "lucide-react";
import type { PageProps } from "../types";
import { Badge, Callout, Card, CardBody, CardHeader, Field, Input, Select, SettingRow, Toggle } from "../components/ui";

export default function GeneralPage({ value, update, readOnly, errors, prefs, navigate }: PageProps) {
  return (
    <div className="space-y-5">
      <Callout tone="info" icon={SlidersHorizontal} title="Workspace behavior, not personal preferences">
        These defaults affect everyone in {`the organization`}. Personal choices such as theme, landing page and density live under{" "}
        <button type="button" onClick={() => navigate("personal")} className="font-semibold underline decoration-blue-300 underline-offset-2 hover:text-blue-900 dark:hover:text-blue-200">
          Personal preferences
        </button>
        .
      </Callout>

      <Card id="default-views">
        <CardHeader
          icon={CalendarRange}
          title="Default views"
          description="Set the starting view for dashboards, reports and list screens across the workspace."
          aside={<Badge tone="blue">Organization default</Badge>}
        />
        <CardBody className="grid gap-4 md:grid-cols-2">
          <Field label="Default reporting period" error={errors.reportingPeriod} hint="Applied to reports and financial summaries.">
            <Select value={value.reportingPeriod} disabled={readOnly} onChange={(event) => update("reportingPeriod", event.target.value)}>
              {["Month to date", "Last 30 days", "Current month", "Previous month", "Quarter to date", "Year to date"].map((option) => (
                <option key={option}>{option}</option>
              ))}
            </Select>
          </Field>
          <Field label="Default property portfolio view">
            <Select value={value.portfolioView} disabled={readOnly} onChange={(event) => update("portfolioView", event.target.value)}>
              {["Grid", "List", "Map", "Table"].map((option) => (
                <option key={option}>{option}</option>
              ))}
            </Select>
          </Field>
          <Field label="Default table page size" error={errors.tablePageSize} hint="Allowed range: 10–100 rows.">
            <Input type="number" min={10} max={100} value={value.tablePageSize} disabled={readOnly} invalid={!!errors.tablePageSize} onChange={(event) => update("tablePageSize", event.target.value)} />
          </Field>
          <Field label="Default filter" hint="Starting filter for property, lease and tenant lists.">
            <Select value={value.defaultFilter} disabled={readOnly} onChange={(event) => update("defaultFilter", event.target.value)}>
              {["Active records", "All records", "My assignments", "Needs attention", "Recently viewed"].map((option) => (
                <option key={option}>{option}</option>
              ))}
            </Select>
          </Field>
        </CardBody>
      </Card>

      <div className="grid gap-5 xl:grid-cols-2">
        <Card id="formats">
          <CardHeader icon={CalendarRange} title="Display formats" description="Defaults used when dates and currency are rendered." />
          <CardBody className="space-y-4">
            <Field label="Date format">
              <Select value={value.dateFormat} disabled={readOnly} onChange={(event) => update("dateFormat", event.target.value)}>
                {["MMM d, yyyy", "MM/dd/yyyy", "dd/MM/yyyy", "yyyy-MM-dd"].map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </Select>
            </Field>
            <Field label="Time format">
              <Select value={value.timeFormat} disabled={readOnly} onChange={(event) => update("timeFormat", event.target.value)}>
                {["12-hour", "24-hour"].map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </Select>
            </Field>
            <Field label="Currency display">
              <Select value={value.currencyDisplay} disabled={readOnly} onChange={(event) => update("currencyDisplay", event.target.value)}>
                {["Symbol · $1,250.00", "Code · USD 1,250.00", "Compact · $1.25K", "No cents · $1,250"].map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </Select>
            </Field>
            <div className="rounded-lg bg-slate-50 px-3 py-2.5 text-[11.5px] leading-relaxed text-slate-500 dark:bg-slate-800/60 dark:text-slate-400">
              Preview: <span className="font-medium text-slate-700 dark:text-slate-200">Aug 12, 2026 · 3:45 PM · $1,250.00</span>
            </div>
          </CardBody>
        </Card>

        <Card id="interactions">
          <CardHeader icon={Eye} title="Interaction preferences" description="How tables and potentially destructive actions behave." />
          <CardBody className="divide-y divide-slate-100 py-0 dark:divide-slate-800">
            <SettingRow title="Confirmation dialogs" description="Ask before deleting or archiving records.">
              <Toggle label="Confirmation dialogs" checked={!!value.confirmDestructive} disabled={readOnly} onChange={(checked) => update("confirmDestructive", checked)} />
            </SettingRow>
            <SettingRow title="Default sorting" description="Starting sort order for list-style screens.">
              <Select value={value.defaultSort} disabled={readOnly} onChange={(event) => update("defaultSort", event.target.value)} className="h-8.5 w-[160px] text-[12px]">
                {["Recently updated", "Name (A–Z)", "Newest first", "Oldest first", "Amount (high–low)"].map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </Select>
            </SettingRow>
            <SettingRow title="Document preview" description="Where uploaded documents open by default.">
              <Select value={value.documentPreview} disabled={readOnly} onChange={(event) => update("documentPreview", event.target.value)} className="h-8.5 w-[160px] text-[12px]">
                {["Side panel", "Full page", "New tab", "Inline preview"].map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </Select>
            </SettingRow>
          </CardBody>
        </Card>
      </div>

      <Card id="scope">
        <CardHeader
          icon={UserRound}
          title="Personal defaults live elsewhere"
          description="A clear separation keeps individual choices from changing the whole workspace."
          aside={<Badge tone="violet">Personal scope</Badge>}
        />
        <CardBody className="grid gap-4 sm:grid-cols-3">
          {[
            { icon: LayoutGrid, label: "Default dashboard after login", value: prefs?.landingPage ?? "Dashboard overview" },
            { icon: ListFilter, label: "Table density", value: prefs?.tableDensity ?? "Comfortable" },
            { icon: MonitorPlay, label: "Theme", value: prefs?.theme ? prefs.theme[0].toUpperCase() + prefs.theme.slice(1) : "Light" },
          ].map((item) => (
            <div key={item.label} className="rounded-xl border border-slate-200 bg-slate-50/40 p-3.5 dark:border-slate-700 dark:bg-slate-800/30">
              <item.icon className="h-4 w-4 text-slate-400" />
              <p className="mt-2 text-[11px] font-medium uppercase tracking-wide text-slate-400 dark:text-slate-500">{item.label}</p>
              <p className="mt-0.5 text-[12.5px] font-medium text-slate-700 dark:text-slate-200">{item.value}</p>
            </div>
          ))}
          <div className="sm:col-span-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-3 dark:border-slate-800">
            <p className="flex items-center gap-2 text-[12px] text-slate-500 dark:text-slate-400">
              <span className="font-medium text-slate-700 dark:text-slate-200">Language:</span> {prefs?.language ?? "English (United States)"}
              <Badge tone="amber">Prototype only</Badge>
              <span className="text-slate-400">Translation is not available.</span>
            </p>
            <button type="button" onClick={() => navigate("personal")} className="text-[11.5px] font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400">
              Change
            </button>
          </div>
          <div className="sm:col-span-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-3 dark:border-slate-800">
            <p className="flex items-center gap-2 text-[12px] text-slate-500 dark:text-slate-400">
              <Table2 className="h-4 w-4" /> Personal preferences are stored against your mock user, not the organization.
            </p>
            <button
              type="button"
              onClick={() => navigate("personal")}
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400"
            >
              Open personal preferences <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </CardBody>
      </Card>

      <Callout tone="neutral" title="Defaults apply going forward">
        General preferences affect the starting state of views for workspace members. They do not change existing records, leases or reports.
      </Callout>
    </div>
  );
}
