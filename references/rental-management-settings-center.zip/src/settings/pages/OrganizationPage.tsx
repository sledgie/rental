import {
  Activity,
  ArrowUpRight,
  Building2,
  CalendarDays,
  Globe2,
  Image as ImageIcon,
  Mail,
  MapPin,
  ShieldCheck,
  Trash2,
  Upload,
  UserPlus,
  Users,
} from "lucide-react";
import { useRef } from "react";
import { US_STATES, COUNTRIES, CURRENCIES, FISCAL_MONTHS, TIMEZONES } from "../mockSettings";
import type { PageProps } from "../types";
import { cnDate } from "../utils";
import { Badge, Button, Callout, Card, CardBody, CardHeader, Field, Input, Select, SettingRow, Toggle } from "../components/ui";

export default function OrganizationPage(props: PageProps) {
  const { value, update, readOnly, errors, org, members, openDirectory, notify } = props;
  const fileRef = useRef<HTMLInputElement>(null);
  const activeMembers = members.filter((member) => member.status === "Active");

  const handleLogo = (file?: File) => {
    if (!file) return;
    if (!/^image\/(png|jpeg|jpg|webp)$/.test(file.type)) {
      notify("Unsupported image format", "error", "Choose a PNG, JPG or WebP file.");
      return;
    }
    if (file.size > 600 * 1024) {
      notify("Logo is too large", "error", "Keep the file under 600 KB for this prototype.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      update("logo", reader.result as string);
      notify("Logo updated in preview", "info", "Save changes to keep this logo for the organization.");
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-5">
      <Card id="identity">
        <CardHeader
          icon={Building2}
          title="Brand & identity"
          description="The primary business identity shown across statements, notices, portals and documents."
          aside={<Badge tone="blue">Organization-wide</Badge>}
        />
        <CardBody className="space-y-5">
          <div className="flex flex-col gap-4 rounded-xl border border-slate-200 bg-slate-50/50 p-4 sm:flex-row sm:items-center dark:border-slate-700 dark:bg-slate-800/30">
            <div className="relative flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-blue-600 text-lg font-semibold tracking-tight text-white shadow-sm">
              {value.logo ? <img src={value.logo} alt="Organization logo preview" className="h-full w-full object-cover" /> : org.monogram}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[13px] font-semibold text-slate-900 dark:text-white">Business logo</p>
              <p className="mt-0.5 text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
                Used on tenant-facing documents and statements. PNG, JPG or WebP up to 600 KB. Stored locally in this prototype.
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <input
                ref={fileRef}
                id="organization-logo"
                type="file"
                accept="image/png,image/jpeg,image/webp"
                disabled={readOnly}
                onChange={(event) => handleLogo(event.target.files?.[0])}
              />
              <Button
                type="button"
                size="sm"
                icon={Upload}
                disabled={readOnly}
                onClick={() => fileRef.current?.click()}
              >
                Upload
              </Button>
              {value.logo ? (
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  icon={Trash2}
                  disabled={readOnly}
                  onClick={() => {
                    update("logo", "");
                    notify("Logo removed from preview", "info");
                  }}
                >
                  Remove
                </Button>
              ) : (
                <span className="hidden items-center gap-1.5 text-[11px] text-slate-400 sm:flex">
                  <ImageIcon className="h-3.5 w-3.5" /> Monogram fallback
                </span>
              )}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Organization display name" required error={errors.displayName} hint="Shown in navigation, headings and notifications.">
              <Input value={value.displayName} disabled={readOnly} invalid={!!errors.displayName} onChange={(event) => update("displayName", event.target.value)} placeholder="e.g. Northstar Property Group" />
            </Field>
            <Field label="Legal business name" required error={errors.legalName} hint="Must match your registered entity name.">
              <Input value={value.legalName} disabled={readOnly} invalid={!!errors.legalName} onChange={(event) => update("legalName", event.target.value)} />
            </Field>
            <Field label="Business type" required error={errors.businessType}>
              <Select value={value.businessType} disabled={readOnly} invalid={!!errors.businessType} onChange={(event) => update("businessType", event.target.value)}>
                {["Property management company", "Individual landlord", "Real estate investment firm", "Homeowners association", "Property owner / operator"].map((option) => (
                  <option key={option}>{option}</option>
                ))}
              </Select>
            </Field>
            <Field label="Business registration number" hint="Optional. Keep your records current.">
              <Input value={value.registrationNumber} disabled={readOnly} onChange={(event) => update("registrationNumber", event.target.value)} placeholder="e.g. OR-2041887" />
            </Field>
            <Field label="Business website" error={errors.website} hint="Include the full https:// address." className="md:col-span-2">
              <Input value={value.website} disabled={readOnly} icon={Globe2} invalid={!!errors.website} onChange={(event) => update("website", event.target.value)} placeholder="https://example.com" />
            </Field>
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-5 xl:grid-cols-[1.55fr_1fr]">
        <div className="space-y-5">
          <Card id="contact">
            <CardHeader icon={Mail} title="Contact details" description="Where tenants and vendors can reach the organization." />
            <CardBody className="grid gap-4 md:grid-cols-2">
              <Field label="Business email" required error={errors.email}>
                <Input type="email" value={value.email} disabled={readOnly} invalid={!!errors.email} onChange={(event) => update("email", event.target.value)} placeholder="hello@example.com" />
              </Field>
              <Field label="Business phone" hint="Include the area code.">
                <Input value={value.phone} disabled={readOnly} onChange={(event) => update("phone", event.target.value)} placeholder="(503) 555-0184" />
              </Field>
            </CardBody>
          </Card>

          <Card id="address">
            <CardHeader icon={MapPin} title="Business address" description="The legal mailing address for the organization." />
            <CardBody className="grid gap-4 md:grid-cols-6">
              <Field label="Street address" required error={errors.addressLine1} className="md:col-span-6">
                <Input value={value.addressLine1} disabled={readOnly} invalid={!!errors.addressLine1} onChange={(event) => update("addressLine1", event.target.value)} />
              </Field>
              <Field label="Address line 2" className="md:col-span-6">
                <Input value={value.addressLine2} disabled={readOnly} onChange={(event) => update("addressLine2", event.target.value)} placeholder="Suite, unit or floor" />
              </Field>
              <Field label="City" required error={errors.city} className="md:col-span-2">
                <Input value={value.city} disabled={readOnly} invalid={!!errors.city} onChange={(event) => update("city", event.target.value)} />
              </Field>
              <Field label="State / province" required error={errors.state} className="md:col-span-2">
                <Select value={value.state} disabled={readOnly} invalid={!!errors.state} onChange={(event) => update("state", event.target.value)}>
                  {[...new Set([value.state, ...US_STATES])].filter(Boolean).map((option) => (
                    <option key={option}>{option}</option>
                  ))}
                </Select>
              </Field>
              <Field label="Postal / ZIP" required error={errors.postalCode} className="md:col-span-2">
                <Input value={value.postalCode} disabled={readOnly} invalid={!!errors.postalCode} onChange={(event) => update("postalCode", event.target.value)} />
              </Field>
              <Field label="Country" required error={errors.country} className="md:col-span-6">
                <Select value={value.country} disabled={readOnly} invalid={!!errors.country} onChange={(event) => update("country", event.target.value)}>
                  {COUNTRIES.map((option) => (
                    <option key={option}>{option}</option>
                  ))}
                </Select>
              </Field>
            </CardBody>
          </Card>

          <Card id="regional">
            <CardHeader icon={ShieldCheck} title="Regional & financial formats" description="Applied to new financial records, exports and statements." />
            <CardBody className="grid gap-4 md:grid-cols-2">
              <Field label="Default currency" required error={errors.currency} hint="Used for new leases, invoices and reports.">
                <Select value={value.currency} disabled={readOnly} invalid={!!errors.currency} onChange={(event) => update("currency", event.target.value)}>
                  {CURRENCIES.map((option) => (
                    <option key={option}>{option}</option>
                  ))}
                </Select>
              </Field>
              <Field label="Time zone" required error={errors.timeZone}>
                <Select value={value.timeZone} disabled={readOnly} invalid={!!errors.timeZone} onChange={(event) => update("timeZone", event.target.value)}>
                  {TIMEZONES.map((option) => (
                    <option key={option}>{option}</option>
                  ))}
                </Select>
              </Field>
              <Field label="Date format">
                <Select value={value.dateFormat} disabled={readOnly} onChange={(event) => update("dateFormat", event.target.value)}>
                  {["MMM d, yyyy", "MM/dd/yyyy", "dd/MM/yyyy", "yyyy-MM-dd"].map((option) => (
                    <option key={option}>{option}</option>
                  ))}
                </Select>
              </Field>
              <Field label="Number format">
                <Select value={value.numberFormat} disabled={readOnly} onChange={(event) => update("numberFormat", event.target.value)}>
                  {["1,234.56", "1.234,56", "1 234,56"].map((option) => (
                    <option key={option}>{option}</option>
                  ))}
                </Select>
              </Field>
              <Field label="Fiscal year start" required error={errors.fiscalYearStart} hint="Affects financial reporting periods only.">
                <Select value={value.fiscalYearStart} disabled={readOnly} invalid={!!errors.fiscalYearStart} onChange={(event) => update("fiscalYearStart", event.target.value)}>
                  {FISCAL_MONTHS.map((option) => (
                    <option key={option}>{option}</option>
                  ))}
                </Select>
              </Field>
              <Field label="Organization code" hint="Read-only identifier for exports and support.">
                <Input value={value.orgCode} disabled readOnly />
              </Field>
            </CardBody>
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader icon={ShieldCheck} title="Organization status" />
            <CardBody className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[12px] text-slate-500 dark:text-slate-400">Workspace status</span>
                <Badge tone="green" dot>Active</Badge>
              </div>
              <div className="space-y-0.5 divide-y divide-slate-100 text-[12px] dark:divide-slate-800">
                {[
                  ["Plan", `${value.plan} workspace`],
                  ["Member since", cnDate(value.createdAt)],
                  ["Organization ID", value.orgCode],
                  ["Portfolio", `${org.propertyCount} properties · ${org.unitCount} units`],
                ].map(([label, val]) => (
                  <div key={label} className="flex items-center justify-between gap-4 py-2">
                    <span className="text-slate-500 dark:text-slate-400">{label}</span>
                    <span className="text-right font-medium text-slate-700 dark:text-slate-200">{val}</span>
                  </div>
                ))}
              </div>
              <Callout tone="neutral" icon={ShieldCheck}>
                This is a frontend prototype. Organization metadata is stored in your browser and is not sent to a server.
              </Callout>
            </CardBody>
          </Card>

          <Card id="records">
            <CardHeader icon={Users} title="Team summary" description="Membership data is shared with the Organization module." />
            <CardBody className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {activeMembers.slice(0, 4).map((member) => (
                    <span
                      key={member.id}
                      title={`${member.name} · ${member.role}`}
                      className={`flex h-7 w-7 items-center justify-center rounded-full border-2 border-white text-[9.5px] font-semibold text-white dark:border-slate-900 ${member.avatarTone}`}
                    >
                      {member.initials}
                    </span>
                  ))}
                </div>
                <span className="text-[11.5px] text-slate-500 dark:text-slate-400">
                  {activeMembers.length} active members
                </span>
              </div>
              <div className="space-y-1.5">
                <button
                  type="button"
                  onClick={() => openDirectory("members")}
                  className="flex w-full items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-left transition hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
                >
                  <span className="flex items-center gap-2 text-[12px] font-medium text-slate-700 dark:text-slate-200"><Users className="h-3.5 w-3.5 text-slate-400" />Members</span>
                  <ArrowUpRight className="h-3.5 w-3.5 text-slate-400" />
                </button>
                <button
                  type="button"
                  onClick={() => openDirectory("invitations")}
                  className="flex w-full items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-left transition hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
                >
                  <span className="flex items-center gap-2 text-[12px] font-medium text-slate-700 dark:text-slate-200"><UserPlus className="h-3.5 w-3.5 text-slate-400" />Invitations</span>
                  <ArrowUpRight className="h-3.5 w-3.5 text-slate-400" />
                </button>
                <button
                  type="button"
                  onClick={() => openDirectory("activity")}
                  className="flex w-full items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-left transition hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
                >
                  <span className="flex items-center gap-2 text-[12px] font-medium text-slate-700 dark:text-slate-200"><Activity className="h-3.5 w-3.5 text-slate-400" />Activity log</span>
                  <ArrowUpRight className="h-3.5 w-3.5 text-slate-400" />
                </button>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-400 dark:text-slate-500">
                Opens a read-only view of existing organization records. Member management stays in the Organization module.
              </p>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title="Default preferences" description="Organization-wide behavior for new records and workflows." />
            <CardBody className="divide-y divide-slate-100 py-0 dark:divide-slate-800">
              <SettingRow title="Property-level permissions" description="Allow access to be scoped per property.">
                <Toggle label="Property-level permissions" checked={!!value.propertyLevelPermissions} disabled={readOnly} onChange={(checked) => update("propertyLevelPermissions", checked)} />
              </SettingRow>
              <SettingRow title="Vendor approval" description="Require approval before new vendors are used.">
                <Toggle label="Vendor approval" checked={!!value.requireVendorApproval} disabled={readOnly} onChange={(checked) => update("requireVendorApproval", checked)} />
              </SettingRow>
              <SettingRow title="Auto-archive signed leases" description="Archive fully signed leases after completion.">
                <Toggle label="Auto-archive signed leases" checked={!!value.autoArchiveSignedLeases} disabled={readOnly} onChange={(checked) => update("autoArchiveSignedLeases", checked)} />
              </SettingRow>
            </CardBody>
          </Card>
        </div>
      </div>

      <div className="flex items-center gap-2 px-1 text-[11.5px] text-slate-400 dark:text-slate-500">
        <CalendarDays className="h-3.5 w-3.5" />
        Organization created {cnDate(value.createdAt)} · IDs and metadata are read-only in this prototype.
      </div>
    </div>
  );
}
