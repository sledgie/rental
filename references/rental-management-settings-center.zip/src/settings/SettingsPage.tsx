import {
  Building2,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  Eye,
  Info,
  Lock,
  RotateCcw,
  Save,
  Search,
  Settings2,
  Undo2,
  X,
} from "lucide-react";
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import { CATEGORY_MAP, GROUP_LABELS, GROUP_ORDER, SEARCH_INDEX, SETTINGS_CATEGORIES } from "./catalog";
import DirectoryDrawer from "./components/DirectoryDrawer";
import { Badge, Button, Callout, Card, Input, Modal } from "./components/ui";
import { CURRENT_USER, defaultUserPreferences } from "./mockSettings";
import GeneralPage from "./pages/GeneralPage";
import FinancialPage from "./pages/FinancialPage";
import OrganizationPage from "./pages/OrganizationPage";
import PropertyPage from "./pages/PropertyPage";
import MaintenancePage from "./pages/MaintenancePage";
import ProjectsPage from "./pages/ProjectsPage";
import NotificationsPage from "./pages/NotificationsPage";
import TasksPage from "./pages/TasksPage";
import WorkflowPage from "./pages/WorkflowPage";
import DocumentsPage from "./pages/DocumentsPage";
import SecurityPage from "./pages/SecurityPage";
import IntegrationsPage from "./pages/IntegrationsPage";
import DataPage from "./pages/DataPage";
import PersonalPage from "./pages/PersonalPage";
import { useSettings } from "./store";
import type { CategoryId, DirectoryTab, PageProps, UserPreferences } from "./types";
import { friendlyErrorList, validateCategory } from "./validation";
import { clone } from "./utils";

const PAGE_COMPONENTS: Record<CategoryId, (props: PageProps) => React.ReactElement> = {
  organization: OrganizationPage,
  general: GeneralPage,
  financial: FinancialPage,
  property: PropertyPage,
  maintenance: MaintenancePage,
  projects: ProjectsPage,
  notifications: NotificationsPage,
  tasks: TasksPage,
  workflow: WorkflowPage,
  documents: DocumentsPage,
  security: SecurityPage,
  integrations: IntegrationsPage,
  data: DataPage,
  personal: PersonalPage,
};

interface SettingsPageProps {
  category: CategoryId;
  onCategoryChange: (category: CategoryId) => void;
  onDirtyChange: (dirty: boolean, discard: () => void) => void;
}

export default function SettingsPage({ category, onCategoryChange, onDirtyChange }: SettingsPageProps) {
  const settings = useSettings();
  const {
    orgSettings,
    prefs,
    activeOrg,
    role,
    canEdit,
    saveCategory,
    resetCategory,
    savePreferences,
    resetPreferences,
    notify,
    members,
    activity,
    defaults,
    revision,
  } = settings;

  const editable = canEdit(category);
  const readOnly = !editable;
  const isPersonal = category === "personal";
  const isImmediate = CATEGORY_MAP[category]?.immediate;
  const savedValue = useMemo(
    () => (isPersonal ? prefs : isImmediate ? orgSettings[category] ?? defaults[category] : orgSettings[category] ?? defaults[category]),
    [isPersonal, isImmediate, prefs, orgSettings, defaults, category],
  );
  const [draft, setDraft] = useState<any>(() => clone(savedValue));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);
  const [search, setSearch] = useState("");
  const [pending, setPending] = useState<{ category: CategoryId; anchor?: string } | null>(null);
  const [resetOpen, setResetOpen] = useState(false);
  const [directory, setDirectory] = useState<{ open: boolean; tab: DirectoryTab }>({ open: false, tab: "members" });
  const pendingAnchor = useRef<string | undefined>(undefined);
  const searchRef = useRef<HTMLInputElement>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const formReadOnly = readOnly || saving;

  const dirty = !isImmediate && JSON.stringify(draft) !== JSON.stringify(savedValue);
  const pageKey = `${activeOrg.id}:${category}`;
  const orgDisplayName = orgSettings.organization?.displayName?.trim() || activeOrg.name;

  useLayoutEffect(() => {
    setDraft(clone(savedValue));
    setErrors({});
    setSearch("");
    setLastSavedAt(null);
    // Reset when the active organization, category or persisted values change
    // through a save, reset or mock import.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeOrg.id, category, revision]);

  const discardChanges = useCallback(() => {
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    setSaving(false);
    setDraft(clone(savedValue));
    setErrors({});
  }, [savedValue]);

  useEffect(() => {
    onDirtyChange(dirty, discardChanges);
  }, [dirty, discardChanges, onDirtyChange]);

  useEffect(() => {
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    setSaving(false);
  }, [activeOrg.id, category]);

  useEffect(
    () => () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    },
    [],
  );

  useEffect(() => {
    const handler = (event: BeforeUnloadEvent) => {
      if (!dirty) return;
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty]);

  useEffect(() => {
    const anchor = pendingAnchor.current;
    if (!anchor) return;
    pendingAnchor.current = undefined;
    const timer = setTimeout(() => {
      document.getElementById(anchor)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 120);
    return () => clearTimeout(timer);
  }, [category]);

  const matches = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return { fields: [], categories: SETTINGS_CATEGORIES };
    const fields = SEARCH_INDEX.filter((entry) => {
      const categoryLabel = CATEGORY_MAP[entry.category]?.label ?? "";
      return `${entry.label} ${entry.keywords} ${categoryLabel}`.toLowerCase().includes(query);
    }).slice(0, 9);
    const categories = SETTINGS_CATEGORIES.filter((entry) =>
      `${entry.label} ${entry.description} ${entry.keywords.join(" ")}`.toLowerCase().includes(query),
    );
    return { fields, categories };
  }, [search]);

  const scrollToAnchor = (anchor?: string) => {
    if (!anchor) {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    setTimeout(() => document.getElementById(anchor)?.scrollIntoView({ behavior: "smooth", block: "center" }), 120);
  };

  const goCategory = (next: CategoryId, anchor?: string) => {
    setSearch("");
    setErrors({});
    if (next === category) {
      scrollToAnchor(anchor);
      return;
    }
    pendingAnchor.current = anchor;
    onCategoryChange(next);
  };

  const attemptCategory = (next: CategoryId, anchor?: string) => {
    if (next === category) {
      scrollToAnchor(anchor);
      setSearch("");
      return;
    }
    if (dirty) {
      setPending({ category: next, anchor });
      return;
    }
    goCategory(next, anchor);
  };

  const update = (key: string, value: unknown) => {
    setDraft((current: any) => ({ ...current, [key]: value }));
    if (errors[key]) setErrors((current) => ({ ...current, [key]: "" }));
  };

  const handleSave = () => {
    if (readOnly || saving) return;
    const validation = validateCategory(category, draft);
    if (Object.keys(validation).length) {
      setErrors(validation);
      notify("Changes were not saved", "error", `${Object.keys(validation).length} field${Object.keys(validation).length === 1 ? "" : "s"} need attention. Review the highlighted fields.`);
      setTimeout(() => document.getElementById("settings-error-summary")?.scrollIntoView({ behavior: "smooth", block: "center" }), 80);
      return;
    }
    setErrors({});
    setSaving(true);
    saveTimer.current = setTimeout(() => {
      saveTimer.current = null;
      if (isPersonal) savePreferences(draft as UserPreferences);
      else saveCategory(category, draft);
      setSaving(false);
      setLastSavedAt(new Date());
      notify(
        isPersonal ? "Personal preferences saved" : `${CATEGORY_MAP[category].shortLabel} settings saved`,
        "success",
        isPersonal ? "Your choices are stored against the current mock user." : `Changes are scoped to ${orgDisplayName}.`,
      );
    }, 700);
  };

  const handleDiscard = () => {
    if (!dirty) return;
    discardChanges();
    notify("Changes discarded", "info", "Restored the last saved configuration for this category.");
  };

  const confirmReset = () => {
    setResetOpen(false);
    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
      saveTimer.current = null;
    }
    setSaving(false);
    if (isPersonal) {
      resetPreferences();
      setDraft(defaultUserPreferences(CURRENT_USER.id));
      setLastSavedAt(new Date());
      notify("Personal preferences reset", "success", "Restored personal prototype defaults.");
    } else {
      resetCategory(category);
      setDraft(clone(defaults[category]));
      setLastSavedAt(new Date());
      notify(`${CATEGORY_MAP[category].shortLabel} settings reset`, "success", "Only this category was restored. Existing records are unchanged.");
    }
    setErrors({});
  };

  const Page = PAGE_COMPONENTS[category];
  const CategoryIcon = CATEGORY_MAP[category].icon;
  const categoryMeta = CATEGORY_MAP[category];
  const validationErrors = Object.values(errors).filter(Boolean);

  return (
    <div className="mx-auto w-full max-w-[1480px] px-4 pb-24 pt-5 sm:px-6 lg:px-8 lg:pb-12">
      <div className="mb-5 flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2.5">
            <h1 className="text-[26px] font-semibold tracking-[-0.03em] text-slate-900 dark:text-white">Settings</h1>
            <Badge tone="gray" icon={Building2}>{activeOrg.shortName}</Badge>
            <Badge tone="violet">Prototype · mock data</Badge>
          </div>
          <p className="mt-1 max-w-2xl text-[13px] leading-relaxed text-slate-500 dark:text-slate-400">
            Configure your organization and manage how your rental business operates.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {isImmediate ? (
            <span className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 text-[11.5px] font-medium text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300">
              <CheckCircle2 className="h-3.5 w-3.5" /> Applies immediately
            </span>
          ) : (
            <>
              <Button type="button" variant="secondary" icon={Undo2} onClick={handleDiscard} disabled={!dirty || saving || readOnly}>
                Discard
              </Button>
              <Button type="button" variant="primary" icon={Save} loading={saving} onClick={handleSave} disabled={!dirty || saving || readOnly}>
                Save changes
              </Button>
            </>
          )}
          <Button type="button" variant="ghost" icon={RotateCcw} onClick={() => setResetOpen(true)} disabled={readOnly || saving} className="hidden sm:inline-flex">
            Reset
          </Button>
        </div>
      </div>

      <div className="grid items-start gap-5 lg:grid-cols-[252px_minmax(0,1fr)]">
        <aside className="lg:sticky lg:top-20">
          <div className="mb-3 lg:hidden">
            <Card className="p-3">
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                <Input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search settings…"
                  className="pl-9"
                  aria-label="Search settings"
                />
              </div>
              {search.trim() ? (
                <div className="mt-2 max-h-64 space-y-1 overflow-y-auto">
                  {matches.fields.map((entry) => (
                    <button
                      key={`${entry.category}-${entry.label}`}
                      type="button"
                      onClick={() => attemptCategory(entry.category, entry.anchor)}
                      className="flex w-full items-center justify-between gap-2 rounded-lg px-2 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      <span className="min-w-0">
                        <span className="block truncate text-[12px] font-medium text-slate-700 dark:text-slate-200">{entry.label}</span>
                        <span className="block text-[10.5px] text-slate-400">{CATEGORY_MAP[entry.category].shortLabel}</span>
                      </span>
                      <ChevronRight className="h-3.5 w-3.5 shrink-0 text-slate-300" />
                    </button>
                  ))}
                  {matches.categories.slice(0, 4).map((entry) => (
                    <button
                      key={entry.id}
                      type="button"
                      onClick={() => attemptCategory(entry.id)}
                      className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      <entry.icon className="h-3.5 w-3.5 text-slate-400" />
                      <span className="min-w-0 flex-1 truncate text-[12px] font-medium text-slate-700 dark:text-slate-200">{entry.label}</span>
                      <ChevronRight className="h-3.5 w-3.5 shrink-0 text-slate-300" />
                    </button>
                  ))}
                  {!matches.fields.length && !matches.categories.length ? <p className="px-2 py-3 text-[11.5px] text-slate-400">No settings found for “{search}”.</p> : null}
                </div>
              ) : (
                <div className="mt-2">
                  <select
                    value={category}
                    onChange={(event) => attemptCategory(event.target.value as CategoryId)}
                    aria-label="Settings category"
                    className="h-9.5 w-full rounded-lg border border-slate-200 bg-white px-3 text-[13px] text-slate-800 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/15 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  >
                    {GROUP_ORDER.map((group) => (
                      <optgroup key={group} label={GROUP_LABELS[group]}>
                        {SETTINGS_CATEGORIES.filter((entry) => entry.group === group).map((entry) => (
                          <option key={entry.id} value={entry.id}>{entry.label}</option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                </div>
              )}
            </Card>
          </div>

          <Card className="hidden max-h-[calc(100vh-6rem)] overflow-y-auto lg:block">
            <div className="border-b border-slate-100 p-2.5 dark:border-slate-800">
              <div className="relative">
                <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                <input
                  ref={searchRef}
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search settings…"
                  aria-label="Search settings"
                  className="h-8.5 w-full rounded-lg border border-slate-200 bg-white pl-8 pr-8 text-[12.5px] text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/15 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
                {search ? (
                  <button type="button" onClick={() => setSearch("")} aria-label="Clear search" className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
                    <X className="h-3.5 w-3.5" />
                  </button>
                ) : (
                  <kbd className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 rounded border border-slate-200 bg-slate-50 px-1 text-[9px] font-medium text-slate-400 dark:border-slate-700 dark:bg-slate-800">⌘K</kbd>
                )}
              </div>
            </div>

            {search.trim() ? (
              <div className="max-h-[calc(100vh-280px)] overflow-y-auto p-2">
                <p className="px-2 py-1.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-400">
                  {matches.fields.length + matches.categories.length} matches
                </p>
                {matches.fields.map((entry) => (
                  <button
                    key={`${entry.category}-${entry.label}`}
                    type="button"
                    onClick={() => attemptCategory(entry.category, entry.anchor)}
                    className="group flex w-full items-start justify-between gap-2 rounded-lg px-2 py-2 text-left transition hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    <span className="min-w-0">
                      <span className="block text-[12px] font-medium text-slate-700 group-hover:text-blue-700 dark:text-slate-200 dark:group-hover:text-blue-300">{entry.label}</span>
                      <span className="mt-0.5 block text-[10.5px] text-slate-400">{CATEGORY_MAP[entry.category].shortLabel}</span>
                    </span>
                    <ChevronRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-300" />
                  </button>
                ))}
                {matches.categories.length ? (
                  <>
                    <p className="mt-2 px-2 py-1.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-slate-400">Categories</p>
                    {matches.categories.map((entry) => (
                      <button
                        key={entry.id}
                        type="button"
                        onClick={() => attemptCategory(entry.id)}
                        className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left transition hover:bg-slate-50 dark:hover:bg-slate-800"
                      >
                        <entry.icon className="h-3.5 w-3.5 text-slate-400" />
                        <span className="text-[12px] font-medium text-slate-700 dark:text-slate-200">{entry.label}</span>
                      </button>
                    ))}
                  </>
                ) : null}
                {!matches.fields.length && !matches.categories.length ? (
                  <div className="px-2 py-6 text-center">
                    <Search className="mx-auto h-5 w-5 text-slate-300" />
                    <p className="mt-2 text-[12px] font-medium text-slate-600 dark:text-slate-300">No settings found</p>
                    <p className="mt-0.5 text-[11px] text-slate-400">Try “rent”, “email” or “invoice”.</p>
                  </div>
                ) : null}
              </div>
            ) : (
              <nav className="p-2" aria-label="Settings categories">
                {GROUP_ORDER.map((group) => (
                  <div key={group} className={group === "personal" ? "mt-1 border-t border-slate-100 pt-2 dark:border-slate-800" : ""}>
                    <p className="px-2 pb-1 pt-2 text-[9.5px] font-semibold uppercase tracking-[0.12em] text-slate-400 dark:text-slate-500">
                      {GROUP_LABELS[group]}
                    </p>
                    <div className="space-y-0.5">
                      {SETTINGS_CATEGORIES.filter((entry) => entry.group === group).map((entry) => {
                        const active = entry.id === category;
                        const locked = !settings.canEdit(entry.id);
                        return (
                          <button
                            key={entry.id}
                            type="button"
                            onClick={() => attemptCategory(entry.id)}
                            aria-current={active ? "page" : undefined}
                            className={cn(
                              "group flex w-full items-center gap-2.5 rounded-lg px-2 py-[7px] text-left transition",
                              active
                                ? "bg-blue-50 text-blue-700 ring-1 ring-inset ring-blue-600/10 dark:bg-blue-500/10 dark:text-blue-300 dark:ring-blue-400/20"
                                : "text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white",
                            )}
                          >
                            <entry.icon className={cn("h-4 w-4 shrink-0", active ? "text-blue-600 dark:text-blue-400" : "text-slate-400 group-hover:text-slate-500 dark:text-slate-500")} />
                            <span className="min-w-0 flex-1 truncate text-[12.5px] font-medium">{entry.label}</span>
                            {locked && entry.id !== "personal" ? <Lock className="h-3 w-3 shrink-0 text-slate-300 dark:text-slate-600" /> : null}
                            {active ? <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-blue-600 dark:bg-blue-400" /> : null}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </nav>
            )}

            <div className="border-t border-slate-100 p-2.5 dark:border-slate-800">
              <div className="flex items-start gap-2 rounded-lg bg-slate-50 px-2.5 py-2 dark:bg-slate-800/50">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-400" />
                <div>
                  <p className="text-[11px] font-medium text-slate-600 dark:text-slate-300">Prototype settings</p>
                  <p className="mt-0.5 text-[10.5px] leading-relaxed text-slate-400">
                    Stored in your browser per organization. No production policies are enforced.
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </aside>

        <main className="min-w-0" aria-live="polite">
          <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
            <div className="flex min-w-0 items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 shadow-sm dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300">
                <CategoryIcon className="h-4.5 w-4.5" />
              </span>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-[17px] font-semibold tracking-[-0.02em] text-slate-900 dark:text-white">{categoryMeta.label}</h2>
                  <Badge tone={isPersonal ? "violet" : "blue"}>{isPersonal ? "Personal scope" : isImmediate ? "Simulated" : "Organization-wide"}</Badge>
                </div>
                <p className="mt-0.5 max-w-xl text-[12px] leading-relaxed text-slate-500 dark:text-slate-400">{categoryMeta.description}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 pt-1">
              {saving ? (
                <span className="flex items-center gap-1.5 text-[11.5px] text-slate-500 dark:text-slate-400">
                  <Settings2 className="h-3.5 w-3.5 animate-spin" /> Saving…
                </span>
              ) : dirty ? (
                <span className="flex items-center gap-1.5 text-[11.5px] font-medium text-amber-600 dark:text-amber-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-amber-500" /> Unsaved changes
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-[11.5px] text-slate-400">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                  {lastSavedAt ? `Saved ${lastSavedAt.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}` : "All changes saved"}
                </span>
              )}
              <button
                type="button"
                onClick={() => setResetOpen(true)}
                disabled={readOnly || saving}
                className="inline-flex items-center gap-1 text-[11.5px] font-medium text-slate-500 underline-offset-2 hover:text-slate-800 hover:underline disabled:opacity-50 sm:hidden dark:text-slate-400 dark:hover:text-slate-200"
              >
                <RotateCcw className="h-3 w-3" /> Reset
              </button>
            </div>
          </div>

          {readOnly ? (
            <Callout tone="warning" icon={Lock} title="View-only access" className="mb-4">
              You are viewing these settings as <strong>{role}</strong>. Your role can review this category but cannot change it. Ask an Owner or Administrator if a change is needed.
            </Callout>
          ) : null}

          {validationErrors.length ? (
            <div id="settings-error-summary" className="mb-4">
              <Callout tone="danger" icon={CircleAlert} title={`Your changes were not saved (${validationErrors.length} issue${validationErrors.length === 1 ? "" : "s"})`}>
                <ul className="mt-1 space-y-1">
                  {friendlyErrorList(errors).map((message, index) => (
                    <li key={`${message}-${index}`}>• {message}</li>
                  ))}
                </ul>
              </Callout>
            </div>
          ) : null}

          {isPersonal ? (
            <Callout tone="neutral" icon={Eye} className="mb-4">
              Personal preferences are associated with {CURRENT_USER.name} and are separate from organization-wide settings.
            </Callout>
          ) : null}

          <div key={pageKey}>
            <Page
              value={isImmediate ? orgSettings.integrations : draft}
              update={update}
              readOnly={formReadOnly}
              errors={errors}
              org={activeOrg}
              prefs={prefs}
              navigate={(next, anchor) => attemptCategory(next, anchor)}
              openDirectory={(tab) => setDirectory({ open: true, tab })}
              notify={notify}
              activity={activity}
              members={members}
            />
          </div>

          {!isImmediate && !readOnly ? (
            <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white/70 px-4 py-3 dark:border-slate-800 dark:bg-slate-900/60">
              <p className="flex items-center gap-1.5 text-[11.5px] text-slate-400 dark:text-slate-500">
                <Info className="h-3.5 w-3.5" />
                Saving updates only this category and never changes existing rental records.
              </p>
              <div className="flex items-center gap-2">
                <Button type="button" variant="ghost" size="sm" onClick={handleDiscard} disabled={!dirty || saving}>
                  Discard
                </Button>
                <Button type="button" variant="primary" size="sm" icon={Save} loading={saving} onClick={handleSave} disabled={!dirty || saving}>
                  Save changes
                </Button>
              </div>
            </div>
          ) : null}
        </main>
      </div>

      {dirty && !readOnly && !isImmediate ? (
        <div className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 px-4 py-2.5 backdrop-blur lg:hidden dark:border-slate-700 dark:bg-slate-900/95">
          <div className="flex items-center justify-between gap-3">
            <span className="flex items-center gap-1.5 text-[11.5px] font-medium text-amber-600 dark:text-amber-400">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-500" /> Unsaved changes
            </span>
            <div className="flex items-center gap-2">
              <Button type="button" size="sm" variant="secondary" onClick={handleDiscard} disabled={saving}>Discard</Button>
              <Button type="button" size="sm" variant="primary" loading={saving} onClick={handleSave} disabled={saving}>Save changes</Button>
            </div>
          </div>
        </div>
      ) : null}

      <Modal
        open={pending !== null}
        onClose={() => setPending(null)}
        title="You have unsaved changes"
        description="Leaving this category will discard your edits since the last save."
        icon={CircleAlert}
        size="sm"
        footer={
          <>
            <Button type="button" variant="secondary" onClick={() => setPending(null)}>Keep editing</Button>
            <Button
              type="button"
              variant="danger"
              onClick={() => {
                const next = pending;
                setPending(null);
                if (!next) return;
                discardChanges();
                goCategory(next.category, next.anchor);
              }}
            >
              Discard & continue
            </Button>
          </>
        }
      >
        <p className="text-[12.5px] leading-relaxed text-slate-600 dark:text-slate-300">
          Your changes to <span className="font-medium">{categoryMeta.label}</span> have not been saved. You can continue editing, or discard them and move to another section.
        </p>
      </Modal>

      <Modal
        open={resetOpen}
        onClose={() => setResetOpen(false)}
        title={`Reset ${categoryMeta.shortLabel.toLowerCase()} settings?`}
        description="Only this category will be restored. No other settings or records are affected."
        icon={RotateCcw}
        size="sm"
        footer={
          <>
            <Button type="button" variant="secondary" onClick={() => setResetOpen(false)}>Cancel</Button>
            <Button type="button" variant="danger" icon={RotateCcw} onClick={confirmReset}>Reset to defaults</Button>
          </>
        }
      >
        <div className="space-y-3">
          <p className="text-[12.5px] leading-relaxed text-slate-600 dark:text-slate-300">
            This restores the prototype default values for <span className="font-medium">{categoryMeta.label}</span> for {isPersonal ? "your mock user" : orgDisplayName}. This action does not delete records or reset the full application.
          </p>
          {dirty ? (
            <Callout tone="warning" icon={CircleAlert}>
              Your current unsaved edits in this category will be lost.
            </Callout>
          ) : null}
        </div>
      </Modal>

      <DirectoryDrawer
        open={directory.open}
        initialTab={directory.tab}
        onClose={() => setDirectory({ ...directory, open: false })}
      />
    </div>
  );
}
