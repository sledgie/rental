import {
  Activity,
  ArrowRight,
  Bell,
  Building2,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  ChevronsUpDown,
  CircleHelp,
  FileSignature,
  FileText,
  Hammer,
  HelpCircle,
  Landmark,
  LayoutDashboard,
  LogOut,
  Menu,
  PieChart,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Users,
  Wallet,
  Workflow,
  Wrench,
  X,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Toasts, Badge, Button, Input, Modal } from "@/settings/components/ui";
import { CATEGORY_MAP, SEARCH_INDEX, SETTINGS_CATEGORIES } from "@/settings/catalog";
import SettingsPage from "@/settings/SettingsPage";
import { SettingsProvider, useSettings } from "@/settings/store";
import type { CategoryId } from "@/settings/types";
import { relativeTime } from "@/settings/utils";
import { MODULES, ModulePreview, OverviewPage, type ModuleId } from "@/workspace/WorkspacePages";

type Route =
  | { page: "settings"; category: CategoryId }
  | { page: "overview" }
  | { page: "module"; module: ModuleId };

function isCategory(value: string | undefined): value is CategoryId {
  return !!value && SETTINGS_CATEGORIES.some((category) => category.id === value);
}

function parseHash(): Route {
  const raw = window.location.hash.replace(/^#\/?/, "");
  const [segment, sub] = raw.split("/");
  if (segment === "overview") return { page: "overview" };
  if (segment === "settings") return { page: "settings", category: isCategory(sub) ? sub : "organization" };
  if (segment && segment in MODULES) return { page: "module", module: segment as ModuleId };
  return { page: "settings", category: "organization" };
}

function routeHash(route: Route): string {
  if (route.page === "overview") return "#/overview";
  if (route.page === "module") return `#/${route.module}`;
  return `#/settings/${route.category}`;
}

const WORKSPACE_NAV: Array<{ label: string; page: "overview" } | { label: string; module: ModuleId }> = [
  { label: "Overview", page: "overview" },
];

const PORTFOLIO_NAV: ModuleId[] = ["properties", "leases", "tenants"];
const OPERATIONS_NAV: ModuleId[] = ["maintenance", "projects", "documents"];
const FINANCE_NAV: ModuleId[] = ["accounting", "reports"];
const AUTOMATION_NAV: ModuleId[] = ["automation"];

const NAV_ICONS: Record<ModuleId, typeof Building2> = {
  properties: Building2,
  leases: FileSignature,
  tenants: Users,
  maintenance: Wrench,
  projects: Hammer,
  accounting: Landmark,
  reports: PieChart,
  documents: FileText,
  automation: Workflow,
};

function SidebarContent({ route, onNavigate, onClose, onSwitchOrganization }: { route: Route; onNavigate: (route: Route) => void; onClose?: () => void; onSwitchOrganization: (orgId: string) => void }) {
  const { orgs, activeOrg, currentUser, role, orgSettings } = useSettings();
  const [orgMenuOpen, setOrgMenuOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);

  const navButton = (label: string, active: boolean, Icon: typeof Building2, onClick: () => void, badge?: string) => (
    <button
      key={label}
      type="button"
      onClick={onClick}
      className={`group flex h-8.5 w-full items-center gap-2.5 rounded-lg px-2.5 text-left transition ${
        active
          ? "bg-blue-50 font-medium text-blue-700 ring-1 ring-inset ring-blue-600/10 dark:bg-blue-500/10 dark:text-blue-300 dark:ring-blue-400/20"
          : "text-slate-600 hover:bg-slate-100/80 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800/60 dark:hover:text-slate-100"
      }`}
    >
      <Icon className={`h-4 w-4 shrink-0 ${active ? "text-blue-600 dark:text-blue-400" : "text-slate-400 group-hover:text-slate-500 dark:text-slate-500"}`} />
      <span className="min-w-0 flex-1 truncate text-[12.5px]">{label}</span>
      {badge ? <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[9.5px] font-medium text-slate-500 dark:bg-slate-700 dark:text-slate-300">{badge}</span> : null}
    </button>
  );

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-16 shrink-0 items-center justify-between border-b border-slate-200/80 px-4 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-[9px] bg-blue-600 text-white shadow-sm shadow-blue-600/25">
            <Building2 className="h-4 w-4" strokeWidth={2.2} />
          </span>
          <div className="leading-tight">
            <p className="text-[14.5px] font-semibold tracking-[-0.03em] text-slate-900 dark:text-white">Rentora</p>
            <p className="text-[9px] font-medium uppercase tracking-[0.14em] text-slate-400">Property operations</p>
          </div>
        </div>
        {onClose ? (
          <button type="button" onClick={onClose} aria-label="Close navigation" className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800">
            <X className="h-4 w-4" />
          </button>
        ) : null}
      </div>

      <div className="relative px-3 pb-1 pt-3">
        <button
          type="button"
          onClick={() => setOrgMenuOpen((current) => !current)}
          className="flex w-full items-center gap-2.5 rounded-xl border border-slate-200 bg-white px-2.5 py-2 text-left shadow-[0_1px_2px_rgba(15,23,42,0.03)] transition hover:border-slate-300 hover:bg-slate-50/50 dark:border-slate-700 dark:bg-slate-900 dark:hover:bg-slate-800/60"
        >
          <span className={`flex h-7 w-7 shrink-0 items-center justify-center overflow-hidden rounded-lg text-[10px] font-semibold text-white ${activeOrg.color}`}>
            {orgSettings.organization?.logo ? <img src={orgSettings.organization.logo} alt="" className="h-full w-full object-cover" /> : activeOrg.monogram}
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[12px] font-medium text-slate-800 dark:text-slate-100">{orgSettings.organization?.displayName?.trim() || activeOrg.name}</span>
            <span className="block text-[10px] text-slate-400">{role} · {activeOrg.plan}</span>
          </span>
          <ChevronsUpDown className="h-3.5 w-3.5 shrink-0 text-slate-400" />
        </button>
        {orgMenuOpen ? (
          <>
            <button type="button" aria-label="Close organization menu" className="fixed inset-0 z-30 cursor-default" onClick={() => setOrgMenuOpen(false)} />
            <div className="animate-rise absolute inset-x-3 top-[calc(100%-2px)] z-40 overflow-hidden rounded-xl border border-slate-200 bg-white p-1 shadow-xl shadow-slate-950/10 dark:border-slate-700 dark:bg-slate-900">
              <p className="px-2 pb-1 pt-1.5 text-[9.5px] font-semibold uppercase tracking-[0.1em] text-slate-400">Your organizations</p>
              {orgs.map((org) => (
                <button
                  key={org.id}
                  type="button"
                  onClick={() => { setOrgMenuOpen(false); onSwitchOrganization(org.id); }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-[9px] font-semibold text-white ${org.color}`}>{org.monogram}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[11.5px] font-medium text-slate-700 dark:text-slate-200">{org.name}</span>
                    <span className="block text-[9.5px] text-slate-400">{org.role}</span>
                  </span>
                  {activeOrg.id === org.id ? <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-blue-600 dark:text-blue-400" /> : null}
                </button>
              ))}
              <p className="mt-1 border-t border-slate-100 px-2 py-1.5 text-[9px] leading-relaxed text-slate-400 dark:border-slate-800">
                Roles are simulated from mock organization memberships.
              </p>
            </div>
          </>
        ) : null}
      </div>

      <nav className="flex-1 overflow-y-auto px-3 pb-3" aria-label="Application">
        {[
          { label: "", items: WORKSPACE_NAV.map((item) => ({ label: item.label, icon: LayoutDashboard, route: { page: "overview" } as Route, badge: undefined })) },
          { label: "Portfolio", items: PORTFOLIO_NAV.map((id) => ({ label: MODULES[id].label.replace(" & units", ""), icon: NAV_ICONS[id], route: { page: "module", module: id } as Route, badge: id === "leases" ? "8" : undefined })) },
          { label: "Operations", items: OPERATIONS_NAV.map((id) => ({ label: MODULES[id].label, icon: NAV_ICONS[id], route: { page: "module", module: id } as Route, badge: id === "maintenance" ? "12" : id === "documents" ? "3" : undefined })) },
          { label: "Finance", items: FINANCE_NAV.map((id) => ({ label: MODULES[id].label, icon: NAV_ICONS[id], route: { page: "module", module: id } as Route, badge: undefined })) },
          { label: "Automation", items: AUTOMATION_NAV.map((id) => ({ label: MODULES[id].label, icon: NAV_ICONS[id], route: { page: "module", module: id } as Route, badge: undefined })) },
        ].map((group, groupIndex) => (
          <div key={group.label || `main-${groupIndex}`} className={groupIndex > 0 ? "mt-4" : "mt-2"}>
            {group.label ? <p className="px-2 py-1.5 text-[9.5px] font-semibold uppercase tracking-[0.13em] text-slate-400 dark:text-slate-500">{group.label}</p> : null}
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const active = item.route.page === route.page && (item.route.page !== "module" || route.page !== "module" || item.route.module === route.module);
                return navButton(item.label, active, item.icon, () => onNavigate(item.route), item.badge);
              })}
            </div>
          </div>
        ))}

        <div className="mt-4 border-t border-slate-200/80 pt-3 dark:border-slate-800">
          <button
            type="button"
            onClick={() => onNavigate({ page: "settings", category: "organization" })}
            className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition ${
              route.page === "settings"
                ? "bg-slate-900 text-white shadow-sm dark:bg-white dark:text-slate-900"
                : "text-slate-600 hover:bg-slate-100/80 dark:text-slate-400 dark:hover:bg-slate-800"
            }`}
          >
            <Settings2 className={`h-4 w-4 ${route.page === "settings" ? "" : "text-slate-400"}`} />
            <span className="flex-1 text-[12.5px] font-medium">Settings</span>
            <ChevronRight className="h-3.5 w-3.5 opacity-60" />
          </button>
          <p className="mt-1.5 px-2.5 text-[9.5px] leading-relaxed text-slate-400">
            Organization, financial, operations & access configuration
          </p>
        </div>
      </nav>

      <div className="shrink-0 border-t border-slate-200/80 p-3 dark:border-slate-800">
        <div className="mb-2 flex items-start gap-2 rounded-lg bg-slate-50 px-2.5 py-2 dark:bg-slate-800/40">
          <Sparkles className="mt-0.5 h-3 w-3 shrink-0 text-violet-500" />
          <div className="min-w-0">
            <p className="text-[10.5px] font-medium text-slate-600 dark:text-slate-300">Settings Center prototype</p>
            <p className="mt-0.5 text-[9.5px] leading-relaxed text-slate-400">Mock data only. Nothing is sent to a server.</p>
          </div>
        </div>
        <button type="button" onClick={() => setHelpOpen(true)} className="flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left text-[11.5px] text-slate-500 transition hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800">
          <HelpCircle className="h-3.5 w-3.5 text-slate-400" /> Help & resources
        </button>
        <button
          type="button"
          onClick={() => onNavigate({ page: "settings", category: "personal" })}
          className="mt-1 flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-blue-600 text-[9.5px] font-semibold text-white">{currentUser.initials}</span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[11.5px] font-medium text-slate-700 dark:text-slate-200">{currentUser.name}</span>
            <span className="block truncate text-[9.5px] text-slate-400">{role}</span>
          </span>
          <ChevronDown className="h-3.5 w-3.5 text-slate-400" />
        </button>
      </div>

      <Modal
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        title="Settings Center help"
        description="A quick guide to this prototype workspace."
        icon={CircleHelp}
        footer={<Button type="button" variant="primary" onClick={() => setHelpOpen(false)}>Got it</Button>}
      >
        <div className="space-y-3 text-[12px] leading-relaxed text-slate-600 dark:text-slate-300">
          <p><strong className="text-slate-800 dark:text-slate-100">Search</strong> by setting name or keyword in the Settings sidebar, or press ⌘K / Ctrl+K anywhere.</p>
          <p><strong className="text-slate-800 dark:text-slate-100">Save behavior.</strong> Each category saves independently. Unsaved changes are protected when you navigate away.</p>
          <p><strong className="text-slate-800 dark:text-slate-100">Scoping.</strong> Organization settings belong to the active organization. Personal preferences follow your mock user.</p>
          <p><strong className="text-slate-800 dark:text-slate-100">Simulations.</strong> Email, SMS, integrations and signatures are mocked. No credentials are stored and no external service is contacted.</p>
          <p className="rounded-lg bg-slate-50 px-3 py-2 text-[11.5px] text-slate-500 dark:bg-slate-800/50 dark:text-slate-400">
            This is a frontend prototype. Access controls are simulated and do not represent production security enforcement.
          </p>
        </div>
      </Modal>
    </div>
  );
}

function CommandPalette({
  open,
  onClose,
  onSelect,
}: {
  open: boolean;
  onClose: () => void;
  onSelect: (category: CategoryId) => void;
}) {
  const [query, setQuery] = useState("");
  const fieldMatches = useMemo(() => {
    const value = query.trim().toLowerCase();
    if (!value) return SEARCH_INDEX.slice(0, 5);
    return SEARCH_INDEX.filter((entry) => `${entry.label} ${entry.keywords} ${CATEGORY_MAP[entry.category].label}`.toLowerCase().includes(value)).slice(0, 8);
  }, [query]);
  const categoryMatches = useMemo(() => {
    const value = query.trim().toLowerCase();
    if (!value) return SETTINGS_CATEGORIES;
    return SETTINGS_CATEGORIES.filter((entry) => `${entry.label} ${entry.description} ${entry.keywords.join(" ")}`.toLowerCase().includes(value));
  }, [query]);

  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  const first = fieldMatches[0];
  return (
    <Modal open={open} onClose={onClose} title="Search settings" description="Jump to a category or a specific setting. ⌘K / Ctrl+K" size="lg">
      <div className="space-y-3">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <Input
            autoFocus
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && first) {
                onSelect(first.category);
                onClose();
              }
            }}
            placeholder="Try “late fee”, “time zone”, “integration”…"
            className="h-10 pl-9"
          />
        </div>
        {query.trim() ? (
          <div className="max-h-[52vh] overflow-y-auto">
            {fieldMatches.length ? (
              <>
                <p className="px-1 pb-1 pt-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-400">Settings</p>
                {fieldMatches.map((entry) => (
                  <button
                    key={`${entry.category}-${entry.label}`}
                    type="button"
                    onClick={() => { onSelect(entry.category); onClose(); }}
                    className="flex w-full items-center justify-between gap-3 rounded-lg px-2.5 py-2 text-left transition hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-[12.5px] font-medium text-slate-800 dark:text-slate-100">{entry.label}</span>
                      <span className="block text-[10.5px] text-slate-400">{CATEGORY_MAP[entry.category].label}</span>
                    </span>
                    <ChevronRight className="h-3.5 w-3.5 text-slate-300" />
                  </button>
                ))}
              </>
            ) : null}
            {categoryMatches.length ? (
              <>
                <p className="mt-2 px-1 pb-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-400">Categories</p>
                {categoryMatches.map((entry) => (
                  <button
                    key={entry.id}
                    type="button"
                    onClick={() => { onSelect(entry.id); onClose(); }}
                    className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    <entry.icon className="h-4 w-4 text-slate-400" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[12.5px] font-medium text-slate-800 dark:text-slate-100">{entry.label}</span>
                      <span className="block truncate text-[10.5px] text-slate-400">{entry.description}</span>
                    </span>
                  </button>
                ))}
              </>
            ) : null}
            {!fieldMatches.length && !categoryMatches.length ? (
              <div className="py-8 text-center">
                <Search className="mx-auto h-5 w-5 text-slate-300" />
                <p className="mt-2 text-[12.5px] font-medium text-slate-700 dark:text-slate-200">No settings found</p>
                <p className="mt-0.5 text-[11px] text-slate-400">Try “rent”, “email” or “security”.</p>
              </div>
            ) : null}
          </div>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2">
            {categoryMatches.slice(0, 8).map((entry) => (
              <button
                key={entry.id}
                type="button"
                onClick={() => { onSelect(entry.id); onClose(); }}
                className="flex items-start gap-2.5 rounded-xl border border-slate-200 p-3 text-left transition hover:border-blue-300 hover:bg-blue-50/30 dark:border-slate-700 dark:hover:border-blue-500/40 dark:hover:bg-blue-500/5"
              >
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-slate-500 ring-1 ring-slate-200/70 dark:bg-slate-800 dark:text-slate-400 dark:ring-slate-700">
                  <entry.icon className="h-3.5 w-3.5" />
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-[12px] font-medium text-slate-800 dark:text-slate-100">{entry.label}</span>
                  <span className="mt-0.5 line-clamp-1 block text-[10.5px] text-slate-400">{entry.description}</span>
                </span>
              </button>
            ))}
          </div>
        )}
        <p className="flex items-center gap-1.5 border-t border-slate-100 pt-2.5 text-[10.5px] text-slate-400 dark:border-slate-800">
          <Sparkles className="h-3 w-3" /> Search covers every category, field and keyword in the Settings Center.
        </p>
      </div>
    </Modal>
  );
}

function Shell() {
  const { activeOrg, currentUser, role, notify, activity, toasts, dismissToast } = useSettings();
  const [route, setRoute] = useState<Route>(() => parseHash());
  const [mobileOpen, setMobileOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [menu, setMenu] = useState<"notifications" | "user" | null>(null);
  const [notificationUnread, setNotificationUnread] = useState(true);
  const [helpOpen, setHelpOpen] = useState(false);
  const [unsaved, setUnsaved] = useState<null | { kind: "route"; route: Route } | { kind: "org"; orgId: string }>(null);
  const dirtyRef = useRef<{ dirty: boolean; discard: () => void }>({ dirty: false, discard: () => undefined });
  const { setActiveOrg, orgs } = useSettings();

  const handleDirtyChange = useCallback((dirty: boolean, discard: () => void) => {
    dirtyRef.current = { dirty, discard };
  }, []);

  const applyRoute = useCallback((next: Route) => {
    setRoute(next);
    setMobileOpen(false);
    setPaletteOpen(false);
    setMenu(null);
    window.history.replaceState(null, "", routeHash(next));
    window.scrollTo({ top: 0 });
  }, []);

  const requestRoute = useCallback(
    (next: Route) => {
      const leavingSettings = route.page === "settings" && (next.page !== "settings" || next.category !== route.category);
      if (leavingSettings && dirtyRef.current.dirty) {
        setUnsaved({ kind: "route", route: next });
        return;
      }
      applyRoute(next);
    },
    [route, applyRoute],
  );

  const requestOrg = (orgId: string) => {
    if (orgId === activeOrg.id) return;
    if (route.page === "settings" && dirtyRef.current.dirty) {
      setUnsaved({ kind: "org", orgId });
      return;
    }
    setActiveOrg(orgId);
    setMobileOpen(false);
    const target = orgs.find((org) => org.id === orgId);
    notify(`Switched to ${target?.shortName ?? "organization"}`, "info", "Organization settings are scoped to this workspace.");
  };

  useEffect(() => {
    window.history.replaceState(null, "", routeHash(route));
  }, [route]);

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPaletteOpen(true);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  const currentCategory = route.page === "settings" ? CATEGORY_MAP[route.category] : null;
  const breadcrumb =
    route.page === "overview" ? "Overview" : route.page === "module" ? MODULES[route.module].label : currentCategory?.shortLabel ?? "Settings";

  const settingsSelection = (category: CategoryId) => requestRoute({ page: "settings", category });

  const notifications = useMemo(
    () => [
      { title: "Rent payment received", description: "Jordan Rivera paid $1,850.00 for Unit 4B.", icon: Wallet, at: "12 min ago", tone: "text-emerald-600 dark:text-emerald-400" },
      { title: "New maintenance request", description: "Priority 1 · no heat reported at Cedar Heights.", icon: Wrench, at: "48 min ago", tone: "text-amber-600 dark:text-amber-400" },
      { title: "8 lease renewals due", description: "Renewal reminders were simulated for property managers.", icon: FileSignature, at: "2 hrs ago", tone: "text-blue-600 dark:text-blue-400" },
      ...activity.slice(0, 2).map((event) => ({ title: event.action, description: event.detail ?? "", icon: Activity, at: relativeTime(event.at), tone: "text-slate-500 dark:text-slate-400" })),
    ],
    [activity],
  );

  return (
    <div className="min-h-screen bg-[#f6f7f9] dark:bg-[#080d17]">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[248px] border-r border-slate-200/80 bg-white dark:border-slate-800 dark:bg-slate-900 lg:block">
        <SidebarContent route={route} onNavigate={requestRoute} onSwitchOrganization={requestOrg} />
      </aside>

      {mobileOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 animate-fade bg-slate-950/40 backdrop-blur-[2px]" onClick={() => setMobileOpen(false)} />
          <div className="animate-rise absolute inset-y-0 left-0 w-[280px] border-r border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900">
            <SidebarContent route={route} onNavigate={requestRoute} onClose={() => setMobileOpen(false)} onSwitchOrganization={requestOrg} />
          </div>
        </div>
      ) : null}

      <div className="lg:pl-[248px]">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-slate-200/80 bg-white/85 px-4 backdrop-blur-md sm:px-6 lg:px-8 dark:border-slate-800 dark:bg-slate-900/85">
          <div className="flex min-w-0 items-center gap-2">
            <button type="button" onClick={() => setMobileOpen(true)} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 lg:hidden" aria-label="Open navigation">
              <Menu className="h-5 w-5" />
            </button>
            <div className="hidden items-center gap-2 sm:flex">
              <button type="button" onClick={() => requestRoute({ page: "overview" })} className="text-[12px] text-slate-400 transition hover:text-slate-700 dark:hover:text-slate-200">Workspace</button>
              <ChevronRight className="h-3 w-3 text-slate-300 dark:text-slate-600" />
              <span className="text-[12px] font-medium text-slate-700 dark:text-slate-200">{route.page === "settings" ? "Settings" : breadcrumb}</span>
              {route.page === "settings" ? (
                <>
                  <ChevronRight className="h-3 w-3 text-slate-300 dark:text-slate-600" />
                  <span className="text-[12px] text-slate-400">{breadcrumb}</span>
                </>
              ) : null}
            </div>
            <span className="text-[13.5px] font-semibold text-slate-800 dark:text-slate-100 sm:hidden">{route.page === "settings" ? "Settings" : breadcrumb}</span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => setPaletteOpen(true)}
              className="hidden h-8.5 w-[220px] items-center gap-2 rounded-lg border border-slate-200 bg-slate-50/60 px-2.5 text-left text-[11.5px] text-slate-400 transition hover:border-slate-300 hover:bg-white md:flex dark:border-slate-700 dark:bg-slate-800/40 dark:hover:bg-slate-800"
            >
              <Search className="h-3.5 w-3.5" />
              <span className="flex-1">Search settings…</span>
              <kbd className="rounded border border-slate-200 bg-white px-1 text-[9px] font-medium dark:border-slate-600 dark:bg-slate-900">⌘K</kbd>
            </button>
            <button type="button" onClick={() => setPaletteOpen(true)} className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 md:hidden dark:text-slate-400 dark:hover:bg-slate-800" aria-label="Search settings">
              <Search className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => setHelpOpen(true)}
              className="hidden rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 sm:block dark:text-slate-400 dark:hover:bg-slate-800"
              aria-label="Help"
            >
              <CircleHelp className="h-4 w-4" />
            </button>
            <div className="relative">
              <button
                type="button"
                onClick={() => setMenu(menu === "notifications" ? null : "notifications")}
                className="relative rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
                aria-label="Notifications"
              >
                <Bell className="h-4 w-4" />
                {notificationUnread ? <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-blue-600 ring-2 ring-white dark:ring-slate-900" /> : null}
              </button>
              {menu === "notifications" ? (
                <>
                  <button type="button" aria-label="Close notifications" className="fixed inset-0 z-30 cursor-default" onClick={() => setMenu(null)} />
                  <div className="animate-rise absolute right-0 top-11 z-40 w-[340px] max-w-[calc(100vw-2rem)] overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl shadow-slate-950/10 dark:border-slate-700 dark:bg-slate-900">
                    <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3 dark:border-slate-800">
                      <p className="text-[12.5px] font-semibold text-slate-800 dark:text-slate-100">Notifications</p>
                      <button type="button" onClick={() => setNotificationUnread(false)} className="text-[10.5px] font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400">Mark all read</button>
                    </div>
                    <div className="max-h-[340px] overflow-y-auto">
                      {notifications.map((item, index) => (
                        <div key={`${item.title}-${index}`} className="flex items-start gap-2.5 border-b border-slate-50 px-4 py-3 last:border-0 dark:border-slate-800/60">
                          <span className={`mt-0.5 ${item.tone}`}><item.icon className="h-4 w-4" /></span>
                          <div className="min-w-0 flex-1">
                            <p className="text-[11.5px] font-medium text-slate-800 dark:text-slate-100">{item.title}</p>
                            <p className="mt-0.5 text-[10.5px] leading-relaxed text-slate-400">{item.description}</p>
                            <p className="mt-0.5 text-[9.5px] text-slate-300 dark:text-slate-500">{item.at}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <button
                      type="button"
                      onClick={() => { setMenu(null); settingsSelection("notifications"); }}
                      className="flex w-full items-center justify-center gap-1.5 border-t border-slate-100 py-2.5 text-[11.5px] font-semibold text-blue-600 hover:bg-slate-50 dark:border-slate-800 dark:text-blue-400 dark:hover:bg-slate-800/50"
                    >
                      Review notification settings <ArrowRight className="h-3 w-3" />
                    </button>
                  </div>
                </>
              ) : null}
            </div>
            <div className="mx-1 hidden h-5 w-px bg-slate-200 sm:block dark:bg-slate-700" />
            <div className="relative">
              <button type="button" onClick={() => setMenu(menu === "user" ? null : "user")} className="flex items-center gap-2 rounded-lg p-1 pr-1.5 transition hover:bg-slate-100 dark:hover:bg-slate-800">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-blue-600 text-[10px] font-semibold text-white">{currentUser.initials}</span>
                <ChevronDown className="hidden h-3 w-3 text-slate-400 sm:block" />
              </button>
              {menu === "user" ? (
                <>
                  <button type="button" aria-label="Close user menu" className="fixed inset-0 z-30 cursor-default" onClick={() => setMenu(null)} />
                  <div className="animate-rise absolute right-0 top-11 z-40 w-[270px] overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl shadow-slate-950/10 dark:border-slate-700 dark:bg-slate-900">
                    <div className="border-b border-slate-100 px-4 py-3 dark:border-slate-800">
                      <p className="text-[12.5px] font-semibold text-slate-800 dark:text-slate-100">{currentUser.name}</p>
                      <p className="truncate text-[10.5px] text-slate-400">{currentUser.email}</p>
                      <div className="mt-2 flex flex-wrap items-center gap-1.5">
                        <Badge tone="blue">{role}</Badge>
                        <Badge tone="gray">{activeOrg.plan}</Badge>
                      </div>
                    </div>
                    <div className="p-1">
                      <button type="button" onClick={() => { setMenu(null); settingsSelection("personal"); }} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[11.5px] text-slate-600 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800">
                        <Settings2 className="h-3.5 w-3.5 text-slate-400" /> Personal preferences
                      </button>
                      <button type="button" onClick={() => { setMenu(null); settingsSelection("security"); }} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[11.5px] text-slate-600 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800">
                        <ShieldCheck className="h-3.5 w-3.5 text-slate-400" /> Account & access
                      </button>
                      <button type="button" onClick={() => { setMenu(null); settingsSelection("organization"); }} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[11.5px] text-slate-600 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-slate-800">
                        <Building2 className="h-3.5 w-3.5 text-slate-400" /> Organization settings
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => { setMenu(null); notify("Sign-out is disabled in this prototype", "info", "There is no production authentication in this demo."); }}
                      className="flex w-full items-center gap-2 border-t border-slate-100 px-3.5 py-2.5 text-left text-[11.5px] text-slate-400 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800"
                    >
                      <LogOut className="h-3.5 w-3.5" /> Sign out (prototype)
                    </button>
                  </div>
                </>
              ) : null}
            </div>
          </div>
        </header>

        <div>
          {route.page === "settings" ? (
            <SettingsPage
              key={activeOrg.id}
              category={route.category}
              onCategoryChange={(category) => applyRoute({ page: "settings", category })}
              onDirtyChange={handleDirtyChange}
            />
          ) : route.page === "overview" ? (
            <OverviewPage onOpenSettings={settingsSelection} onOpenModule={(module) => requestRoute({ page: "module", module })} />
          ) : (
            <ModulePreview moduleId={route.module} onOpenSettings={settingsSelection} />
          )}
        </div>
      </div>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} onSelect={(category) => requestRoute({ page: "settings", category })} />

      <Modal
        open={unsaved !== null}
        onClose={() => setUnsaved(null)}
        title="Leave with unsaved changes?"
        description="Your changes in Settings have not been saved."
        icon={CircleHelp}
        size="sm"
        footer={
          <>
            <Button type="button" variant="secondary" onClick={() => setUnsaved(null)}>Keep editing</Button>
            <Button
              type="button"
              variant="danger"
              onClick={() => {
                const action = unsaved;
                setUnsaved(null);
                dirtyRef.current.discard();
                if (action?.kind === "route") applyRoute(action.route);
                if (action?.kind === "org") {
                  setActiveOrg(action.orgId);
                  setMobileOpen(false);
                  const target = orgs.find((org) => org.id === action.orgId);
                  notify(`Switched to ${target?.shortName ?? "organization"}`, "info", "Previous unsaved edits were discarded.");
                }
              }}
            >
              Discard & continue
            </Button>
          </>
        }
      >
        <p className="text-[12.5px] leading-relaxed text-slate-600 dark:text-slate-300">
          You have edits that have not been saved in <span className="font-medium">{currentCategory?.label ?? "Settings"}</span>. Continue editing, or discard them and continue to the selected destination.
        </p>
      </Modal>

      <Modal
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        title="Settings Center help"
        description="A quick guide to configuration in this prototype."
        icon={CircleHelp}
        footer={<Button type="button" variant="primary" onClick={() => setHelpOpen(false)}>Got it</Button>}
      >
        <div className="space-y-3 text-[12px] leading-relaxed text-slate-600 dark:text-slate-300">
          <p><strong className="text-slate-800 dark:text-slate-100">Find a setting.</strong> Search by name or keyword inside Settings, or press ⌘K / Ctrl+K anywhere to jump to a category.</p>
          <p><strong className="text-slate-800 dark:text-slate-100">Save with confidence.</strong> Each category saves on its own. Unsaved edits are detected when you leave a category, switch organizations or use app navigation.</p>
          <p><strong className="text-slate-800 dark:text-slate-100">Scoped correctly.</strong> Organization settings belong to the active organization. Personal preferences belong to your mock user.</p>
          <p><strong className="text-slate-800 dark:text-slate-100">Simulation only.</strong> Integrations, email, SMS and e-signatures are mocked. No credentials are stored and no external message is sent.</p>
          <p className="rounded-lg bg-slate-50 px-3 py-2 text-[11.5px] text-slate-500 dark:bg-slate-800/50 dark:text-slate-400">
            Role restrictions are simulated in the UI and are not production security enforcement.
          </p>
        </div>
      </Modal>

      <div className="sr-only" aria-live="polite">{route.page}</div>
      <Toasts toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <Shell />
    </SettingsProvider>
  );
}
